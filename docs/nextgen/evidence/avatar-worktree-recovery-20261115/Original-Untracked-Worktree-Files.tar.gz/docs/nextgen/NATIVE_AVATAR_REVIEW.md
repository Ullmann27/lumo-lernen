# Independent native LUMO integration review

This review checks the actual Godot learning route and imported character. It is
separate from the producer's own tests. The pattern domain implementation is
commit `aee6a418ea5b56b9d2696b825ac8ec477eb5bdc0`; its deterministic verification is
recorded in `PATTERN_NATIVE_V1.md` and `evidence/pattern-native-v1/RESULT.json`.

## Ownership and reproducibility

The reviewer owns only the two scripts under `scripts/tests/nextgen_*_review.gd`,
this document and its evidence. Production files under `scripts/lumo_next`,
`assets/lumo_next`, the existing world and the routed scene belong to Chat 3.
They were copied read-only, as a 29-file, 14,334,171-byte snapshot, into the
reviewer's own worktree for a real import. The snapshot manifest records source
paths, Git origin, each file's SHA-256 and whether the producer had committed it.
Those staged production files are not part of the QA commit.

Godot: `4.6.3.stable.official.7d41c59c4`. Each run has its own XDG data/config/cache
directories. Import logs and application state must not be shared with a real
child profile. The renderer uses the existing authenticated Xorg/software-Mesa
runner and its own display; it is not a physical Android performance test.

## Two independent gates

`scripts/tests/nextgen_avatar_contract_review.gd` loads the actual producer GLB
through Godot's importer. It compares every original bone and parent relation
against the original facial GLB; two additional ear bones are allowed. It checks
all nine original clips, fourteen learning clips, the mouth/expression morphs,
real registered target nodes, actual head orientation and the wrist-to-paw ray.
Neither pointing angle nor mouth support is accepted solely from a diagnostic
flag. Mouth checks read the imported meshes' blend-shape weights.

The same gate exercises explicit playback fixtures, measured/frozen/invalid
amplitude, timed cue boundaries, late events, owner/revision/cancel-epoch
rejection, shared cancellation and the distinction between removing the active
target and removing an unrelated object. A generated two-second PCM tone also
runs through a real `AudioStreamPlayer`, checking its playback clock, seek,
output-bus mute, pause and stop. The PCM provider measures the generated samples
at the actual media position. This is an engine audio-path test with a Dummy
mixer, not a recording of Android TTS or proof of physical speaker output.

`scripts/tests/nextgen_learning_route_review.gd` loads
`scenes/learning/learning_world.tscn` itself and requires its real Chat-3 adapter.
Its bounded native matrix contains `bridge_ten`, `addition`, `subtract_ten`,
`equal_groups`, `equal_sharing`, `bridge_hundred`, `fraction_parts`, `syllables`,
`plant_parts`, `english_objects`, `pattern` and the integrated `task_card`. It checks that each tested route
really uses the imported character and registers its actual lesson objects.

The route gate projects the full mesh AABB corners and registry anchors between
the real header and footer. It checks 48-dp button bounds at 360×800, 412×915,
900×1100, 1280×720 and 2400×1080, using density 2.625 in the last case. A separate
412×915 scenario enlarges the actual native labels to 150%. Layout changes must
preserve placed objects, candidates, hints and attempt counts. These checks do
not prove Android system-font propagation, polygon-level occlusion or every
possible animation silhouette.

The 8+5 and Ba-na-ne checks inject actual touch events into the routed buttons.
They verify object identity and deterministic learning state after those child
actions. The pattern gate requires visible registered items, a hint before an
answer, a separate candidate and confirmation, and pending-answer cancellation
through the public scoped Stop and application lifecycle.

The final union gate also requires the actual segmented syllable path: one
native request for Banane, followed by Ba, na and ne; each segment must bind its
own active audio turn. The mouth remains closed during preparation and the
point target must match the currently audible registered syllable card. Duplicate
completion and completion after the common Stop must not start another segment.

Speech in the route gate crosses the existing `speakLearning` /
`getLearningSpeechStatus` / `stopLearningSpeech` method boundary and actual JSON
decoding. Its host object is explicitly a fixture; it does not invoke Android's
local voice. This boundary is needed because a valid Integer ID in a hand-built
Dictionary can become a Float after real JSON parsing.

## First snapshot findings

The initial snapshot imported without `ERROR` or parse-error lines. All original
65 bones and their hierarchy survived; the export adds two ear bones. Its 23
clips and expected mouth/expression morphs were imported. The independent
head/paw geometry, real Godot player path, ordinary Stop, pause, focused input,
old-turn rejection and strict outer ownership checks passed.

The initial actor gate had 282 checks with four failed assertions. Three
assertions describe one defect: removing the current registered target clears
gaze/pointing but leaves its audio turn and mouth active, emits no corresponding
transport stop, and accepts its late sample. Removing an unrelated target
correctly leaves the current explanation alone. The fourth failure is the real
JSON numeric-ID boundary described below.

The first eleven-kind route run exercised 3,796 checks. All completed geometry,
button, text and resize-state checks passed for the ten existing native kinds.
The not-yet-implemented pattern scene had no controls/registered items and
triggered a null `main_button` assignment in the inherited refresh path. This
was a pending producer integration, not evidence that the pattern domain was
invalid.

The route exposed two further state boundaries, with one additional transition
isolated in a focused rerun:

1. `apply_playback_status` compares `str(status.id)` with the saved string native
   ID. `JSON.parse_string('{"id":4711}')` yields `4711.0`, whose string differs
   from `"4711"`. The valid real status is rejected, leaving the scene mouth
   closed. IDs require strict validation and compatible canonicalization, not
   truncation of arbitrary fractional values.
2. Binding a new owner in reduced-motion mode leaves `state=interrupt`,
   `clip=interrupt`, `_interrupt_left=0.0`. The observed path interrupts on
   registry lesson change, then starts a new turn that clears the interrupt
   timer without transitioning to listening.
3. A late old-owner native sample changes the new owner's state to `explaining`
   before its native ID is rejected. The scene calls `set_teacher_speaking`
   before checking whether `apply_playback_status` accepted the sample. Rejected
   packets must not mutate the new owner's gesture.

These findings, exact source hashes, logs and minimal reproductions were sent
to Chat 3 in its explicitly authorized parent-folder inbox. The reviewer did
not modify the producer's implementation.

## Commands

Run the import before either gate:

```sh
godot --headless --editor --import --path . --quit
godot --headless --path . --script scripts/tests/nextgen_avatar_contract_review.gd
godot --headless --path . --script scripts/tests/nextgen_learning_route_review.gd
```

Use a focused route selection when repeating a concrete failing boundary:

```sh
godot --headless --path . --script scripts/tests/nextgen_learning_route_review.gd -- --review-kind=bridge_ten
```

The existing local renderer can produce actual routed screenshots. Select an
unused display and a new output directory for each run:

```sh
python tools/run_local_renderer.py --display 187 --output /tmp/lumo-review-render --project . --timeout 180 -- --script scripts/tests/nextgen_learning_route_review.gd -- --review-kind=bridge_ten,syllables,pattern --review-capture-dir=/tmp/lumo-review-captures
```

Do not describe these reference scenes as complete Flutter coverage. All
Flutter task routes, physical Android lifecycle/audio, phoneme timing and device
frame rate require their own measured evidence. The tests report those limits
explicitly and fail when a requested producer resource or activity is absent.
