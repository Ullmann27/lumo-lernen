# Originalbelege zu LUMO 0.13.15 (2027)

**Diese Sammlung belegt keinen bestandenen Android-Lerndurchlauf und keine vollständige Modernisierung.** Sie bewahrt die einzelnen Validierungs-, Build- und QA-Versuche getrennt. `fullModernizationComplete` bleibt `false`; ursprüngliche Androidtour, zusätzliche Referenzszenen und gemeinsames Performancegate sind noch nicht durch einen bestandenen Lauf belegt.

Die Quelldateien wurden unverändert kopiert. Für diese Sammlung wurden keine neuen Tests ausgeführt, keine APK heruntergeladen oder kopiert und keine Git- oder Produktdatei geändert. Vorhandene lokale Auswertungen sind zusätzlich zu den Originalarchiven erhalten und im Manifest als Inhaltskopien ausgewiesen.

## Chronologie der Originalbelege

Alle Zeiten sind UTC am 15. November 2026. Angegebene Artefaktzeiten bezeichnen die Veröffentlichung des jeweiligen Belegarchivs, nicht die Dauer seiner Tests.

| Zeitpunkt / Versuch | Originalbelege in dieser Sammlung | Tatsächlich belegtes Ergebnis |
| --- | --- | --- |
| 20:58:51, Validierungsartefakt; Quelllauf `43759362796` | `local/ci-third-validation/` | Flutter **2.870 bestanden, 0 fehlgeschlagen, 202 übersprungen**; **55 Host-Vertragsprüfungen bestanden**. Elf native Prüfläufe melden zusammen 55.509 Prüfaussagen. Diese können sich überschneiden und sind keine 55.509 unabhängigen Tests. Analyse: 0 Fehler, 4 Warnungen, 275 Hinweise. 18 geschützte Dateien stimmen mit dem Manifest überein. |
| 21:00:35, erster Build-Versuch | `local/ci-third-build-attempt1/` | Abbruch beim Modelldownload: `curl: (56) Recv failure: Connection reset by peer`. Kein APK-Abschluss dieses Versuchs. |
| 21:01:01–21:11:03, Build-Wiederholung; Job `132956370454` | `local/ci-third-build-attempt2/`; Original-Jobmetadaten unter `github/qa-first-43764149440/extracted/origin/` | Build erfolgreich; getrennte Prüfreports für arm64 und x86_64. Paket, Signatur, eingebettete Quellen und 16-KiB-Ausrichtung geprüft. Diese Paketprüfung belegt keine App-Laufzeit oder hörbare Wiedergabe. |
| 21:15:16–21:15:19, ursprüngliche Androidprobe | `local/ci-third-android-attempt2/` | `FAIL` vor Installation bei der Zertifikatsauswertung. Die Originalausgabe verwendet `V2 Signer` und enthält den erwarteten SHA-256. Der frühere Parser akzeptierte dieses Ausgabeformat nicht. Keine durchgespielte App-Tour. |
| 21:31:31–21:34:53, erster zusätzlicher QA-Lauf `43764149440`; Job `132965369358` | `github/qa-first-43764149440/` | Beide Prüfersuiten laufen mit **33 + 21 bestandenen Prüfungen**. Der eigentliche Replay-Aufruf scheitert bereits an `/usr/bin/sh: 1: set: Illegal option -o pipefail` (Exit 2). Die Androidtour und die beiden Referenzszenen werden nicht ausgeführt. |
| 21:47:59–21:48:31, QA-Wiederholung `43765321689`; Job `132968997041` | `local/ci-reference-path-failure/` | Das unveränderte x86-APK wird frisch installiert: `Performing Streamed Install / Success`. Danach `FAIL` bei `Expected exactly one installed base APK`, noch vor Onboarding. Die konkrete `pm path`-Ausgabe wurde im Original nicht gespeichert; eine bestimmte Tilde im tatsächlichen Pfad ist damit nicht nachgewiesen. |

Die Quellpipeline `43759362796` endet insgesamt mit `failure`; ihre erfolgreiche Validierung und ihr erfolgreicher Build sind eigenständige Teilbefunde. Auch das erfolgreiche Rooten oder Installieren des Emulators ist kein bestandenes Lern- oder Performancegate.

## Exakte Produkt- und QA-Identität

Produktquelle: Flutter `72a7914059d10152604b877cfeaf8bd1d2155810`, Godot `ec702dad29def7ea3db6f62f2ead7b8ca6bca2bb`, Version `0.13.15` / `2027`.

| APK-Prüfreport | Tatsächliche APK-Bytes laut Report | APK-SHA-256 |
| --- | ---: | --- |
| `local/ci-third-build-attempt2/VERIFY-arm64.json` | 535014830 | `20722fad9ca114c0182b928d132fdc674aa7a9b76f92eea20f3135a605e63be5` |
| `local/ci-third-build-attempt2/VERIFY-x86.json` | 538177759 | `9f3166a4e071f3f0e4217b1aa7e2e100bbf9ee2cfeb41bdbc47d33827e768fc9` |

Diese Größen stammen aus den jeweiligen vorhandenen Paketprüfreports. Die APK-Dateien selbst sind nicht Bestandteil dieser Sammlung. Beleg-ZIP-Größen sind separat im Manifest erfasst.

QA-Quellen: erster Replay `493f26b2b7850e0a4465e25e9141da93d45ae784`, zweiter Replay `b24978686c032ee7d3601058d094f311c6d1d95f`. Beide verwenden dasselbe bestehende APK; ihre QA-Commits sind keine neuen APK-Produktquellen.

## Lokale Prüfer- und Wrapperbelege

`local/reference-qa-checkers.log` dokumentiert **54 bestandene Prüfertests**. `local/reference-qa-wrapper-regression.json` dokumentiert **drei Wrapperfälle mit Stub-Python-Prozessen**: ursprünglicher Fehler verhindert den Zusatzlauf, Zusatzfehler wird weitergegeben, beide simulierten Erfolge beenden den Wrapper erfolgreich. Diese Belege haben keine eigenen Ausführungszeitstempel und werden nicht zu den CI-Testergebnissen addiert. Sie enthalten keine Android- oder App-Ausführung.

Die spätere Pfadkorrektur `5d8375afa94ff4c3af21f7ad5ede52db974e52c8` ist getrennt in `local/ci-reference-path-failure/failure-review.json` beschrieben; `path-reader-regressions.log` belegt **13 gezielte Parser-/Identitätsprüfungen**. Ein historisch aufgezeichneter `~~`-Pfad dient dabei ausschließlich als Parserregression. Er belegt weder den konkreten Pfad dieses Fehlversuchs noch einen neuen Android-Lerndurchlauf.

## Originaltreue und Dateiverzeichnis

- `MANIFEST.json`: jede Datei mit Bytes, SHA-256 und Herkunft; Originalarchivmitglieder sind zusätzlich ihrem ZIP zugeordnet. Manifest und Prüfsummenliste sind zur Vermeidung zirkulärer Hashes aus dieser Liste ausgenommen.
- `SHA256SUMS`: Prüfsummen aller Dateien einschließlich Manifest; nur diese Prüfsummenliste selbst ist ausgenommen.
- `SOURCE-COPY-VERIFICATION.json`: ursprünglicher absoluter Dateipfad und bytegleiche Kopie; Originaldateien bleiben erhalten.
- `chronology.json`: maschinenlesbare getrennte Ergebnisse und ausdrückliche Grenzen der Laufzeitbelege.
- `github/qa-first-43764149440/retrieval-verification.json`: GitHub-Herkunft und Downloadprüfung. Das 7.731-Byte-ZIP hat SHA-256 `8205802b6722b5c55b37057f5407b5b64589cbea8d4f2c106feb13ad645c7563`.
- `github/qa-first-43764149440/job-132965369358.log`: vollständiger vom Connector dekodierter Jobtext, 338.650 UTF-8-Bytes und 2.913 Zeilen, einschließlich BOM und Shellfehler. Keine Behauptung über einen separat ermittelten Hash unverarbeiteter HTTP-Logbytes.

Spätere Laufzeitergebnisse müssen mit eigener Run-, Job-, QA- und APK-Identität ergänzt werden. Diese Sammlung ersetzt weder die ausstehende vollständige Androidtour noch Referenz-, Performance- oder physische Gerätebelege.
