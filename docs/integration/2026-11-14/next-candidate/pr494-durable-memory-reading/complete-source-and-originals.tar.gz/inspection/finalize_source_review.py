#!/usr/bin/env python3
"""Read-only source/evidence binding; does not import or execute product/tests."""
from __future__ import annotations
import collections
import difflib
import hashlib
import json
from pathlib import Path
import re
import tarfile
import tempfile
import zlib

ROOT = Path('/tmp/host-pr494-28462-integration-b3c2bd-20261114')
INV = Path('/tmp/host-b3c2bd-next-authorities-flutter-evidence-20261114/originals/artifact-members/source/host/source-inventory-before.json')
HOST = 'b3c2bd008b4f1b07b4bfcb19f61839c4486b77e1'
TREE = '4ebddcbe209191714dc64cba2815e5a67b64513b'
PRODUCER = '28462a7547048b75fa114e6f5832248e54c94faa'
PRODUCER_TREE = '21cc39c37c96c8d76d46434b42b172e88ffb745e'
PARENT = 'b7210db3f53361987fd33592de438fd7984d991a'
NATIVE = 'f9d9772bb932d7ee8702eeb5bca6d98c286f3b98'
NATIVE_TREE = '4036a20ab80de78bcdf0d074b585be88c2946492'

def ident(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}

def obj(relative):
    return json.loads((ROOT / relative).read_bytes())

def tree_digest(entries):
    ordered = sorted(entries, key=lambda x: (x['path'] + ('/' if x['type'] == 'tree' else '\0')).encode())
    raw = b''.join(str(int(x['mode'])).encode() + b' ' + x['path'].encode() + b'\0' + bytes.fromhex(x['sha']) for x in ordered)
    return hashlib.sha1(b'tree ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()

def validate_tree(document):
    assert document['truncated'] is False
    expected = {'': document['sha']}
    expected.update({e['path']: e['sha'] for e in document['tree'] if e['type'] == 'tree'})
    grouped = collections.defaultdict(list)
    for entry in document['tree']:
        parent, _, name = entry['path'].rpartition('/')
        grouped[parent].append(dict(entry, path=name))
    for path, entries in grouped.items():
        assert tree_digest(entries) == expected[path], path
    return len(grouped)

def apply_original_hunks(before, patch):
    assert not before or before.endswith('\n')
    old = before.splitlines()
    output = []
    cursor = 0
    chunks = re.split(r'(?m)(?=^@@ )', patch)
    count = 0
    for chunk in chunks:
        if not chunk:
            continue
        lines = chunk.splitlines()
        header = re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*', lines[0])
        assert header, lines[0]
        start, old_count, new_start, new_count = [int(v) if v is not None else 1 for v in header.groups()]
        index = start - 1 if old_count else start
        assert index >= cursor
        output.extend(old[cursor:index])
        cursor = index
        used = made = 0
        for line in lines[1:]:
            assert line and line[0] in ' +-'
            sign, body = line[0], line[1:]
            if sign in ' -':
                assert cursor < len(old) and old[cursor] == body, (cursor, line)
                cursor += 1
                used += 1
            if sign in ' +':
                output.append(body)
                made += 1
        assert used == old_count and made == new_count, (used, old_count, made, new_count)
        count += 1
    output.extend(old[cursor:])
    return '\n'.join(output) + '\n', count

def block(text, start, end):
    return text[text.index(start):text.index(end)]

def write_new(path, data):
    p = ROOT / path
    p.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(data, str):
        data = data.encode('utf-8')
    with p.open('xb') as handle:
        handle.write(data)
    assert p.read_bytes() == data
    return dict(path=path, **ident(data))

def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()

inventory = json.loads(INV.read_bytes())
assert inventory['head'] == HOST and inventory['tree'] == TREE and len(inventory['tracked']) == 4708
current = {item['path']: item for item in inventory['tracked']}
assert len(current) == 4708
commit = obj('originals/api/commit-original.json')
assert commit['sha'] == PRODUCER and commit['commit']['tree']['sha'] == PRODUCER_TREE
assert [x['sha'] for x in commit['parents']] == [PARENT]
root_tree = obj('originals/api/producer-root-tree.json')
lib_tree = obj('originals/api/producer-lib-tree.json')
test_tree = obj('originals/api/producer-test-tree.json')
assert root_tree['sha'] == PRODUCER_TREE
tree_counts = {name: validate_tree(tree) for name, tree in [('root',root_tree),('lib',lib_tree),('test',test_tree)]}
producer_entries = {x['path']: x for x in root_tree['tree'] if x['type'] == 'blob'}
producer_entries.update({'lib/' + x['path']: x for x in lib_tree['tree'] if x['type'] == 'blob'})
producer_entries.update({'test/' + x['path']: x for x in test_tree['tree'] if x['type'] == 'blob'})
assert next(x['sha'] for x in root_tree['tree'] if x['path']=='lib') == lib_tree['sha']
assert next(x['sha'] for x in root_tree['tree'] if x['path']=='test') == test_tree['sha']

mapping = []
diffs = []
hunks = []
for entry in commit['files']:
    path = entry['filename']
    final = (ROOT/'final-source'/path).read_bytes()
    assert ident(final)['git_blob'] == entry['sha'] == producer_entries[path]['sha']
    assert producer_entries[path]['mode'] == '100644'
    if entry['status'] == 'modified':
        before = (ROOT/'before-source'/path).read_bytes()
        record = current[path]
        assert ident(before)['git_blob'] == record['git_blob'] == record['actual_blob']
        assert ident(before)['sha256'] == record['sha256'] and len(before) == record['bytes']
        preimage = dict(mode=record['mode'], **ident(before))
    else:
        assert entry['status'] == 'added' and path not in current
        before = b''
        preimage = None
    reconstructed, count = apply_original_hunks(before.decode(), entry['patch'])
    assert reconstructed.encode() == final, path
    hunks.append({'path':path,'original_hunks':count,'exact_reconstruction':True})
    mapping.append({'path':path,'mode':'100644','before':preimage,'after':ident(final),
                    'producer_sha':PRODUCER,'producer_tree':PRODUCER_TREE,
                    'origin':'exact published producer blob; no local merge or edit'})
    diffs.append(''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),final.decode().splitlines(keepends=True),
                                           fromfile='a/'+path if before else '/dev/null',tofile='b/'+path)))
assert len(mapping)==4
assert sorted(x.relative_to(ROOT/'final-source').as_posix() for x in (ROOT/'final-source').rglob('*') if x.is_file()) == sorted(x['path'] for x in mapping)

dependencies = []
for p in sorted((ROOT/'reference-source').rglob('*')):
    if not p.is_file():
        continue
    path = p.relative_to(ROOT/'reference-source').as_posix()
    data = p.read_bytes()
    identity = ident(data)
    assert identity['git_blob'] == current[path]['git_blob'] and identity['sha256'] == current[path]['sha256']
    dependencies.append({'path':path,**identity,'mode':current[path]['mode'],
                         'producer_blob':producer_entries[path]['sha'],
                         'producer_identical':identity['git_blob']==producer_entries[path]['sha']})
assert len(dependencies)==9
assert all(x['producer_identical'] for x in dependencies if x['path'].startswith('lib/'))

def lock_package(text, name):
    match = re.search(r'(?ms)^  '+re.escape(name)+r':\n.*?(?=^  \S|\Z)',text)
    assert match, name
    return match.group(0)
package_proof=[]
for name in ('shared_preferences','shared_preferences_platform_interface','flutter_test'):
    current_text=(ROOT/'reference-source/pubspec.lock').read_text()
    producer_text=(ROOT/'originals/producer-dependencies/pubspec.lock').read_text()
    left=lock_package(current_text,name)
    right=lock_package(producer_text,name)
    assert left==right
    package_proof.append({'name':name,'identical_locked_block':True,'block':left})
assert '  shared_preferences_platform_interface: ^2.4.2\n' in (ROOT/'reference-source/pubspec.yaml').read_text()
assert '  shared_preferences: ^2.3.3\n' in (ROOT/'reference-source/pubspec.yaml').read_text()

old_memory=(ROOT/'before-source/lib/features/games/memory/memory_flutter_adapter.dart').read_text()
new_memory=(ROOT/'final-source/lib/features/games/memory/memory_flutter_adapter.dart').read_text()
old_daily=(ROOT/'before-source/lib/domain/analysis/daily_recommendation_engine.dart').read_text()
new_daily=(ROOT/'final-source/lib/domain/analysis/daily_recommendation_engine.dart').read_text()
preserved_blocks=[]
for name,left,right in [
 ('memory catalog, owner validation and storage keys',old_memory[:old_memory.index('  @override\n  Future<String?> readRound()')],new_memory[:new_memory.index('  // The legacy Preferences API changes')]),
 ('memory write/exception functions',old_memory[old_memory.index('  @override\n  Future<void> writeRound'):],new_memory[new_memory.index('  @override\n  Future<void> writeRound'):]),
 ('parent report generic subject assessment',block(old_daily,'  SubjectAnalysisBlock _subjectBlock','  SubjectAnalysisBlock _germanBlock'),block(new_daily,'  SubjectAnalysisBlock _subjectBlock','  SubjectAnalysisBlock _germanBlock')),
 ('public plan signature',block(old_daily,'  DailyRecommendationPlan buildPlan','    final weakSkills'),block(new_daily,'  DailyRecommendationPlan buildPlan','    final weakSkills')),
 ('public report signature',block(old_daily,'  ParentReportSummary buildReport','    final reading'),block(new_daily,'  ParentReportSummary buildReport','    // Persisted summaries')),
]:
    assert left==right,name
    preserved_blocks.append({'name':name,'byte_identical':True,**ident(left.encode())})
assert all(word not in new_daily for word in ('latestReading','averageAlignmentScore','problemWords','interventionCount','completedSentences'))
assert new_daily.count('required List<ReadingAnalysisSummary> readingSummaries,')==2
protected=[]
for path, record in current.items():
    if (path.startswith(('lib/','config/','.github/probes/','scripts/verify_')) and
        any(t in path.lower() for t in ('writing','schreib','journal','ink_surface','diktat','math_task_templates','godot-source','legacy_release_pin','verify_connect_four','modernization_android_tour','lumo_village_android_probe','games_screen'))):
        assert path not in {x['path'] for x in mapping}
        protected.append(record)
assert all(x['path'] not in {m['path'] for m in mapping} for x in dependencies)
protection = {
 'schema':1,'baseline_host':HOST,'baseline_tree':TREE,
 'baseline_inventory':{'path':str(INV),**ident(INV.read_bytes()),'tracked_records':4708,
  'source_archive':'/tmp/host-b3c2bd-next-authorities-flutter-evidence-20261114/complete-original-pack.tar.gz',
  'source_archive_sha256':'5b3d851aa8d6625b363608769a23c3badcfe206dd160b70e43fac89e4c9d4188'},
 'immutable_application_precondition':'Root must verify the two exact old blobs and two absent new paths at its actual publication parent. This pack neither moves nor names a new product ref.',
 'all_other_paths_excluded_from_source_pack':True,'protected_records':protected,
 'dependencies':dependencies,'packages':package_proof,'pubspec_and_lock_not_changed':True,
 'preserved_production_blocks':preserved_blocks,'original_hunk_reconstruction':hunks,
 'merkle_tree_groups_verified':tree_counts,
 'semantics':[
  'Daily and parent competence text now uses the existing SkillRecord assessment getters; unconfirmed ASR summaries no longer become deficits, strengths, priorities or claimed reading accuracy.',
  'ReadingAnalysisSummary, ReadingProgressRepository and persisted legacy summaries are unchanged; both public readingSummaries arguments remain compatible.',
  'PreferencesMemoryStore awaits a fresh platform reload for every readRound/readStats; reload failures remain errors and cannot confirm optimistic-cache-only writes.',
  'Owner validation, owner-specific round/stats keys, historical lumo_memory_v2 non-migration, dealer/rules/rewards and write failure handling are byte-identical.',
  'The existing MemoryRoundController still serializes by owner and checks active profile before/after reads/writes; unchanged recovery compares actual reloaded bytes.',
  'The new Memory tests replace only the platform boundary, retain the real Preferences cache and controller, and use an independent test backend. These are controlled test faults, not physical-device durability claims.',
 ],
 'source_tests_executed_here':False
}

evidence=ROOT/'originals/producer-flutter'
raw=(evidence/'selected/feature-evidence/full-flutter/flutter-machine.jsonl').read_bytes()
events=[];non_json=[];non_dict=[];blanks=0
for line_number,line in enumerate(raw.decode().splitlines(),1):
    if not line.strip():
        blanks+=1
        continue
    try: parsed=json.loads(line)
    except json.JSONDecodeError:
        non_json.append({'line':line_number,'content':line})
        continue
    if not isinstance(parsed,dict):
        non_dict.append({'line':line_number,'type':type(parsed).__name__})
        continue
    events.append((line_number,parsed))
suites={};starts={};finishes={};done=[]
for number,event in events:
    typ=event.get('type')
    if typ=='suite':
        sid=event['suite']['id'];assert sid not in suites;suites[sid]=event['suite']
    elif typ=='testStart':
        tid=event['test']['id'];assert tid not in starts;starts[tid]=(number,event['test'])
    elif typ=='testDone':
        tid=event['testID'];assert tid not in finishes;finishes[tid]=(number,event)
    elif typ=='done':done.append((number,event))
assert len(done)==1 and done[0][1]['success'] is True
assert set(starts)==set(finishes)
assert not [e for _,e in events if e.get('type')=='error']
assert all(e['result']=='success' and e['skipped'] is False for _,e in finishes.values())
visible=[(tid,number,event) for tid,(number,event) in finishes.items() if event.get('hidden') is False]
hidden=[e for _,e in finishes.values() if e.get('hidden') is True]
assert len(visible)==2632 and len(hidden)==570
roster=[]
for path,required in [('test/games/memory_preferences_durability_test.dart',14),('test/reading_asr_evidence_boundary_test.dart',10)]:
    selected=[s for s in suites.values() if s['path'].endswith('/'+path)]
    assert len(selected)==1
    sid=selected[0]['id'];cases=[]
    for tid,number,finish in visible:
        start_line,start=starts[tid]
        if start['suiteID']!=sid:continue
        assert start['metadata']['skip'] is False
        src=(ROOT/'final-source'/path).read_text().splitlines()
        assert 'test(' in src[start['line']-1],(path,start['line'])
        cases.append({'id':tid,'name':start['name'],'source_line':start['line'],'source_column':start['column'],
                      'test_start_original_line':start_line,'test_done_original_line':number,
                      'result':finish['result'],'skipped':finish['skipped'],'hidden':finish['hidden']})
    assert len(cases)==required and len({c['name'] for c in cases})==required
    roster.append({'path':path,'suite':selected[0],'visible_successes':len(cases),'cases':cases,
                   'source':ident((ROOT/'final-source'/path).read_bytes())})
summary=obj('originals/producer-flutter/full-suite-summary-from-original-job.json')
assert summary==obj('originals/producer-flutter/selected/feature-evidence/full-flutter/acceptance-summary.json')
assert summary['status']=='PASS' and summary['passed']==2632 and summary['failed']==[] and summary['skipped']==[]
assert summary['flutter_exit_code']==0 and summary['runner_completed_successfully'] is True
assert summary['runner_errors']==[] and summary['capture_error_files']==[]
joblog=(evidence/'original-flutter-job.log').read_text()
summary_lines=[]
invocations=[]
for number,line in enumerate(joblog.splitlines(),1):
    if 'run_full_flutter_acceptance.py' in line: invocations.append({'line':number,'content':line})
    position=line.find('{"status":')
    if position>=0:
        try: candidate=json.loads(line[position:])
        except json.JSONDecodeError:continue
        if candidate==summary:summary_lines.append(number)
assert len(summary_lines)==1 and invocations
run=obj('originals/producer-flutter/run-original.json')
jobs=obj('originals/producer-flutter/jobs-original.json')
assert run['id']==43624674585 and run['run_attempt']==1 and run['head_sha']==PRODUCER
assert run['status']=='completed' and run['conclusion']=='success'
job=next(x for x in jobs['jobs'] if x['id']==132537752822)
assert job['run_id']==run['id'] and job['run_attempt']==1 and job['head_sha']==PRODUCER
assert job['status']=='completed' and job['conclusion']=='success'
api=obj('originals/producer-flutter/artifacts-original-connector.json')
artifact=next(x for x in api['artifacts'] if x['id']==14125828378)
assert artifact['workflow_run']['id']==run['id'] and artifact['workflow_run']['head_sha']==PRODUCER
assert artifact['size_in_bytes']==343185779
assert (evidence/'selected/feature-evidence/HOST-SOURCE.txt').read_text()==PRODUCER+'\n'
central=obj('originals/producer-flutter/central-directory.json')
ranges=obj('originals/producer-flutter/range-download-report.json')
assert len(central)==593 and len({x['name'] for x in central})==593
selected_integrity=[]
for item in ranges['members']:
    name=item['artifact_entry']
    data=(evidence/'selected'/name).read_bytes()
    idx=next(x for x in central if x['name']==name)
    identity=ident(data);crc=format(zlib.crc32(data)&0xffffffff,'08x')
    assert len(data)==item['bytes']==idx['bytes']
    assert identity['sha256']==item['sha256'] and crc==item['crc32']==idx['crc32']
    selected_integrity.append({'path':name,**identity,'crc32':crc,'published_central_directory_match':True})
assert len(selected_integrity)==4
sourcebinding=obj('originals/producer-flutter/source-binding.json')
assert sourcebinding['host_sha']==PRODUCER
for entry in sourcebinding['files']:
    if entry['path'].startswith('test/'):
        data=(ROOT/'final-source'/entry['path']).read_bytes()
        assert ident(data)['git_blob']==entry['git_blob_sha'] and ident(data)['sha256']==entry['sha256']
producer_case_report=obj('originals/producer-flutter/actual-new-cases-review.json')
assert producer_case_report['new_case_count']==24
assert producer_case_report['machine_non_json_line_count']==len(non_json)+len(non_dict)==398
test_evidence={
 'schema':1,'status':'VERIFIED_PUBLISHED_PRODUCER_ORIGINALS','executed_host':PRODUCER,'executed_tree':PRODUCER_TREE,
 'run_id':run['id'],'attempt':1,'job_id':job['id'],'job_conclusion':'success',
 'evidence_commit':'e048e1f61b22e04424244a23bbd99591443e5977',
 'subsequent_evidence_commit':'e77c802080ea0f1abe1a0e8fba39b17d9fe0e88d',
 'machine_original':ident(raw),'job_log':ident((evidence/'original-flutter-job.log').read_bytes()),
 'original_full_suite':{'visible_pass':2632,'hidden_successes':570,'fail':0,'skip':0,
   'flutter_exit_code':summary['flutter_exit_code'],'terminal_done':done[0][1],
   'done_original_line':done[0][0],'summary_job_log_line':summary_lines[0]},
 'actual_new_groups':roster,'total_actual_new_cases':24,'invocation_originals':invocations,
 'original_stream_classification':{'dict_events':len(events),'invalid_json_lines':len(non_json),
  'valid_json_non_dict_lines':len(non_dict),'blank_lines':blanks,'ignored_by_original_runner':398,
  'non_json_originals':non_json,'json_non_dict_line_numbers':[x['line'] for x in non_dict]},
 'selected_original_members':selected_integrity,
 'artifact':artifact,
 'transport_boundary':{'published_full_zip_digest':artifact['digest'],'complete_zip_downloaded_here':False,
  'complete_zip_sha256_or_all_members_verified_here':False,
  'published_4_full_members_read_and_crc_sha_git_blob_checked_here':True,
  'compressed_range_read_here':'Unsupported by UTF-8-only GitHub Fetch; original error retained in inspection. No binary range reconstructed or fetched again.',
  'new_live_ci_job_log_or_artifact_export':False,
  'originals_provenance':'Complete original log, JSONL, summaries and API responses were read from immutable published Git blobs; no synthetic results or count-difference inference.'},
 'target_combination_test_status':'NOT_RUN',
 'test_execution_performed_here':False,'android_audio_fps_or_model_claim':False
}
freeze={
 'schema':1,'status':'SOURCE_FROZEN_NOT_RUN','base_host_sha':HOST,'base_host_tree':TREE,
 'native_sha':NATIVE,'native_tree':NATIVE_TREE,'producer_sha':PRODUCER,'producer_tree':PRODUCER_TREE,
 'producer_parent':PARENT,'files':mapping,'source_count':4,
 'application_precondition':'Two exact current preimages plus two absent paths; Root owns any later commit/ref. All four final blobs already exist in Ullmann27/lumo-lernen.',
 'no_workflow_pin_lockfile_or_other_product_change':True,'local_product_tests_executed':False
}
review={
 'schema':1,'result':'NO_CONCRETE_SOURCE_BLOCKER_IN_FOUR_FILE_SCOPE','base_host':HOST,'producer':PRODUCER,
 'complete_four_files_read':True,'exact_current_preimages_equal_producer_parent':True,
 'exact_source_dependencies_equal_producer':7,'lockfile_change_needed':False,
 'reasoning':protection['semantics'],
 'protected_modules':'No Writer, InkSurface, Journal, Diktat, Math, Village, C4, Garage, speech or pin source is included in final-source; full baseline dependency records retained separately.',
 'actual_producer_evidence':'14 Memory + 10 ASR cases independently traced by suite/test IDs to successful visible completions and source lines in the complete original stream on 28462. Full producer suite 2632/0/0; this is not a b3 combination result.',
 'remaining_acceptance':'Root will include these two test files in the next complete integrated APK/Flutter build. No additional local Flutter run or workflow is proposed.',
 'limitations':['Preferences durability fault cases use the real Dart cache/controller with an isolated platform backend; no Android physical-storage proof.',
  'ASR summary storage/history is preserved; no speech-recognition accuracy or reading-assessment model claim.',
  'Full 343185779-byte producer artifact was not downloaded or hashed here. Four complete published member bytes and their CRC/hash bindings were checked.',
  'This source pack contains no new test execution, imports of product code, active checkout writes, Git mutations or CI actions.']
}
outputs=[]
for path,value in [('source-freeze.json',freeze),('source-index.json',{'files':mapping}),
 ('source-protection.json',protection),('producer-24-original-review.json',test_evidence),('review.json',review)]:
    outputs.append(write_new(path,json_bytes(value)))
outputs.append(write_new('integration.patch',''.join(diffs)))
handoff={
 'schema':1,'status':'READY_FOR_ROOT_SOURCE_CHECKPOINT','pack':str(ROOT),
 'files':mapping,'source_freeze':next(x for x in outputs if x['path']=='source-freeze.json'),
 'review':next(x for x in outputs if x['path']=='review.json'),
 'producer_test_review':next(x for x in outputs if x['path']=='producer-24-original-review.json'),
 'source_protection':next(x for x in outputs if x['path']=='source-protection.json'),
 'integration_patch':next(x for x in outputs if x['path']=='integration.patch'),
 'actual_tests_on_target':{'status':'NOT_RUN','reason':'No execution authorized or necessary before Root checkpoint; next integrated full suite will discover both added test files.'},
 'producer_evidence_commit_is_not_execution_commit':True,
 'inspection_errors':['initial-jsonl-read-error.json was an analysis-only assumption error before any writes/test execution; all original lines were subsequently classified explicitly.',
 'binary-range-fetch-original-response.json preserves the UTF-8-only reader rejection. The full machine/log bytes were independently read by their published text blobs.'],
 'preserved_current_host_evidence':'Both b3 Flutter53 and Android compile/19+11+8 evidence packs were frozen separately; no new four-file combination success is inferred.'
}
outputs.append(write_new('handoff.json',json_bytes(handoff)))
entries=[]
for path in sorted(ROOT.rglob('*')):
    if path.is_file():
        entries.append({'path':path.relative_to(ROOT).as_posix(),**ident(path.read_bytes())})
manifest={'schema':1,'files':entries,'count':len(entries),'bytes':sum(x['bytes'] for x in entries),
          'scope':'Complete selected source/preimage/reference/API/producer-test originals and independent review. Excludes separate source Git checkouts and any full producer ZIP.'}
outputs.append(write_new('manifest.json',json_bytes(manifest)))
archive=ROOT/'complete-source-and-originals.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
    for path in sorted(ROOT.rglob('*')):
        if path.is_file() and path!=archive:
            tf.add(path,arcname=path.relative_to(ROOT).as_posix(),recursive=False)
with tarfile.open(archive,'r:gz') as tf:
    members=[m for m in tf.getmembers() if m.isfile()]
    assert len({m.name for m in members})==len(members)
    for member in members:
        assert tf.extractfile(member).read()==(ROOT/member.name).read_bytes()
binding={'schema':1,'archive':ident(archive.read_bytes()),'members':len(members),
         'all_members_roundtripped_byte_equal':True}
outputs.append(write_new('archive-binding.json',json_bytes(binding)))
print(json.dumps({'root':str(ROOT),'outputs':outputs,'archive':binding},indent=2))

