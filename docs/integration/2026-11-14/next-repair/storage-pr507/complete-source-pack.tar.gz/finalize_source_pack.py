import ast
import difflib
import hashlib
import io
import json
import pathlib
import re
import shutil
import tarfile

ROOT = pathlib.Path('/tmp/host-pr507-0d7e-integration-7ac-20261114')
OLD = pathlib.Path('/tmp/host-pr507-e2db-readonly-against7ac-20261114')
RADAR = pathlib.Path('/tmp/host-next-producer-radar-1938-20261114')
FAILURE = pathlib.Path('/tmp/host-pr507-corrected-ci-failure-20261114')


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def put(path, data):
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert target.read_bytes() == data, str(target)
    else:
        target.write_bytes(data)
    assert target.read_bytes() == data
    return {'path': path, **identity(data)}


def write_json(path, value):
    return put(path, (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())


def copy(source, path):
    return put(path, source.read_bytes())


mapping = json.loads((ROOT / 'source-mapping.preliminary.json').read_text())
tree = json.loads((RADAR / 'active7ac-tree-entries.json').read_text())
entries = {entry['path']: entry for entry in tree['entries']}
files = json.loads((RADAR / 'files507.json').read_text())
original_files = {entry['filename']: entry for entry in files}
correction = json.loads((RADAR / 'pr507-compiler-correction.json').read_text())
base = mapping['base']
producer = mapping['producer']
assert correction['commits'][0]['sha'] == producer
assert correction['commits'][0]['parents'][0]['sha'] == mapping['producer_parent']
producer_tree = correction['commits'][0]['commit']['tree']['sha']

original_records = []
for name in ('pr507.json', 'files507.json', 'active7ac-tree-entries.json',
             'pr507-compiler-correction.json', 'pr507-corrected-feature-jobs.json'):
    original_records.append(copy(RADAR / name, 'originals/api/' + name))
for source in sorted(FAILURE.iterdir()):
    if source.is_file():
        original_records.append(copy(source, 'originals/corrected-ci-failure/' + source.name))
for source in sorted((OLD / 'reference-source/upstream').iterdir()):
    if source.is_file():
        original_records.append(copy(source, 'reference-source/upstream/' + source.name))
copy(OLD / 'originals/producer-git-commit.original.json', 'originals/api/e2db-git-commit.original.json')

# Bind original producer end bytes for all ten candidates. The three changed
# old tests are identical in the executed producer and 7ac before this proposal.
for row in mapping['sources']:
    path = row['path']
    if row['selection'] == 'root_exact_regression_update':
        source = ROOT / 'before' / path
    elif path.endswith('memory_round.dart'):
        source = ROOT / 'newly-read-originals' / path
    else:
        source = OLD / 'original-source/producer' / path
    data = source.read_bytes()
    assert identity(data)['git_blob'] == row['producer_blob']
    copy(source, 'original-source/0d7e/' + path)
    assert identity((ROOT / 'final-source' / path).read_bytes()) == row['after']

dependency_paths = [
    'lib/features/games/shared/lumo_game_pause_scope.dart',
    'lib/features/games/connect_four/connect_four_round.dart',
    'lib/features/games/memory/memory_table_session.dart',
    '.github/probes/modernization_android_tour.py',
    'pubspec.yaml', 'pubspec.lock',
]
dependencies = []
for path in dependency_paths:
    locations = [OLD / 'reference-source/current' / path, OLD / 'reference-source' / path]
    source = next((candidate for candidate in locations if candidate.is_file()), None)
    assert source, path
    data = source.read_bytes()
    assert identity(data)['git_blob'] == entries[path]['sha'], path
    record = copy(source, 'reference-source/current/' + path)
    dependencies.append({'repository_path': path, 'mode': entries[path]['mode'], **record})
path = 'lib/features/games/memory/lumo_memory_game.dart'
data = (ROOT / 'newly-read-originals/reference-memory-screen.dart').read_bytes()
assert identity(data)['git_blob'] == entries[path]['sha']
dependencies.append({'repository_path': path, 'mode': entries[path]['mode'],
                     **put('reference-source/current/' + path, data)})
native_path = pathlib.Path('/workspace/scratch/b3485b7bb989/host3fac-nativece909-contract-independent-review-20261114/originals/native/scripts/games/memory/memory_table.gd')
native = native_path.read_bytes()
assert identity(native)['git_blob'] == '9c998e33aee127453a67d25a6e020638472b8387'
native_record = put('reference-source/native-f9/scripts/games/memory/memory_table.gd', native)
native_record['binding_scope'] = 'Local original bytes rehashed here; equality to f9 was read and reported by Godot. No duplicate Native API read.'

final_paths = {row['path'] for row in mapping['sources']}
protected = []
for path, entry in sorted(entries.items()):
    if entry['type'] != 'blob':
        continue
    selected = (path in {
        'config/godot-source.json', 'scripts/verify_legacy_release_pin.py',
        'scripts/tests/test_candidate_2011_pin.py', 'scripts/verify_connect_four_delivery.py',
        '.github/workflows/lumo-connect-four-2020.yml', 'lib/features/games/games_screen.dart',
        'lib/core/embedded_game_service.dart', 'lib/features/lumo3d/lumo3d_launcher.dart',
        '.github/probes/creative_android_probe.py', '.github/probes/modernization_android_tour.py',
        'lib/domain/analysis/daily_recommendation_engine.dart',
        'test/games/memory_preferences_durability_test.dart',
        'test/reading_asr_evidence_boundary_test.dart',
        'test/games_screen_flow_test.dart', 'test/games/connect_four_native_route_test.dart',
    } or (path.startswith(('lib/', 'android/')) and any(term in path.lower() for term in
          ('journal', 'schreibtrainer', 'ink_surface', 'learning_speech', 'speech_envelope',
           'learning_voice', 'lumo_learningspeech', 'lumolearningspeech', 'lumospeechenvelope',
           'native_table', 'memory_table', 'connect_four_round', 'math_task_templates', 'village'))))
    if selected:
        assert path not in final_paths
        protected.append({'path': path, 'mode': entry['mode'], 'git_blob': entry['sha'],
                          'binding': 'unchanged base-tree entry; no replacement in this proposal'})

preservation = {
    'schema': 1, 'base': base, 'base_tree': mapping['base_tree'],
    'scope': '10 paths; no active checkout or Git mutation; no tests/imports',
    'protected_tree_entries': protected,
    'direct_dependency_bytes': dependencies, 'native_memory_presenter_original': native_record,
    'root_c4_layout': 'Only the exact two producer patches apply to _place catch and the new _retryFinishedRound. Exact inverse yields all 43,222 original bytes; all UI/layout/scroll/48dp/native-entry code is preserved.',
    'wallet': 'Only the three already-known result-ID branches gain await _persist(current). _transaction, _commit, _persist, _emit, amounts, validation, queues and migration are unchanged.',
    'memory': 'Exact published corrected producer bytes on identical 7ac/28462 preimages. Keys, owner queue, rules, random state, result IDs and existing reward function remain; positive write confirmation is added.',
    'pr508_collision_contract': {
        'base_c4_blob': 'ed3a47ea8995ff829a97fd0240500fa7ffc47a96',
        'this_pack': ['_place catch', 'new _retryFinishedRound'],
        'godot_separate': ['_initializeRound automatic native launch', '_setMode/_setLevel native-opening guards', 'column UI native-opening guard', 'native-route and games-flow tests'],
        'status': 'Disjoint source regions reported to Godot; combined final C4 blob belongs to Root and is not claimed here.'},
    'excluded_preview': {
        'paths': ['.github/probes/creative_android_probe.py', 'tools/android_qa/tests/test_kart_preview_skip.py'],
        'reason': '7ac has no matching preview-skip caller/test; its current tour has no Tippen zum Überspringen/preview-skip call. Whole producer helper would drop current Boru/standalone-caption guards. Root owns separate OCR decision; Pipeline owns current-frame reuse.'},
}
write_json('preservation.json', preservation)

upstream = [
    {'path': 'reference-source/upstream/shared_preferences_2.5.5_legacy.dart',
     'url': 'https://github.com/flutter/packages/blob/shared_preferences-v2.5.5/packages/shared_preferences/shared_preferences/lib/src/shared_preferences_legacy.dart',
     'role': 'The pinned 2.5.5 legacy Dart cache is changed before platform write; reload obtains the platform snapshot, not an independent disk acknowledgement.'},
    {'path': 'reference-source/upstream/LegacySharedPreferencesPlugin_2.4.28.kt',
     'url': 'https://github.com/flutter/packages/blob/9854cd5607da4001f2dd3cbdcd6903202d28958c/packages/shared_preferences/shared_preferences_android/android/src/main/kotlin/io/flutter/plugins/sharedpreferences/LegacySharedPreferencesPlugin.kt',
     'role': 'Official Android 2.4.28 tag resolves to 9854cd56. Legacy setString returns synchronous SharedPreferences.Editor.commit; getAll reads the native preferences map.'},
    {'path': 'reference-source/upstream/SharedPreferencesImpl_android15.java',
     'url': 'https://github.com/aosp-mirror/platform_frameworks_base/blob/android-15.0.0_r1/core/java/android/app/SharedPreferencesImpl.java',
     'role': 'Android15 commit applies commitToMemory before disk write and returns writeToDiskResult. getAll copies mMap; a failed disk return does not make that native snapshot a positive commit. writeToFile retains the distinction between memory and disk generations.'},
]
for entry in upstream:
    entry.update(identity((ROOT / entry['path']).read_bytes()))
write_json('official-storage-source-binding.json', {
    'schema': 1, 'lock': next(row for row in dependencies if row['repository_path'] == 'pubspec.lock'),
    'pinned_packages': {'shared_preferences': '2.5.5', 'shared_preferences_android': '2.4.28'},
    'sources': upstream,
    'conclusion': 'A platform snapshot equal to an attempted write is insufficient to positively acknowledge it. The proposal requires a true reply from a same-value platform commit before exposing a recovered/restored state or deduplicated award.',
    'limits': ['Source-derived conditional failure, not a claimed observed data loss in 7ac.',
               'No Android disk-failure experiment, APK install, crash/power-loss proof or universal OS-version assertion was performed.',
               'Native Memory consumes the authoritative Dart acknowledgement; it has no independent second SharedPreferences commit barrier.'],
})

log = (ROOT / 'originals/corrected-ci-failure/job-132564402577.original.log').read_text()
assert identity(log.encode())['sha256'] == '730624ed6be190ce6305d6b8c90e4d8eddb96c9a25ac22c5c4b4139c5e1b4ab2'
failures = []
for line_number, line in enumerate(log.splitlines(), 1):
    if line.endswith(' [E]'):
        failures.append({'line': line_number, 'original_line': line})
assert len(failures) == 7
assert '00:03 +23 -7: Some tests failed.' in log
write_json('original-failure-analysis.json', {
    'schema': 1, 'producer': producer, 'run_id': 43633267932, 'attempt': 1,
    'job_id': 132564402577, 'job_conclusion': 'failure',
    'step': 'Recheck durable wallet queues across caller zones and actual Memory profiles',
    'original_log': {'path': 'originals/corrected-ci-failure/job-132564402577.original.log', **identity(log.encode())},
    'actual_step_result': {'passed': 23, 'failed': 7, 'exit': 1},
    'original_failures': failures,
    'wallet_primary': {'actual': 'Four exact write-count assertions failed: 2->3, 3->4, and twice 4->5.',
                       'repair': 'Require the additional same-value positive commit, exact ordered snapshots, unchanged reward values/IDs, and no duplicate emitted events; existing caller-zone/queue barriers stay.'},
    'memory_primary': {'actual': 'First failure at test line175: original stats opening-confirmation plus blocked profi snapshot produced two recorded writes before gate.complete().',
                       'repair': 'Require the original same-value opening write, then ordered child-specific mutations. Original best/legacy bytes/profile hiding remain asserted. Always complete the fixture-owned gate in finally.'},
    'two_later_memory_failures': {
        'actual': 'Later tests could not find their difficulty selectors; no separate product exception is present in the original trace.',
        'source_inference': 'The first assertion exits before completing its gate. The real controller retains an unfinished static _ownerWrites entry for the same owner; subsequent open() waits on it and has no controller/UI selectors. The intervening delayed-identity test switches to childB and passes.',
        'limit': 'This cause is traced from the exact original source and event order, not claimed as an independently executed replay. The corrupt-stats test remains byte-identical.'},
    'new_45_cases': 'NOT_EXECUTED in this failing CI attempt; no new result is inferred.',
    'materialization': 'Root preserved its first local log copy with one extra LF and the exact correction receipt; the API was fetched only once. Both copies are included with distinct hashes.',
})

# Capture all import dependencies without running Dart or importing products.
imports = []
for row in mapping['sources']:
    path = row['path']
    text = (ROOT / 'final-source' / path).read_text()
    for match in re.finditer(r"^import\s+'([^']+)'", text, re.MULTILINE):
        target = match.group(1)
        resolved = None
        if target.startswith('package:lumo_lernen/'):
            resolved = 'lib/' + target.removeprefix('package:lumo_lernen/')
        elif not target.startswith(('dart:', 'package:')):
            import posixpath
            resolved = posixpath.normpath(posixpath.join(posixpath.dirname(path), target))
        if resolved:
            assert resolved in entries or resolved in final_paths, (path, resolved)
        imports.append({'source': path, 'import': target, 'repository_path': resolved,
                        'base_blob': entries.get(resolved, {}).get('sha') if resolved else None})
write_json('import-binding.json', {'imports': imports, 'product_import_execution': 'NONE'})

test_paths = [row['path'] for row in mapping['sources'] if row['selection'] == 'root_exact_regression_update']
test_paths += [row['path'] for row in mapping['sources'] if row['path'].startswith('test/') and row['path'] not in test_paths]
declared = []
for path in test_paths:
    text = (ROOT / 'final-source' / path).read_text()
    assert 'skip:' not in text
    cases = [{'line': text.count('\n', 0, match.start()) + 1, 'declared_name_literal': match.group(2)}
             for match in re.finditer(r'''\b(test|testWidgets)\(\s*('(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*")''', text)]
    declared.append({'path': path, 'source': identity(text.encode()), 'declarations': cases})
write_json('test-plan.json', {
    'schema': 1, 'execution': 'NOT_RUN; Root source checkpoint is required first.',
    'files': declared,
    'planned_groups': [{'scope': 'Three existing regression files', 'historical_runtime_cases': 30,
                        'original_outcome_on_0d7e': '23 PASS /7 FAIL'},
                       {'scope': 'Three new producer files', 'producer_declared_cases': 45,
                        'qualification': 'Source inventory only; this CI attempt did not reach them.'}],
    'command_after_root_authorization': ['flutter', 'test', '--no-pub', '--machine', '--concurrency=1',
                                        *test_paths],
    'required_result': 'All actual visible tests must finish successfully with no skips; verify machine stream and process exit. Do not substitute the planned count for actual execution.',
    'next_boundary': 'A new complete APK/C4 acceptance must use the later combined checkpoint. Current 7ac remains publication-blocked; no device or release success is claimed.'})

freeze = {key: value for key, value in mapping.items() if key != 'execution'}
freeze.update({'producer_tree': producer_tree, 'status': 'SOURCE_FROZEN_UNTESTED',
               'source_count': len(mapping['sources']), 'tests_executed': False})
freeze_record = write_json('source-freeze.json', freeze)
write_json('source-index.json', {'base': base, 'producer': producer,
                                'files': [{'path': row['path'], **row['after']} for row in mapping['sources']]})

handoff = {
    'schema': 1, 'status': 'SOURCE_FROZEN_UNTESTED', 'source_freeze': freeze_record,
    'base': {'sha': base, 'tree': mapping['base_tree']},
    'producer': {'sha': producer, 'tree': producer_tree, 'pr': 507},
    'paths': mapping['sources'],
    'outcome': 'Ten-path selective source proposal. Three exact corrected producer products, one two-hunk C4 merge, three exact new tests, and three strict existing regression updates.',
    'why': 'Positive native persistence acknowledgement cannot be replaced by a matching optimistic cache; retries must preserve one reward and one result ID. C4 failed bot/terminal reward work must remain resumable through the same paused clock.',
    'actual_evidence': 'Producer0d7e old30 stage failed23/7. Root-supplied complete original retained; new45 not reached. Official Flutter/AOSP source originals and native-Dart ACK consumer bound.',
    'protection': 'No protected Writer/InkSurface/Journal/Math/Village/Speech/PCM/Table bridge/pin/workflow bytes are replaced. C4 layout preserved; PR508 owner regions disjoint.',
    'validation': 'Only byte/hash, exact patch inversion, JSON and import-path/source comparisons performed. No Dart/Flutter test, product import, build, device action, Git mutation or CI start.',
    'pending': ['Independent source review and Root source checkpoint',
                'Run the six focused files once on the checkpointed combination and retain real results',
                'Combine Root/Godot PR508 disjoint C4 edits under a separate exact final hash',
                'Full integrated APK/Android acceptance on the new candidate; current7ac is not released'],
}
write_json('handoff.json', handoff)

manifest_files = []
for path in sorted(ROOT.rglob('*')):
    if path.is_file() and path.name not in ('manifest.json', 'complete-source-pack.tar.gz', 'archive-binding.json'):
        manifest_files.append({'path': path.relative_to(ROOT).as_posix(), **identity(path.read_bytes())})
manifest_record = write_json('manifest.json', {'schema': 1, 'files': manifest_files})
archive_members = manifest_files + [manifest_record]
archive = ROOT / 'complete-source-pack.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as out:
    for entry in archive_members:
        data = (ROOT / entry['path']).read_bytes()
        info = tarfile.TarInfo(entry['path'])
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        out.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as readback:
    assert len(readback.getmembers()) == len(archive_members)
    assert readback.getnames() == [entry['path'] for entry in archive_members]
    for entry in archive_members:
        assert readback.extractfile(entry['path']).read() == (ROOT / entry['path']).read_bytes()
archive_record = {'path': archive.name, **identity(archive.read_bytes())}
write_json('archive-binding.json', {'archive': archive_record, 'members': len(archive_members),
                                    'roundtrip': 'all member bytes fully compared',
                                    'manifest': manifest_record})
print(json.dumps({'freeze': freeze_record, 'manifest': manifest_record,
                  'handoff': identity((ROOT / 'handoff.json').read_bytes()),
                  'archive': archive_record, 'members': len(archive_members)}, indent=2))
