import difflib
import hashlib
import json
import pathlib
import re
import shutil

ROOT = pathlib.Path('/tmp/host-pr507-0d7e-integration-7ac-20261114')
OLD = pathlib.Path('/tmp/host-pr507-e2db-readonly-against7ac-20261114')
RADAR = pathlib.Path('/tmp/host-next-producer-radar-1938-20261114')
BASE = '7ac736fdbd042769592e88de0f9849632242316d'
PRODUCER = '0d7e6e5efb1fe8cd2e9a7f92cdd4034b81173304'


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def save(path, data):
    path = ROOT / path
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, f'existing byte mismatch: {path}'
    else:
        path.write_bytes(data)
    assert path.read_bytes() == data
    return identity(data)


def swap(text, before, after):
    assert text.count(before) == 1, (text.count(before), before)
    return text.replace(before, after, 1)


def apply_exact_hunks(text, patch):
    groups = []
    for line in patch.splitlines(keepends=True):
        if line.startswith('@@ '):
            groups.append([])
        elif groups and line[:1] in (' ', '+', '-'):
            groups[-1].append(line)
        else:
            raise AssertionError(f'unsupported patch line: {line!r}')
    changes = []
    for group in groups:
        old = ''.join(line[1:] for line in group if line[:1] in (' ', '-'))
        new = ''.join(line[1:] for line in group if line[:1] in (' ', '+'))
        if not old.endswith('\n'):
            old += '\n'
        if not new.endswith('\n'):
            new += '\n'
        text = swap(text, old, new)
        changes.append((old, new))
    return text, changes


tree = json.loads((RADAR / 'active7ac-tree-entries.json').read_text())
assert tree['head'] == BASE
entries = {entry['path']: entry for entry in tree['entries']}
files = json.loads((RADAR / 'files507.json').read_text())
producer_files = {entry['filename']: entry for entry in files}
correction = json.loads((RADAR / 'pr507-compiler-correction.json').read_text())
assert correction['total_commits'] == 1 and correction['ahead_by'] == 1
assert [entry['filename'] for entry in correction['files']] == [
    'lib/features/games/memory/memory_round.dart']
assert correction['commits'][0]['sha'] == PRODUCER
assert correction['commits'][0]['parents'][0]['sha'] == 'e2db0d60af51266caa9b54ffd08eb0947ae99ac6'

products = [
    'lib/core/reward_wallet_repository.dart',
    'lib/features/games/memory/memory_flutter_adapter.dart',
    'lib/features/games/memory/memory_round.dart',
    'lib/features/games/connect_four/lumo_connect_four_game.dart',
]
new_tests = [
    'test/games/connect_four_bot_save_retry_test.dart',
    'test/games/memory_native_commit_confirmation_test.dart',
    'test/reward_wallet_dedup_confirmation_test.dart',
]
old_tests = [
    'test/reward_wallet_queue_zone_test.dart',
    'test/reward_wallet_transaction_test.dart',
    'test/games/memory_profile_storage_test.dart',
]
rows = []
for path in products + new_tests + old_tests:
    if path in old_tests:
        before = (ROOT / 'newly-read-originals' / path).read_bytes()
        proposed = before
        mode = 'root_exact_regression_update'
    elif path in new_tests:
        assert path not in entries
        before = None
        proposed = (OLD / 'original-source/producer' / path).read_bytes()
        assert identity(proposed)['git_blob'] == producer_files[path]['sha']
        mode = 'exact_published_producer'
    else:
        before = (OLD / 'original-source/current' / path).read_bytes()
        parent = (OLD / 'original-source/parent' / path).read_bytes()
        original = (OLD / 'original-source/producer' / path).read_bytes()
        assert identity(original)['git_blob'] == producer_files[path]['sha']
        save('original-source/e2db/' + path, original)
        save('common-base/' + path, parent)
        if path.endswith('memory_round.dart'):
            proposed = (ROOT / 'newly-read-originals' / path).read_bytes()
            corrected, changes = apply_exact_hunks(original.decode(), correction['files'][0]['patch'])
            assert corrected.encode() == proposed
            assert identity(proposed)['git_blob'] == correction['files'][0]['sha']
            assert parent == before
            mode = 'exact_published_producer'
        elif path.endswith('lumo_connect_four_game.dart'):
            proposed_text, changes = apply_exact_hunks(before.decode(), producer_files[path]['patch'])
            assert len(changes) == 2
            original_reconstruction, _ = apply_exact_hunks(parent.decode(), producer_files[path]['patch'])
            assert original_reconstruction.encode() == original
            restored = proposed_text
            for old, new in reversed(changes):
                restored = swap(restored, new, old)
            assert restored.encode() == before
            proposed = proposed_text.encode()
            mode = 'exact_two_producer_hunks_on_root'
        else:
            assert before == parent
            proposed = original
            mode = 'exact_published_producer'
    if before is not None:
        assert identity(before)['git_blob'] == entries[path]['sha']
        save('before/' + path, before)
    if path not in old_tests:
        save('final-source/' + path, proposed)
    rows.append({'path': path, 'mode': '100644', 'before': identity(before) if before is not None else None,
                 'selection': mode, 'producer_sha': PRODUCER,
                 'producer_blob': correction['files'][0]['sha'] if path.endswith('memory_round.dart')
                 else producer_files.get(path, {}).get('sha'), 'after': identity(proposed)})

# Existing zone tests still require the original queue ordering and caller zone.
path = old_tests[0]
text = (ROOT / 'before' / path).read_text()
text = swap(text,
    "    final originalZone = _HeldMicrotasks();\n    Object? failure;",
    "    final emitted = <RewardWallet>[];\n    final subscription = wallet.changes.listen(emitted.add);\n    addTearDown(subscription.cancel);\n    final originalZone = _HeldMicrotasks();\n    Object? failure;")
text = swap(text,
    "    expect((await store.persisted())['stars'], 0);\n\n    final retried",
    "    expect((await store.persisted())['stars'], 0);\n    expect(emitted, isEmpty);\n\n    final retried")
text = swap(text,
    "    await wallet.awardGameResult(\n      resultId: 'retry-round',\n      stars: 2,\n      xp: 16,\n    );\n    expect(store.writes, hasLength(2));\n    expect(await store.persisted(), retried.toJson());",
    "    final replay = await wallet.awardGameResult(\n      resultId: 'retry-round',\n      stars: 2,\n      xp: 16,\n    );\n    await Future<void>.delayed(Duration.zero);\n    // Rejection, successful retry, then the same-value durability confirmation.\n    expect(store.writes, hasLength(3));\n    expect(store.writes, List.filled(3, retried.toJson()));\n    expect(replay, same(retried));\n    expect(emitted.map((value) => value.toJson()).toList(), [retried.toJson()]);\n    expect(await store.persisted(), retried.toJson());")
text = swap(text,
    "    final reopened = RewardWalletRepository();\n    final replay = await reopened.awardGameResult(",
    "    final reopened = RewardWalletRepository();\n    final replayEvents = <RewardWallet>[];\n    final replaySubscription = reopened.changes.listen(replayEvents.add);\n    addTearDown(replaySubscription.cancel);\n    final replay = await reopened.awardGameResult(")
text = swap(text,
    "    expect(replay.gameResultIds, ['first', 'second', 'third']);\n    expect(store.writes, hasLength(3));",
    "    expect(replay.gameResultIds, ['first', 'second', 'third']);\n    await Future<void>.delayed(Duration.zero);\n    // Reopening confirms the final snapshot; it grants no fourth reward.\n    expect(store.writes, hasLength(4));\n    expect(store.writes.last, store.writes[2]);\n    expect(replay.toJson(), wallet.snapshot.toJson());\n    expect(await store.persisted(), replay.toJson());\n    expect(replayEvents, isEmpty);")
save('final-source/' + path, text.encode())

# Existing transaction tests keep exact balance, reward ID and event order.
path = old_tests[1]
text = (ROOT / 'before' / path).read_text()
text = swap(text,
    "      expect(wallet.snapshot.stars, 9);\n      expect(store.writtenSnapshots, hasLength(4));\n      await subscription.cancel();",
    "      expect(wallet.snapshot.stars, 9);\n      await Future<void>.delayed(Duration.zero);\n      // The duplicate is a confirmed same-value write, never another award.\n      expect(store.writtenSnapshots, hasLength(5));\n      expect(store.writtenSnapshots[3], savedAward);\n      expect(store.writtenSnapshots[4], savedAward);\n      expect(await store.persistedWallet(), savedAward);\n      expect(\n        store.writtenSnapshots\n            .map((value) => [value['stars'], value['xp'], value['gameResultIds']])\n            .toList(),\n        [\n          [6, 20, ['race-1']],\n          [3, 0, <String>[]],\n          [3, 5, <String>[]],\n          [9, 25, ['race-1']],\n          [9, 25, ['race-1']],\n        ],\n      );\n      expect(\n        emitted.map((value) => [value.stars, value.xp, value.gameResultIds]).toList(),\n        [\n          [3, 0, <String>[]],\n          [3, 5, <String>[]],\n          [9, 25, ['race-1']],\n        ],\n      );\n      await subscription.cancel();")
save('final-source/' + path, text.encode())

# A confirmed restored statistics snapshot is an explicit write. The two
# blocked-write fixtures must release their own gate even after an assertion.
path = old_tests[2]
text = (ROOT / 'before' / path).read_text()
start = text.index("  testWidgets('Delayed old-child write cannot overwrite the newly selected child',")
end = text.index("  testWidgets('Delayed identity load cannot expose old best after profile switch',", start)
block = text[start:end]
block = swap(block,
    "    await _open(tester, app);\n    final gate = Completer<void>();",
    "    await _open(tester, app);\n    expect(store.writes, [\n      (key: 'flutter.${_key(_a)}',\n       value: '{\"difficulty\":\"leicht\",\"best\":{\"leicht\":7}}'),\n    ], reason: 'Opening confirms the unchanged, validated child snapshot.');\n    final gate = Completer<void>();")
block = swap(block,
    "    expect(store.writes, hasLength(1));",
    "    expect(store.writes, hasLength(2));\n    expect(store.writes.last,\n        (key: 'flutter.${_key(_a)}',\n         value: '{\"difficulty\":\"profi\",\"best\":{\"leicht\":7}}'));\n    expect((await store.disk())['flutter.${_key(_a)}'],\n        '{\"difficulty\":\"leicht\",\"best\":{\"leicht\":7}}');")
block = swap(block,
    "    expect(disk['flutter.lumo_memory_v2'], _legacy);\n    await tester.pumpWidget(const SizedBox.shrink());",
    "    expect(disk['flutter.lumo_memory_v2'], _legacy);\n    expect(store.writes, [\n      (key: 'flutter.${_key(_a)}',\n       value: '{\"difficulty\":\"leicht\",\"best\":{\"leicht\":7}}'),\n      (key: 'flutter.${_key(_a)}',\n       value: '{\"difficulty\":\"profi\",\"best\":{\"leicht\":7}}'),\n      (key: 'flutter.${_key(_b)}',\n       value: '{\"difficulty\":\"mittel\",\"best\":{\"mittel\":11}}'),\n      (key: 'flutter.${_key(_b)}',\n       value: '{\"difficulty\":\"knifflig\",\"best\":{\"mittel\":11}}'),\n    ]);")
prefix, body = block.split('    store.gate = gate;\n', 1)
assert body.endswith('  });\n\n')
body = body[:-len('  });\n\n')]
block = (prefix + '    store.gate = gate;\n    try {\n' +
         ''.join('  ' + line if line.strip() else line for line in body.splitlines(keepends=True)) +
         "    } finally {\n      // A failed assertion must not retain this child's static owner queue.\n      if (!gate.isCompleted) gate.complete();\n      await tester.pump();\n      await tester.pump();\n      await tester.pumpWidget(const SizedBox.shrink());\n    }\n  });\n\n")
text = text[:start] + block + text[end:]
start = text.index("  testWidgets('Pending successive choices retain captured snapshots and final order',")
end = text.index("  testWidgets('Unreadable existing child stats are preserved instead of reset',", start)
block = text[start:end]
block = swap(block,
    "    await _open(tester, app);\n    final gate = Completer<void>();",
    "    await _open(tester, app);\n    expect(store.writes, [\n      (key: 'flutter.${_key(_a)}',\n       value: '{\"difficulty\":\"leicht\",\"best\":{\"leicht\":7}}'),\n    ], reason: 'Opening confirms the unchanged, validated child snapshot.');\n    final gate = Completer<void>();")
block = swap(block,
    "    expect(store.writes, hasLength(1), reason: 'Second write waits for the first');\n    expect(jsonDecode(store.writes.single.value)['difficulty'], 'mittel');",
    "    expect(store.writes, hasLength(2),\n        reason: 'After the opening confirmation, the second choice waits for the first.');\n    expect(jsonDecode(store.writes[1].value)['difficulty'], 'mittel');\n    expect((await store.disk())['flutter.${_key(_a)}'],\n        '{\"difficulty\":\"leicht\",\"best\":{\"leicht\":7}}');")
block = swap(block,
    "    expect(store.writes, hasLength(2));",
    "    expect(store.writes, hasLength(3));\n    expect(store.writes.map((entry) => entry.key).toList(),\n        List.filled(3, 'flutter.${_key(_a)}'));\n    expect(store.writes.map((entry) => jsonDecode(entry.value)).toList(), [\n      {'difficulty': 'leicht', 'best': {'leicht': 7}},\n      {'difficulty': 'mittel', 'best': {'leicht': 7}},\n      {'difficulty': 'profi', 'best': {'leicht': 7}},\n    ]);")
block = swap(block, '    await tester.pumpWidget(const SizedBox.shrink());\n', '')
prefix, body = block.split('    store.gate = gate;\n', 1)
assert body.endswith('  });\n\n')
body = body[:-len('  });\n\n')]
block = (prefix + '    store.gate = gate;\n    try {\n' +
         ''.join('  ' + line if line.strip() else line for line in body.splitlines(keepends=True)) +
         "    } finally {\n      if (!gate.isCompleted) gate.complete();\n      await tester.pump();\n      await tester.pump();\n      await tester.pumpWidget(const SizedBox.shrink());\n    }\n  });\n\n")
text = text[:start] + block + text[end:]
save('final-source/' + path, text.encode())

for row in rows:
    row['after'] = identity((ROOT / 'final-source' / row['path']).read_bytes())
    if row['selection'] == 'root_exact_regression_update':
        row['producer_blob'] = row['before']['git_blob']
save('source-mapping.preliminary.json', (json.dumps({
    'schema': 1, 'base': BASE, 'base_tree': tree['tree'],
    'producer': PRODUCER, 'producer_parent': 'e2db0d60af51266caa9b54ffd08eb0947ae99ac6',
    'sources': rows, 'execution': 'NOT_RUN: source checkpoint required',
}, ensure_ascii=False, indent=2) + '\n').encode())

patches = []
for row in rows:
    path = row['path']
    before = (ROOT / 'before' / path).read_text().splitlines(keepends=True) if row['before'] else []
    after = (ROOT / 'final-source' / path).read_text().splitlines(keepends=True)
    patches.extend(difflib.unified_diff(before, after,
        fromfile='a/' + path if row['before'] else '/dev/null', tofile='b/' + path))
save('integration.patch', ''.join(patches).encode())
for label, paths in [('production', products), ('regression-adjustments', old_tests)]:
    changes = []
    for path in paths:
        changes.extend(difflib.unified_diff((ROOT / 'before' / path).read_text().splitlines(keepends=True),
            (ROOT / 'final-source' / path).read_text().splitlines(keepends=True),
            fromfile='a/' + path, tofile='b/' + path))
    save(label + '.patch', ''.join(changes).encode())
print(json.dumps({'sources': len(rows), 'base': BASE, 'producer': PRODUCER,
                  'sources_bytes': sum(row['after']['bytes'] for row in rows),
                  'rows': rows}, ensure_ascii=False, indent=2))
