#!/usr/bin/env python3
"""Freeze source bytes and archive them; never import or execute the tests."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path(__file__).resolve().parent
V1 = Path('/tmp/host-pr508-c4-optin-followup-7ac-20261114')
HOST = '37414d0ceeb6db13ddd2b5bbc64789e3260ac1e5'
TREE = 'a2ab2d1883aa764424e48e3b992cc3d09c3a84e5'


def identity(data):
    return {'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest(),
            'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}


def write(name, value):
    data=(json.dumps(value, ensure_ascii=False, indent=2)+'\n').encode()
    path=ROOT/name
    with path.open('xb') as stream:
        stream.write(data)
    assert path.read_bytes() == data
    return identity(data)


def main():
    base={item['path']:item for item in json.loads(
        (ROOT/'originals/checkpoint37414-tree-leaves.json').read_bytes())}
    publication=json.loads((ROOT/'originals/checkpoint37414-publication.json').read_bytes())
    assert HOST in json.dumps(publication) and TREE in json.dumps(publication)
    files=[]
    for path in sorted((ROOT/'final-source').rglob('*')):
        if not path.is_file():
            continue
        name=path.relative_to(ROOT/'final-source').as_posix()
        before=ROOT/'before'/name
        if before.is_file():
            preimage=identity(before.read_bytes())
            assert preimage['git_blob'] == base[name]['sha']
            assert base[name]['mode'] == '100644'
        else:
            assert name not in base
            preimage=None
        files.append({'path':name, 'mode':'100644', 'before':preimage,
                      'after':identity(path.read_bytes())})
    assert len(files) == 9
    references=[]
    for path in sorted((ROOT/'reference-source').rglob('*')):
        if path.is_file():
            name=path.relative_to(ROOT/'reference-source').as_posix()
            record=identity(path.read_bytes())
            assert record['git_blob'] == base[name]['sha']
            references.append({'path':name, **record})
    static=json.loads((ROOT/'static-preservation.json').read_bytes())
    assert static['planned_total'] == 54 and not static['tests_imported_or_executed']
    source_freeze=write('source-freeze.json', {
        'schema':2, 'status':'SOURCE_FROZEN_NO_TESTS_YET',
        'base_host':HOST, 'base_tree':TREE,
        'historical_product_base':'7ac736fdbd042769592e88de0f9849632242316d',
        'native_unchanged':'f9d9772bb932d7ee8702eeb5bca6d98c286f3b98',
        'files':files, 'unchanged_execution_references':references,
        'v1_preserved':{'path':str(V1), 'freeze':identity((V1/'source-freeze.json').read_bytes()),
                        'manifest':identity((V1/'manifest.json').read_bytes())},
        'readiness_contract':{
            'existing_call':"wait_for_flutter_control(contract.NATIVE_ENTRY, tag + '-native-ready', timeout=30)",
            'existing_global_budget_seconds':900,
            'wait_sends_no_input':True, 'fresh_touch_observations_after_wait':2,
            'report_fields':['native_entry_ready','reopen.native_ready'],
            'offline_replay':'Every readiness PNG/XML/density/reason/target; strict distinct-file and monotonic order from portal through all wait observations to fresh touch and Native.',
        },
        'source_scope':'Nine external source paths only; no checkout/index/ref/workflow/Native/pin mutation.',
        'main_activity_untouched':True, 'tests_executed':False,
    })
    modules=['tools.android_qa.tests.test_connect_four_flutter_navigation',
             'tools.android_qa.tests.test_connect_four_android_evidence',
             'tools.android_qa.tests.test_connect_four_probe_deadlines']
    write('test-plan.json', {
        'status':'PENDING_ROOT_CHECKPOINT',
        'argv':['python3','-B','-m','unittest',*modules,'-v'],
        'cwd':'Exact future published checkpoint checkout',
        'expected_methods_from_static_source':54,
        'navigation_methods':16, 'evidence_methods':27, 'unchanged_deadline_methods':11,
        'original_methods_retained':36, 'new_vs_original':18, 'additional_vs_v1':7,
        'require_actual_exit_zero_no_failures_errors_skips_expected_failures':True,
        'dependencies':['Python standard library','Pillow','tools/android_qa/native_surface_readiness.py'],
        'widget_tests_only_in_future_real_CI':[
            'test/games/connect_four_native_route_test.dart',
            'test/games/connect_four_navigation_test.dart',
            'test/games/games_screen_flow_test.dart'],
        'tests_executed':False,
        'remaining_device_gate':'Actual first entry and reopening via observed enabled opt-in, complete native/save/ACK sequence, one Back and unchanged mailbox/return verification.',
    })
    write('publication-sources.json', {
        'repository':'Ullmann27/lumo-lernen', 'expected_parent':HOST, 'expected_parent_tree':TREE,
        'remote_actions_performed':False,
        'entries':[{'source':str(ROOT/'final-source'/row['path']), 'target':row['path'],
                    'mode':row['mode'], 'old_blob':row['before']['git_blob'] if row['before'] else None,
                    'new_blob':row['after']['git_blob'], 'bytes':row['after']['bytes'],
                    'sha256':row['after']['sha256']} for row in files],
        'note':'C4 preimage is the published PR507 union parent 0927a3b8. Other PR507/Speech paths remain outside this pack. No workflow changes.',
    })
    write('handoff.json', {
        'status':'SOURCE_FROZEN_PENDING_REVIEW_CHECKPOINT_AND_TESTS',
        'base_host':HOST, 'base_tree':TREE, 'source_freeze':source_freeze,
        'source_paths':files,
        'integration_patch':identity((ROOT/'integration.patch').read_bytes()),
        'v1_to_v2_patch':identity((ROOT/'v1-to-v2.patch').read_bytes()),
        'producer_source_binding':identity((ROOT/'producer-1aeb-source-binding.json').read_bytes()),
        'static_preservation':identity((ROOT/'static-preservation.json').read_bytes()),
        'shared_c4_end_blob':'6c9ee29c314bf999349c73da6faf9226ac0f8916',
        'unchanged_from_v1':['lib/features/games/connect_four/lumo_connect_four_game.dart',
                             'test/games/connect_four_native_route_test.dart'],
        'v2_scope':['Existing read-only 30s readiness wait between one portal and fresh native opt-in touch.',
                    'Original readiness fully replayed and ordered; delayed/timeout/no-extra-input and invalid/reused evidence cases.',
                    'Producer 1aeb pump, two-size new navigation test and Nunito-900 caption style only.'],
        'originals_preserved':True, 'no_tests_imported_or_executed':True,
        'pending_python_methods':54, 'no_widget_android_runtime_fps_or_release_claim':True,
        'historical_reviews_only':[
            '/tmp/host-pr507-pr508-c4-union-independent-review-20261114/review.json',
            '/tmp/host-pr508-optin-evidence-independent-review-20261114/review.json'],
        'v2_peer_review':'Requested separately after this freeze; not asserted here.',
    })
    readme='''# PR508 V2: explicit C4 opening with read-only readiness

Nine end-source paths are frozen against published Host 37414d0ceeb6db13ddd2b5bbc64789e3260ac1e5 / Tree a2ab2d1883aa764424e48e3b992cc3d09c3a84e5. No checkout, index, ref, workflow, Native source or pin is changed by this pack. V1 remains in its original directory unchanged.

Both first opening and reopening use one existing portal touch, the unchanged read-only wait_for_flutter_control for “In 3D weiterspielen” with its existing 30-second local limit, then the unchanged fresh two-observation touch helper. The 900-second overall limit remains. No input is sent by the wait. Readiness never substitutes for the later two current touch observations. A missing/disabled control or elapsed limit fails without another portal or native dispatch.

The report explicitly references each readiness JSON. The offline verifier rechecks every wait PNG in full, exact image SHA/dimensions, hierarchy, density-command original, rejected-observation reason and final valid target. It requires the first acceptable wait observation to be final, and all portal/wait/touch files and observation times to be distinct and ordered before the actual native state. Existing source/round/owner/save/ACK/reward/Back/return/mailbox checks are unchanged.

The shared C4 product stays exactly at V1 blob 6c9ee29c314bf999349c73da6faf9226ac0f8916, retaining both PR507 recovery functions. Its actual checkpoint preimage is PR507 blob 0927a3b853e168325e00ebaacc2156a49356ac1e. The existing native-route Widget test also stays byte-identical to V1.

The later published PR508 head 1aeb6879221aa08291f712faef353e0efedd12cc contributes only three selected changes: a pump after the opt-in tap, the complete new navigation test (absent in both our 7ac and 37414 trees; two viewport instances), and the existing 3D-Hub button’s Nunito/w900/14 style. The current Pubspec and actual Nunito-Black Git blob prove that family and weight are present. No older whole Hub, MainActivity, flow test, or producer workflow is substituted.

Source parsing and byte/hash comparisons only have been performed. All 36 original Python test methods are retained. The pending checkpoint run contains 54 methods: 16 navigation, 27 evidence, and 11 unchanged deadlines. Seven methods are additional to V1. The future exact checkpoint test, Widget CI, and real Android reachability/roundtrip acceptance remain open.

integration.patch is against the actual 37414 preimages. v1-to-v2.patch isolates the readiness/producer follow-up. publication-sources.json lists exact local files, repository targets, modes, sizes, SHA256 and old/new Git blobs. The archive is lossless and every member is byte-compared to the local originals. No new test or device success is inferred from these source checks.
'''
    with (ROOT/'README.md').open('x') as stream:
        stream.write(readme)
    excludes={'source-originals.tar.gz','archive-roundtrip.json','manifest.json','SHA256SUMS'}
    paths=[path for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name not in excludes]
    rows=[{'path':path.relative_to(ROOT).as_posix(), **identity(path.read_bytes())} for path in paths]
    archive=ROOT/'source-originals.tar.gz'
    with archive.open('xb') as stream:
        with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as tar:
                for path, row in zip(paths, rows):
                    data=path.read_bytes()
                    item=tarfile.TarInfo(row['path'])
                    item.size=len(data); item.mode=0o644; item.mtime=0
                    tar.addfile(item, io.BytesIO(data))
    with tarfile.open(archive, 'r:gz') as tar:
        members=tar.getmembers()
        assert [item.name for item in members] == [row['path'] for row in rows]
        for item, row, path in zip(members, rows, paths):
            assert item.isfile()
            data=tar.extractfile(item).read()
            assert data == path.read_bytes()
            assert identity(data) == {key:row[key] for key in ('bytes','sha256','git_blob')}
    write('archive-roundtrip.json', {'status':'EVERY_MEMBER_BYTE_EQUAL', 'count':len(rows),
        'members':rows, 'archive':identity(archive.read_bytes()),
        'no_test_engine_or_device_execution':True})
    manifest=write('manifest.json', {'schema':1, 'status':'FROZEN', 'files':[
        {'path':path.relative_to(ROOT).as_posix(), **identity(path.read_bytes())}
        for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name not in ('manifest.json','SHA256SUMS')]})
    data=json.loads((ROOT/'manifest.json').read_bytes())
    sums=''.join(row['sha256']+'  '+row['path']+'\n' for row in data['files'])+manifest['sha256']+'  manifest.json\n'
    with (ROOT/'SHA256SUMS').open('x') as stream:
        stream.write(sums)
    # Re-read the untouched V1 manifest and every member it binds.
    for row in json.loads((V1/'manifest.json').read_bytes())['files']:
        assert identity((V1/row['path']).read_bytes()) == {key:row[key] for key in ('bytes','sha256','git_blob')}
    print(json.dumps({'pack':str(ROOT), 'source_freeze':source_freeze, 'manifest':manifest,
        'handoff':identity((ROOT/'handoff.json').read_bytes()),
        'archive':identity(archive.read_bytes()), 'archive_members':len(rows), 'sources':files}, ensure_ascii=False))


if __name__ == '__main__':
    main()
