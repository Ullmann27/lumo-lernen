# PR508 V2: explicit C4 opening with read-only readiness

Nine end-source paths are frozen against published Host 37414d0ceeb6db13ddd2b5bbc64789e3260ac1e5 / Tree a2ab2d1883aa764424e48e3b992cc3d09c3a84e5. No checkout, index, ref, workflow, Native source or pin is changed by this pack. V1 remains in its original directory unchanged.

Both first opening and reopening use one existing portal touch, the unchanged read-only wait_for_flutter_control for “In 3D weiterspielen” with its existing 30-second local limit, then the unchanged fresh two-observation touch helper. The 900-second overall limit remains. No input is sent by the wait. Readiness never substitutes for the later two current touch observations. A missing/disabled control or elapsed limit fails without another portal or native dispatch.

The report explicitly references each readiness JSON. The offline verifier rechecks every wait PNG in full, exact image SHA/dimensions, hierarchy, density-command original, rejected-observation reason and final valid target. It requires the first acceptable wait observation to be final, and all portal/wait/touch files and observation times to be distinct and ordered before the actual native state. Existing source/round/owner/save/ACK/reward/Back/return/mailbox checks are unchanged.

The shared C4 product stays exactly at V1 blob 6c9ee29c314bf999349c73da6faf9226ac0f8916, retaining both PR507 recovery functions. Its actual checkpoint preimage is PR507 blob 0927a3b853e168325e00ebaacc2156a49356ac1e. The existing native-route Widget test also stays byte-identical to V1.

The later published PR508 head 1aeb6879221aa08291f712faef353e0efedd12cc contributes only three selected changes: a pump after the opt-in tap, the complete new navigation test (absent in both our 7ac and 37414 trees; two viewport instances), and the existing 3D-Hub button’s Nunito/w900/14 style. The current Pubspec and actual Nunito-Black Git blob prove that family and weight are present. No older whole Hub, MainActivity, flow test, or producer workflow is substituted.

Source parsing and byte/hash comparisons only have been performed. All 36 original Python test methods are retained. The pending checkpoint run contains 54 methods: 16 navigation, 27 evidence, and 11 unchanged deadlines. Seven methods are additional to V1. The future exact checkpoint test, Widget CI, and real Android reachability/roundtrip acceptance remain open.

integration.patch is against the actual 37414 preimages. v1-to-v2.patch isolates the readiness/producer follow-up. publication-sources.json lists exact local files, repository targets, modes, sizes, SHA256 and old/new Git blobs. The archive is lossless and every member is byte-compared to the local originals. No new test or device success is inferred from these source checks.
