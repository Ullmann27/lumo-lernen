import 'dart:convert';
import 'dart:io';
import 'lib/core/math_task_templates.dart';

void main() {
  const cases = <(int, String)>[
    (2, 'Geld'),
    (3, 'Geometrie Formen'),
    (4, 'Geometrie Formen'),
  ];
  final results = <Map<String, Object?>>[];
  for (final (grade, unit) in cases) {
    final task = MathTaskTemplates.generate(grade: grade, unit: unit, seed: 1);
    results.add({
      'grade': grade,
      'requested_unit': unit,
      'seed': 1,
      'actual_unit': task.unit,
      'actual_difficulty': task.difficulty,
      'actual_pattern': task.promptPattern,
      'exact_topic_preserved': task.unit == unit,
    });
  }
  final failed = results.where((row) => row['exact_topic_preserved'] == false).length;
  stdout.writeln(const JsonEncoder.withIndent('  ').convert({
    'scope': 'Three known cases against the unchanged 0411 math source; isolated original-source RED only',
    'cases': results,
    'checks': results.length,
    'failure_count': failed,
  }));
  if (failed != 0) exitCode = 1;
}
