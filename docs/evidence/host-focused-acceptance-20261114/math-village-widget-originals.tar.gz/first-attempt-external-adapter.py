from pathlib import Path
import subprocess,os,json,time,hashlib,importlib.util,signal
root=Path('/workspace/scratch/b3485b7bb989/math491-bb97-validation-checkout')
out=Path('/workspace/scratch/b3485b7bb989/host-math491-bb97-validation-20261114')
sdk=Path('/workspace/scratch/b3485b7bb989/toolchains/flutter-3.44.9/flutter')
phase='math-flutter';expected=1
cmd=[str(sdk/'bin/flutter'),'test','--no-pub','--machine','--timeout=60s','--concurrency=2','test/math_exact_topic_selection_test.dart']
env=dict(os.environ,CI='true',FLUTTER_SUPPRESS_ANALYTICS='true',DART_SUPPRESS_ANALYTICS='true',PUB_CACHE='/workspace/scratch/b3485b7bb989/toolchains/flutter-3.44.9/pub-cache',GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1')
env['PATH']=str(sdk/'bin')+os.pathsep+env['PATH']
start=time.monotonic();timedout=False
with (out/(phase+'.stdout.jsonl')).open('xb') as stdout,(out/(phase+'.stderr.log')).open('xb') as stderr:
 process=subprocess.Popen(cmd,cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 try:code=process.wait(timeout=300)
 except subprocess.TimeoutExpired:
  timedout=True;os.killpg(process.pid,signal.SIGKILL);code=process.wait()
events=[];nonjson=[]
raw=(out/(phase+'.stdout.jsonl')).read_bytes();err=(out/(phase+'.stderr.log')).read_bytes()
for line in raw.decode().splitlines():
 if not line.strip():continue
 try:events.append(json.loads(line))
 except json.JSONDecodeError:nonjson.append(line)
spec=importlib.util.spec_from_file_location('lumo_original_flutter_summary',root/'scripts/run_full_flutter_acceptance.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
summary=module.summarize(events,code,[])
result={'phase':phase,'source':'bb97ab6b2e563f3662f1ce5e6141e95cf62d79a7','tree':'e2db771277ed3d181ed34410a7a736252bcdf0df','argv':cmd,'cwd':str(root),'expected_visible_cases':expected,'elapsed_seconds':round(time.monotonic()-start,3),'timed_out':timedout,'summary':summary,'exact_count_matches':summary['passed']==expected,'stdout_sha256':hashlib.sha256(raw).hexdigest(),'stderr_sha256':hashlib.sha256(err).hexdigest(),'non_json_stdout_lines':nonjson,'events':len(events),'device_run':False}
result['status']='PASS' if summary['status']=='PASS' and result['exact_count_matches'] and not timedout else 'FAIL'
(out/(phase+'-result.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
