# Math491 and Village focused Flutter validation on bb97

Source: bb97ab6b2e563f3662f1ce5e6141e95cf62d79a7, tree e2db771277ed3d181ed34410a7a736252bcdf0df. This pack never substitutes later Host commits.

## Actual outcomes
- Isolated unchanged 0411 Math source: the three known topic-selection counterexamples each fail, actual Dart exit 1.
- Published bb97 shared production Dart contract: actual exit 0, 29,845 checks, 3,955 template calls, 4,640 factory calls, no failures.
- Official pinned Flutter 3.44.9 / Dart 3.12.2 and strict pub resolution: actual exit 0; pubspec and lockfile unchanged. The separately frozen complete Dart/pub pack is referenced under completed-dart-pub-reference.
- One authorized combined Flutter follow-up: exactly 9 visible tests passed, no failures or skips, actual exit 0, 22.867 seconds. These are one Math contract, two Village routing cases and six Village capture cases. Six original PNGs were fully decoded and hashed; no human visual review is asserted.
- The optional Feature22 rerun was not executed.

## First attempt and narrow evidence repair
The first Math-only Flutter execution emitted one successful visible test plus a successful final done event. The external evidence adapter mistakenly passed an auxiliary Flutter JSON array into the unchanged repository summarize() and raised AttributeError before persisting the child exit. Its original stdout/stderr, exact adapter source and honest INCOMPLETE_EXECUTION_RECEIPT record remain included. The child exit is unknown; it is not reconstructed or reported as a complete process PASS.

Root authorized one combined follow-up of the same Math test and eight Village cases. The corrected external driver persists the actual child exit, timestamps and raw stream hashes before parsing. It passes only dictionary events to the unchanged summarize(), exactly as the repository's own runner already does, and retains all auxiliary JSON values. No project source or test expectation was changed.

## Preservation and limits
All 2,327 materialized tracked files and 4,383 logical index paths, HEAD, tree, raw index and empty Git status are exactly equal before setup and after all tests. Complete original streams and source inventories are included.

The Village tests use the actual Flutter widgets with a mocked native bridge. Their successful routing assertions and PNGs do not establish Android entry/return, native runtime behavior, audio, FPS or semantic visual acceptance. Package/SDK archives and caches remain outside this compact pack. No Git index, ref, product source, pin or active CI was changed.

manifest.json inventories every original member in compact-originals.tar.gz, except the manifest itself which is also archived. archive-binding.json records a full byte-for-byte reread of every archive member. The already frozen Dart/pub archive is not duplicated; its exact hash and path are retained.
