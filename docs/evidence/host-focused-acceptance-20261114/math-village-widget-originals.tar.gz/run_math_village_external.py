from pathlib import Path
import subprocess,os,json,time,hashlib,importlib.util,signal,datetime,sys
root=Path('/workspace/scratch/b3485b7bb989/math491-bb97-validation-checkout')
out=Path('/workspace/scratch/b3485b7bb989/host-math491-bb97-validation-20261114')
sdk=Path('/workspace/scratch/b3485b7bb989/toolchains/flutter-3.44.9/flutter')
phase='math-village-focused'
expected=9
captures=out/'village-captures'
captures.mkdir(exist_ok=False)
cmd=[str(sdk/'bin/flutter'),'test','--no-pub','--machine','--timeout=60s','--concurrency=2','test/math_exact_topic_selection_test.dart','test/games/dorfwirtschaft_portal_test.dart','test/design/dorfwirtschaft_spielewelt_capture_test.dart']
env=dict(os.environ,CI='true',BOT='true',FLUTTER_SUPPRESS_ANALYTICS='true',DART_SUPPRESS_ANALYTICS='true',PUB_CACHE='/workspace/scratch/b3485b7bb989/toolchains/flutter-3.44.9/pub-cache',GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1',LUMO_VILLAGE_CAPTURES=str(captures),LUMO_GESTURE_ASSET_ROOT=str(root))
env['PATH']=str(sdk/'bin')+os.pathsep+env['PATH']
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,obj):
 p=out/name
 with p.open('x',encoding='utf8') as f:
  json.dump(obj,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
started=datetime.datetime.now(datetime.timezone.utc).isoformat();start=time.monotonic();timedout=False
with (out/(phase+'.stdout.jsonl')).open('xb') as stdout,(out/(phase+'.stderr.log')).open('xb') as stderr:
 process=subprocess.Popen(cmd,cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 try:code=process.wait(timeout=600)
 except subprocess.TimeoutExpired:
  timedout=True;os.killpg(process.pid,signal.SIGKILL);code=process.wait()
elapsed=round(time.monotonic()-start,3)
raw=(out/(phase+'.stdout.jsonl')).read_bytes();err=(out/(phase+'.stderr.log')).read_bytes()
receipt={'phase':phase,'source':'bb97ab6b2e563f3662f1ce5e6141e95cf62d79a7','tree':'e2db771277ed3d181ed34410a7a736252bcdf0df','started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':cmd,'cwd':str(root),'environment_controls':{k:env[k] for k in ['CI','BOT','FLUTTER_SUPPRESS_ANALYTICS','DART_SUPPRESS_ANALYTICS','PUB_CACHE','GIT_OPTIONAL_LOCKS','GIT_NO_LAZY_FETCH','LUMO_VILLAGE_CAPTURES','LUMO_GESTURE_ASSET_ROOT']},'exit_code':code,'elapsed_seconds':elapsed,'timed_out':timedout,'stdout':{'path':phase+'.stdout.jsonl','bytes':len(raw),'sha256':sha(raw)},'stderr':{'path':phase+'.stderr.log','bytes':len(err),'sha256':sha(err)},'receipt_persisted_before_parsing':True}
write(phase+'-execution.json',receipt)
try:
 events=[];aux=[];nonjson=[]
 for n,line in enumerate(raw.decode().splitlines(),1):
  if not line.strip():continue
  try:obj=json.loads(line)
  except json.JSONDecodeError:nonjson.append({'line':n,'text':line});continue
  if isinstance(obj,dict):events.append(obj)
  else:aux.append({'line':n,'type':type(obj).__name__,'value':obj})
 spec=importlib.util.spec_from_file_location('lumo_original_flutter_summary',root/'scripts/run_full_flutter_acceptance.py')
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 capture_errors=sorted(str(p.relative_to(out)) for p in captures.rglob('*.error.txt'))
 summary=module.summarize(events,code,capture_errors)
 names={x['test']['id']:x['test']['name'] for x in events if x.get('type')=='testStart'}
 visible=[{'name':names.get(x['testID'],str(x['testID'])),'result':x.get('result'),'skipped':x.get('skipped')} for x in events if x.get('type')=='testDone' and not x.get('hidden')]
 pngs=[]
 from PIL import Image
 for p in sorted(captures.rglob('*.png')):
  b=p.read_bytes()
  with Image.open(p) as im:dim=im.size;im.verify()
  pngs.append({'path':str(p.relative_to(out)),'bytes':len(b),'sha256':sha(b),'dimensions':list(dim),'decode_checked':True,'human_visual_review':False})
 result={'execution_receipt':phase+'-execution.json','execution_receipt_sha256':sha((out/(phase+'-execution.json')).read_bytes()),'summary':summary,'expected_visible_cases':expected,'visible_cases':visible,'exact_count_matches':summary['passed']==expected and len(visible)==expected,'capture_pngs':pngs,'required_capture_count':6,'exact_capture_count_matches':len(pngs)==6,'auxiliary_json_values':aux,'non_json_stdout_lines':nonjson,'parser_behavior':'Only dictionary test events are passed to unchanged repository summarize(), matching its existing main(); all auxiliary values remain in the original stdout and this report.','scope':'One Math contract plus two Village routing tests and six actual Flutter widget captures. Native bridge is mocked in these tests; no Android/device/native-runtime acceptance.','feature_22_run':'NOT_RUN; optional broad rerun omitted per Root instruction.'}
 result['status']='PASS' if summary['status']=='PASS' and result['exact_count_matches'] and result['exact_capture_count_matches'] and not timedout else 'FAIL'
 write(phase+'-result.json',result)
 print(json.dumps({'status':result['status'],'exit_code':code,'elapsed_seconds':elapsed,'summary':summary,'visible_cases':visible,'capture_count':len(pngs),'stdout_sha256':sha(raw),'stderr_sha256':sha(err)},ensure_ascii=False),flush=True)
except Exception as exc:
 write(phase+'-adapter-error.json',{'type':type(exc).__name__,'message':str(exc),'execution_receipt_preserved':True})
 raise
