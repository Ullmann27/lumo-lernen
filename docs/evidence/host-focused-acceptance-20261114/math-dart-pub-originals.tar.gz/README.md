# Math491: original Dart RED, current Dart contract and strict pub resolution

This is an independent frozen evidence pack for Host bb97ab6b2e563f3662f1ce5e6141e95cf62d79a7 / tree e2db771277ed3d181ed34410a7a736252bcdf0df.

The unchanged 0411 Math source was executed only in an isolated RED view: all three known topic-selection cases failed, actual exit 1. The published bb97 shared Dart contract then completed with actual exit 0: 29,845 checks, 3,955 template calls, 4,640 factory calls, 145 cumulative topics, no failures.

Flutter 3.44.9 / Dart 3.12.2 was obtained from the official release index and verified against the exact official SDK archive checksum before extraction. The actual strict pub command completed with exit 0 in 499.368 seconds. Both pubspec and lockfile remained byte-identical; all 104 resolved package roots exist.

Original stdout and stderr remain separate and unchanged. All 2,327 materialized tracked files and all 4,383 logical index entries, HEAD, tree, raw index and empty Git status compare exactly before and at this freeze. Pure Dart transitive local source inputs and both pub manifests are included.

This is not a widget, renderer, device, audio or Android acceptance. The separate first widget execution has successful test-stream events but an unavailable child exit because its external evidence adapter failed; that original stays outside this already-complete Dart/pub scope.

compact-originals.tar.gz contains every file listed by manifest.json. archive-binding.json records a complete byte-for-byte reread. No product file, Git index, branch, pin or active CI run was changed by this packaging.
