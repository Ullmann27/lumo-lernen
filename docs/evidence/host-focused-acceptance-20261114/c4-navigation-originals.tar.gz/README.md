# Actual adb88 C4 navigation targeted validation

Exact published source adb88bef880861e23b451166c04ee7d28c96a95d / tree f027cfbefe935835b6b80f34843e2b5297816cee was checked out in a separate detached sparse worktree. The authorized command ran exactly once: the three C4 evidence, observation-deadline and new Flutter-navigation unittest modules. All 36 methods passed (17 + 11 + 8), with zero errors, failures or skips. Complete raw stdout/stderr, actual subprocess exit status, timestamps and exact environment/command are preserved.

All 4,421 indexed source paths, 629 materialized tracked files, HEAD, tree, raw index SHA256, status and sparse flags were identical before and after. The 3,792 deliberately absent sparse paths are explicitly listed, not represented as materialized files. The three active source files match the unchanged 4b5f7a62 source freeze, including their exact published Producer blobs.

The Python/Pillow environment is recorded. The original stderr includes one Pillow getdata deprecation warning before that method's separate ok line; the complete original stream remains unchanged. There was no second test run, baseline rerun, actionlint, Android device, OCR, renderer, APK build, CI activation or product edit. These tests use explicit synthetic clock/device boundaries and do not establish a real C4 device return. The separate actual Boru repair/old failure and its 70-method validation remain in their own unchanged original packs.

The compact archive preserves all result metadata and original logs, excluding the disposable checkout and existing image archives. Every archive member was reread and compared byte-for-byte with its source.
