# Native173 Dream: separate source connection review

This read-only review compares published PR173 `454e81229b0193cba75844e9985a53deb2ce5c91` / tree `ab886683d8bc1ef86f2fff5e154a6dcb654ffb21` with current `f052c2795b765265dbb6f5c27b9e92b557d39a39` / tree `35492eec16cac6774bc546b6e57628900bef61cb`.

The three existing entry-point patches apply without conflict in an external snapshot and produce exactly the published Git blobs. The proposed follow-up contains9 runtime/provenance files (including two GLBs) and4 supplied probes/captures. The13 text references stored here are exact published bytes reconstructed from complete original Compare patches and independently Git-blob verified; they include the optional asset generator and reference-only harness. No repository source has been edited. The two GLB bodies and Blender design files are deliberately not copied; their published blob identities and declared provenance hashes are listed without claiming a fresh payload verification.

## Preserve current integrations

Keep the current PR174 Wisp implementation, C4 return, learning product,52-mode runner and17-raster helper/test contract. Several PR173 paths are already byte-identical; the old Wisp component and test differ and must not replace the current versions. In particular, the Producer nine-call wrapper expects rendered Wisp18, while the current unchanged f052 probe emits14 checks. That wrapper is a reference only. Five of its calls are the new Dream checks: two headless probes and three rendered invocations producing7 PNGs.

## Dependencies and remaining evidence

The24 direct resource edges resolve to18 unique existing or proposed sources. Existing quality, event, host bridge, scene router and production entry points are hash-bound in dependency-bindings.json. No missing direct dependency was found. The saved exact-head CI list is empty; no new run was queried. Published developer notes are not promoted to current integration acceptance.

Future validation needs the actual combined source import, the two supplied headless regressions and real render captures. The supplied garden captures fix1280x720,412x915 and2400x1080. The two ambience image pairs report their actual dimensions; the reference harness checks equal size, decoded/nonuniform/different pixels and advancing animation time. No new image has been viewed or rendered in this review. No Android, frame-rate, completed52-mode or visual acceptance is asserted. The earlier f052 validation remains a separate immutable checkpoint.

All writes were confined to this external review directory. No test, Git mutation, source change, download or CI action was performed.
