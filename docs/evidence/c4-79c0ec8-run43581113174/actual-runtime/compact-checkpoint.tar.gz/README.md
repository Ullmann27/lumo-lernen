# C4 runtime checkpoint — Host 79c0ec86 / Native f052c279

This compact pack records the completed `connect-four-runtime` job 132405832474 from pull-request run 43581113174, attempt 1. The actual job completed successfully at 2026-11-14 09:36:16 UTC. The single original run snapshot was still in progress. This checkpoint makes no conclusion about the other build or Android jobs.

## Exact source and actual result

- Host: `79c0ec868d6a6236eb2ae942d18251d0ed96379f`, tree `e70dccc439c99a1bc2e8546f552a7886b8838225`.
- Native: `f052c2795b765265dbb6f5c27b9e92b557d39a39`, tree `35492eec16cac6774bc546b6e57628900bef61cb`.
- The real Dart and Godot processes both exited 0. The original gate and native report contain 170 native checks, 250 captured frames, 90 observed moving frames, and 43 winning frames. All 259 PNGs (250 frames and nine named captures) fully decoded and matched the actual runtime image report.
- The original Dart report records a human/bot sequence and reopening the same round. Its boundary is the production Dart controller with test SharedPreferences and local-file transport. It does not establish Android Binder, device storage, physical touch, or Android FPS.
- The two separate original headless gates report `CONNECT_FOUR_RETURN_PASS checks=21` and `[TreasureWisp] PASS checks=14`, each with its actual Godot engine banner.
- The before/after source fingerprints are byte-identical, SHA256 `3a945a26fee45206284355936ef8bd65766f67a390fa7ecba9801c62c4ea8f82`. Their recorded scope is 447 Host files and 1,246 Native files.
- Six artifact log files were checked for the explicitly recorded engine error/leak patterns. None matched. Original rendering capability warnings remain in the full logs.

## What is included

The pack contains the full original runtime job output (lossless deterministic gzip), original run/jobs/artifacts JSON, 25 exact artifact text/log/JSON members (large members losslessly compressed), source fingerprints, all nine layout sidecars, complete archive and PNG identities, the frozen current installer, official Godot release/tag/commit metadata, and the derived verification reports. `original-materialization.json` and `transport-index.json` map compressed bytes back to original paths, sizes and SHA256 values. No original log is shortened or filtered.

The original artifact `14108381749` is 22,151,623 bytes, SHA256 `575b4ecf1bb4ae372ec79bf0c744706506a2c209c99b323ea28bf5e491b05639`. All 399 members were read and CRC/SHA256 checked. The complete ZIP remains outside this compact transport at `/tmp/host-c4-79c0ec86-runtime-evidence-20261114/14108381749-original.zip`. PNG and shader-cache binary payloads are not duplicated in this pack. Their complete member identities remain in `archive-verification.json` and `png-index.json`.

## Six originals selected for Root's visual review

`review-selection.json` binds six byte-exact selected originals to this new archive, Host and Native revision. The separate `review-images/` directory contains the empty board, phone portrait after bot response, compact landscape, fold landscape, pause and winning-round images. Selection is not a visual approval receipt. The archive has no separately named post-return Flutter screenshot or Wisp scene capture; the return and reopen evidence must not be relabeled as such an image.

## Actual binary and renderer boundary

The current strict installer pins the official Linux x86_64 release archive SHA256 `d0bc2113065e481c9c2c2b2c37daa4e8be3fe9e27f0ab9ab0b6096e9a37907f3`. The actual CI download/install succeeded and reported `4.6.3.stable.official.7d41c59c4`. The official `godotengine/godot-builds` release asset metadata has that same archive digest. No second local engine download is claimed.

The source-repository tag resolves to `35e80b3a8822a9df9be390814b62f44c0a9c69e8`, while the release-metadata repository tag resolves to `4aa5b4950f650adc0aac8cb465479570b60c8122`. Both retrieved refs directly target commits, so there is no annotated-tag peeling step in these responses. These repository identities are not interchangeable with the binary's embedded banner. The exact build-source mapping of `7d41c59c4` remains unresolved; this difference alone is not evidence of an unofficial binary.

The current successful renderer is desktop Mesa/llvmpipe under Xvfb. The historical Android SwiftShader uniform-link failures and actual GMS ANRs remain separate failed observations. No shader parameter, renderer configuration, product source, Git reference or CI run was changed. No result from the former 682 run is reused here.
