extends SceneTree

const NOTICE_PATHS := [
	"assets/characters/lumo_facial/ATTRIBUTION.md",
	"assets/characters/lumo_animated/ATTRIBUTION.md",
	"THIRD_PARTY_NOTICES.md",
]

func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size() != 2:
		push_error("Exactly one PCK path and one evidence directory are required")
		quit(2)
		return
	var pack_path: String = args[0]
	var output_path: String = args[1]
	var report := {"engine": Engine.get_version_info(), "pack": pack_path,
		"pack_sha256": FileAccess.get_sha256(pack_path), "before_load": [], "members": []}
	for relative_path: String in NOTICE_PATHS:
		var exists_before := FileAccess.file_exists("res://" + relative_path)
		report["before_load"].append({"path": relative_path, "exists": exists_before})
		if exists_before:
			push_error("Inspection project contains a notice before PCK loading")
			quit(2)
			return
	var loaded := ProjectSettings.load_resource_pack(pack_path, true)
	report["pack_loaded"] = loaded
	if not loaded:
		push_error("Actual PCK loading failed")
		quit(2)
		return
	for relative_path: String in NOTICE_PATHS:
		var packed_path := "res://" + relative_path
		var member := {"path": relative_path, "resource_path": packed_path,
			"present": FileAccess.file_exists(packed_path)}
		if member["present"]:
			var bytes := FileAccess.get_file_as_bytes(packed_path)
			if FileAccess.get_open_error() != OK:
				push_error("PCK member read failed: " + relative_path)
				quit(2)
				return
			member["bytes"] = bytes.size()
			member["sha256"] = FileAccess.get_sha256(packed_path)
			var destination := output_path.path_join(relative_path.replace("/", "__"))
			var file := FileAccess.open(destination, FileAccess.WRITE)
			if file == null:
				push_error("Evidence member write failed")
				quit(2)
				return
			file.store_buffer(bytes)
			file.close()
			member["extracted_original"] = destination
		report["members"].append(member)
	var report_file := FileAccess.open(output_path.path_join("pack-notices.json"), FileAccess.WRITE)
	if report_file == null:
		push_error("Inspection report write failed")
		quit(2)
		return
	report_file.store_string(JSON.stringify(report, "\t") + "\n")
	report_file.close()
	print("PACKAGING_NOTICE_INSPECTION_COMPLETE entries=3")
	quit(0)
