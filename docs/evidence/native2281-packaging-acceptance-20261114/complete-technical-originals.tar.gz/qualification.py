#!/usr/bin/env python3
"""One authorized Android-PCK qualification, with original process outputs."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import stat
import subprocess
import sys

ENGINE = Path('/opt/godot/4.6.3/Godot_v4.6.3-stable_linux.x86_64')
ENGINE_SHA = 'f64d4ed19fc9df9440321653fcc80df8c6e365ba7b6de0a29e2cfa9fa71bfeb3'
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_NO_LAZY_FETCH='1')


def digest(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()}


def save_json(path, value):
    raw = (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()
    path.write_bytes(raw)
    if path.read_bytes() != raw:
        raise RuntimeError('JSON readback mismatch: ' + str(path))


def git(repo, *args):
    return subprocess.run(['git', '-C', str(repo), *args], env=GIT_ENV,
                          capture_output=True, check=True).stdout


def snapshot(repo, out, label):
    dest = out / label
    dest.mkdir()
    raw_tree = git(repo, 'ls-tree', '-r', '-z', 'HEAD')
    raw_index = git(repo, 'ls-files', '--stage', '-z')
    head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    tree = git(repo, 'rev-parse', 'HEAD^{tree}').decode().strip()
    status = git(repo, 'status', '--porcelain=v1', '--untracked-files=no')
    untracked = git(repo, 'ls-files', '--others', '--exclude-standard', '-z')
    index_path = Path(git(repo, 'rev-parse', '--path-format=absolute', '--git-path', 'index').decode().strip())
    index_bytes = index_path.read_bytes()
    for name, raw in [('tree.z', raw_tree), ('index-stage.z', raw_index),
                      ('index.bin', index_bytes), ('tracked-status.txt', status),
                      ('untracked.z', untracked), ('commit.txt', git(repo, 'cat-file', '-p', 'HEAD'))]:
        (dest / name).write_bytes(raw)
    entries = []
    for row in raw_tree.rstrip(b'\0').split(b'\0'):
        meta, path_bytes = row.split(b'\t', 1)
        mode, kind, blob = meta.decode().split()
        path = path_bytes.decode()
        source = repo / path
        if kind != 'blob' or not source.exists():
            raise RuntimeError('Missing or non-blob tracked source: ' + path)
        raw = os.readlink(source).encode() if source.is_symlink() else source.read_bytes()
        actual_mode = '120000' if source.is_symlink() else ('100755' if source.stat().st_mode & stat.S_IXUSR else '100644')
        identity = digest(raw)
        if identity['git_blob'] != blob or mode != actual_mode:
            raise RuntimeError('Tracked byte/mode mismatch: ' + path)
        entries.append({'path': path, 'mode': mode, **identity})
    result = {'head': head, 'tree': tree, 'index': digest(index_bytes),
              'index_stage': digest(raw_index), 'tracked_status': status.decode(),
              'tracked_count': len(entries), 'tracked': entries,
              'untracked_paths': untracked.decode().rstrip('\0').split('\0') if untracked else []}
    save_json(dest / 'snapshot.json', result)
    return result


def process(out, name, argv, env, budget):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    timed_out = False
    with (out / (name + '.stdout')).open('wb') as stdout, (out / (name + '.stderr')).open('wb') as stderr:
        try:
            p = subprocess.run(argv, stdout=stdout, stderr=stderr, env=env, timeout=budget)
            code = p.returncode
        except subprocess.TimeoutExpired:
            timed_out, code = True, None
    result = {'argv': argv, 'started_at': started,
              'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'exit_code': code, 'timeout_seconds': budget, 'timed_out': timed_out,
              'stdout': digest((out / (name + '.stdout')).read_bytes()),
              'stderr': digest((out / (name + '.stderr')).read_bytes())}
    save_json(out / (name + '.json'), result)
    print(json.dumps({'stage': name, **result}), flush=True)
    if timed_out or code != 0:
        raise RuntimeError('Command failed: ' + name)
    return result


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--repo', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    p.add_argument('--head', required=True)
    p.add_argument('--tree', required=True)
    a = p.parse_args()
    a.output.mkdir(exist_ok=False)
    if hashlib.file_digest(ENGINE.open('rb'), 'sha256').hexdigest() != ENGINE_SHA:
        raise RuntimeError('Unexpected engine binary')
    before = snapshot(a.repo, a.output, 'before')
    if before['head'] != a.head or before['tree'] != a.tree or before['tracked_status'] or before['untracked_paths']:
        raise RuntimeError('Initial source identity or cleanliness mismatch')
    env = dict(os.environ)
    for key, name in [('XDG_DATA_HOME', 'xdg-data'), ('XDG_CONFIG_HOME', 'xdg-config'),
                      ('XDG_CACHE_HOME', 'xdg-cache'), ('TMPDIR', 'tmp')]:
        path = a.output / name
        path.mkdir()
        env[key] = str(path)
    save_json(a.output / 'environment-overrides.json', {k:env[k] for k in ['XDG_DATA_HOME','XDG_CONFIG_HOME','XDG_CACHE_HOME','TMPDIR']})
    failure = None
    stages = []
    try:
        stages.append(process(a.output, 'import', [str(ENGINE), '--headless', '--path', str(a.repo), '--editor', '--import', '--quit'], env, 600))
        imported = snapshot(a.repo, a.output, 'after-import')
        if any(imported[k] != before[k] for k in ['head', 'tree', 'index', 'index_stage', 'tracked_status', 'tracked']):
            raise RuntimeError('Source or index changed during import')
        stages.append(process(a.output, 'export', [str(ENGINE), '--headless', '--path', str(a.repo), '--export-pack', 'Android', str(a.output / 'lumo_game.pck')], env, 600))
    except Exception as exc:
        failure = str(exc)
    after = snapshot(a.repo, a.output, 'after')
    unchanged = all(after[k] == before[k] for k in ['head', 'tree', 'index', 'index_stage', 'tracked_status', 'tracked'])
    generated = []
    for path in after['untracked_paths']:
        f = a.repo / path
        generated.append({'path':path, **digest(f.read_bytes())})
    save_json(a.output / 'generated-untracked.json', generated)
    result = {'head':a.head,'tree':a.tree,'source_and_index_unchanged':unchanged,
              'completed_import_and_export': len(stages) == 2, 'error':failure,
              'no_render_or_device_test':True,'generated_untracked_count':len(generated),
              'pack':digest((a.output / 'lumo_game.pck').read_bytes()) if (a.output / 'lumo_game.pck').exists() else None}
    save_json(a.output / 'qualification.json', result)
    print(json.dumps(result), flush=True)
    return 0 if failure is None and unchanged and len(stages) == 2 else 1


if __name__ == '__main__':
    sys.exit(main())
