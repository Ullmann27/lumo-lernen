# Getrennter Dorf-Android-Vorschlag, V2

Basis ist Host a118409930ecdf605743382051e88f7e0898b8e9. Die drei ursprünglichen Quellen stammen exakt aus veröffentlichtem Host-PR497 / 07cac7225e2f7b6451665dfda9c38841f51c758b. original-source/ und producer-source-freeze.json erhalten diese Bytes unverändert.

final-source/ enthält nur:
- .github/probes/lumo_village_android_probe.py
- tools/android_qa/village_android_evidence.py
- tools/android_qa/tests/test_village_android_evidence.py

Alle drei Pfade fehlen noch in der festen Host-Basis. source-freeze-v2.json bindet die vollständigen Enddateien und die vorhandenen Abhängigkeiten. Für die neue Kombination wurde kein Test, Import der Probe, Emulator oder Geräteaufruf ausgeführt.

## Enger V2-Fix

Der veröffentlichte await_processes-Helper prüfte seine lokale Frist nur vor dem Prozessabruf. Mehrere echte ADB-Abfragen konnten danach die lokale Frist überschreiten, obwohl das globale 900-Sekunden-Budget noch frei war. V2 speichert ausschließlich das beobachtete Ergebnis zwischen, weist eine Ankunft bei time.monotonic() >= deadline ab und gibt erst danach dasselbe Ergebnis zurück. Die Grenze entspricht dem vorhandenen aktuellen C4-Rückweg.

Alle übrigen Probe-Methoden, die globale 900-Sekunden-Prüfung, ursprünglichen Fehlerzweige und der vollständige Verifier sind unverändert. Die 31 ursprünglichen synthetischen Testmethoden sind AST-identisch. Drei neue Methoden rufen die tatsächliche await_processes-Funktion mit simulierter Prozessantwort und Uhr auf: verspätet, exakt an der Frist, unmittelbar davor, jeweils für 60 Sekunden Flutter und 90 Sekunden Native. Die 34 Methoden sind bisher nur statisch gezählt, nicht ausgeführt. Es wird kein RED oder GREEN behauptet.

## Echte spätere Android-Abnahme

Die Probe setzt den bestehenden vollständigen erfolgreichen Main-Tour-Bericht derselben 2020-APK voraus. Sie bindet ursprüngliche Run-/Job-/Artifactdaten, APK-/PCK-/Signer-/Host-/Native-Identität, die API35-Version, den semantischen Portaltouch, die beobachtete Native-PID und das initialisierte profilspezifische Dorf.

Der Originalverifier verlangt ursprüngliche PNG-/OCR-/TSV-/ADB-Daten, genau eine sichtbare Rückgabe nach zwei stabilen Beobachtungen, eine frische games-Bestätigung, das Ende des Nativeprozesses, denselben wieder sichtbaren Flutterprozess und unveränderte Lern-/Profil-/Belohnungs-/Kinderdaten. Gemeldetes PASS allein reicht nicht. Es gibt keine physische ARM64-, FPS-, Audio- oder Releasefreigabe.

Die native Dorfroute muss mit afc0df9 oder einem ausdrücklich bestätigten Nachfolger verbunden werden. Die noch bestehende Basis-Pinkonfiguration wird hier weder geändert noch als afc0df9 ausgegeben.

## Gemeinsame Gates bleiben bei Root

reference-only-upstream-gate-hunks.txt enthält ausschließlich die Originalhunks für:
1. Ausführung nach erfolgreicher Haupttour und vor der bestehenden C4-Tour.
2. Pflichtprüfung von village-result.json einschließlich SHA der vorherigen Haupttour.
3. Unveränderte Originalkopie VILLAGE-ANDROID-RESULT.json im Deliverypaket.
4. Die dazugehörigen Candidate-/Delivery-Gegenfälle.

Diese Hunkdatei ist kein anwendbarer Endpatch auf den inzwischen erweiterten Discovery-Stand. Keine konkurrierenden Workflow-, Candidate- oder Delivery-Enddateien sind in diesem Pack enthalten.

Nach Root-Checkpoint lautet der gezielte Vertragstest:
python3 -m unittest discover -s tools/android_qa/tests -p test_village_android_evidence.py -v

Die endgültige CI-Kommandozeile muss die vorhandene Python/Pillow-Umgebung verwenden. 34 erfolgreiche synthetische Methoden würden weiterhin keinen Android-Rundweg ersetzen.
