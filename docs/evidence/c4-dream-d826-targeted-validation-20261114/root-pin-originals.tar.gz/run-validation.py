from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

REPO = Path('/tmp/lumo-root-recovery-1105/host-c4')
OUT = Path('/tmp/host-d826-pin-targeted-validation-20261114')
OUT.mkdir(exist_ok=False)
ENV = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'GIT_OPTIONAL_LOCKS': '0',
       'GIT_NO_LAZY_FETCH': '1', 'GIT_TERMINAL_PROMPT': '0',
       'PYTHONPATH': str(REPO / 'tools/android_qa/tests') + os.pathsep + str(REPO)}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, env=ENV)


def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()}


def state():
    names = ['config/godot-source.json', 'scripts/verify_legacy_release_pin.py',
             'scripts/tests/test_candidate_2011_pin.py', 'scripts/tests/test_legacy_release_pin.py',
             'tools/android_qa/tests/test_update_2019_preservation.py',
             'tools/android_qa/tests/test_kart_garage_evidence.py',
             '.github/probes/modernization_android_tour.py',
             '.github/workflows/lumo-connect-four-2020.yml',
             'scripts/verify_connect_four_delivery.py', 'scripts/tests/test_connect_four_delivery.py']
    return {'head': git('rev-parse', 'HEAD').decode().strip(),
            'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
            'index_sha256': hashlib.sha256(git('ls-files', '--stage', '-z')).hexdigest(),
            'status': git('status', '--porcelain=v1', '--untracked-files=all').decode(),
            'sources': {name: identity(REPO / name) for name in names}}


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


before = state()
assert before['head'] == 'd826ce4e11879bc797f7d96c0a7e2c966e0773f7'
assert before['tree'] == '7269a76137233bf16149e8fb89b612ba06a77668'
assert before['status'] == ''
save('source-before.json', before)
command = [sys.executable, '-m', 'unittest',
           'scripts.tests.test_candidate_2011_pin',
           'scripts.tests.test_legacy_release_pin',
           'tools.android_qa.tests.test_update_2019_preservation.StudioUpdateWrapperExecutionTests',
           'tools.android_qa.tests.test_kart_garage_evidence.CurrentGarageProbeWiringTests.test_continue_requires_touch_then_physical_drive_and_retains_original_evidence',
           '-v']
save('command.json', {'command': command, 'working_directory': str(REPO),
                     'expected_cases': 68, 'executions_authorized': 1})
started = datetime.now(timezone.utc).isoformat()
tick = time.monotonic()
with (OUT / 'unittest.stdout').open('xb') as stdout, (OUT / 'unittest.stderr').open('xb') as stderr:
    result = subprocess.run(command, cwd=REPO, env=ENV, stdout=stdout, stderr=stderr, timeout=180)
elapsed = time.monotonic() - tick
after = state()
save('source-after.json', after)
raw = (OUT / 'unittest.stderr').read_text()
passed = result.returncode == 0 and 'Ran 68 tests in ' in raw and raw.rstrip().endswith('OK')
summary = {'schema': 1, 'host': before['head'], 'tree': before['tree'],
           'started_at': started, 'elapsed_seconds': elapsed, 'exit_code': result.returncode,
           'expected_cases': 68, 'complete_output_confirms_68_passed': passed,
           'source_state_unchanged': before == after,
           'stdout': identity(OUT / 'unittest.stdout'), 'stderr': identity(OUT / 'unittest.stderr'),
           'scope': 'One actual run: 24 candidate pin, 40 legacy pin, 3 real historical-wrapper boundary cases and the repaired one garage case; no engine or Android execution.'}
save('summary.json', summary)
(OUT / 'run-validation.py').write_bytes(Path(__file__).read_bytes())
save('manifest.json', {'schema': 1, 'files': [dict(path=p.relative_to(OUT).as_posix(), **identity(p))
                                           for p in sorted(OUT.rglob('*')) if p.is_file()]})
print(json.dumps(summary, indent=2))
assert passed and before == after, 'Preserved actual validation failure; do not repeat implicitly'
