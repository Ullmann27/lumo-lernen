#!/usr/bin/env python3
"""One authorized targeted validation; all evidence stays outside the checkout."""
from __future__ import annotations

import datetime as dt
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile
import time

ROOT = Path('/tmp/lumo-root-recovery-1105/host-c4')
OUT = Path('/tmp/host-d826-dream-targeted-validation-20261114')
EXPECTED_HEAD = 'd826ce4e11879bc797f7d96c0a7e2c966e0773f7'
EXPECTED_TREE = '7269a76137233bf16149e8fb89b612ba06a77668'
LINT = Path('/workspace/scratch/e0abce7d2838/toolchain/actionlint/actionlint')
ENV = dict(os.environ)
ENV.update(PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0')
ENV['PATH'] = str(Path(sys.executable).parent) + os.pathsep + ENV.get('PATH', '')


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)


def write_json(path, value):
    write(path, encoded(value))


def compressed(path, raw):
    data = gzip.compress(raw, mtime=0)
    write(path, data)
    if gzip.decompress(data) != raw:
        raise RuntimeError('Lossless evidence roundtrip failed')
    return {'path': str(path.relative_to(OUT)), 'bytes': len(data),
            'sha256': digest(data), 'original_bytes': len(raw),
            'original_sha256': digest(raw), 'roundtrip_equal': True}


def git(*args):
    result = subprocess.run(['git', '--no-optional-locks', '-C', str(ROOT), *args],
                            env=ENV, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            check=False)
    if result.returncode or result.stderr:
        raise RuntimeError('Read-only git metadata failed: ' + repr(args) +
                           ' rc=' + str(result.returncode) + ' stderr=' + repr(result.stderr))
    return result.stdout


def file_identity(path):
    info = path.lstat()
    if stat.S_ISLNK(info.st_mode):
        raw = os.fsencode(os.readlink(path))
        return {'bytes': len(raw), 'sha256': digest(raw),
                'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest(),
                'kind': 'symlink', 'filesystem_mode': oct(stat.S_IMODE(info.st_mode))}
    if not stat.S_ISREG(info.st_mode):
        raise RuntimeError('Unexpected materialized source type: ' + str(path))
    sha = hashlib.sha256()
    blob = hashlib.sha1(b'blob ' + str(info.st_size).encode() + b'\0')
    size = 0
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            sha.update(chunk)
            blob.update(chunk)
            size += len(chunk)
    if size != info.st_size:
        raise RuntimeError('Source size changed while hashing: ' + str(path))
    return {'bytes': size, 'sha256': sha.hexdigest(), 'git_blob': blob.hexdigest(),
            'kind': 'regular', 'filesystem_mode': oct(stat.S_IMODE(info.st_mode))}


def snapshot(label):
    target = OUT / label
    target.mkdir()
    head = git('rev-parse', 'HEAD').decode().strip()
    tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
    status_raw = git('status', '--porcelain=v1', '-z', '--untracked-files=all')
    index_path = Path(git('rev-parse', '--git-path', 'index').decode().strip())
    if not index_path.is_absolute():
        index_path = ROOT / index_path
    index_raw = index_path.read_bytes()
    staged = git('ls-files', '--stage', '-z')
    flags_raw = git('ls-files', '-v', '-z')
    flags = {row[2:].decode(): chr(row[0]) for row in flags_raw.split(b'\0') if row}
    inventory = []
    for entry in staged.split(b'\0'):
        if not entry:
            continue
        header, relative = entry.split(b'\t', 1)
        mode, blob, stage = header.decode().split()
        name = relative.decode()
        if stage != '0':
            raise RuntimeError('Unmerged source: ' + name)
        path = ROOT / name
        record = {'path': name, 'index_mode': mode, 'index_blob': blob,
                  'index_flag': flags[name], 'present': path.exists() or path.is_symlink()}
        if record['present']:
            record.update(file_identity(path))
            expected_mode = '120000' if record['kind'] == 'symlink' else ('100755' if path.stat().st_mode & stat.S_IXUSR else '100644')
            if record['git_blob'] != blob or expected_mode != mode:
                raise RuntimeError('Materialized source differs from index: ' + name)
        elif flags[name] != 'S':
            raise RuntimeError('Missing non-sparse source: ' + name)
        inventory.append(record)
    inventory_raw = encoded(inventory)
    result = {'head': head, 'tree': tree, 'status_bytes': len(status_raw),
              'status_sha256': digest(status_raw), 'status_hex': status_raw.hex(),
              'index_path': str(index_path), 'index_bytes': len(index_raw),
              'index_sha256': digest(index_raw), 'index_entries': len(inventory),
              'materialized_sources': sum(x['present'] for x in inventory),
              'skip_worktree_sources': sum(x['index_flag'] == 'S' for x in inventory),
              'source_inventory_bytes': len(inventory_raw),
              'source_inventory_sha256': digest(inventory_raw)}
    compressed(target / 'source-inventory.json.gz', inventory_raw)
    compressed(target / 'ls-files-stage.original.gz', staged)
    compressed(target / 'ls-files-flags.original.gz', flags_raw)
    write(target / 'status.original', status_raw)
    write_json(target / 'git-and-source-binding.json', result)
    return result


def invoke(label, argv):
    result_path = OUT / (label + '-result.json')
    if result_path.exists():
        raise RuntimeError('Refusing repeated authorized command: ' + label)
    start = now()
    tick = time.monotonic()
    print(label + ' START ' + start, flush=True)
    with (OUT / (label + '.stdout.log')).open('xb') as stdout, (OUT / (label + '.stderr.log')).open('xb') as stderr:
        completed = subprocess.run(argv, cwd=ROOT, env=ENV, stdout=stdout, stderr=stderr,
                                   check=False)
    elapsed = time.monotonic() - tick
    result = {'argv': argv, 'cwd': str(ROOT), 'started_at_utc': start,
              'finished_at_utc': now(), 'elapsed_seconds': elapsed,
              'exit_code': completed.returncode, 'environment_overrides': {
                  'PYTHONDONTWRITEBYTECODE': '1', 'GIT_OPTIONAL_LOCKS': '0',
                  'PATH_prefix': str(Path(sys.executable).parent)}}
    for stream in ['stdout', 'stderr']:
        path = OUT / (label + '.' + stream + '.log')
        raw = path.read_bytes()
        result[stream] = {'path': path.name, 'bytes': len(raw), 'sha256': digest(raw)}
    write_json(result_path, result)
    print(label + ' END exit=' + str(completed.returncode) + ' elapsed=' + str(elapsed), flush=True)
    return result


def main():
    if set(p.name for p in OUT.iterdir()) != {'run_validation.py'}:
        raise RuntimeError('Evidence directory is not fresh; refusing to overwrite or rerun')
    if ENV.get('LUMO_C4_REFERENCE_HOST') not in (None, str(ROOT)):
        raise RuntimeError('Unexpected external reference host')
    write_json(OUT / 'environment.json', {
        'python_executable': sys.executable, 'python_version': sys.version,
        'python_binary': file_identity(Path(sys.executable).resolve()),
        'actionlint_path': str(LINT), 'actionlint_binary': file_identity(LINT),
        'platform': sys.platform, 'test_scope': 'Exactly two unittest modules and one workflow lint',
        'local_engine_renderer_device_runs': 0})
    before = snapshot('before')
    if before['head'] != EXPECTED_HEAD or before['tree'] != EXPECTED_TREE or before['status_bytes']:
        raise RuntimeError('Unexpected published source or dirty checkout')
    if before['materialized_sources'] != 1843 or before['skip_worktree_sources'] != 2438:
        raise RuntimeError('Unexpected sparse materialization boundary')
    print('BOUND ' + before['head'] + ' materialized=' + str(before['materialized_sources']), flush=True)
    test = invoke('unittest', [sys.executable, '-m', 'unittest',
                  'scripts.tests.test_connect_four_delivery',
                  'scripts.tests.test_connect_four_pipeline', '-v'])
    lint = invoke('actionlint', [str(LINT), '.github/workflows/lumo-connect-four-2020.yml'])
    after = snapshot('after')
    unchanged = before == after
    stderr = (OUT / 'unittest.stderr.log').read_text()
    ran = re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s$', stderr, re.M)
    statuses = re.findall(r'^(test_\S+) \((scripts\.tests\.test_connect_four_(delivery|pipeline)\.[^)]+)\) \.\.\. (.+)$', stderr, re.M)
    module_counts = {name: sum(row[2] == name for row in statuses) for name in ['delivery', 'pipeline']}
    failure_summary = re.findall(r'^FAILED \(([^\n]+)\)$', stderr, re.M)
    summary = {'reported_run_summaries': [{'tests': int(a), 'unittest_seconds': float(b)} for a, b in ran],
               'individual_case_lines': len(statuses), 'module_counts': module_counts,
               'ok_cases': sum(row[3] == 'ok' for row in statuses),
               'skipped_cases': sum(row[3].startswith('skipped') for row in statuses),
               'failure_cases': sum(row[3] == 'FAIL' for row in statuses),
               'error_cases': sum(row[3] == 'ERROR' for row in statuses),
               'raw_failure_summaries': failure_summary,
               'plain_ok_footer': bool(re.search(r'^OK$', stderr, re.M))}
    write_json(OUT / 'test-counts.json', summary)
    passed = (test['exit_code'] == 0 and lint['exit_code'] == 0 and unchanged
              and len(ran) == 1 and int(ran[0][0]) == 67
              and module_counts == {'delivery': 56, 'pipeline': 11}
              and summary['ok_cases'] == 67 and summary['skipped_cases'] == 0
              and summary['plain_ok_footer'])
    handoff = {'schema': 1, 'status': 'PASS' if passed else 'FAIL',
               'host': EXPECTED_HEAD, 'tree': EXPECTED_TREE, 'root': str(ROOT),
               'test_command_invocations': 1, 'actionlint_invocations': 1,
               'test_result': test, 'actionlint_result': lint, 'counts': summary,
               'source_before_after_equal': unchanged, 'source_binding': before,
               'scope': 'Local source and workflow contracts only; no engine, renderer, Android, APK or delivery acceptance',
               'source_index_ref_mutations': 0 if unchanged else 'SOURCE_CHANGE_DETECTED'}
    write_json(OUT / 'handoff.json', handoff)
    write(OUT / 'README.md', (
        '# Host d826 Dream targeted validation\n\n'
        f'Source: `{EXPECTED_HEAD}`, tree `{EXPECTED_TREE}`.\n\n'
        'Exactly one unittest invocation ran the Delivery and Pipeline modules, followed by exactly one actionlint invocation for the C4 workflow. '
        'Complete stdout and stderr, actual exit codes, UTC timestamps and monotonic durations are preserved. '
        'The before/after records bind HEAD, tree, raw index hash, original Git status and every materialized tracked source against its Git blob and mode. '
        'Missing skip-worktree files remain explicitly enumerated; nothing was materialized by this runner.\n\n'
        f'Result: {handoff["status"]}. Cases: {module_counts}; source comparison equal: {unchanged}. '
        'These are local contract results, not engine, device, APK or publication evidence. No optional suites or reruns were performed.\n'
    ).encode())
    objects = []
    for path in sorted(OUT.rglob('*')):
        if path.is_file():
            raw = path.read_bytes()
            objects.append({'path': path.relative_to(OUT).as_posix(), 'bytes': len(raw), 'sha256': digest(raw)})
    write_json(OUT / 'manifest.json', {'schema': 1, 'files': objects, 'file_count': len(objects),
               'total_bytes': sum(x['bytes'] for x in objects), 'self_and_later_transport_files_excluded': True})
    sums = ''.join(x['sha256'] + '  ' + x['path'] + '\n' for x in objects)
    sums += digest((OUT / 'manifest.json').read_bytes()) + '  manifest.json\n'
    write(OUT / 'SHA256SUMS', sums.encode())
    payloads = [(path.relative_to(OUT).as_posix(), path.read_bytes()) for path in sorted(OUT.rglob('*')) if path.is_file()]
    archive = OUT / 'evidence.tar.gz'
    with archive.open('xb') as target:
        with gzip.GzipFile(filename='', mode='wb', fileobj=target, mtime=0) as compressed_stream:
            with tarfile.open(fileobj=compressed_stream, mode='w', format=tarfile.USTAR_FORMAT) as tar:
                for name, raw in payloads:
                    info = tarfile.TarInfo(name)
                    info.size = len(raw)
                    info.mode = 0o644
                    info.mtime = 0
                    tar.addfile(info, io.BytesIO(raw))
    with tarfile.open(archive, 'r:gz') as tar:
        members = tar.getmembers()
        if len(members) != len(payloads):
            raise RuntimeError('Transport member count differs')
        expected = dict(payloads)
        for member in members:
            if not member.isfile() or tar.extractfile(member).read() != expected.pop(member.name):
                raise RuntimeError('Transport bytes differ')
        if expected:
            raise RuntimeError('Transport missing files')
    raw_archive = archive.read_bytes()
    transport = {'archive': str(archive), 'bytes': len(raw_archive), 'sha256': digest(raw_archive),
                 'roundtrip_members': len(payloads), 'all_members_byte_identical': True}
    write_json(OUT / 'archive-roundtrip.json', transport)
    print(json.dumps({'status': handoff['status'], 'counts': summary, 'source_before_after_equal': unchanged,
                     'handoff_sha256': digest((OUT / 'handoff.json').read_bytes()),
                     'manifest_sha256': digest((OUT / 'manifest.json').read_bytes()),
                     'transport': transport}, indent=2), flush=True)
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
