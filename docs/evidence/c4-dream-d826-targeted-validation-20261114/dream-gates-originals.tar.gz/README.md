# Host d826 Dream targeted validation

Source: `d826ce4e11879bc797f7d96c0a7e2c966e0773f7`, tree `7269a76137233bf16149e8fb89b612ba06a77668`.

Exactly one unittest invocation ran the Delivery and Pipeline modules, followed by exactly one actionlint invocation for the C4 workflow. Complete stdout and stderr, actual exit codes, UTC timestamps and monotonic durations are preserved. The before/after records bind HEAD, tree, raw index hash, original Git status and every materialized tracked source against its Git blob and mode. Missing skip-worktree files remain explicitly enumerated; nothing was materialized by this runner.

Result: PASS. Cases: {'delivery': 56, 'pipeline': 11}; source comparison equal: True. These are local contract results, not engine, device, APK or publication evidence. No optional suites or reruns were performed.
