#!/usr/bin/env python3
"""Use unchanged collector guards; retain one RAM buffer for explicit selection."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import os
import sys
import time
import zipfile

SOURCE = Path('/workspace/scratch/b3485b7bb989/host-artifact-memory-collector/collect_artifact.py')
spec = importlib.util.spec_from_file_location('frozen_artifact_collector', SOURCE)
collector = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = collector
spec.loader.exec_module(collector)

def main():
    artifact_id = int(sys.argv[1])
    root = Path(__file__).resolve().parent / 'artifacts' / str(artifact_id)
    metadata, raw_metadata = collector.artifact_metadata(root / 'artifact.json')
    assert metadata['id'] == artifact_id
    assert metadata['workflow_run']['id'] == 43566692796
    assert metadata['workflow_run']['head_sha'] == '7e2ab20f6f323c66a1e02de3550d73ef31b2037e'
    limits = collector.Limits(8*1024*1024, 20*1024*1024, 100*1024*1024, 20000, 120)
    limits.validate()
    with collector.load_archive(local_zip=None, url_file=Path('/tmp/pr483-private-downloads') / f'{artifact_id}.url', metadata=metadata, limits=limits) as buffer:
        with zipfile.ZipFile(buffer) as archive:
            infos, expanded, _ = collector.validate_members(archive, [], limits)
            inventory = [collector.read_member(archive, item) for item in infos]
            report = {'schema':1, 'artifact':metadata, 'metadata_sha256':hashlib.sha256(raw_metadata).hexdigest(), 'collector_source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(), 'archive_size_sha256_verified_before_parse':True, 'all_members_crc_sha256_verified':True, 'complete_zip_written_locally':False, 'complete_zip_retention':'Original external Actions artifact only; one BytesIO buffer is retained until explicit selection is materialized.', 'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'expanded_bytes':expanded, 'members':inventory}
            with (root / 'inventory.json').open('x') as f:
                json.dump(report,f,indent=2);f.write('\n')
            print(json.dumps({'ready':artifact_id,'members':len(inventory),'expanded_bytes':expanded}),flush=True)
            selection_path=root / 'selection.json'
            deadline=time.monotonic()+180
            while not selection_path.exists():
                if time.monotonic()>=deadline:raise RuntimeError('Explicit selection deadline expired')
                time.sleep(.1)
            selected=json.loads(selection_path.read_text())
            _, _, total=collector.validate_members(archive,selected,limits)
            original=root / 'originals';original.mkdir(mode=0o700)
            expected={i['path']:i for i in inventory}
            for name in selected:
                destination=original/name;destination.parent.mkdir(parents=True,exist_ok=True)
                with destination.open('xb') as f:
                    actual=collector.read_member(archive,archive.getinfo(name),f)
                    f.flush();os.fsync(f.fileno())
                assert actual==expected[name]
            with (root/'materialized.json').open('x') as f:
                json.dump({'schema':1,'selection':selected,'materialized_bytes':total,'all_selected_match_inventory':True,'complete_zip_written_locally':False},f,indent=2);f.write('\n')
            print(json.dumps({'complete':artifact_id,'materialized':len(selected),'bytes':total}),flush=True)

if __name__=='__main__':
    try:main()
    except collector.Rejected as exc:
        print(json.dumps({'status':'FAIL','code':exc.code}),file=sys.stderr);raise SystemExit(1)
    except Exception as exc:
        print(json.dumps({'status':'FAIL','exception_type':type(exc).__name__}),file=sys.stderr);raise SystemExit(1)
