# Producer493 Flutter return observer — exact source integration

Base Host 146b5199d0a6d5e2d158e7be15db6d226ed18204 / tree 09cf7b51d98ebcefd9e3c6af09c1be52439d03ad. The three final sources are byte-for-byte published Producer493 commit 6f42fa8c0f18ea27dac90d7799ca06a1f9f0614a / tree 7732acb45cd26887608b001c2ae19040774a7b83. Their Git blobs are checked against the complete original commit response.

The production delta is exactly the new wait_for_flutter_control method and the games_ready call after the existing proved leave touch. It observes for at most 30 seconds within the existing 900-second overall budget, sends no further input, rejects stale pause, invalid portal geometry/ownership and expired/changed evidence. The subsequent actual portal touch still requires two fresh stable observations.

The existing deadline module receives exactly four additive mock/assertion lines. Eight navigation counterexample methods are added. Actual static counts are 8 navigation + 11 deadline + 17 existing evidence methods = 36 in these three modules; no test has yet been run in this pack. Root will select the precise post-checkpoint validation command. No producer workflow or branch exception was copied; existing build budget 120 remains unchanged.

This source integration is distinct from the actual 3d91 Boru OCR repair. It does not reinterpret the failed Android job or claim a successful device return. before-source and dependency-source are read-only original Git bytes; all work was confined to this external pack.
