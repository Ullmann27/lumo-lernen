# Actual a8a9 kart-word targeted validation

Source: a8a9b84cffd9819d4c8c2dddb55e870f448a9f13, tree 6f737f9d2a57005ec4a32495af62d118bfcea28a. A separate detached sparse worktree was created from the existing Git object store. Root's original checkout was not altered.

Exactly one targeted unittest invocation ran 70 methods: 14 new original-word cases, 25 existing garage/driver/cup wiring cases, 9 existing original driver-word cases and 22 existing native-surface-readiness cases. All 70 passed, with zero errors, failures or skips. The original stdout/stderr and subprocess exit status are preserved separately.

Exactly one additional invocation ran the new positive Boru callback regression against the frozen 0411 before-source production helper and callback. It failed with the original RuntimeError: No currently visible vehicle card in the actual left list. That expected ERROR/exit 1 is retained as red evidence, not converted into a successful old test. old-source-binding.json checks both before-source bytes against the manifest frozen before this validation.

All 4,406 index paths, 628 materialized tracked files, HEAD, tree, raw index digest, status and sparse flags match before and after. Python and Pillow versions, actual timestamps, exact commands/environment and full logs are included. The 3,778 unmaterialized tracked paths were explicitly sparse; none were silently treated as file bytes.

These are deterministic callback/fixture and synthetic boundary tests. No new Android tour, OCR, renderer, APK build, benchmark or C4 acceptance was run. The original 3d91 Android/update jobs remain failed. Later visibility, selection and racing still require the next authorized real run.

The compact archive contains all validation metadata, commands and original streams. It excludes the disposable checkout, existing original PNGs and the original 53.6 MB Actions ZIP, whose complete source/byte identities remain bound by the published checkpoint and original evidence pack.
