from pathlib import Path
import datetime,hashlib,json,os,re,stat,subprocess,sys,time
ROOT=Path('/tmp/host-a8a9-kart-word-targeted-validation-20261114/checkout')
OUT=ROOT.parent
PYTHON=Path('/tmp/lumo-root-recovery-1242/py/bin/python')
SOURCE_PACK=Path('/tmp/host-3d91-kart-word-repair-20261114')
HEAD='a8a9b84cffd9819d4c8c2dddb55e870f448a9f13'
TREE='6f737f9d2a57005ec4a32495af62d118bfcea28a'
ENV=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0',REQUIRE_ALL_TESTS='true',PYTHONPATH=os.pathsep.join([str(ROOT/'tools/android_qa/tests'),str(ROOT/'tools/android_qa'),str(ROOT)]))
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def h(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def save(name,obj):
 p=OUT/name
 if p.exists(): raise RuntimeError('Refusing to overwrite '+str(p))
 p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def git(*args):
 p=subprocess.run(['git','-C',str(ROOT),*args],env=ENV,capture_output=True)
 if p.returncode: raise RuntimeError('Git read failed '+str(args)+' '+p.stderr.decode(errors='replace'))
 return p.stdout

def snapshot(name):
 head=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip()
 assert (head,tree)==(HEAD,TREE),(head,tree)
 index_path=Path(git('rev-parse','--git-path','index').decode().strip())
 if not index_path.is_absolute():index_path=ROOT/index_path
 index=index_path.read_bytes();stage=git('ls-files','--stage','-z')
 status=git('status','--porcelain=v1','-z','--untracked-files=all')
 flags=git('ls-files','-v','-z');untracked=git('ls-files','--others','--exclude-standard','-z')
 sources=[];missing=0
 for entry in stage.split(b'\0'):
  if not entry:continue
  meta,rawpath=entry.split(b'\t',1);mode,oid,st=meta.decode().split();assert st=='0'
  path=rawpath.decode();p=ROOT/path
  if p.is_symlink():data=os.readlink(p).encode();actual_mode='120000'
  elif p.is_file():
   data=p.read_bytes();actual_mode='100755' if p.stat().st_mode & stat.S_IXUSR else '100644'
  else:
   missing+=1;sources.append({'path':path,'git_blob':oid,'mode':mode,'materialized':False});continue
  actual=blob(data)
  if actual!=oid or actual_mode!=mode:raise RuntimeError('Tracked bytes/mode differ: '+path)
  sources.append({'path':path,'git_blob':oid,'mode':mode,'materialized':True,'bytes':len(data),'sha256':h(data)})
 assert not status,status
 assert not untracked,untracked
 freeze=json.loads((SOURCE_PACK/'source-freeze.json').read_text())
 for e in freeze['sources']:
  b=(ROOT/e['path']).read_bytes();assert (len(b),h(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob']),e['path']
 value={'captured_at':now(),'head':head,'tree':tree,'index':{'path':str(index_path),'bytes':len(index),'sha256':h(index)},'stage_sha256':h(stage),'flags_sha256':h(flags),'status_utf8':status.decode(),'status_sha256':h(status),'untracked_utf8':untracked.decode(),'tracked_count':len(sources),'materialized_count':len(sources)-missing,'absent_count':missing,'sources':sources}
 save(name,value)
 print(json.dumps({'snapshot':name,'head':head,'tracked':len(sources),'materialized':len(sources)-missing,'index_sha256':h(index)}),flush=True)
 return value

def run(name,args,extra_env=None):
 env=dict(ENV,**(extra_env or {}))
 started=now();tick=time.monotonic()
 stdout=OUT/(name+'.stdout.log');stderr=OUT/(name+'.stderr.log')
 assert not stdout.exists() and not stderr.exists()
 with stdout.open('xb') as out,stderr.open('xb') as err:
  p=subprocess.run([str(PYTHON),*args],cwd=ROOT,env=env,stdout=out,stderr=err)
 ended=now();duration=time.monotonic()-tick
 outb=stdout.read_bytes();errb=stderr.read_bytes();text=errb.decode()
 match=re.search(r'Ran (\d+) tests? in ([0-9.]+)s',text)
 summary={'name':name,'argv':[str(PYTHON),*args],'cwd':str(ROOT),'environment':{k:env[k] for k in ['PYTHONDONTWRITEBYTECODE','GIT_OPTIONAL_LOCKS','REQUIRE_ALL_TESTS','PYTHONPATH',*list((extra_env or {}).keys())]},'started_at':started,'ended_at':ended,'duration_seconds':duration,'exit_code':p.returncode,'reported_tests':int(match.group(1)) if match else None,'reported_seconds':float(match.group(2)) if match else None,'stdout':{'path':stdout.name,'bytes':len(outb),'sha256':h(outb)},'stderr':{'path':stderr.name,'bytes':len(errb),'sha256':h(errb)},'errors':len(re.findall(r'^ERROR: ',text,re.M)),'failures':len(re.findall(r'^FAIL: ',text,re.M)),'skips':len(re.findall(r'^test_.*\.\.\. skipped ',text,re.M)),'unittest_plain_ok':bool(re.search(r'\nOK\s*$',text))}
 save(name+'.result.json',summary);print(json.dumps(summary),flush=True)
 return summary,text

before=snapshot('sources-before.json')
result={'started_at':now(),'head':HEAD,'tree':TREE,'scope':'One authorized 70-method targeted run plus one original callback red replay; no Android/OCR/engine run','phases':[]}
try:
 version=subprocess.run([str(PYTHON),'-c','import sys,PIL; print(sys.version); print(PIL.__version__)'],capture_output=True,text=True,env=ENV,check=True)
 save('environment.json',{'python':str(PYTHON),'version_stdout':version.stdout,'version_stderr':version.stderr,'runner_python':sys.version,'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip()})
 green,text=run('targeted-green',['-m','unittest','test_kart_scroll_word_evidence','test_kart_garage_evidence','test_kart_driver_word_evidence','test_native_surface_readiness','-v'])
 result['phases'].append(green)
 if not (green['exit_code']==0 and green['reported_tests']==70 and green['errors']==0 and green['failures']==0 and green['skips']==0 and green['unittest_plain_ok']):
  result['outcome']='FAIL';result['reason']='The targeted gate did not meet the exact expected 70/0/0/0 result; original red replay was not started.'
 else:
  red,redtext=run('original-boru-red',['-m','unittest','test_kart_scroll_word_evidence.GarageOriginalWordSequenceTests.test_original_boru_frame_recovers_only_scroll_after_two_bound_frames','-v'],{'LUMO_KART_WORD_SOURCE_ROOT':str(SOURCE_PACK/'before-source')})
  result['phases'].append(red)
  expected=red['exit_code']==1 and red['reported_tests']==1 and red['errors']==1 and red['failures']==0 and red['skips']==0 and 'RuntimeError: No currently visible vehicle card in the actual left list' in redtext
  result['outcome']='PASS' if expected else 'FAIL';result['expected_original_red_verified']=expected
except BaseException as e:
 result['outcome']='ERROR';result['exception_type']=type(e).__name__;result['exception']=str(e)
 raise
finally:
 after=snapshot('sources-after.json')
 keys=['head','tree','index','stage_sha256','flags_sha256','status_utf8','status_sha256','untracked_utf8','tracked_count','materialized_count','absent_count','sources']
 equal={k:before[k]==after[k] for k in keys}
 result['source_unchanged']=equal;result['ended_at']=now()
 if not all(equal.values()):result['outcome']='FAIL';result['reason']='Source/index/status changed'
 save('result.json',result);print(json.dumps({'outcome':result['outcome'],'source_unchanged':all(equal.values()),'phases':[(p['name'],p['reported_tests'],p['exit_code']) for p in result['phases']]}),flush=True)
if result['outcome']!='PASS':raise SystemExit(1)
