"""Freeze only source/provenance; this program never imports or runs the probes."""
import ast
import copy
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FINAL = ROOT / 'final-source'
EXPECTED = {
    '.github/probes/creative_android_probe.py': 'aeea464a5973bceafcea069449d08e2acb7a32e0390f12b3380bab71b6b76ced',
    '.github/probes/modernization_android_tour.py': 'd98eeb982344bb09762a783aeb71bef2c93cc8ed30d5e932a96712fe382673db',
    'tools/android_qa/tests/test_kart_continue_caption.py': 'd1e4f1392f4d3e3b3312729e8a5d1e91e6a9f5d91d997640b40a900b66ba3568',
}


def record(path, relative):
    data = path.read_bytes()
    return {'path': str(relative), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def write_json(name, obj):
    path = ROOT / name
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')
    return record(path, name)


sources = [record(path, path.relative_to(FINAL)) for path in sorted(FINAL.rglob('*')) if path.is_file()]
assert len(sources) == 9
for item in sources:
    if item['path'] in EXPECTED:
        assert item['sha256'] == EXPECTED[item['path']], item

fixture_root = FINAL / 'tools/android_qa/tests/fixtures/kart-continue-08e'
provenance = json.loads((fixture_root / 'provenance.json').read_bytes())
for item in provenance['files']:
    actual = record(fixture_root / item['file'], item['file'])
    assert actual['bytes'] == item['bytes'] and actual['sha256'] == item['sha256'], item

base = json.loads((ROOT / 'source-base.json').read_bytes())
for item in base['sources']:
    actual = record(ROOT / 'before' / item['path'], item['path'])
    assert actual == item

changed = {
    '.github/probes/creative_android_probe.py': {'native_tap', 'native_text'},
    '.github/probes/modernization_android_tour.py': {'_continue_actual_race'},
}
preservation = []
for relative, allowed in changed.items():
    original_text = (ROOT / 'before' / relative).read_text()
    final_text = (FINAL / relative).read_text()
    old, new = ast.parse(original_text), ast.parse(final_text)
    old_functions = {node.name: node for node in old.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
    new_functions = {node.name: node for node in new.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
    added = sorted(set(new_functions) - set(old_functions))
    assert added == (['standalone_caption_target'] if relative.endswith('creative_android_probe.py') else [])
    actual_changed = {name for name, node in old_functions.items()
                      if ast.dump(node) != ast.dump(new_functions[name])}
    assert actual_changed == allowed, (relative, actual_changed)
    restored = copy.deepcopy(new)
    restored.body = [copy.deepcopy(old_functions[node.name])
                     if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in allowed else node
                     for node in restored.body
                     if not (isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in added)]
    assert ast.dump(restored) == ast.dump(old)
    entry = {'path': relative, 'changed_existing_top_level_functions': sorted(actual_changed),
             'added_functions': added,
             'unchanged_existing_top_level_functions': sorted(set(old_functions) - actual_changed),
             'whole_module_after_replacing_only_listed_functions_matches_original_ast': True}
    if relative.endswith('creative_android_probe.py'):
        for name in ('image_lines', 'read_component_caption'):
            before_segment = ast.get_source_segment(original_text, old_functions[name])
            after_segment = ast.get_source_segment(final_text, new_functions[name])
            assert before_segment == after_segment
            entry[name + '_source_bytes_unchanged'] = True
        before_tap = ast.get_source_segment(original_text, old_functions['native_tap'])
        after_tap = ast.get_source_segment(final_text, new_functions['native_tap'])
        assert before_tap.split('            if not matches:', 1)[1] == after_tap.split('            if not matches:', 1)[1]
        entry['native_tap_existing_target_stability_hash_deadline_dispatch_and_finally_suffix_byte_equal'] = True
    else:
        restored_continue = copy.deepcopy(new_functions['_continue_actual_race'])
        removed = 0
        for node in ast.walk(restored_continue):
            if isinstance(node, ast.Call):
                for keyword in list(node.keywords):
                    if keyword.arg == 'standalone_caption':
                        assert isinstance(keyword.value, ast.Constant) and keyword.value.value is True
                        node.keywords.remove(keyword)
                        removed += 1
        assert removed == 1 and ast.dump(restored_continue) == ast.dump(old_functions['_continue_actual_race'])
        entry['only_continue_change_is_explicit_true_keyword'] = True
        entry['hud_drive_resumed_state_and_save_checks_unchanged'] = True
    preservation.append(entry)

test_tree = ast.parse((FINAL / 'tools/android_qa/tests/test_kart_continue_caption.py').read_bytes())
methods = [node.name for node in ast.walk(test_tree) if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')]
assert len(methods) == 9
write_json('source-preservation.json', {
    'scope': 'Read-only structural source comparison; no probe/test imported or executed.',
    'base_head': base['head'], 'base_tree': base['tree'],
    'production_files': preservation, 'prepared_test_methods': methods,
    'tests_executed': 0,
})

patch = []
binary_paths = []
for item in sources:
    relative = item['path']
    path = FINAL / relative
    if path.suffix == '.png':
        binary_paths.append(item)
        continue
    before = ROOT / 'before' / relative
    patch.extend(difflib.unified_diff(before.read_text().splitlines(True) if before.is_file() else [],
                                     path.read_text().splitlines(True),
                                     fromfile='a/' + relative if before.is_file() else '/dev/null',
                                     tofile='b/' + relative))
(ROOT / 'source-text.patch').write_text(''.join(patch))
write_json('binary-original-mapping.json', {'scope': 'Two original PNGs accompany the text patch without re-encoding.',
                                          'files': binary_paths, 'artifact': provenance['artifact_id'],
                                          'archive_sha256': provenance['archive_sha256']})
freeze = write_json('source-freeze.json', {
    'schema': 1, 'kind': 'pr486_pause_standalone_caption_source_checkpoint',
    'base_head': base['head'], 'base_tree': base['tree'],
    'source_root': 'final-source', 'files': sources,
    'tests': {'prepared_methods': 9, 'executed': 0, 'status': 'NOT_RUN_AWAITING_ROOT_SOURCE_CHECKPOINT'},
    'original_failed_run': provenance['run_id'], 'original_failed_job': provenance['job_id'],
    'original_failed_source': provenance['source_sha'],
})
write_json('handoff.json', {
    'schema': 1, 'status': 'SOURCE_FROZEN_TESTS_NOT_RUN', 'source_freeze': freeze,
    'source_count': 9,
    'base_head': base['head'], 'base_tree': base['tree'],
    'changes': [
        'Only Continue opts into exact standalone-caption selection.',
        'An exact word span contained by a longer same-variant OCR line is retained as negative role evidence.',
        'All independent exact regions must identify the same physical control at pairwise IoU >= 0.6.',
        'Original surface dimensions, two observations, PNG hashes, deadlines, touch and post-touch HUD/save checks are preserved.',
    ],
    'original_observation': {
        'run': provenance['run_id'], 'job': provenance['job_id'], 'artifact': provenance['artifact_id'],
        'archive_sha256': provenance['archive_sha256'],
        'instruction_word_bounds': [1540, 264, 1848, 300],
        'standalone_button_caption_bounds': [1093, 388, 1430, 427],
        'actual_failed_touch': [1694, 282],
        'frame_files': [item for item in sources if item['path'].endswith('.png')],
        'png_viewing': 'Both byte-identical PNGs were actually opened before the executor interruption.',
    },
    'validation_scope': {
        'actual_local_test_runs': 0,
        'prepared_methods': methods,
        'replay_uses': 'Actual native_text/native_tap/Continue methods and original PNG/OCR; ADB, capture delivery, OCR delivery and time are mocked.',
        'replay_stops': 'At the unchanged mandatory HUD call; no real resume/gameplay claim.',
        'unchanged_direct_import_modules': [
            'kart_complete_android_probe', 'pr207_android_smoke',
            'flutter_surface_readiness', 'rooted_emulator',
            'native_ocr_tiles', 'native_surface_readiness',
            'kart_tour_evidence', 'kart_garage_evidence', 'kart_android_race',
        ],
        'dependencies_note': 'These module names were read from the actual before sources. Their transitive dependencies and physical paths must be checked in the subsequent checkout. Pillow remains required. No dependency copied or downloaded here.',
    },
    'interruption_recovery': {
        'production_and_fixture_writes': 'Confirmed and retained in workspace.',
        'interrupted_test_write': 'Read-only recovery proved the file absent; restored exactly from the retained full function-store source.',
        'test_source_sha256': EXPECTED['tools/android_qa/tests/test_kart_continue_caption.py'],
        'lost_logs_recreated': False,
    },
    'remaining': [
        'Root publishes/checkpoints these exact source bytes before targeted Red/Green execution.',
        'A future real Android tour must prove Continue/resume; these fixtures cannot prove it.',
        'The historical full run remains FAILURE. Real GMS ANRs and pure SwiftShader shader-link failures remain independent blockers.',
        'The two missing-wrapper reruns remain pending until Root restores the actual QA checkout.',
    ],
    'mutations': 'Only this external source/evidence pack; no worktree, index, ref, CI or device mutation.',
})
(ROOT / 'README.md').write_text('''# PR486: observed Continue target repair

This is a source checkpoint, not a test result or Android acceptance. Exactly nine proposed paths are in `final-source/`: two narrowly changed probe files, one nine-method test, and six original-fixture/provenance files. No tests have been executed for this patch. Root must checkpoint the source before the targeted replay.

## Original failure

Run 43574161418, attempt 1, job 132384862551 and artifact 14106471875 belong to QA 08e63bd32917a6672ae99b66a17c3fa57c83977a. The original archive is 116,961,715 bytes with SHA256 e044ba0959d2099a5b2b498f1ca31d9f6ac7f9fbad4fabffb2d0d00c92dfc3f3. Its previous complete CRC/SHA inventory remains in the separate original checkpoint. A necessary second RAM read checked the identical archive and extracted only the two exact PNGs and three small original reports. No archive was retained here and no image was re-encoded.

Both original PNGs were actually viewed. The explanatory sentence contains a `weiterfahren` word span at [1540,264,1848,300], while the independent `Weiterfahren` button caption is at [1093,388,1430,427]. The failed readiness report recorded two observations of the sentence word and a touch at [1694,282]. The subsequent HUD check correctly rejected the remaining pause screen. The frozen original report and both original images remain unchanged.

## Narrow change

Only Continue opts in. Its exact caption candidates are compared with complete longer OCR lines from the same variant. Embedded word spans remain recorded as negative role evidence. Distinct independent controls remain ambiguous; duplicate observations must have pairwise IoU of at least 0.6. The selected rectangle is an original observation, never a fixed screen coordinate. Existing callers keep their original defaults and forwarded arguments.

The complete OCR reader, target stability checks, screenshot hashes, surface dimensions, all deadlines, physical touch and following HUD/drive/save conditions remain intact. `source-preservation.json` records structural and byte comparisons without importing or running the probes.

## Prepared replay and limits

The nine methods exercise the actual Continue/native-text/native-tap methods with the two original PNG/OCR pairs. Capture delivery, OCR delivery, ADB and clocks are explicit test boundaries. The positive test stops at the existing mandatory HUD call and claims neither a resumed race nor an Android run. Negative cases cover sentence-only text, two independent controls, offscreen bounds, changed PNG bytes, late OCR and non-exact text; ordering and existing-call defaults are also covered. No execution log or PASS is invented.

The two production sources are based on the published 0d7ea79cd02b921ed685abc79b27df8a5f6b4ccb, tree 863c4b45bcd6a564070ca128565688bde7e1ed11. Their before bytes are identical to those bound by the failed 08e job. `source-text.patch` covers every text path; `binary-original-mapping.json` binds the two accompanying PNGs. `source-freeze.json` provides exact SHA256 and Git blob identities for all nine paths.

The interrupted test-file write had not completed. After the environment returned, absence was checked and the full source was restored byte-for-byte from the retained function store. Original logs were not recreated. The historical full run, actual GMS ANRs and pure SwiftShader shader failures remain failures independent of this target-selection repair.
''')

files = [record(path, path.relative_to(ROOT)) for path in sorted(ROOT.rglob('*'))
         if path.is_file() and path.name not in ('manifest.json', 'SHA256SUMS')]
manifest = write_json('manifest.json', {'schema': 1, 'scope': 'Complete external source/evidence pack; no tests run.',
                                      'files': files, 'total_bytes': sum(item['bytes'] for item in files)})
rows = files + [manifest]
(ROOT / 'SHA256SUMS').write_text(''.join(item['sha256'] + '  ' + item['path'] + '\n' for item in sorted(rows, key=lambda item: item['path'])))
for item in rows:
    assert record(ROOT / item['path'], item['path']) == item
print(json.dumps({'source_freeze': freeze, 'handoff': record(ROOT / 'handoff.json', 'handoff.json'),
                  'manifest': manifest, 'files': len(files), 'tests_executed': 0}, indent=2))
