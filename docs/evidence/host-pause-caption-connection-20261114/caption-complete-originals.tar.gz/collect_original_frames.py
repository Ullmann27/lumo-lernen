"""Read the same approved original ZIP in RAM; retain only two original frames."""
import hashlib
import io
import json
from pathlib import Path
import sys
import urllib.request
import zipfile

OUT = Path(__file__).resolve().parent
BASE = OUT.parent / "host-pr486-08e63bd3-console-evidence/artifacts/14106471875"


def main(path):
    config = json.loads(path.read_bytes())
    try:
        with urllib.request.urlopen(config["url"], timeout=120) as response:
            raw = response.read(config["size"] + 1)
    finally:
        path.unlink()
    if len(raw) != config["size"] or hashlib.sha256(raw).hexdigest() != config["sha256"]:
        raise ValueError("Original archive identity differs")
    index = json.loads((BASE / "verification.json").read_bytes())
    members = {row["path"]: row for row in index["members"]}
    target = OUT / "final-source/tools/android_qa/tests/fixtures/kart-continue-08e"
    target.mkdir(parents=True)
    rows = []
    wanted = ["21_continue/21_continue_touch-0.png", "21_continue/21_continue_touch-1.png",
              "21_continue/21_continue_touch-0-ocr.json", "21_continue/21_continue_touch-1-ocr.json",
              "21_continue/21_continue_touch-surface-readiness.json"]
    with zipfile.ZipFile(io.BytesIO(raw)) as source:
        for name in wanted:
            data = source.read(name)
            expected = members[name]
            if len(data) != expected["bytes"] or hashlib.sha256(data).hexdigest() != expected["sha256"]:
                raise ValueError("Original member differs from the previously verified full inventory")
            filename = Path(name).name
            with (target / filename).open("xb") as stream:
                stream.write(data)
            rows.append({"file": filename, "original_member": name, "bytes": len(data), "sha256": expected["sha256"]})
    provenance = {"schema": 1, "repository": "Ullmann27/lumo-lernen", "run_id": 43574161418,
        "run_attempt": 1, "job_id": 132384862551, "source_sha": "08e63bd32917a6672ae99b66a17c3fa57c83977a",
        "artifact_id": config["artifact_id"], "archive_bytes": len(raw), "archive_sha256": config["sha256"],
        "prior_full_inventory_sha256": hashlib.sha256((BASE / "verification.json").read_bytes()).hexdigest(),
        "files": rows, "scope": "Byte-identical original frames/OCR/readiness from the failed run. No PNG re-encoding, new Android execution or successful Continue claim."}
    (target / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    print(json.dumps({"selected_bytes": sum(row["bytes"] for row in rows), "files": len(rows), "zip_retained": False}))


if __name__ == "__main__":
    try:
        main(Path(sys.argv[1]))
    except Exception as error:
        print(json.dumps({"status": "FAIL", "error_type": type(error).__name__}), file=sys.stderr)
        raise SystemExit(1)
