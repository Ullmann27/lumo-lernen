#!/usr/bin/env python3
"""Preserve an authorized original ZIP and a bounded diagnostic selection."""
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import sys
import urllib.request
import zipfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_new(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(data)


def main(config_path):
    config = json.loads(config_path.read_bytes())
    try:
        request = urllib.request.Request(config["url"])
        with urllib.request.urlopen(request, timeout=120) as response:
            archive_bytes = response.read(config["size"] + 1)
    finally:
        config_path.unlink()
    if len(archive_bytes) != config["size"] or digest(archive_bytes) != config["sha256"]:
        raise ValueError("Original archive size or digest differs from the official metadata")
    out = Path(config["out"])
    archive = None  # Original ZIP is verified in RAM and retained only by Actions.
    index, selected, excluded = [], [], []
    selection_bytes = 0
    text_suffixes = {".json", ".stdout", ".stderr", ".txt", ".log", ".tsv", ".xml", ".sh"}
    observations = []
    with zipfile.ZipFile(io.BytesIO(archive_bytes)) as source:
        names = [info.filename for info in source.infolist()]
        if len(names) != len(set(names)):
            raise ValueError("Duplicate archive names")
        for info in sorted(source.infolist(), key=lambda item: (not item.filename.startswith(("runtime-anr/", "framework-start/", "renderer-")), item.filename)):
            path = PurePosixPath(info.filename)
            mode = info.external_attr >> 16
            if path.is_absolute() or ".." in path.parts or "\\" in info.filename or info.is_dir() or (stat.S_IFMT(mode) not in (0, stat.S_IFREG)):
                raise ValueError("Archive contains a nonregular or unsafe member")
            data = source.read(info)  # zipfile validates the original CRC.
            if len(data) != info.file_size:
                raise ValueError("Archive member size differs")
            record = {"path": info.filename, "bytes": len(data), "compressed_bytes": info.compress_size,
                      "crc32": f"{info.CRC:08x}", "sha256": digest(data)}
            index.append(record)
            if path.suffix in text_suffixes and len(data) <= 256 * 1024 and selection_bytes + len(data) <= 8 * 1024 * 1024:
                destination = out / "selected-originals" / path
                write_new(destination, data)
                if digest(destination.read_bytes()) != record["sha256"]:
                    raise ValueError("Materialized original bytes differ")
                selected.append(record)
                selection_bytes += len(data)
            else:
                excluded.append({"path": info.filename, "reason": "outside bounded small diagnostic selection"})
            if path.name in {"logcat-all.stdout", "logcat.txt", "0008-original-logcat-stdout.stdout"}:
                lines = data.decode("utf-8", errors="replace").splitlines()
                matched = [{"line": i + 1, "text": line} for i, line in enumerate(lines)
                           if "am_anr" in line or "ANR in " in line or "exceed GL_MAX_FRAGMENT_UNIFORM_VECTORS" in line]
                observations.append({"member": record, "selected_original_lines": matched,
                                     "scope": "Derived locations only; the full original member remains in the digest-verified ZIP."})
    metadata_path = Path(config["metadata_snapshot"])
    metadata_raw = metadata_path.read_text()
    position = metadata_raw.index("[", metadata_raw.index('"artifacts"')) + 1
    decoder = json.JSONDecoder()
    artifact_raw = None
    while True:
        while metadata_raw[position] in " \t\r\n,":
            position += 1
        if metadata_raw[position] == "]":
            break
        value, end = decoder.raw_decode(metadata_raw, position)
        if value.get("id") == config["artifact_id"]:
            artifact_raw = metadata_raw[position:end].encode()
            break
        position = end
    if artifact_raw is None:
        raise ValueError("Official artifact object absent from the saved original API list")
    write_new(out / "artifact-object.json", artifact_raw)
    report = {"schema": 1, "artifact_id": config["artifact_id"], "original_metadata": str(metadata_path),
              "original_metadata_sha256": digest(metadata_path.read_bytes()),
              "archive_path": archive, "archive_bytes": len(archive_bytes), "archive_sha256": digest(archive_bytes),
              "all_members_crc_and_sha256_verified": True, "members": index,
              "selected_members": selected, "selected_bytes": selection_bytes,
              "excluded_from_materialization": excluded,
              "scope": "Complete original ZIP verified only in RAM. Only the exact selected members are materialized; the ZIP remains available from the original Actions artifact. No re-encoding or acceptance claim."}
    write_new(out / "verification.json", (json.dumps(report, indent=2, ensure_ascii=False) + "\n").encode())
    write_new(out / "log-observations.json", (json.dumps(observations, indent=2, ensure_ascii=False) + "\n").encode())
    write_new(out / "archive-location.json", (json.dumps({"artifact_id": config["artifact_id"], "archive_path": archive,
              "sha256": config["sha256"], "bytes": config["size"], "reason": "Authorized RAM-only original ZIP verification; original API and complete member index remain in the workspace. No local ZIP copy exists."}, indent=2) + "\n").encode())
    print(json.dumps({"artifact_id": config["artifact_id"], "archive": archive, "sha256": config["sha256"],
          "members": len(index), "selected_members": len(selected), "selected_bytes": selection_bytes,
          "verification_sha256": digest((out / "verification.json").read_bytes())}))


if __name__ == "__main__":
    try:
        main(Path(sys.argv[1]))
    except Exception as error:
        # A failing network exception must not disclose its signed URL.
        print(json.dumps({"status": "FAIL", "error_type": type(error).__name__}), file=sys.stderr)
        raise SystemExit(1)
