"""Source-only workflow freeze; never imports tests or invokes any gate."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
REVISION = '0d7ea79cd02b921ed685abc79b27df8a5f6b4ccb'
TREE = '863c4b45bcd6a564070ca128565688bde7e1ed11'
WORKFLOW = '.github/workflows/lumo-console-start-7b16.yml'
TEST = 'scripts/tests/test_console_start_workflow.py'


def record(path, relative):
    data = path.read_bytes()
    return {'path': str(relative), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def write_json(name, data):
    path = ROOT / name
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')
    return record(path, name)


before = (ROOT / 'before' / WORKFLOW).read_text()
after = (ROOT / 'final-source' / WORKFLOW).read_text()
addition = """          .probe-venv/bin/python -B -m unittest -v tools.android_qa.tests.test_kart_continue_caption \\
            2>&1 | tee pause-caption-contracts.log
          grep -Eq '^Ran 9 tests in ' pause-caption-contracts.log
          grep -Fx 'OK' pause-caption-contracts.log
"""
upload = '            pause-caption-contracts.log\n'
assert after.count(addition) == 1 and after.count(upload) == 1
assert after.replace(addition, '').replace(upload, '') == before
old_device = before.split('  android-diagnostic:\n', 1)[1]
new_device = after.split('  android-diagnostic:\n', 1)[1]
assert old_device == new_device
counts = lambda text: [(name, int(count)) for count, name in re.findall(
    r"grep -Eq '\^Ran (\d+) tests in ' ([\w-]+)-contracts.log", text)]
original_groups, final_groups = counts(before), counts(after)
assert sum(value for _, value in original_groups) == 238
assert [(name, value) for name, value in final_groups if name != 'pause-caption'] == original_groups
assert sum(value for _, value in final_groups) == 247
original_test = ast.parse((ROOT / 'before' / TEST).read_bytes())
final_test = ast.parse((ROOT / 'final-source' / TEST).read_bytes())
methods = lambda tree: {node.name: ast.dump(node) for node in ast.walk(tree)
                        if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')}
old_methods, new_methods = methods(original_test), methods(final_test)
assert old_methods.keys() == new_methods.keys() and len(new_methods) == 9
changed_methods = [name for name in old_methods if old_methods[name] != new_methods[name]]
assert changed_methods == ['test_all_86_console_and_7_parser_and_9_diagnostic_cases_are_required',
                           'test_failed_observations_and_all_contract_logs_are_always_retained']
pip = '.probe-venv/bin/python -m pip install --disable-pip-version-check uiautomator2==3.7.0 Pillow==12.3.0'
assert before.count(pip) == after.count(pip) == 2
patch = []
for relative in (WORKFLOW, TEST):
    patch.extend(difflib.unified_diff((ROOT / 'before' / relative).read_text().splitlines(True),
                                     (ROOT / 'final-source' / relative).read_text().splitlines(True),
                                     fromfile='a/' + relative, tofile='b/' + relative))
(ROOT / 'workflow.patch').write_text(''.join(patch))

dependency_records = []
for path in sorted((ROOT / 'read-only-dependencies').rglob('*.py')):
    relative = path.relative_to(ROOT / 'read-only-dependencies')
    tree = ast.parse(path.read_bytes())
    dependency_records.append({**record(path, relative),
        'url': 'https://github.com/Ullmann27/lumo-lernen/blob/' + REVISION + '/' + str(relative),
        'top_level_imports': [ast.unparse(node) for node in tree.body if isinstance(node, (ast.Import, ast.ImportFrom))]})
write_json('source-preservation.json', {
    'scope': 'Static byte/AST comparison only; no test, installation or actionlint run.',
    'base_head': REVISION, 'base_tree': TREE,
    'removing_only_new_pause_group_and_log_restores_complete_old_workflow': True,
    'entire_actual_android_job_byte_equal': True,
    'actual_android_job_sha256': hashlib.sha256(old_device.encode()).hexdigest(),
    'existing_groups_unchanged': original_groups, 'new_groups': final_groups,
    'required_methods_before': 238, 'required_methods_after': 247,
    'workflow_test_methods_before': 9, 'workflow_test_methods_after': 9,
    'changed_existing_workflow_methods': changed_methods,
    'unchanged_workflow_methods': [name for name in old_methods if name not in changed_methods],
    'existing_dependency_install_command_unchanged': pip,
})
write_json('dependency-review.json', {
    'scope': 'Read original source import statements and existing workflow installation; no package installed or test imported.',
    'existing_workflow_command': pip,
    'new_test_imports': 'Python standard library only; actual original PNG inspection uses PIL through creative_android_probe/native_surface_readiness.',
    'required_image_dependency': 'Pillow==12.3.0 is already installed in the same contract venv.',
    'existing_ui_dependency': 'uiautomator2==3.7.0 is retained without any new installation step.',
    'external_tools_in_replay': 'No real ADB or Tesseract is invoked by the new replay: their delivery boundaries are mocked explicitly.',
    'new_dependency_changes': [], 'unchanged_direct_dependency_sources': dependency_records,
    'limits': 'A future actual checkpoint test still has to validate import/materialization. No local environment readiness or executed PASS is inferred here.',
})
sources = [record(ROOT / 'final-source' / relative, relative) for relative in (WORKFLOW, TEST)]
freeze = write_json('source-freeze.json', {
    'schema': 1, 'kind': 'separate_pause_caption_console_workflow_attachment',
    'base_head': REVISION, 'base_tree': TREE,
    'files': sources, 'tests_executed': 0, 'actionlint_executed': False,
    'pause_source_freeze_sha256': '3387f3240023ee63c4eb23c62f7d694e27e5041096c3b52a537e84d14123bc7b',
})
handoff = write_json('handoff.json', {
    'schema': 1, 'status': 'SOURCE_FROZEN_AWAITING_ROOT_CHECKPOINT',
    'source_freeze': freeze, 'proposed_files': sources,
    'required_existing_methods': 238, 'additional_pause_methods': 9,
    'required_total_if_executed': 247,
    'retained_original_log': 'pause-caption-contracts.log',
    'failure_propagation': 'Existing set -euo pipefail plus tee, exact Ran 9, and a standalone exact OK line are mandatory; skipped-test summaries cannot satisfy OK.',
    'artifact': 'Existing always() contracts artifact gains only the new original log path.',
    'android_job': 'Complete byte-equal body, same APK, source binding, renderer matrix, observers and time limits.',
    'validation': {'tests_executed': 0, 'actionlint_executed': False, 'new_packages_installed': 0},
    'mutations': 'Only this separate external source pack. No worktree, Git index, ref, CI or device changed.',
})
(ROOT / 'README.md').write_text('''# Separate Pause-Caption CI attachment

This two-file source pack is based on published QA 0d7ea79cd02b921ed685abc79b27df8a5f6b4ccb, tree 863c4b45bcd6a564070ca128565688bde7e1ed11. It follows the separate unchanged nine-path Pause source freeze 3387f3240023ee63c4eb23c62f7d694e27e5041096c3b52a537e84d14123bc7b.

The actual Console-Start contract job receives a distinct mandatory invocation of tools.android_qa.tests.test_kart_continue_caption, with its full combined output in pause-caption-contracts.log. Existing pipefail propagation, an exact nine-test count and exact OK are mandatory. The existing always-uploaded contracts artifact gains this original log. All six previous groups, including their exact counts 86/7/9/6/9/121, are byte-preserved. The future mandatory total is 247 only when the actual jobs execute; no new PASS is claimed here.

The existing workflow test keeps exactly nine methods. Two methods gain assertions for the new real command/count/log and the already installed Pillow dependency; every previous assertion remains. The complete three-renderer Android job is byte-identical to its QA0d version. There is no new device run, APK build, retry, source binding relaxation or new installation.

Source import review confirms that the new test itself uses Python's standard library and the real PNG inspection uses the already installed Pillow 12.3.0. Existing uiautomator2 remains unchanged. Two exact original import dependencies from QA0d are saved separately as read-only provenance; no dependency source is proposed for modification. Import/materialization and execution remain future checkpoint validation.

No tests or actionlint were run during preparation. Root alone owns the source checkpoint, subsequent scoped validation and any CI activation. Both original failed Android results and the independent GMS/shader blockers remain unchanged.
''')
files = [record(path, path.relative_to(ROOT)) for path in sorted(ROOT.rglob('*'))
         if path.is_file() and path.name not in ('manifest.json', 'SHA256SUMS')]
manifest = write_json('manifest.json', {'schema': 1, 'files': files,
                                      'total_bytes': sum(item['bytes'] for item in files)})
rows = files + [manifest]
(ROOT / 'SHA256SUMS').write_text(''.join(item['sha256'] + '  ' + item['path'] + '\n' for item in sorted(rows, key=lambda item: item['path'])))
for item in rows:
    assert record(ROOT / item['path'], item['path']) == item
print(json.dumps({'source_freeze': freeze, 'handoff': handoff, 'manifest': manifest,
                  'tests_executed': 0, 'actionlint_executed': False}, indent=2))
