#!/usr/bin/env python3
"""Freeze the actual current Runtime originals; no engine or product execution."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

SOURCE=Path(__file__).resolve().parent
PACK=Path('/tmp/host0cda-runtime-originals-checkpoint-20261114')


def identity(data):
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
            'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}


def write(name,value):
    data=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
    with (PACK/name).open('xb') as stream:
        stream.write(data)
    assert (PACK/name).read_bytes()==data
    return identity(data)


def main():
    PACK.mkdir(exist_ok=False)
    report=json.loads((SOURCE/'runtime-original-replay.json').read_bytes())
    assert report['status']=='ORIGINAL_RUNTIME_REPLAY_PASS'
    assert report['run_id']==43637785992 and report['job_id']==132578338806
    assert report['artifact_id']==14130094271
    verification=json.loads((SOURCE/'inspection/verification.json').read_bytes())
    actual_artifacts=json.loads((SOURCE/'original-metadata/artifacts.original.json').read_bytes())['artifacts']
    actual_artifact=[item for item in actual_artifacts if item['id']==report['artifact_id']]
    assert len(actual_artifact)==1
    selected={}
    for path in sorted(SOURCE.rglob('*')):
        if not path.is_file():
            continue
        relative=path.relative_to(SOURCE).as_posix()
        if relative=='original-14130094271.zip' or relative.startswith('inspection/originals/runtime/frames/'):
            continue
        selected['runtime/'+relative]=path
    native_inventory=Path('/tmp/host7ac-f9-reader-checkout-20261114/source-inventory')
    for path in sorted(native_inventory.iterdir()):
        if path.is_file():
            selected['exact-f9-reader-checkout/'+path.name]=path
    entries=[]
    for name,path in sorted(selected.items()):
        assert not path.is_symlink()
        entries.append({'archive_path':name,'source_path':str(path),
                        'mode':'100755' if path.stat().st_mode&0o111 else '100644',
                        **identity(path.read_bytes())})
    write('inclusion.json',{'schema':1,'files':entries,'count':len(entries),
                           'uncompressed_bytes':sum(row['bytes'] for row in entries)})
    zip_path=SOURCE/'original-14130094271.zip'
    exclusions={'scope':'Full ZIP and the complete 250-frame sequence remain separately unchanged; no duplicate large original archive in this compact checkpoint.',
        'full_original_zip':{'path':str(zip_path),**identity(zip_path.read_bytes())},
        'frame_originals':[{'path':str(SOURCE/'inspection/originals'/row['path']),
                           **{key:row[key] for key in ('bytes','sha256','git_blob')}}
                          for row in verification['members'] if row['path'].startswith('runtime/frames/')],
        'actions_expires_at':actual_artifact[0]['expires_at'],
        'omitted_originals_not_deleted_or_modified':True}
    assert len(exclusions['frame_originals'])==250
    write('exclusion-and-retention.json',exclusions)
    results=report['pure_replay_results']
    readme=f'''# Actual Host0cda / Nativef9 C4 desktop Runtime originals

Run {report['run_id']}, attempt 1; successful job {report['job_id']}. This pack contains the complete once-fetched job log, original terminal-job API snapshot, complete CRC/SHA/member and decoded-PNG catalog, all non-frame original members, all nine named captures, exact unchanged production readers and the pure replay evidence.

The complete ZIP remains separately at {zip_path}. Its exact {report['archive']['bytes']} bytes hash to {report['archive']['sha256']}. All 399 members were completely CRC/SHA-checked and byte-equal after materialization, and all 259 PNGs were fully decoded. The 250 original frame PNGs remain in the complete ZIP and the original materialization. Neither was removed or altered.

The pure original replay returned zero: {results['native_checks']} actual native assertions, {results['frames']} frames, {results['observed_moving_frames']} moving frames, {results['observed_winning_frames']} winning frames, {report['native_input_events']} input events and {report['native_target_observations']} target observations. The minimum observed target dimension is {report['minimum_target_dp']} dp. Exact original Return21 and Wisp14 logs also passed their unchanged reader. All 458 scoped Host and 1,295 scoped Native source records match their actual immutable trees and their unchanged original before/after snapshots. These scopes do not claim that every documentation path was exercised.

The current Host tree is independently rebuilt from all 4,941 actual leaves. The local sparse Native reader checkout is actually f9d9772bb932d7ee8702eeb5bca6d98c286f3b98 / 4036a20ab80de78bcdf0d074b585be88c2946492; its source files and raw index remain unchanged across the replay. The earlier reader-inventory provenance is retained explicitly, never presented as an old Host runtime result.

No engine or product tests were repeated. This proves the current CI's desktop Dart/Godot pairing and the integrity of its original evidence, not Android Binder, real disk persistence, human visual acceptance, device FPS, an APK, the full52/Dream/Discovery suite or the complete seven-job workflow. Pipeline remains the sole status reader. A first local metadata-copy attempt assumed manifest.json; the actual central filename is raw-manifest.json. That harmless path failure is documented without replacing or refetching any original.
'''
    with (PACK/'README.md').open('x') as stream:
        stream.write(readme)
    archive=PACK/'technical-originals.tar.gz'
    with archive.open('xb') as stream:
        with gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as compressed:
            with tarfile.open(fileobj=compressed,mode='w') as tar:
                for row in entries:
                    data=Path(row['source_path']).read_bytes()
                    assert identity(data)=={key:row[key] for key in ('bytes','sha256','git_blob')}
                    member=tarfile.TarInfo(row['archive_path']);member.size=len(data)
                    member.mode=int(row['mode'][-3:],8);member.mtime=0
                    tar.addfile(member,io.BytesIO(data))
    with tarfile.open(archive,'r:gz') as tar:
        members=tar.getmembers()
        assert [item.name for item in members]==[row['archive_path'] for row in entries]
        for item,row in zip(members,entries):
            assert item.isfile()
            data=tar.extractfile(item).read()
            assert data==Path(row['source_path']).read_bytes()
            assert identity(data)=={key:row[key] for key in ('bytes','sha256','git_blob')}
    # Recheck every original member and the retained full ZIP after the archive operation.
    for row in verification['members']:
        if row['directory']:
            continue
        data=(SOURCE/'inspection/originals'/row['path']).read_bytes()
        assert identity(data)=={key:row[key] for key in ('bytes','sha256','git_blob')}
    assert identity(zip_path.read_bytes())=={key:exclusions['full_original_zip'][key] for key in ('bytes','sha256','git_blob')}
    roundtrip={'status':'ALL_ARCHIVE_MEMBERS_BYTE_EQUAL','archive':{'path':str(archive),**identity(archive.read_bytes())},
        'members':len(entries),'uncompressed_bytes':sum(row['bytes'] for row in entries),
        'every_member_complete_readback_and_source_bytes_equal':True,
        'all_399_original_member_bytes_unchanged':True,'full_original_zip_unchanged':True}
    write('roundtrip.json',roundtrip)
    handoff=write('handoff.json',{'status':'FROZEN','run_id':report['run_id'],'attempt':1,
        'job_id':report['job_id'],'artifact_id':report['artifact_id'],
        'host':report['source_binding']['host'],'native':report['source_binding']['native'],
        'technical_archive':roundtrip['archive'],'original_root':str(SOURCE),
        'replay_report':str(SOURCE/'runtime-original-replay.json'),
        'visual_catalog':str(SOURCE/'runtime-visual-catalog.json'),
        'original_full_job_log':report['original_full_job_log'],
        'full_original_archive':exclusions['full_original_zip'],
        'scoped_result':'Actual desktop Runtime170/250 frames with Return21/Wisp14 and exact pure replay.',
        'new_engine_or_product_tests':False,'complete_workflow_or_apk_or_android_or_fps_acceptance':False})
    manifest=write('manifest.json',{'schema':1,'status':'FROZEN','files':[
        {'path':path.name,**identity(path.read_bytes())} for path in sorted(PACK.iterdir()) if path.is_file()]})
    data=json.loads((PACK/'manifest.json').read_bytes())
    with (PACK/'SHA256SUMS').open('x') as stream:
        stream.write(''.join(row['sha256']+'  '+row['path']+'\n' for row in data['files'])+
                     manifest['sha256']+'  manifest.json\n')
    print(json.dumps({'pack':str(PACK),'manifest':manifest,'archive':roundtrip['archive'],
        'members':len(entries),'handoff':handoff,
        'replay':identity((SOURCE/'runtime-original-replay.json').read_bytes())}))


if __name__=='__main__':
    main()
