#!/usr/bin/env python3
"""Read-only replay of the exact original 0cda/f9 C4 runtime artifact."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ORIGINALS = ROOT / 'inspection/originals'
OUTPUT = ORIGINALS / 'runtime'
NATIVE = Path('/tmp/host7ac-f9-reader-checkout-20261114/native')
HOST_TREE = ROOT / 'source-binding/host-tree-binding.json'
NATIVE_INVENTORY = Path('/tmp/host7ac-f9-reader-checkout-20261114/source-inventory/source-inventory.json')
HOST_SHA = '0cda410b9e5dceba3ffaf04f9c0fc45880dac6a9'
HOST_TREE_SHA = 'a97942c991cbb38d22c8b97f06a3e5bb162ab942'
NATIVE_SHA = 'f9d9772bb932d7ee8702eeb5bca6d98c286f3b98'
NATIVE_TREE_SHA = '4036a20ab80de78bcdf0d074b585be88c2946492'
RUN = 43637785992
JOB = 132578338806
ARTIFACT = 14130094271


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes().decode('utf-8'))


def record(path):
    require(path.is_file() and not path.is_symlink(), 'Missing/nonregular original: '+str(path))
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}


def load_bound(path, sha256, blob, host_entries):
    actual = record(path)
    require(actual['sha256'] == sha256 and actual['git_blob'] == blob, 'Reader bytes differ')
    repository_path = 'scripts/'+path.name
    require(host_entries[repository_path]['sha'] == blob, 'Reader differs from exact Host tree')
    spec = importlib.util.spec_from_file_location('bound_'+path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module, {'repository_path': repository_path, **actual}


def local_native_state():
    def git(*args):
        return subprocess.check_output(['git','-C',str(NATIVE),*args],
                env={**__import__('os').environ, 'GIT_OPTIONAL_LOCKS':'0','GIT_NO_LAZY_FETCH':'1'})
    index_path = Path(git('rev-parse','--path-format=absolute','--git-path','index').decode().strip())
    result = {'head':git('rev-parse','HEAD').decode().strip(),
              'tree':git('rev-parse','HEAD^{tree}').decode().strip(),
              'index':record(index_path),
              'status_hex':git('status','--porcelain=v1','-z').hex()}
    inventory = read(NATIVE_INVENTORY)
    materialized = {}
    for row in inventory['tracked']:
        if not row['materialized']:
            continue
        path = NATIVE / row['path']
        value = record(path)
        value['mode'] = '100755' if path.stat().st_mode & 0o111 else '100644'
        require(value['git_blob'] == row['git_blob'] and value['mode'] == row['mode'], 'Native reader changed')
        materialized[row['path']] = value
    require(result['head'] == NATIVE_SHA and result['tree'] == NATIVE_TREE_SHA and result['status_hex'] == '',
            'Local Native reader checkout not exact/clean')
    result['materialized'] = materialized
    return result


def main():
    sys.dont_write_bytecode = True
    verification = read(ROOT/'inspection/verification.json')
    archive = record(ROOT/'original-14130094271.zip')
    require(archive['bytes'] == 22161744 and archive['sha256'] ==
            '50f23a953075c8d58cec71284eb052f2c880019a9106944e169f8b6c33ebeec3', 'Archive identity differs')
    member_before = {}
    for row in verification['members']:
        if row['directory']:
            continue
        actual = record(ORIGINALS/row['path'])
        require(all(actual[key] == row[key] for key in actual), 'Changed original member: '+row['path'])
        member_before[row['path']] = actual
    require(len(member_before) == 399 and len(verification['pngs']) == 259, 'Unexpected complete archive roster')
    run = read(ROOT/'original-metadata/run.original.json')
    jobs = read(ROOT/'original-metadata/jobs.original.json')['jobs']
    artifacts = read(ROOT/'original-metadata/artifacts.original.json')['artifacts']
    require(run['id'] == RUN and run['run_attempt'] == 1 and run['head_sha'] == HOST_SHA and
            run['path'] == '.github/workflows/lumo-connect-four-2020.yml' and
            run['repository']['full_name'] == 'Ullmann27/lumo-lernen', 'Run binding differs')
    selected_jobs = [job for job in jobs if job['id'] == JOB]
    require(len(selected_jobs) == 1, 'Missing/duplicate terminal runtime job')
    job = selected_jobs[0]
    require(job['run_id'] == RUN and job['run_attempt'] == 1 and job['head_sha'] == HOST_SHA and
            job['name'] == 'connect-four-runtime' and job['status'] == 'completed' and
            job['conclusion'] == 'success', 'Runtime job is not successful on requested source')
    selected_artifacts = [value for value in artifacts if value['id'] == ARTIFACT]
    require(len(selected_artifacts) == 1, 'Missing/duplicate exact runtime artifact')
    artifact = selected_artifacts[0]
    require(artifact['name'] == 'lumo-connect-four-2020-desktop-runtime' and
            artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == HOST_SHA and
            artifact['size_in_bytes'] == archive['bytes'] and artifact['digest'] == 'sha256:'+archive['sha256'],
            'Artifact API identity differs from actual archive')
    tree = read(HOST_TREE)
    require(tree['head'] == HOST_SHA and tree['tree'] == HOST_TREE_SHA, 'Host tree identity differs')
    host_entries = {row['path']:row for row in tree['entries']}
    native_inventory = read(NATIVE_INVENTORY)
    require(native_inventory['head'] == NATIVE_SHA and native_inventory['tree'] == NATIVE_TREE_SHA,
            'Native tree identity differs')
    native_entries = {row['path']:{'sha':row['git_blob'],'mode':row['mode'],'type':'blob'}
                      for row in native_inventory['tracked']}
    native_before = local_native_state()
    runtime, runtime_reader = load_bound(ROOT/'bound-readers/run_connect_four_runtime.py',
            'dc91ce099bcd65a2b6a1250d49db4e7522b6643a8735505642eeeb0ca51a0d6b',
            '36d93ed0908705e339346bf5ef451cf047b641b5', host_entries)
    delivery, delivery_reader = load_bound(ROOT/'bound-readers/verify_connect_four_delivery.py',
            '229b33a0f1b7de1c09cbfff871edaec5470e783df9068629a2337d3de4ccaa18',
            '1c788c7d1ea153bcbad90813537f022b6c1d8871', host_entries)
    before = read(OUTPUT/'source-before.json')
    after = read(OUTPUT/'source-after.json')
    require(before == after, 'Runtime source before/after documents differ')
    source_binding = {}
    for name, revision, entries, scopes, tree_sha in (
            ('host',HOST_SHA,host_entries,runtime.HOST_PATHS,HOST_TREE_SHA),
            ('native',NATIVE_SHA,native_entries,runtime.NATIVE_PATHS,NATIVE_TREE_SHA)):
        actual = before[name]
        require(actual['head'] == revision, 'Runtime source SHA differs: '+name)
        expected = {path:row for path,row in entries.items()
                    if any(path == prefix or path.startswith(prefix+'/') for prefix in scopes)}
        rows = {row['path']:row for row in actual['files']}
        require(len(rows) == len(actual['files']) and set(rows) == set(expected), 'Source roster differs: '+name)
        for path,row in rows.items():
            reference = expected[path]
            require(row['git_blob'] == reference['sha'] and row['mode'] == reference['mode'] and
                    reference['type'] == 'blob' and row['mode'] in ('100644','100755'),
                    'Source blob/mode differs: '+path)
            require(isinstance(row['bytes'],int) and row['bytes'] >= 0 and
                    re.fullmatch(r'[0-9a-f]{64}',row['sha256']), 'Malformed original byte identity: '+path)
            if 'size' in reference:
                require(row['bytes'] == reference['size'], 'Source size differs: '+path)
        source_binding[name] = {'head':revision,'tree':tree_sha,'scope':list(scopes),
                                'exact_scoped_files':len(rows),'all_oids_modes_match_exact_tree':True,
                                'original_before_after_equal':True}
    gate = read(OUTPUT/'runtime-gate.json')
    require(gate['passed'] is True and gate['exit_codes'] == {'dart':0,'godot':0} and
            gate['godot_version'] == '4.6.3.stable.official.7d41c59c4', 'Runtime result or engine differs')
    session = read(OUTPUT/'session.json')
    require(session == gate['session'], 'Session original differs from gate')
    actual_log = runtime.validate_native_log(OUTPUT/'original-godot.log')
    require(actual_log == gate['original_godot_log'], 'Recomputed original Godot log differs')
    result = runtime.validate_results(OUTPUT,session)
    require(result == gate['results'], 'Pure runtime result replay differs from original manifest')
    additional = delivery.checked_additional_native_logs(OUTPUT)
    original_import = (ORIGINALS/'original-import.log').read_text()
    require(original_import.splitlines().count(delivery.ADDITIONAL_ENGINE_BANNER) == 1 and
            not delivery.ERROR_LINE.search(original_import), 'Original engine import failed or has duplicate banner')
    member_after = {name:record(ORIGINALS/name) for name in member_before}
    require(member_after == member_before and record(ROOT/'original-14130094271.zip') == archive,
            'Pure replay changed original archive/member bytes')
    native_after = local_native_state()
    require(native_after == native_before, 'Pure replay changed local Native reader source/index')
    reader_after = [record(ROOT/'bound-readers'/name) for name in
                    ('run_connect_four_runtime.py','verify_connect_four_delivery.py')]
    require(reader_after == [{k:v for k,v in row.items() if k != 'repository_path'}
                             for row in (runtime_reader,delivery_reader)], 'Pure replay changed reader bytes')
    native_result = read(OUTPUT/'native-result.json')
    named_images = [row for row in result['images'] if '/' not in row['path']]
    report = {'schema':1,'status':'ORIGINAL_RUNTIME_REPLAY_PASS','run_id':RUN,'attempt':1,
              'job_id':JOB,'job_status':job['status'],'job_conclusion':job['conclusion'],
              'job_started_at':job['started_at'],'job_completed_at':job['completed_at'],
              'artifact_id':ARTIFACT,'artifact_name':artifact['name'],'archive':archive,
              'source_binding':source_binding,'source_before_original':record(OUTPUT/'source-before.json'),
              'source_after_original':record(OUTPUT/'source-after.json'),
              'reader_binding':[runtime_reader,delivery_reader],
              'original_runtime_gate':record(OUTPUT/'runtime-gate.json'),
              'original_full_job_log':record(ROOT/'job-132578338806.original.log'),
              'pure_replay_results':result,'additional_native_logs':additional,
              'import_log':record(ORIGINALS/'original-import.log'),
              'native_input_events':len(native_result['inputs']),
              'native_target_observations':len(native_result['targets']),
              'minimum_target_dp':min(min(t['size_dp']) for t in native_result['targets']),
              'all_399_original_members_unchanged':True,'local_reader_source_and_index_unchanged':True,
              'engine_or_product_tests_executed_here':False,'human_visual_review_performed_here':False,
              'complete_workflow_acceptance':False,
              'scope':'Actual current-source two-process desktop C4 runtime and exact pure original replay; not Android Binder, real disk persistence, device FPS, APK or complete seven-job acceptance.',
              'retention':{'local_original_zip':str(ROOT/'original-14130094271.zip'),
                           'original_member_root':str(ORIGINALS),'actions_expires_at':artifact['expires_at']}}
    (ROOT/'runtime-original-replay.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    (ROOT/'runtime-visual-catalog.json').write_text(json.dumps({'scope':'Nine named original captures for direct review; no visual PASS from decoding.',
        'run_id':RUN,'artifact_id':ARTIFACT,'original_root':str(OUTPUT),'captures':named_images,
        'frame_sequence':{'count':result['frames'],'relative_directory':'frames','start':'00000.png','end':'00249.png'}},indent=2)+'\n')
    (ROOT/'reader-state-after-replay.json').write_text(json.dumps(native_after,indent=2)+'\n')
    print(json.dumps({'status':report['status'],'source_counts':{k:v['exact_scoped_files'] for k,v in source_binding.items()},
        'native_checks':result['native_checks'],'frames':result['frames'],'pngs':len(result['images']),
        'moving_frames':result['observed_moving_frames'],'winning_frames':result['observed_winning_frames'],
        'inputs':report['native_input_events'],'targets':report['native_target_observations'],
        'minimum_target_dp':report['minimum_target_dp'],'originals_unchanged':True}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
