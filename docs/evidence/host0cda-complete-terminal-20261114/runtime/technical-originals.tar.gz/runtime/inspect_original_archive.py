#!/usr/bin/env python3
"""Inspect immutable CI ZIP bytes; never invoke a product or engine."""
import argparse, hashlib, io, json, stat, zipfile, zlib
from pathlib import Path, PurePosixPath
from PIL import Image, __version__ as pillow_version

def write_json(path, value):
    with path.open("x", encoding="utf-8") as out:
        out.write(json.dumps(value, indent=2, ensure_ascii=False) + "\n")

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--archive", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--size", required=True, type=int)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--artifact", required=True, type=int)
    args=parser.parse_args()
    raw=args.archive.read_bytes()
    if len(raw)!=args.size or hashlib.sha256(raw).hexdigest()!=args.sha256:
        raise ValueError("Archive API byte identity differs")
    args.output.mkdir(exist_ok=False)
    original=args.output/"originals"
    original.mkdir()
    members=[]; pngs=[]; names=set()
    with zipfile.ZipFile(io.BytesIO(raw)) as source:
        for item in source.infolist():
            path=PurePosixPath(item.filename)
            kind=stat.S_IFMT(item.external_attr>>16)
            if (not item.filename or "\\" in item.filename or path.is_absolute() or
                ".." in path.parts or "." in path.parts or str(path)!=item.filename.rstrip("/") or
                any(ord(c)<32 or ord(c)==127 for c in item.filename) or item.filename in names or
                kind not in (0,stat.S_IFREG,stat.S_IFDIR) or item.flag_bits&1):
                raise ValueError("Unsafe, duplicate, encrypted or nonregular ZIP member")
            names.add(item.filename)
            data=source.read(item)
            if len(data)!=item.file_size or zlib.crc32(data)&0xffffffff!=item.CRC:
                raise ValueError("Original member size or CRC differs")
            digest=hashlib.sha256(data).hexdigest()
            blob=hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
            row={"path":item.filename,"bytes":len(data),"sha256":digest,"git_blob":blob,
                 "crc32":format(item.CRC,"08x"),"compressed_bytes":item.compress_size,"directory":item.is_dir()}
            members.append(row)
            target=original.joinpath(*path.parts)
            if item.is_dir():
                target.mkdir(parents=True,exist_ok=True)
                continue
            target.parent.mkdir(parents=True,exist_ok=True)
            with target.open("xb") as out: out.write(data)
            if target.read_bytes()!=data:
                raise ValueError("Materialized original readback differs")
            if path.suffix.lower()==".png":
                with Image.open(io.BytesIO(data)) as image:
                    if image.format!="PNG": raise ValueError("PNG member format differs")
                    image.verify()
                with Image.open(io.BytesIO(data)) as image:
                    image.load()
                    pngs.append({"path":item.filename,"bytes":len(data),"sha256":digest,
                                 "width":image.width,"height":image.height,"mode":image.mode,"complete_decode":True})
    result={"schema":1,"scope":"Original ZIP/member integrity and PNG decoding only; no engine, product, device or visual acceptance",
            "artifact_id":args.artifact,"run_id":43637785992,"attempt":1,
            "expected_host":"0cda410b9e5dceba3ffaf04f9c0fc45880dac6a9",
            "expected_native":"f9d9772bb932d7ee8702eeb5bca6d98c286f3b98",
            "archive_bytes":len(raw),"archive_sha256":args.sha256,
            "members":members,"pngs":pngs,"pillow_version":pillow_version,
            "all_members_crc_sha_verified":True,"all_regular_originals_materialized_and_readback_equal":True}
    write_json(args.output/"verification.json",result)
    print(json.dumps({"artifact":args.artifact,"members":len(members),"pngs":len(pngs),
                      "expanded_bytes":sum(m["bytes"] for m in members),"originals":str(original),
                      "archive_sha256":args.sha256}))
if __name__=="__main__":
    main()
