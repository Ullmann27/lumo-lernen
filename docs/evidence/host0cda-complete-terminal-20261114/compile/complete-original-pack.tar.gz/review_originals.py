"""Read the assigned original CI evidence; never execute product or test code."""
from pathlib import Path
import datetime
import gzip
import hashlib
import io
import json
import re
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parent
SNAPSHOT = Path('/tmp/host0cda-c4-run43637785992-evidence-20261114/snapshots/20261114T203550Z')
HOST = '0cda410b9e5dceba3ffaf04f9c0fc45880dac6a9'
TREE = 'a97942c991cbb38d22c8b97f06a3e5bb162ab942'
RUN = 43637785992
JOB = 132578338582
ARTIFACT = 14130856331

def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}

def write_original(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, str(path)
    else:
        with path.open('xb') as handle:
            handle.write(data)
    assert path.read_bytes() == data

def write_json(path, value):
    write_original(path, (json.dumps(value, indent=2, ensure_ascii=False)+'\n').encode())

for name in ('run.original.json', 'jobs.original.json', 'artifacts.original.json', 'raw-manifest.json'):
    write_original(ROOT/'metadata'/name, (SNAPSHOT/name).read_bytes())
write_original(ROOT/'activation-binding.json', (ROOT.parent/'activation-binding.json').read_bytes())
run = json.loads((ROOT/'metadata/run.original.json').read_bytes())
jobs = json.loads((ROOT/'metadata/jobs.original.json').read_bytes())
artifacts = json.loads((ROOT/'metadata/artifacts.original.json').read_bytes())
job, = [item for item in jobs['jobs'] if item['id'] == JOB]
artifact, = [item for item in artifacts['artifacts'] if item['id'] == ARTIFACT]
assert run['id'] == RUN and run['run_attempt'] == 1 and run['head_sha'] == HOST
assert job['run_id'] == RUN and job['run_attempt'] == 1 and job['head_sha'] == HOST
assert (job['status'], job['conclusion']) == ('completed', 'success')
assert artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == HOST
assert artifact['expired'] is False
archive = ROOT/f'artifact-{ARTIFACT}.original.zip'
assert identity(archive.read_bytes())['bytes'] == artifact['size_in_bytes'] == 6631
assert 'sha256:'+identity(archive.read_bytes())['sha256'] == artifact['digest']
zip_binding = json.loads((ROOT/'zip-member-binding.json').read_bytes())
with zipfile.ZipFile(archive) as zipped:
    assert len(zipped.infolist()) == len(set(zipped.namelist())) == 6
    by_name = {item['member']: item for item in zip_binding['members']}
    assert set(by_name) == set(zipped.namelist())
    for member in zipped.infolist():
        data = zipped.read(member)
        assert member.filename == Path(member.filename).name
        assert data == (ROOT/'artifact-originals'/member.filename).read_bytes()
        assert identity(data)['sha256'] == by_name[member.filename]['sha256']
        assert len(data) == member.file_size == by_name[member.filename]['bytes']
        assert f'{member.CRC:08x}' == by_name[member.filename]['crc32']

originals = ROOT/'artifact-originals'
assert (originals/'source-sha.txt').read_bytes() == (HOST+'\n').encode()
result = json.loads((originals/'result.json').read_bytes())
c4 = json.loads((originals/'connect-four-classes.json').read_bytes())
assert result['status'] == c4['status'] == 'PASS'
assert result['flutter_source_commit'] == c4['source'] == HOST
host_classes = ['MainActivity','LumoGameActivity','LumoHostPlugin','CardsTableBridge',
    'CardsAuthorityService','CardsAuthorityRegistry','LumoLearningSpeech',
    'LumoOfflineSpeechBridge','LumoOfflineSpeechEngine','LumoSpeechEnvelope',
    'TableGameActivity','TableGamesHostPlugin','TableGamesBridge','TableAuthorityService','TableGameIntent']
c4_classes = ['ConnectFourGameActivity','ConnectFourAuthorityService','ConnectFourBridge']
assert set(result['classes']) == set(host_classes)
assert set(c4['classes']) == set(c4_classes)
for classes in (result['classes'], c4['classes']):
    for name, records in classes.items():
        assert len(records) == 1
        assert records[0]['path'].endswith('/'+name+'.class')
        assert records[0]['bytes'] > 0
        assert re.fullmatch(r'[0-9a-f]{64}', records[0]['sha256'])

registry = (originals/'cards-authority-registry.log').read_text()
cases = re.findall(r'^(test_\w+) \(([^\n]+)\) \.\.\. ok$', registry, re.M)
assert len(cases) == len({case[1] for case in cases}) == 10
assert re.findall(r'^Ran (\d+) tests in ([0-9.]+)s$', registry, re.M) == [('10','16.960')]
assert len(re.findall(r'^OK$', registry, re.M)) == 1
assert not re.search(r'^\S+ \([^\n]+\) \.\.\. (?:skipped|FAIL|ERROR)', registry, re.M)
assert not re.search(r'^(?:FAILED|ERROR:|FAIL:)', registry, re.M)
compile_log = (originals/'compile.log').read_text()
job_path = ROOT/f'job-{JOB}.original.log'
job_log = job_path.read_text(encoding='utf-8')
assert identity(job_path.read_bytes())['sha256'] == 'ade82ea052bde93bf0faa72d1dc3ca2fcf50a127de78f473a53cdef3fe443015'
markers = ['> Task :app:compileDebugKotlin', '> Task :app:compileDebugJavaWithJavac',
           'BUILD SUCCESSFUL in 2m 57s', '107 actionable tasks: 102 executed, 5 up-to-date']
for marker in markers:
    assert compile_log.splitlines().count(marker) == 1
    assert sum(line.endswith(marker) for line in job_log.splitlines()) == 1
assert '##[error]' not in job_log
steps = [item for item in job['steps'] if item['number'] in (6,7)]
assert len(steps) == 2 and all(item['conclusion'] == 'success' for item in steps)

review = {
    'schema': 'lumo.original-compile-review.v1',
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'PASS_ORIGINAL_CI_COMPILE_EVIDENCE',
    'repository': 'Ullmann27/lumo-lernen', 'host': HOST, 'tree': TREE,
    'run_id': RUN, 'attempt': 1, 'job_id': JOB,
    'job_started_at': job['started_at'], 'job_completed_at': job['completed_at'],
    'job_conclusion': job['conclusion'], 'relevant_steps': steps,
    'artifact': artifact, 'zip': identity(archive.read_bytes()),
    'zip_members_complete_crc_sha_checked': 6,
    'full_original_job_log': {'path': job_path.name, **identity(job_path.read_bytes())},
    'actual_compile_markers': markers,
    'host_class_report_count': len(host_classes), 'host_class_names': host_classes,
    'c4_class_report_count': len(c4_classes), 'c4_class_names': c4_classes,
    'class_binary_limitation': 'The original reports contain paths/sizes/SHA256. Actual .class bytes are not in this artifact and were not independently rehashed here.',
    'actual_registry_contracts': {'count': 10, 'passed': 10, 'failures': 0, 'errors': 0,
        'skips': 0, 'runtime_seconds': 16.960, 'methods': [case[1] for case in cases],
        'source': 'artifact-originals/cards-authority-registry.log'},
    'flutter_version_original': (originals/'flutter-version.txt').read_text(),
    'exit_observation': {'numeric_child_exit_not_separately_stored_in_artifact': True,
        'github_compile_step': 'success', 'gradle': 'BUILD SUCCESSFUL', 'unittest': 'OK'},
    'preservation': 'Original bytes, all Gradle warnings and normal Gradle skipped/no-source task records are retained. Gradle task states are not counted as unittest skips.',
    'scope': 'Actual Kotlin/Java host compilation and original 10 registry/embedded boundary tests only. No APK, Android runtime, pixels, audio, or full-suite acceptance is inferred.',
    'pending_separate_evidence': ['current full Flutter stream and exact 82 target cases', 'current build Speech23/17/30 contracts', 'remaining C4 build/device/delivery gates'],
    'local_actions': 'Read and verify existing original evidence only; no tests, imports, product/source/index/ref modifications, or additional API polls.'
}
write_json(ROOT/'review.json', review)
handoff = {'schema':'lumo.evidence-handoff.v1','scope':review['scope'], 'host':HOST,
    'tree':TREE, 'run_id':RUN,'attempt':1,'job_id':JOB,'artifact_id':ARTIFACT,
    'status':review['status'], 'review':identity((ROOT/'review.json').read_bytes()),
    'original_archive':identity(archive.read_bytes()),'full_job_log':identity(job_path.read_bytes()),
    'publication': 'Evidence only; Root owns any later Git publication. Full Flutter remains pending separately.'}
write_json(ROOT/'handoff.json', handoff)
files = sorted(path for path in ROOT.rglob('*') if path.is_file()
               and path.name not in ('manifest.json','complete-original-pack.tar.gz','archive-binding.json'))
manifest = {'schema':'lumo.evidence-manifest.v1', 'entries':[
    {'path':path.relative_to(ROOT).as_posix(),**identity(path.read_bytes())} for path in files]}
write_json(ROOT/'manifest.json', manifest)
files += [ROOT/'manifest.json']
tar_buffer=io.BytesIO()
with tarfile.open(fileobj=tar_buffer,mode='w') as tar:
    for path in sorted(files):
        data=path.read_bytes(); info=tarfile.TarInfo(path.relative_to(ROOT).as_posix())
        info.size=len(data); info.mode=0o644; info.mtime=0
        tar.addfile(info,io.BytesIO(data))
packed=gzip.compress(tar_buffer.getvalue(),mtime=0)
write_original(ROOT/'complete-original-pack.tar.gz',packed)
with tarfile.open(fileobj=io.BytesIO(packed),mode='r:gz') as tar:
    assert len(tar.getmembers()) == len(files)
    for member in tar.getmembers():
        assert tar.extractfile(member).read() == (ROOT/member.name).read_bytes()
write_json(ROOT/'archive-binding.json',{'archive':'complete-original-pack.tar.gz',
    **identity(packed),'members':len(files),'complete_roundtrip':True})
print(json.dumps({'review':identity((ROOT/'review.json').read_bytes()),
 'handoff':identity((ROOT/'handoff.json').read_bytes()),
 'manifest':identity((ROOT/'manifest.json').read_bytes()),
 'archive':identity(packed),'members':len(files),'status':review['status']},indent=2))
