"""Inspect original artifact bytes and machine events without running Flutter."""
import argparse
import collections
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import zlib
import zipfile

HOST = '0cda410b9e5dceba3ffaf04f9c0fc45880dac6a9'
TREE = 'a97942c991cbb38d22c8b97f06a3e5bb162ab942'
RUN = 43637785992
ATTEMPT = 1
BUILD_JOB = 132579589188
CATALOG_SHA = '4a4bd535610d1f82ba59ce5f6bbb70ba370fc097b5aef030036bd7d6e092af3a'

def identity(data):
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
            'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}

def store(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as handle:
        handle.write(data)
    assert path.read_bytes() == data

def dump(path, obj):
    store(path,(json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode())

def repository_path(path):
    if path.startswith('test/'):
        return path
    marker = '/test/'
    if path.count(marker) == 1:
        return 'test/'+path.split(marker,1)[1]
    return path

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--zip',required=True,type=Path)
    parser.add_argument('--artifact-id',required=True,type=int)
    parser.add_argument('--metadata-dir',required=True,type=Path)
    parser.add_argument('--catalog',required=True,type=Path)
    parser.add_argument('--activation-binding',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=False)
    output=args.output
    raw_metadata={name:(args.metadata_dir/name).read_bytes() for name in
                  ('run.original.json','jobs.original.json','artifacts.original.json')}
    run=json.loads(raw_metadata['run.original.json'])
    jobs=json.loads(raw_metadata['jobs.original.json'])
    artifacts=json.loads(raw_metadata['artifacts.original.json'])
    assert (run['id'],run['run_attempt'],run['head_sha']) == (RUN,ATTEMPT,HOST)
    job,=[j for j in jobs['jobs'] if j['id']==BUILD_JOB]
    assert (job['run_id'],job['run_attempt'],job['head_sha']) == (RUN,ATTEMPT,HOST)
    artifact,=[a for a in artifacts['artifacts'] if a['id']==args.artifact_id]
    assert artifact['workflow_run']['id']==RUN and artifact['workflow_run']['head_sha']==HOST
    assert artifact['expired'] is False
    archive_hash=hashlib.sha256(); size=0
    with args.zip.open('rb') as handle:
        while chunk:=handle.read(1024*1024):
            archive_hash.update(chunk); size+=len(chunk)
    assert size==artifact['size_in_bytes']
    assert 'sha256:'+archive_hash.hexdigest()==artifact['digest']
    catalog_raw=args.catalog.read_bytes()
    assert hashlib.sha256(catalog_raw).hexdigest()==CATALOG_SHA
    catalog=json.loads(catalog_raw)
    binding_raw=args.activation_binding.read_bytes(); binding=json.loads(binding_raw)
    assert (binding['host'],binding['tree'],binding['run_id'],binding['attempt']) == (HOST,TREE,RUN,ATTEMPT)
    selected={r['path']:r for r in binding['selected_sources']}
    for suite in catalog['flutter_files']:
        assert selected[suite['path']]['git_blob']==suite['selected_source']['git_blob']
    assert sum(s['expected_visible_cases'] for s in catalog['flutter_files'])==82
    for name,data in raw_metadata.items(): store(output/'metadata'/name,data)
    store(output/'catalog.original.json',catalog_raw)
    store(output/'activation-binding.original.json',binding_raw)
    members=[]; materialized={}
    with zipfile.ZipFile(args.zip) as archive:
        names=archive.namelist()
        assert len(names)==len(set(names))
        machine_name,=[name for name in names if PurePosixPath(name).name=='flutter-machine.jsonl']
        summary_name,=[name for name in names if PurePosixPath(name).name=='acceptance-summary.json']
        for member in archive.infolist():
            name=PurePosixPath(member.filename)
            assert not name.is_absolute() and '..' not in name.parts and '\\' not in member.filename
            digest=hashlib.sha256(); crc=0; count=0; selected_raw=[]
            save=member.filename in (machine_name,summary_name)
            with archive.open(member,'r') as handle:
                while chunk:=handle.read(1024*1024):
                    digest.update(chunk); crc=zlib.crc32(chunk,crc); count+=len(chunk)
                    if save: selected_raw.append(chunk)
            assert count==member.file_size and crc & 0xffffffff==member.CRC
            members.append({'member':member.filename,'bytes':count,'sha256':digest.hexdigest(),
                            'crc32':f'{crc & 0xffffffff:08x}','compressed_bytes':member.compress_size,
                            'is_directory':member.is_dir()})
            if save:
                data=b''.join(selected_raw)
                store(output/'originals'/name.name,data)
                materialized[name.name]={'member':member.filename,**identity(data)}
    dump(output/'zip-members.json',members)
    machine=(output/'originals/flutter-machine.jsonl').read_bytes()
    summary=json.loads((output/'originals/acceptance-summary.json').read_bytes())
    starts={}; dones={}; suites={}; all_suites=[]; finals=[]; errors=[]
    duplicates=[]; non_json=[]; other_json=[]; counts=collections.Counter(); blank=0
    def event(value,line_no):
        if isinstance(value,list):
            for nested in value: event(nested,line_no)
            return
        if not isinstance(value,dict):
            other_json.append({'line':line_no,'value':value}); return
        kind=value.get('type')
        if kind is None:
            other_json.append({'line':line_no,'value':value}); return
        counts[kind]+=1
        record={'line':line_no,'event':value}
        if kind=='suite':
            key=value['suite']['id']
            if key in suites: duplicates.append({'kind':kind,'id':key,'line':line_no})
            else: suites[key]=record
        elif kind=='testStart':
            key=value['test']['id']
            if key in starts: duplicates.append({'kind':kind,'id':key,'line':line_no})
            else: starts[key]=record
        elif kind=='testDone':
            key=value['testID']
            if key in dones: duplicates.append({'kind':kind,'id':key,'line':line_no})
            else: dones[key]=record
        elif kind=='allSuites': all_suites.append(record)
        elif kind=='done': finals.append(record)
        elif kind=='error': errors.append(record)
    lines=machine.decode('utf-8').splitlines()
    for no,line in enumerate(lines,1):
        if not line.strip(): blank+=1; continue
        try: value=json.loads(line)
        except json.JSONDecodeError:
            non_json.append({'line':no,'text':line}); continue
        event(value,no)
    visible=[]; hidden=[]; unmatched=[]
    for tid,done in dones.items():
        start=starts.get(tid)
        if start is None:
            unmatched.append({'test_id':tid,'reason':'done without start','done':done});continue
        test=start['event']['test']; suite=suites.get(test['suiteID'])
        if suite is None:
            unmatched.append({'test_id':tid,'reason':'missing suite','start':start});continue
        path=suite['event']['suite']['path']; result=done['event']
        record={'id':tid,'suite_id':test['suiteID'],'suite_original_path':path,
                'path':repository_path(path),'name':test['name'],
                'start_line':start['line'],'done_line':done['line'],
                'start_time_ms':start['event']['time'],'done_time_ms':result['time'],
                'result':result['result'],'skipped':result.get('skipped'),
                'hidden':result.get('hidden'),'metadata':test.get('metadata')}
        (hidden if result.get('hidden') is True else visible).append(record)
    for tid,start in starts.items():
        if tid not in dones: unmatched.append({'test_id':tid,'reason':'start without done','start':start})
    failed=[r for r in visible if r['result']!='success']
    skipped=[r for r in visible if r['skipped'] is not False]
    passed=[r for r in visible if r['result']=='success' and r['skipped'] is False]
    by_case=collections.defaultdict(list)
    for row in visible: by_case[(row['path'],row['name'])].append(row)
    roster=[]; issues=[]; suite_case_counts=[]
    for suite in catalog['flutter_files']:
        assert len(suite['cases'])==suite['expected_visible_cases']
        actual_suite_count=sum(r['path']==suite['path'] for r in visible)
        suite_case_counts.append({'path':suite['path'],'expected':suite['expected_visible_cases'],
                                  'actual_visible':actual_suite_count})
        if actual_suite_count!=suite['expected_visible_cases']:
            issues.append({'selected_suite_case_count':suite_case_counts[-1]})
        for case in suite['cases']:
            matches=by_case[(suite['path'],case['name'])]
            okay=(len(matches)==1 and matches[0]['result']=='success'
                  and matches[0]['skipped'] is False and matches[0]['hidden'] is False
                  and matches[0]['metadata'].get('skip') is False)
            row={'group':suite['group'],'path':suite['path'],'name':case['name'],
                 'source_blob':suite['selected_source']['git_blob'],
                 'actual_matches':matches,'status':'PASS' if okay else 'UNSATISFIED'}
            roster.append(row)
            if not okay: issues.append({'roster_case':row})
    if duplicates: issues.append({'duplicate_protocol_ids':duplicates})
    if unmatched: issues.append({'unpaired_protocol_records':unmatched})
    if errors: issues.append({'error_events':errors})
    if failed: issues.append({'failed_visible':failed})
    if skipped: issues.append({'skipped_visible':skipped})
    if len(finals)!=1 or finals[0]['event'].get('success') is not True:
        issues.append({'final_done_not_unique_success':finals})
    expected_summary={'status':'PASS','passed':len(passed),'failed':[],'skipped':[],
                      'capture_error_files':[],'flutter_exit_code':0,
                      'runner_completed_successfully':True,'runner_errors':[]}
    for key,value in expected_summary.items():
        actual=summary.get(key)
        if actual!=value or type(actual) is not type(value):
            issues.append({'summary_field':key,'expected_from_originals':value,'actual':actual})
    pngs=[m for m in members if m['member'].lower().endswith('.png')]
    if summary.get('rendered_png_count')!=len(pngs):
        issues.append({'png_count_mismatch':{'zip':len(pngs),'summary':summary.get('rendered_png_count')}})
    per_group=collections.Counter(r['group'] for r in roster if r['status']=='PASS')
    result={'schema':'lumo.full-flutter-original-review.v1',
        'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'status':'PASS_CURRENT_FULL_FLUTTER_AND_82_TARGETS' if not issues else 'REQUIRES_REVIEW',
        'host':HOST,'tree':TREE,'run_id':RUN,'attempt':ATTEMPT,'build_job_id':BUILD_JOB,
        'build_job_status_at_snapshot':job['status'],'build_job_conclusion_at_snapshot':job['conclusion'],
        'artifact':artifact,'archive':{'path':str(args.zip),'bytes':size,'sha256':archive_hash.hexdigest()},
        'zip_members_complete_crc_sha_checked':len(members),'png_members':len(pngs),
        'materialized_originals':materialized,'original_summary':summary,
        'stream':{'line_count':len(lines),'blank_line_count':blank,'event_counts':dict(counts),
            'unique_suites':len(suites),'all_suites_events':all_suites,
            'unique_starts':len(starts),'unique_dones':len(dones),'visible_starts_with_dones':len(visible),
            'visible_passed':len(passed),'visible_failed':len(failed),'visible_skipped':len(skipped),
            'hidden_records':len(hidden),'error_events':errors,'final_done':finals,
            'non_json_lines_retained':non_json,'other_json_records_retained':other_json,
            'duplicates':duplicates,'unmatched':unmatched},
        'roster':{'expected':82,'actually_passed':sum(r['status']=='PASS' for r in roster),
                  'passed_per_group':dict(per_group),'suite_case_counts':suite_case_counts,
                  'source_catalog':identity(catalog_raw)},
        'issues':issues,
        'scope':'This is the complete current Flutter test stage and exact 82-case source mapping. No previous producer or 7ac outcome is transferred. No APK, native renderer, Android device, audio, release, or whole-workflow success is inferred.',
        'local_actions':'One original archive inspection and event analysis only; no tests, product imports, package calls, or source/index/ref writes.'}
    dump(output/'visible-cases.json',visible)
    dump(output/'hidden-records.json',hidden)
    dump(output/'target-82-case-results.json',roster)
    dump(output/'review.json',result)
    print(json.dumps({'status':result['status'],'visible_passed':len(passed),
        'visible_failed':len(failed),'visible_skipped':len(skipped),'hidden_records':len(hidden),
        'targets_passed':result['roster']['actually_passed'],'issues':issues,
        'review':identity((output/'review.json').read_bytes())},ensure_ascii=False,indent=2))
    return 0 if not issues else 1

if __name__=='__main__':
    raise SystemExit(main())
