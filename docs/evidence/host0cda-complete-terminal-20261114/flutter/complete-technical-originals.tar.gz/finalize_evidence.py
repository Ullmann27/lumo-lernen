from pathlib import Path
import collections,datetime,gzip,hashlib,io,json,re,tarfile
P=Path(__file__).resolve().parent
I=P/'inspection'
def ident(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def put(rel,b):
 p=P/rel;p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():assert p.read_bytes()==b,str(p)
 else:
  with p.open('xb') as f:f.write(b)
 assert p.read_bytes()==b
 return ident(b)
def js(rel,v):return put(rel,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
review=json.loads((I/'review.json').read_bytes());summary=review['original_summary'];stream=review['stream']
assert (review['host'],review['run_id'],review['attempt'])==('0cda410b9e5dceba3ffaf04f9c0fc45880dac6a9',43637785992,1)
assert (stream['unique_starts'],stream['unique_dones'],stream['visible_starts_with_dones'])==(3320,3320,2733)
assert (stream['visible_passed'],stream['visible_failed'],stream['visible_skipped'],stream['hidden_records'])==(2732,1,0,587)
assert not stream['duplicates'] and not stream['unmatched']
assert len(stream['error_events'])==1 and stream['error_events'][0]['event']['testID']==56
assert len(stream['final_done'])==1 and stream['final_done'][0]['event']=={'success':False,'type':'done','time':558383}
assert summary['flutter_exit_code']==1 and summary['status']=='FAIL' and summary['runner_completed_successfully'] is False
assert summary['passed']==2732 and summary['skipped']==[] and summary['runner_errors']==[]
assert summary['failed']==['Lifecycle pause during reward retry defers the settled result']
visible=json.loads((I/'visible-cases.json').read_bytes());hidden=json.loads((I/'hidden-records.json').read_bytes());targets=json.loads((I/'target-82-case-results.json').read_bytes())
assert len(targets)==82 and sum(t['status']=='PASS' for t in targets)==81
assert all(r['result']=='success' and r['skipped'] is False for r in hidden)
assert collections.Counter('loading' if r['name'].startswith('loading ') else r['name'] for r in hidden)=={'loading':403,'(setUpAll)':92,'(tearDownAll)':92}
assert len({r['id'] for r in visible})==2733
machine=(I/'originals/flutter-machine.jsonl').read_bytes();events=[]
for no,line in enumerate(machine.decode().splitlines(),1):
 try:d=json.loads(line)
 except json.JSONDecodeError:continue
 if isinstance(d,dict) and ((d.get('test') or {}).get('id')==56 or d.get('testID')==56 or (d.get('suite') or {}).get('id')==27):events.append({'line':no,'event':d})
assert len(events)==5 and [e['line'] for e in events]==[56,113,123,124,125]
assert 'connect_four_bot_save_retry_test.dart:261:5' in events[2]['event']['message']
js('failure-original-events.json',{'host':review['host'],'run_id':review['run_id'],'attempt':1,'job_id':132579589188,'artifact_id':14131068776,'machine':ident(machine),'events':events,'scope':'Current 0cda original events; not producer8e64 events.'})
logpath=Path('/tmp/host0cda-c4-run43637785992-evidence-20261114/terminal-build-20261114T2046Z/job-132579589188.original.log')
log=logpath.read_bytes();assert ident(log)['sha256']=='534a5bb9e7ee81cf6942e3274ad9df1b6bb3ace859c1ca9a690e8f2c634164aa'
put('originals/job-132579589188.original.log',log)
put('inspection-program.py',(P.parent/'analysis-programs/review_flutter_originals.py').read_bytes())
put('originals/activation-tree-leaves.json',(P.parent/'activation-originals/tree-leaves.json').read_bytes())
put('metadata-terminal-raw-manifest.json',Path('/tmp/host0cda-c4-run43637785992-evidence-20261114/snapshots/20261114T204541Z/raw-manifest.json').read_bytes())
loglines=log.decode('utf-8').splitlines();matches=[]
for no,line in enumerate(loglines,1):
 if '{"status": "FAIL", "passed":' in line:
  if json.loads(line[line.index('{'):])==summary:matches.append(no)
assert matches==[916] and 'Process completed with exit code 1.' in loglines[916]
metadata=json.loads((I/'metadata/jobs.original.json').read_bytes());job,=[j for j in metadata['jobs'] if j['id']==132579589188]
steps={s['number']:s for s in job['steps']}
assert steps[13]['conclusion']=='failure' and steps[14]['conclusion']=='success'
assert steps[20]['conclusion']=='skipped' and steps[21]['conclusion']=='failure'
assert 'FileNotFoundError' in log.decode() and 'build-contracts.log' in log.decode()
members=json.loads((I/'zip-members.json').read_bytes());assert len(members)==554
pngs=[m for m in members if m['member'].lower().endswith('.png')];assert len(pngs)==552
capture_counts={}
for env,r in summary['capture_png_counts'].items():
 actual=sum(m['member'].startswith(r['directory'].rstrip('/')+'/') for m in pngs)
 assert actual==r['pngs'];capture_counts[env]={'directory':r['directory'],'summary_pngs':r['pngs'],'actual_zip_pngs':actual}
for env,r in summary['capture_file_outputs'].items():assert r['created'] is True and sum(m['member']==r['path'] for m in pngs)==1
conclusion={'schema':1,'status':'ACTUAL_CURRENT_FULL_FLUTTER_FAIL_SINGLE_C4_PRECONDITION','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'host':review['host'],'tree':review['tree'],'run_id':43637785992,'attempt':1,'job_id':132579589188,'artifact_id':14131068776,'actual_visible_tests':{'started_and_finished':2733,'passed':2732,'failed':1,'skipped':0},'hidden_records':{'total':587,'loading':403,'setUpAll':92,'tearDownAll':92,'all_success':True},'protocol':{'suites':403,'reported_all_suites':403,'all_starts':3320,'all_dones':3320,'duplicate_or_unmatched_ids':False,'final_done':stream['final_done'][0],'non_json_lines_retained':len(stream['non_json_lines_retained']),'other_json_process_records_retained':len(stream['other_json_records_retained'])},'target_roster':{'total':82,'passed':81,'failed':1,'pr507_new':{'total':45,'passed':44,'failed':1},'pr507_corrected_existing':{'total':30,'passed':30,'failed':0},'pr508':{'total':7,'passed':7,'failed':0},'case_mapping':'inspection/target-82-case-results.json'},'single_failure':{'path':'test/games/connect_four_bot_save_retry_test.dart','source_blob':'c4b90bc73b76a2df23acdb253fa4213b798fed21','name':summary['failed'][0],'test_id':56,'suite_id':27,'start_ms':9288,'framework_failure_ms':10154,'done_ms':10159,'assertion_line':261,'assertion':'held.entered.isCompleted expected true, actual false','stage':'Before inactive lifecycle and before release of the held platform write.','original_events':'failure-original-events.json'},'actual_process_result':{'summary_exit':1,'joblog_summary_line':916,'joblog_exit1_line':917,'runner_completed_successfully':False,'runner_errors':[]},'later_contract_status':{'build_contract_step20':'skipped','speech23_17_30':'NOT_RUN_THIS_BUILD','step21':'failure saving absent build-contracts.log after skippedStep20; not a separately executed contract failure'},'zip':{'bytes':337141742,'sha256':'cf7caeb2c8bd06eea294e9610daca813d6a32914a46384426c276d02b1d69053','members_full_crc_sha_verified':554,'pngs':552,'pngs_extracted_or_visually_reviewed':False,'capture_counts':capture_counts},'originals':review['materialized_originals'],'boundaries':['No producer or old7ac result is transferred.','Compile job132578338582 remains separately SUCCESS; the full current workflow is FAILURE.','Proposed clock-fixture correction is a separate source-only frozen pack and has not been tested here.','No Android-device, native-renderer, audio, FPS, APK or release approval follows.','The reader originally exited1 because its strict acceptance check found this real failure; all original diagnostics are retained, with no parser-error or retry claim.']}
js('observation-conclusion.json',conclusion)
js('handoff.json',{'schema':1,'status':conclusion['status'],'host':review['host'],'tree':review['tree'],'run_id':43637785992,'attempt':1,'compile_evidence_pack':'../host-compile/complete-original-pack.tar.gz','conclusion':ident((P/'observation-conclusion.json').read_bytes()),'machine':ident(machine),'summary':ident((I/'originals/acceptance-summary.json').read_bytes()),'actual_result':{'visible':'2732PASS/1FAIL/0SKIP','target82':'81PASS/1FAIL','speech23_17_30':'NOT_RUN_STEP20_SKIPPED'},'original_zip':{'path':str(P/'artifact-14131068776.original.zip'),'bytes':337141742,'sha256':review['archive']['sha256'],'complete_crc_sha_member_index':'inspection/zip-members.json'},'storage':'The compact technical archive retains all machine/summary/log/source-binding/report bytes. The original337MB ZIP remains once in place; its552 PNGs are not duplicated or visually reviewed. Root owns durable publication and any future source/CI activation.'})
files=sorted(p for p in P.rglob('*') if p.is_file() and p.name not in ('artifact-14131068776.original.zip','manifest.json','complete-technical-originals.tar.gz','archive-binding.json'))
js('manifest.json',{'schema':1,'entries':[{'path':p.relative_to(P).as_posix(),**ident(p.read_bytes())} for p in files],'external_original_zip':{'path':'artifact-14131068776.original.zip','bytes':337141742,'sha256':review['archive']['sha256']}});files.append(P/'manifest.json')
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tar:
 for p in sorted(files):
  data=p.read_bytes();info=tarfile.TarInfo(p.relative_to(P).as_posix());info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
archive=gzip.compress(buf.getvalue(),mtime=0);put('complete-technical-originals.tar.gz',archive)
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
 assert len(tar.getmembers())==len(files)
 for m in tar.getmembers():assert tar.extractfile(m).read()==(P/m.name).read_bytes()
js('archive-binding.json',{'path':'complete-technical-originals.tar.gz',**ident(archive),'members':len(files),'roundtrip':True,'original_zip_and_png_payloads_not_duplicated':True})
print(json.dumps({n:ident((P/n).read_bytes()) for n in ('observation-conclusion.json','failure-original-events.json','handoff.json','manifest.json','complete-technical-originals.tar.gz')},indent=2))
