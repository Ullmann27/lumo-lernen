"""Bind final original timing and archive metadata without changing input bytes."""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import shlex

ROOT = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(relative):
    return json.loads((ROOT / relative).read_bytes())


def timestamp(value):
    # The original GitHub log includes its UTF-8 BOM; the stored raw bytes stay intact.
    return datetime.fromisoformat(value.removeprefix("\ufeff").replace("Z", "+00:00"))


def write(relative, data):
    path = ROOT / relative
    assert not path.exists()
    path.write_text(json.dumps(data, indent=2) + "\n")
    print(relative, sha(path.read_bytes()))


run = read("proofs/run.json")
jobs = read("proofs/jobs.json")
job = next(item for item in jobs["jobs"] if item["name"] == "new-worlds")
step = next(item for item in job["steps"]
            if item["name"] == "New learning, character and interactive production-scene gates")
assert run["id"] == 43532048311 and run["conclusion"] == "success"
assert run["head_sha"] == "17f5b9d4a14c70050d4a125a8bd6bd8c68ee7845"
assert run["head_commit"]["tree_id"] == "b8ea9b1777e8d0b6302156330d4d1b298a316aea"
raw_log = (ROOT / "jobs/new-worlds-132251894982.log").read_bytes()
lines = raw_log.decode().splitlines()
events = []
for number, line in enumerate(lines, 1):
    match = re.match(r"^(\S+Z) (.*)$", line)
    if (match and timestamp(step["started_at"]) <= timestamp(match[1]) <= timestamp(step["completed_at"])
            and match[2].startswith("Godot Engine v4.6.3")):
        events.append({"line": number, "timestamp": match[1], "raw": line})
source = ROOT / "source-17f5b9d4/tools/validate_nextgen.sh"
calls = []
for line in source.read_text().splitlines():
    if line.startswith("check_probe "):
        words = shlex.split(line)
        calls.append({"probe": words[1], "marker": words[2], "mode": words[3]})
index = read("artifacts/14090115236-verification.json")
results = index["results_tsv"]["nextgen-evidence/nextgen/results.tsv"].splitlines()[1:]
assert len(events) == len(calls) == len(results) == 48
assert [(item["probe"], item["mode"]) for item in calls] == [tuple(row.split("\t")[:2]) for row in results]
selected = {
    ("cards_safe_area_android_contract", "headless"): 180,
    ("cards_safe_area_regression", "headless"): 180,
    ("mobile_safe_area_regression", "headless"): 240,
    ("cards_safe_area_regression", "rendered"): 600,
    ("mobile_safe_area_regression", "rendered"): 900,
}
rows = []
for ordinal, call in enumerate(calls):
    pair = (call["probe"], call["mode"])
    if pair not in selected:
        continue
    start, following = events[ordinal], events[ordinal + 1]
    matches = [number for number in range(start["line"] - 1, following["line"] - 1)
               if call["marker"] in lines[number]]
    assert len(matches) == 1
    number = matches[0]
    passed = {"line": number + 1, "timestamp": lines[number].split(" ", 1)[0], "raw": lines[number]}
    previous = [number for number in range(events[ordinal - 1]["line"] - 1, start["line"] - 1)
                if calls[ordinal - 1]["marker"] in lines[number]]
    assert previous
    number = previous[-1]
    previous_pass = {"line": number + 1, "timestamp": lines[number].split(" ", 1)[0], "raw": lines[number]}
    rows.append({
        **call, "ordered_core_probe": ordinal + 1, "engine_banner": start,
        "required_pass": passed, "following_engine_banner": following,
        "preceding_required_pass": previous_pass,
        "observed_banner_to_pass_seconds": round((timestamp(passed["timestamp"]) - timestamp(start["timestamp"])).total_seconds(), 6),
        "conservative_previous_pass_to_next_banner_seconds": round((timestamp(following["timestamp"]) - timestamp(previous_pass["timestamp"])).total_seconds(), 6),
        "individual_timeout_seconds": selected[pair],
    })
assert len(rows) == 5
all_jobs = []
for item in jobs["jobs"]:
    assert item["conclusion"] == "success"
    all_jobs.append({
        **{key: item[key] for key in ("id", "name", "status", "conclusion", "started_at", "completed_at")},
        "duration_seconds": (timestamp(item["completed_at"]) - timestamp(item["started_at"])).total_seconds(),
        "steps": item["steps"],
    })
write("final-job-and-safe-area-times.json", {
    "schema": 1, "head_sha": run["head_sha"], "source_tree": run["head_commit"]["tree_id"], "run_id": run["id"],
    "original_jobs_api": {"path": "proofs/jobs.json", "sha256": sha((ROOT / "proofs/jobs.json").read_bytes())},
    "original_worlds_log": {"path": "jobs/new-worlds-132251894982.log", "sha256": sha(raw_log)},
    "frozen_sequential_runner": {"path": str(source.relative_to(ROOT)), "sha256": sha(source.read_bytes())},
    "all_48_banners_match_exact_ordered_probe_results": True,
    "worlds_job_seconds": (timestamp(job["completed_at"]) - timestamp(job["started_at"])).total_seconds(),
    "worlds_core_step_seconds": (timestamp(step["completed_at"]) - timestamp(step["started_at"])).total_seconds(),
    "worlds_core_step_original": step, "requested_five_modes": rows, "jobs": all_jobs,
    "timing_method": "Original GitHub job/step wall times have one-second resolution. Per-probe values are observed GitHub log spans from engine banner to required PASS, not exact process-runtime measurements. The enclosing previous-PASS to following-banner span includes neighboring shutdown/startup and is an additional sequential CI-log estimate, not an independently measured process-runtime bound. All 48 ordered banners and results were matched to the exact blocking shell runner.",
    "limits": [
        "Per-mode enclosing intervals overlap slightly and must not be summed as exact elapsed time.",
        "These CI software-renderer durations are not device performance or FPS.",
        "Parallel workflow job duration is not equivalent to sequential Host build duration.",
        "Process creation and exit do not have dedicated timestamps in this original runner; log delivery can add latency.",
    ],
})
print(json.dumps([{key: item[key] for key in ("probe", "mode", "observed_banner_to_pass_seconds", "conservative_previous_pass_to_next_banner_seconds", "individual_timeout_seconds")} for item in rows]))

release, ref = read("archive-release.json"), read("archive-tag-ref.json")
bundle = read("artifacts/14089423812-verification.json")
artifact = next(item for item in read("proofs/artifacts.json")["artifacts"] if item["id"] == 14089423812)
assert ref["object"]["sha"] == run["head_sha"] and ref["object"]["type"] == "commit"
assert release["target_commitish"] == run["head_sha"] and release["draft"] is False and release["prerelease"] is True
assert release["tag_name"] == "integration-evidence-" + run["head_sha"] + "-14089423812"
assets = {item["name"]: item for item in release["assets"]}
assert set(assets) == {"native-evidence.zip", "native-evidence.zip.sha256", "native-artifact.json"}
asset = assets["native-evidence.zip"]
assert asset["state"] == "uploaded" and asset["size"] == bundle["zip_bytes"]
assert asset["digest"] == "sha256:" + bundle["zip_sha256"] == artifact["digest"]
expected_checksum = (bundle["zip_sha256"] + "  native-evidence.zip\n").encode()
assert assets["native-evidence.zip.sha256"]["size"] == len(expected_checksum)
assert assets["native-evidence.zip.sha256"]["digest"] == "sha256:" + sha(expected_checksum)
expected_metadata = (json.dumps(artifact, indent=2) + "\n").encode()
assert assets["native-artifact.json"]["size"] == len(expected_metadata)
assert assets["native-artifact.json"]["digest"] == "sha256:" + sha(expected_metadata)
archive_job = next(item for item in jobs["jobs"] if item["name"] == "archive-evidence")
assert archive_job["conclusion"] == "success"
archive_log = (ROOT / "jobs/archive-evidence-132266192610.log").read_bytes()
assert b"native-evidence.zip: OK" in archive_log
assert b"cmp native-evidence.zip public-native-evidence.zip" in archive_log
write("archive-verification.json", {
    "schema": 1, "status": "ORIGINAL_ARCHIVE_METADATA_AND_DIGEST_BOUND_TO_VERIFIED_ZIP",
    "head_sha": run["head_sha"], "tree": run["head_commit"]["tree_id"], "run_id": run["id"],
    "release_id": release["id"], "release_url": release["html_url"], "tag": release["tag_name"],
    "zip_asset_id": asset["id"], "zip_asset_url": asset["browser_download_url"],
    "zip_bytes": asset["size"], "zip_sha256": bundle["zip_sha256"], "release_api_immutable": release.get("immutable"),
    "release_metadata_sha256": sha((ROOT / "archive-release.json").read_bytes()),
    "tag_ref_metadata_sha256": sha((ROOT / "archive-tag-ref.json").read_bytes()),
    "original_archive_job_log": "jobs/archive-evidence-132266192610.log", "original_archive_job_log_sha256": sha(archive_log),
    "additional_asset_checks": {"checksum_asset_exact_workflow_serialization_sha256": sha(expected_checksum), "artifact_metadata_exact_workflow_serialization_sha256": sha(expected_metadata)},
    "method": [
        "Downloaded original Actions ZIP matches the actual original Actions API digest and byte count.",
        "Actual release API reports the same ZIP digest and byte count; the tag resolves to the exact current source.",
        "The two small metadata assets match the exact workflow serialization independently recomputed from the original Actions API object. No text asset download is claimed.",
        "Successful original archive job verifies the Actions digest, downloads the public release ZIP and executes cmp under bash -e.",
    ],
    "limits": [
        "No second independent local public-release ZIP download is claimed.",
        "The GitHub release immutable field is false. Saved content digests bind the observed bytes.",
        "Evidence archive only; no APK or new release approval by this collector.",
    ],
})
