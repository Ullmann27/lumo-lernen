"""Materialize only the requested current Worlds originals for Root's review."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile


ROOT = Path(__file__).resolve().parent
HEAD = "17f5b9d4a14c70050d4a125a8bd6bd8c68ee7845"
TREE = "b8ea9b1777e8d0b6302156330d4d1b298a316aea"
RUN = 43532048311


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("artifact_id", type=int)
    args = parser.parse_args()
    report = json.loads((ROOT / "artifacts" / f"{args.artifact_id}-verification.json").read_bytes())
    assert report["head"] == HEAD and report["tree"] == TREE and report["run_id"] == RUN
    assert report["name"] == "lumo-nextgen-2018-worlds-evidence"
    assert report["complete_crc_sha256"] and report["all_pngs_fully_decoded"]
    assert not report["log_errors"]
    members = {item["path"]: item for item in report["members"]}
    reference = json.loads((ROOT / "selection-entry-reference-29.json").read_bytes())
    selected = [item for item in reference["selected_paths"]
                if item["artifact_entry"].startswith("nextgen-evidence/")]
    assert len(selected) == 26
    images = []
    sidecars = []
    with zipfile.ZipFile(ROOT / "artifacts" / f"{args.artifact_id}-original.zip") as zipped:
        def preserve(entry):
            item = members[entry]
            raw = zipped.read(entry)
            assert len(raw) == item["bytes"]
            assert hashlib.sha256(raw).hexdigest() == item["sha256"]
            path = ROOT / "review-candidates" / str(args.artifact_id) / entry
            assert not path.exists()
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
            return {"artifact_id": args.artifact_id,
                    "artifact_sha256": report["zip_sha256"],
                    "artifact_entry": entry, "expected_bundle_entry": entry,
                    "local_path": str(path), "bytes": len(raw),
                    "sha256": item["sha256"]}

        for selected_image in selected:
            entry = selected_image["artifact_entry"]
            item = preserve(entry)
            item["module"] = selected_image["module"]
            item["dimensions"] = [members[entry]["png"]["width"],
                                  members[entry]["png"]["height"]]
            item["safe_area_fixture"] = "/cards_safe_area_regression/" in entry or "/mobile_safe_area_regression/" in entry
            images.append(item)
            if "/cards_safe_area_regression/" in entry:
                sidecars.append(preserve(entry.removesuffix(".png") + ".layout.json"))
        for probe, name in [("cards_safe_area_regression", "cards-safe-area.json"),
                            ("mobile_safe_area_regression", "mobile-safe-area.json")]:
            sidecars.append(preserve(f"nextgen-evidence/nextgen/captures/{probe}/{name}"))
    assert len(sidecars) == 5
    output = {
        "schema": 1, "native_commit": HEAD, "source_tree": TREE, "run_id": RUN,
        "artifact_id": args.artifact_id, "images": images,
        "safe_area_original_sidecars_and_reports": sidecars,
        "scope": "Current original candidates only. No collector visual claim or Android claim. The final bundle must preserve these exact bytes.",
    }
    path = ROOT / "current-worlds-26-candidates.json"
    assert not path.exists()
    path.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"catalog": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                      "images": len(images), "safe_area_images": sum(item["safe_area_fixture"] for item in images),
                      "original_sidecars_and_reports": len(sidecars)}, indent=2))


if __name__ == "__main__":
    main()
