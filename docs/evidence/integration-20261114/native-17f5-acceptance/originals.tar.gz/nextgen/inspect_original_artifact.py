"""Index exact 17f Nextgen ZIP bytes without extracting the archive."""
from pathlib import Path, PurePosixPath
from io import BytesIO
import argparse
import hashlib
import json
import re
import stat
import zipfile
from PIL import Image

ROOT = Path(__file__).resolve().parent
HEAD = "17f5b9d4a14c70050d4a125a8bd6bd8c68ee7845"
TREE = "b8ea9b1777e8d0b6302156330d4d1b298a316aea"
RUN = 43532048311
BASELINE = "1d5c5cb45a323228f627ec529e6ff1ddd86f1c57"
BASELINE_TREE = "0941a80d811df4e3630f0c9de44d1417148ae320"


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("artifact_id", type=int)
    parser.add_argument("snapshot")
    args = parser.parse_args()
    api = json.loads((ROOT / "snapshots" / args.snapshot / "artifacts.json").read_bytes())
    matches = [a for a in api["artifacts"] if a["id"] == args.artifact_id]
    assert len(matches) == 1
    artifact = matches[0]
    assert artifact["workflow_run"]["id"] == RUN
    assert artifact["workflow_run"]["head_sha"] == HEAD
    assert artifact["expired"] is False
    archive = ROOT / "artifacts" / f"{args.artifact_id}-original.zip"
    zip_hash = digest(archive)
    assert archive.stat().st_size == artifact["size_in_bytes"]
    assert "sha256:" + zip_hash == artifact["digest"]
    members, images, stamps, issues, results = [], [], [], [], {}
    logs = 0
    with zipfile.ZipFile(archive) as zipped:
        seen = set()
        for entry in zipped.infolist():
            name = entry.filename
            path = PurePosixPath(name)
            assert name and not path.is_absolute() and ".." not in path.parts
            assert "\\" not in name and name not in seen
            assert stat.S_IFMT(entry.external_attr >> 16) in (
                0, stat.S_IFDIR if entry.is_dir() else stat.S_IFREG
            )
            assert not entry.flag_bits & 1
            seen.add(name)
            if entry.is_dir():
                continue
            h, count = hashlib.sha256(), 0
            with zipped.open(entry) as stream:
                while True:
                    chunk = stream.read(1024 * 1024)
                    if not chunk:
                        break
                    count += len(chunk)
                    h.update(chunk)
            assert count == entry.file_size
            item = {"path": name, "bytes": count,
                    "compressed_bytes": entry.compress_size,
                    "crc32": f"{entry.CRC:08x}", "sha256": h.hexdigest()}
            if name.endswith(".png"):
                data = zipped.read(entry)
                with Image.open(BytesIO(data)) as image:
                    assert image.format == "PNG"
                    image.verify()
                with Image.open(BytesIO(data)) as image:
                    image.load()
                    item["png"] = {"width": image.width, "height": image.height,
                                   "mode": image.mode}
                images.append(item)
            if name.endswith(".log"):
                logs += 1
                text = zipped.read(entry).decode("utf-8", errors="replace")
                text = re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", text)
                for number, line in enumerate(text.splitlines(), 1):
                    if re.match(r"\s*(?:SCRIPT ERROR|Parse Error|ERROR:|handle_crash|Program crashed|WARNING: ObjectDB instances leaked|\[[^\]]+\] FAIL)", line):
                        issues.append({"path": name, "line": number, "text": line})
            if path.name in ("source-sha.txt", "source-tree.txt", "source-dirty.txt", "source-dirty-after.txt"):
                value = zipped.read(entry).decode("utf-8").strip()
                baseline = "/baseline-2017/" in name
                expected = {
                    "source-sha.txt": BASELINE if baseline else HEAD,
                    "source-tree.txt": BASELINE_TREE if baseline else TREE,
                    "source-dirty.txt": "", "source-dirty-after.txt": "",
                }[path.name]
                assert value == expected, (name, value, expected)
                stamps.append({"path": name, "value": value,
                               "role": "historical_baseline_2017" if baseline else "current_17f",
                               "sha256": item["sha256"]})
            if path.name == "results.tsv":
                results[name] = zipped.read(entry).decode("utf-8")
            members.append(item)
    report = {
        "schema": 1, "artifact_id": artifact["id"], "name": artifact["name"],
        "head": HEAD, "tree": TREE, "run_id": RUN,
        "zip_bytes": archive.stat().st_size, "zip_sha256": zip_hash,
        "complete_crc_sha256": True, "member_count": len(members),
        "png_count": len(images), "all_pngs_fully_decoded": True,
        "artifact_logs_scanned": logs, "log_errors": issues,
        "source_stamps": stamps, "results_tsv": results, "members": members,
        "scope": "Original byte inspection only; no receipt, visual approval or Android claim.",
    }
    output = ROOT / "artifacts" / f"{artifact['id']}-verification.json"
    assert not output.exists()
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: report[key] for key in (
        "artifact_id", "name", "zip_bytes", "zip_sha256", "member_count", "png_count",
        "artifact_logs_scanned", "log_errors", "results_tsv"
    )}, indent=2))
    return 0 if not issues else 1


if __name__ == "__main__":
    raise SystemExit(main())
