"""Verify the current original 17f5 bundle with the frozen production parser.

This collector does not create a receipt or claim a human visual review.
"""
from pathlib import Path
import argparse
import hashlib
import json
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
HEAD = "17f5b9d4a14c70050d4a125a8bd6bd8c68ee7845"
TREE = "b8ea9b1777e8d0b6302156330d4d1b298a316aea"
RUN = 43532048311
PARSER_MANIFEST = "27afc07db0f287a87489282953eadea36b8bffd5826eaaffda55156c60edac6a"


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def main():
    args = argparse.ArgumentParser()
    args.add_argument("--snapshot", required=True)
    args.add_argument("--artifact-id", required=True, type=int)
    args.add_argument("--worlds-id", required=True, type=int)
    opt = args.parse_args()
    snapshot = ROOT / "snapshots" / opt.snapshot
    parser = ROOT / "parser48-frozen"
    assert digest(parser / "manifest.json") == PARSER_MANIFEST
    frozen = read(parser / "manifest.json")
    for name, expected in frozen["files"].items():
        source = parser / name
        assert source.stat().st_size == expected["bytes"]
        assert digest(source) == expected["sha256"], name
    sys.path[:0] = [str(parser / "scripts"), str(parser)]
    import verify_studio_delivery as verifier

    workflow = read(snapshot / "run.json")
    jobs = read(snapshot / "jobs.json")
    artifacts = read(snapshot / "artifacts.json")
    assert workflow["id"] == RUN and workflow["run_attempt"] == 1
    assert workflow["event"] == "pull_request" and workflow["head_sha"] == HEAD
    assert workflow["head_commit"]["tree_id"] == TREE
    matches = [a for a in artifacts["artifacts"] if a["id"] == opt.artifact_id]
    assert len(matches) == 1
    artifact = matches[0]
    download = read(ROOT / "artifacts" / f"{opt.artifact_id}-download.json")
    archive = Path(download["workspace_symlink"]).resolve(strict=True)
    assert archive.is_file() and archive.stat().st_size == artifact["size_in_bytes"]
    archive_digest = digest(archive)
    assert "sha256:" + archive_digest == artifact["digest"]
    assert archive_digest == download["sha256"]
    verifier.verify_native_acceptance(
        HEAD, artifact, workflow, jobs, native_profile="nextgen-2019"
    )
    with zipfile.ZipFile(archive) as zipped:
        sources = verifier.verify_archive_sources(
            zipped, HEAD, native_profile="nextgen-2019"
        )
        facts = verifier.verify_nextgen_archive(zipped, workflow)

    bundle_index = read(ROOT / "artifacts" / f"{opt.artifact_id}-verification.json")
    assert bundle_index["zip_sha256"] == archive_digest
    assert bundle_index["complete_crc_sha256"] is True
    assert bundle_index["all_pngs_fully_decoded"] is True
    assert not bundle_index["log_errors"]
    actual = {entry["path"]: entry for entry in bundle_index["members"]}
    expected = {}
    bindings = []
    for component, prefix in (
        (opt.worlds_id, ""),
        (14088417302, "touch-evidence/"),
        (14088113248, "touch-evidence/"),
        (14088391493, "touch-evidence/"),
    ):
        index = read(ROOT / "artifacts" / f"{component}-verification.json")
        assert index["complete_crc_sha256"] is True
        assert index["all_pngs_fully_decoded"] is True
        assert not index["log_errors"]
        for entry in index["members"]:
            path = prefix + entry["path"]
            assert path not in expected, path
            assert path in actual, path
            assert (entry["bytes"], entry["sha256"]) == (
                actual[path]["bytes"], actual[path]["sha256"]
            ), path
            expected[path] = entry
        bindings.append({
            "artifact_id": component,
            "original_zip_sha256": index["zip_sha256"],
            "bundle_prefix": prefix,
            "all_members_byte_identical": True,
            "member_count": len(index["members"]),
        })
    assert set(expected) == set(actual), "The bundle must be exactly the component union"
    for name, expected_file in frozen["files"].items():
        assert digest(parser / name) == expected_file["sha256"], name
    archive_jobs = [j for j in jobs["jobs"] if j["name"] == "archive-evidence"]
    report = {
        "schema": 1,
        "status": "PASS",
        "native_head": HEAD,
        "native_tree": TREE,
        "run_id": RUN,
        "attempt": 1,
        "artifact_id": opt.artifact_id,
        "original_zip_bytes": archive.stat().st_size,
        "original_zip_sha256": archive_digest,
        "parser_manifest_sha256": PARSER_MANIFEST,
        "parser_files_unchanged": frozen["files"],
        "original_api_inputs": {
            name: {"path": str((snapshot / name).relative_to(ROOT)),
                   "sha256": digest(snapshot / name)}
            for name in ("run.json", "jobs.json", "artifacts.json")
        },
        "current_sources": sources,
        "production_parser_facts": facts,
        "component_bindings": bindings,
        "archive_job": [{"id": j["id"], "status": j["status"],
                         "conclusion": j["conclusion"]} for j in archive_jobs],
        "scope": "Technical original-bundle verification only. No human visual acceptance, Android acceptance, public release, receipt or pin is granted by this collector.",
    }
    output = ROOT / "strict48-bundle-verification.json"
    assert not output.exists()
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": "PASS", "report": str(output),
                      "report_sha256": digest(output), **facts}, indent=2))


if __name__ == "__main__":
    main()
