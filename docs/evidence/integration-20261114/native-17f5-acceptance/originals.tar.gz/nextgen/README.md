# Native PR166 — 17f5 Nextgen48 original checkpoint

Source `17f5b9d4a14c70050d4a125a8bd6bd8c68ee7845`, tree `b8ea9b1777e8d0b6302156330d4d1b298a316aea`, run `43532048311`, attempt 1. All eight actual jobs completed successfully, including the evidence bundle and public evidence archive.

## Completed technical contract

The exact frozen production Host parser passed the downloaded original bundle: 48 ordered Core probe/mode pairs; 24 Studio, four Village, six Puzzle-menu and seven Safe-Area images; three primary Cards layout sidecars and two fixture reports; six Touch pairs and 32 Touch images. All four current source-tree stamps equal the published tree. The seven parser files were checked before and after use.

Every member of all seven original ZIPs was streamed through CRC and SHA-256 checks; every PNG was fully decoded. The final 193,639,821-byte bundle (`9cca7adfe2c5bf8af5e0db6bafc249f68caa9f1983f440164307bb68b29a91e8`) contains 3,265 entries and is exactly the byte-identical union of the Worlds archive and all three Touch archives. Its 153 PNGs and 118 artifact logs were inspected. Separate Preview and Gameplay originals remain present, as do all eight complete decoded job logs. The independent component archives contain 170 artifact logs; the bundle duplicates its component members and must not be counted as additional tests.

Current Safe-Area markers report Android-contract 20, Cards headless 682, Mobile headless 112, Cards rendered 691 with three images, and Mobile rendered 124 with four images. These are platform-boundary fixtures and software-renderer evidence. They are not Android device results. The actual current Kart test records scene/audio release before resume (50 ms) and final release (51 ms), followed by its real PASS.

## Current review inputs

`recorder-inputs-ready.json` gives absolute original ZIP/API/parser paths and their hashes. The bundle ZIP is resolved to `/tmp/lumo-17f5b9d4-original-zips/14089423812-original.zip`; only a symlink is kept here. `proofs/artifact-14089423812.json` is an exact original API-object byte slice, with offsets and source hash in `artifact-object-byte-slices.json`.

The 29 selected current candidates comprise nine production families, three Touch groups, four Village frames, six Puzzle-menu frames and all seven Safe-Area images. `all-29-candidate-final-bundle-binding.json` checks their actual local bytes against the final bundle. It makes no visual judgment. The four supplied early Root observations (Preview plus three Touch) are copied without edits and separately bound to the final bundle. Root is completing the remaining Worlds observations in a separate review folder after this collector freeze; this checkpoint does not fabricate their findings or claim a final Native visual receipt.

## Original archive and measured time

Release `444891136`, asset `745767423`, and the exact source tag are bound to the same ZIP digest and byte count. The successful original archive job verifies the Actions ZIP, downloads the public release ZIP and compares both under `bash -e`. The release API says `immutable=false`; no server-enforced immutability or second local public-ZIP download is claimed. The archive contains evidence, not an APK.

The Worlds job took 37:38; its Core step took 31:56 according to original job metadata. The five new modes have observed engine-banner-to-PASS spans of 0.141, 8.043, 10.592, 312.570 and 112.443 seconds. `final-job-and-safe-area-times.json` retains exact log lines, timestamps and enclosing intervals. The runner does not independently timestamp process creation/exit; these are CI-log spans, not exact process timers or device performance. Parallel job times cannot be substituted for sequential Host build duration.

## Preservation

- `snapshots/` and `proofs/`: unchanged original API response bytes and exact object slices.
- `jobs/`: eight full original decoded logs, including their BOM/ANSI bytes.
- `originals/`: unchanged component logs, source stamps, manifests, layouts and reports.
- `artifacts/*-verification.json`: complete ZIP member/PNG hash indexes.
- `parser48-frozen/` and `source-17f5b9d4/`: exact frozen parser and Native source bindings.
- `review-candidates/`: only requested current review images and small Safe-Area sidecars/reports.
- `manifest.json` and `SHA256SUMS`: final regular-file inventory; external original ZIPs are separately listed and rehashed at freeze.

No old ee97 result is used as a result for this new source. Root owns the final visual receipt and Host pin decisions. Source files, refs, the index and pins were not changed by this collector.
