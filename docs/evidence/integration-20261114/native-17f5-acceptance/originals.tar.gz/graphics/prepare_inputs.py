#!/usr/bin/env python3
"""Check complete inputs with existing recorder readers; never create a receipt."""
import hashlib
import json
from pathlib import Path
import sys
import zipfile

sys.dont_write_bytecode = True
HOST = Path(__file__).resolve().parent / 'parser-frozen'
sys.path.insert(0, str(HOST / 'scripts'))
from record_kart_graphics_review import _zip_index, _member, _check_manifest, _input_bytes
from verify_kart_graphics_review import REQUIRED_LOGS, SOURCE_FILES, WORKFLOW_FILES

ROOT = Path(__file__).resolve().parent
PROOFS = ROOT / 'proofs'
HEAD = '17f5b9d4a14c70050d4a125a8bd6bd8c68ee7845'
RUN = 43532048253


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


sources = {name: sha(HOST / 'scripts' / name) for name in ['record_kart_graphics_review.py', 'verify_kart_graphics_review.py']}
run = json.loads(_input_bytes(PROOFS / 'run.json', 8 * 1024 * 1024))
jobs = json.loads(_input_bytes(PROOFS / 'jobs.json', 8 * 1024 * 1024))
assert run['id'] == RUN and run['head_sha'] == HEAD
assert run['status'] == 'completed' and run['conclusion'] == 'success'
assert jobs['total_count'] == len(jobs['jobs']) == 3
assert all(job['run_id'] == RUN and job['status'] == 'completed' and job['conclusion'] == 'success' for job in jobs['jobs'])
rows = []
for area in ['home', 'worlds', 'feedback']:
    metadata = PROOFS / (area + '-artifact.json')
    artifact = json.loads(_input_bytes(metadata, 8 * 1024 * 1024))
    archive = (ROOT / 'artifacts' / (str(artifact['id']) + '-original.zip')).resolve()
    assert artifact['digest'] == 'sha256:' + sha(archive)
    assert artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == HEAD
    verification = json.loads((ROOT / (area + '-verified.json')).read_text())
    assert verification['all_checked_gates_clean'] and not verification['errors']
    with zipfile.ZipFile(archive) as zipped:
        entries = _zip_index(zipped)
        raw = {name: metadata.read_bytes() if name == 'artifact.json' else _member(zipped, entries, name)
               for name in (*SOURCE_FILES, *REQUIRED_LOGS[area])}
        _check_manifest(zipped, entries, raw['image-manifest.json'])
    rows.append({'area': area, 'archive': str(archive), 'archive_sha256': sha(archive),
                 'artifact_id': artifact['id'], 'proof_metadata_sha256': sha(metadata),
                 'original_required_files': sorted(raw), 'images': len(verification['images'])})
assert sources == {name: sha(HOST / 'scripts' / name) for name in sources}
summary = {'head_sha': HEAD, 'source_tree': 'b8ea9b1777e8d0b6302156330d4d1b298a316aea',
           'run_id': RUN, 'recorder_input_set_complete': True,
           'proofs_directory': str(PROOFS), 'archives': rows,
           'workflow_proofs': {name: sha(PROOFS / name) for name in WORKFLOW_FILES},
           'existing_recorder_readers': sources,
           'receipt_created': False, 'visual_review_performed_by_this_script': False,
           'scope': 'Only archive, raw proof, source and existing recorder input checks. Root must inspect the current original images and supply actual findings before invoking the recorder.'}
assert not (ROOT / 'recorder-inputs-ready.json').exists()
(ROOT / 'recorder-inputs-ready.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
