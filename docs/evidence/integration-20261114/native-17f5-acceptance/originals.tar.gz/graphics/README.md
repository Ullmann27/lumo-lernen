# Native PR166 — 17f5 Graphics originals

Current source `17f5b9d4a14c70050d4a125a8bd6bd8c68ee7845`, tree `b8ea9b1777e8d0b6302156330d4d1b298a316aea`, workflow run `43532048253`, attempt 1. All three jobs completed successfully.

The three original ZIPs were matched to GitHub sizes and SHA-256 digests. Every member was streamed through CRC/SHA validation. All 62 PNGs were fully decoded (36 current, 26 separately identified ada5 baseline); all 40 artifact logs and three complete original job logs were checked without suppressing actual errors. Project validation retains seven original warnings: six legacy manifest assets are absent and `build_web_bundle.sh` is not executable. These warnings are not reported as absent.

The current renderer feedback marker is PASS 75. Home capture reports 324 checks, its source regression 251; the separate cards header gate reports 295 checks. These are the actual recorded checks, not physical Android or FPS measurements.

Root directly viewed five new originals: landscape/portrait Home, Winter, Crystal and drift release. `root-review/` retains those observations and the Root-created Graphics receipt byte for byte. `final-byte-binding.json` independently binds all five images to their actual current ZIP entries. No findings were rewritten and this collector did not create the receipt. The prior receipt copy is explicitly historical selection context only.

## Files

- `proofs/`: exact final raw run/jobs API bytes and original artifact-object byte slices.
- `snapshots/`: original incremental API responses.
- `jobs/`: all three complete decoded original job logs.
- `originals/`: unchanged artifact logs and source/image stamps; no duplicate PNG payloads.
- `*-verified.json`: complete ZIP member and PNG indexes, source/baseline identities and actual gate markers.
- `parser-frozen/`: the exact recorder readers and their local dependencies.
- `recorder-inputs-ready.json`: actual frozen-reader input check, without invoking the recorder.
- `review-candidates/`: only the five selected current PNGs.
- `artifacts/*-original.zip`: symlinks to preserved original ZIPs under `/tmp/lumo-17f5b9d4-original-zips/`; not duplicated in the workspace.

Nextgen48, new Safe-Area raster/sidecar/report acceptance and actual Android tours are separate and are not granted by this Graphics checkpoint. No old ee97 result is transferred to this source.
