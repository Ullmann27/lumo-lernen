#!/usr/bin/env python3
"""Run exactly the two existing non-device CI discovery commands once."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/b3485b7bb989/lumo-host-studio-runtime-preparation-848')
OUT = Path(__file__).resolve().parent
PYTHON = '/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3'
GRADLE = Path('/workspace/scratch/e0abce7d2838/toolchain/gradle-9.1.0')
JSON_JAR = Path('/workspace/scratch/b3485b7bb989/cards-lifecycle-318-integration-evidence/dependencies/json-20240303.jar')
SOURCE_ROOTS = {'.github', 'scripts', 'tools', 'config', 'lib', 'test',
                'integration_test', 'android', 'assets'}
ROOT_FILES = {'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml', 'AGENTS.md'}
FOLD = {
    'tools/android_qa/fold_device_capture.py': '72ebc6fcb029b6bbae1a8d13162e61ccfb68f67d0216175268e1d5722dfbfd4c',
    'tools/android_qa/tests/test_fold_device_capture.py': '5218e628d752d44424eaee3e03308b343019bcfbe1895aa0114122e5306c8acd',
    'tools/android_qa/FOLD_DEVICE_CAPTURE.md': '5e834bd63bf86c048ca570f6d687642a7d6ab327803e5716241f4e21636826f6',
}


def utc():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def git(*args):
    return subprocess.run(['git', *args], cwd=ROOT, check=True,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout


def sources():
    names = set(git('ls-files', '--cached', '--others', '--exclude-standard', '-z').decode().split('\0'))
    result = {}
    for name in sorted(names):
        if not name or (name.split('/')[0] not in SOURCE_ROOTS and name not in ROOT_FILES):
            continue
        path = ROOT / name
        if path.is_file():
            result[name] = {'bytes': path.stat().st_size, 'sha256': digest(path)}
    return result


def changes(before, after):
    return [name for name in sorted(before.keys() | after.keys())
            if before.get(name) != after.get(name)]


def main():
    if (OUT / 'source-before.json').exists():
        raise SystemExit('This evidence directory already contains an attempt; refusing to repeat.')
    env = dict(os.environ)
    env.update(REQUIRE_ALL_TESTS='true', PYTHONDONTWRITEBYTECODE='1', PYTHONUNBUFFERED='1',
               LUMO_KOTLIN_LIB_DIR=str(GRADLE / 'lib'), LUMO_TEST_JSON_JAR=str(JSON_JAR),
               PATH=str(GRADLE / 'bin') + os.pathsep + env['PATH'])
    if env.get('LUMO_HEARTBEAT_SOURCE'):
        raise SystemExit('Unexpected Activity source override; refusing a different source.')
    assert digest(JSON_JAR) == '3cf6cd6892e32e2b4c1c39e0f52f5248a2f5b37646fdfbb79a66b46b618414ed'
    for name, expected in FOLD.items():
        assert digest(ROOT / name) == expected, name
    before = sources()
    save('source-before.json', before)
    started = utc()
    version_commands = [['java', '-version'], ['java', '--list-modules'],
                        ['node', '--version'], ['tesseract', '--list-langs']]
    versions = []
    for command in version_commands:
        p = subprocess.run(command, env=env, stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT, timeout=20)
        versions.append({'command': command, 'exit_code': p.returncode,
                         'output': p.stdout.decode(errors='replace')})
    metadata = {'schema': 1, 'started_at': started, 'cwd': str(ROOT),
                'python': {'executable': sys.executable, 'version': sys.version},
                'head_before': git('rev-parse', 'HEAD').decode().strip(),
                'tree_before': git('rev-parse', 'HEAD^{tree}').decode().strip(),
                'source_roots': sorted(SOURCE_ROOTS), 'root_files': sorted(ROOT_FILES),
                'source_scope': 'All present tracked and nonignored source/fixture files in named roots; documentation evidence outside these roots is excluded.',
                'source_count': len(before), 'fold_freeze': FOLD,
                'environment_overrides': {k: env[k] for k in ('REQUIRE_ALL_TESTS', 'PYTHONDONTWRITEBYTECODE', 'PYTHONUNBUFFERED', 'LUMO_KOTLIN_LIB_DIR', 'LUMO_TEST_JSON_JAR', 'PATH')},
                'json_jar_sha256': digest(JSON_JAR), 'dependency_versions': versions,
                'pillow_version': importlib.metadata.version('Pillow'),
                'local_environment_limits': ['Primary runtime Pillow is 13.0.0; the CI workflow pins 12.3.0.', 'Installed Tesseract lists eng and osd, but not the CI-installed deu language. No dependency installed or skip suppressed.'],
                'executed_scope': 'Only the two existing Python discovery suites; no Flutter, Godot or Android/emulator execution.'}
    save('run-metadata.json', metadata)
    (OUT / 'git-status-before.txt').write_bytes(git('status', '--porcelain=v1', '--untracked-files=all'))
    jobs = [('scripts-tests', [PYTHON, '-m', 'unittest', 'discover', '-s', 'scripts/tests', '-v']),
            ('android-qa-tests', [PYTHON, '-m', 'unittest', 'discover', '-s', 'tools/android_qa/tests', '-p', 'test_*.py', '-v'])]
    results = []
    for label, command in jobs:
        print(json.dumps({'phase': 'START', 'suite': label, 'at': utc(), 'command': command}), flush=True)
        begin, mono = utc(), time.monotonic()
        path = OUT / (label + '.log')
        with path.open('wb') as log:
            p = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
        text = path.read_text(errors='replace')
        after = sources()
        save('source-after-' + label + '.json', after)
        counts = re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s$', text, re.MULTILINE)
        skips = re.findall(r'^.*(?:\.\.\. skipped |^OK \(skipped=|^FAILED.*skipped=).*$' , text, re.MULTILINE)
        result = {'suite': label, 'command': command, 'started_at': begin, 'finished_at': utc(),
                  'seconds': round(time.monotonic() - mono, 3), 'exit_code': p.returncode,
                  'log': path.name, 'log_bytes': path.stat().st_size, 'log_sha256': digest(path),
                  'unittest_summaries': counts, 'skip_lines': skips,
                  'failure_headers': re.findall(r'^(?:FAIL|ERROR): .+$', text, re.MULTILINE),
                  'source_changes_since_before': changes(before, after),
                  'head_after': git('rev-parse', 'HEAD').decode().strip(),
                  'strict_local_gate_pass': p.returncode == 0 and not skips and not changes(before, after)}
        results.append(result)
        save(label + '-result.json', result)
        print(json.dumps({'phase': 'END', **result}, ensure_ascii=False), flush=True)
    final = sources()
    save('source-after.json', final)
    (OUT / 'git-status-after.txt').write_bytes(git('status', '--porcelain=v1', '--untracked-files=all'))
    save('result.json', {'schema': 1, 'started_at': started, 'finished_at': utc(),
                         'source_count': len(before), 'source_changes': changes(before, final),
                         'results': results, 'strict_local_gate_pass': all(x['strict_local_gate_pass'] for x in results),
                         'environment_limits': metadata['local_environment_limits'],
                         'not_claimed': ['CI execution', 'Android runtime acceptance', 'Flutter or native renderer results']})
    print('COMBINED_LOCAL_RUN_COMPLETE', flush=True)


if __name__ == '__main__':
    main()
