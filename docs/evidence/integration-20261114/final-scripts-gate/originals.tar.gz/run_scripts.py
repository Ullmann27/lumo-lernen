#!/usr/bin/env python3
"""Run the one authorized final scripts discovery without repeating Android QA."""
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time


OUT = Path(__file__).resolve().parent
PREVIOUS_RUNNER = OUT.parent / 'host-studio-combined-local-gates/run_combined.py'
SPEC = importlib.util.spec_from_file_location('previous_combined_gate', PREVIOUS_RUNNER)
BASE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)
BASE.OUT = OUT
ROOT = BASE.ROOT
RECEIPTS = ('config/kart-graphics-2019-visual-review.json',
            'config/nextgen-2019-visual-review.json')
EXPECTED_NATIVE = '17f5b9d4a14c70050d4a125a8bd6bd8c68ee7845'


def utc():
    return datetime.now(timezone.utc).isoformat()


def sources():
    result = BASE.sources()
    # Current receipt images are functional inputs outside the former source
    # roots. Include all of them without copying or re-encoding their bytes.
    for receipt in RECEIPTS:
        document = json.loads((ROOT / receipt).read_text())
        if document['native_revision'] != EXPECTED_NATIVE:
            raise RuntimeError('Unexpected current receipt source: ' + receipt)
        for image in document['images']:
            name = image['path']
            path = ROOT / name
            if not path.is_file():
                raise RuntimeError('Missing current original receipt image: ' + name)
            result[name] = {'bytes': path.stat().st_size, 'sha256': BASE.digest(path)}
    return dict(sorted(result.items()))


def main():
    if (OUT / 'source-before.json').exists():
        raise SystemExit('This evidence folder already contains an attempt; refusing a repeat.')
    env = dict(os.environ)
    env.update(REQUIRE_ALL_TESTS='true', PYTHONDONTWRITEBYTECODE='1', PYTHONUNBUFFERED='1',
               LUMO_KOTLIN_LIB_DIR=str(BASE.GRADLE / 'lib'),
               LUMO_TEST_JSON_JAR=str(BASE.JSON_JAR),
               PATH=str(BASE.GRADLE / 'bin') + os.pathsep + env['PATH'])
    if env.get('LUMO_HEARTBEAT_SOURCE'):
        raise SystemExit('Unexpected Activity source override; refusing different source.')
    if BASE.digest(BASE.JSON_JAR) != '3cf6cd6892e32e2b4c1c39e0f52f5248a2f5b37646fdfbb79a66b46b618414ed':
        raise SystemExit('Unexpected JSON JAR identity.')
    for name, expected in BASE.FOLD.items():
        if BASE.digest(ROOT / name) != expected:
            raise SystemExit('Changed frozen Fold input: ' + name)
    if json.loads((ROOT / 'config/godot-source.json').read_text())['revision'] != EXPECTED_NATIVE:
        raise SystemExit('Unexpected current Native pin.')
    if BASE.digest(ROOT / 'config/nextgen-2019-visual-review.json') != 'b41471c3cb90df69b99228f6da7057851af224528004872215f36332efb1804d':
        raise SystemExit('Unexpected final Nextgen receipt.')
    before = sources()
    BASE.save('source-before.json', before)
    head = BASE.git('rev-parse', 'HEAD').decode().strip()
    tree = BASE.git('rev-parse', 'HEAD^{tree}').decode().strip()
    versions = []
    for command in (['java', '-version'], ['java', '--list-modules'],
                    ['node', '--version'], ['tesseract', '--list-langs']):
        check = subprocess.run(command, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, timeout=20)
        versions.append({'command': command, 'exit_code': check.returncode,
                         'output': check.stdout.decode(errors='replace')})
    metadata = {'schema': 1, 'started_at': utc(), 'cwd': str(ROOT),
                'previous_runner': str(PREVIOUS_RUNNER),
                'previous_runner_sha256': BASE.digest(PREVIOUS_RUNNER),
                'python': {'executable': sys.executable, 'version': sys.version},
                'head_before': head, 'tree_before': tree,
                'native_pin': EXPECTED_NATIVE, 'source_count': len(before),
                'source_roots': sorted(BASE.SOURCE_ROOTS), 'root_files': sorted(BASE.ROOT_FILES),
                'additional_source_inputs': 'All 34 images referenced by the two current 2019 receipts.',
                'source_scope': 'All present tracked/nonignored source and fixture files in the original roots, plus the complete current receipt image references. Historical documentation evidence is not included.',
                'environment_overrides': {key: env[key] for key in
                    ('REQUIRE_ALL_TESTS', 'PYTHONDONTWRITEBYTECODE', 'PYTHONUNBUFFERED',
                     'LUMO_KOTLIN_LIB_DIR', 'LUMO_TEST_JSON_JAR', 'PATH')},
                'json_jar_sha256': BASE.digest(BASE.JSON_JAR),
                'dependency_versions': versions,
                'pillow_version': importlib.metadata.version('Pillow'),
                'local_environment_limits': [
                    'Primary runtime Pillow differs from the CI-pinned version12.3.0; actual installed version is recorded above.',
                    'The actual installed Tesseract language list is recorded; no new dependency installation or skip suppression.'],
                'executed_scope': 'Exactly one scripts/tests unittest discovery. The already passed870 Android-QA tests are not rerun. No Flutter/Godot/Android/emulator execution or actionlint repeat.'}
    BASE.save('run-metadata.json', metadata)
    (OUT / 'git-status-before.txt').write_bytes(BASE.git('status', '--porcelain=v1', '--untracked-files=all'))
    command = [BASE.PYTHON, '-m', 'unittest', 'discover', '-s', 'scripts/tests', '-v']
    print(json.dumps({'phase': 'START', 'at': utc(), 'command': command,
                      'head': head, 'source_count': len(before)}), flush=True)
    start, clock = utc(), time.monotonic()
    log = OUT / 'scripts-tests.log'
    with log.open('wb') as output:
        completed = subprocess.run(command, cwd=ROOT, env=env,
                                   stdout=output, stderr=subprocess.STDOUT)
    duration = time.monotonic() - clock
    text = log.read_text(errors='replace')
    after = sources()
    BASE.save('source-after.json', after)
    head_after = BASE.git('rev-parse', 'HEAD').decode().strip()
    tree_after = BASE.git('rev-parse', 'HEAD^{tree}').decode().strip()
    (OUT / 'git-status-after.txt').write_bytes(BASE.git('status', '--porcelain=v1', '--untracked-files=all'))
    counts = re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s$', text, re.MULTILINE)
    skip_lines = re.findall(r'^.*(?:\.\.\. skipped |^OK \(skipped=|^FAILED.*skipped=).*$', text, re.MULTILINE)
    failures = re.findall(r'^FAIL: .+$', text, re.MULTILINE)
    errors = re.findall(r'^ERROR: .+$', text, re.MULTILINE)
    changes = BASE.changes(before, after)
    result = {'schema': 1, 'started_at': start, 'finished_at': utc(),
              'command': command, 'seconds': duration, 'exit_code': completed.returncode,
              'log': log.name, 'log_bytes': log.stat().st_size, 'log_sha256': BASE.digest(log),
              'unittest_summaries': counts, 'test_count': int(counts[-1][0]) if counts else None,
              'failure_count': len(failures), 'error_count': len(errors),
              'skip_lines': skip_lines, 'skip_count': len(skip_lines),
              'failure_headers': failures, 'error_headers': errors,
              'source_count_before': len(before), 'source_count_after': len(after),
              'source_changes': changes, 'head_before': head, 'head_after': head_after,
              'tree_before': tree, 'tree_after': tree_after,
              'head_and_tree_unchanged': head == head_after and tree == tree_after,
              'strict_local_gate_pass': completed.returncode == 0 and bool(counts) and
                  not skip_lines and not failures and not errors and not changes and
                  head == head_after and tree == tree_after,
              'not_claimed': ['Android runtime acceptance', 'CI execution',
                              'Repeated870 Android-QA suite', 'Native renderer acceptance']}
    BASE.save('result.json', result)
    print(json.dumps({'phase': 'END', **result}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
