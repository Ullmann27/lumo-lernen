# Bounded Host producer recheck — 2026-11-14 00:19 UTC

Exactly the same 20 PRs and two named Graphics/Village refs from the 23:55 snapshot were read once. PR465/474 are our own unchanged integration/QA branches. Nineteen PR heads and both refs are unchanged. PR475/476 are now merged/closed without a head change; their actual base branches and merge timestamps are retained in comparison.json.

Only PR466 advanced: 31883868 → 4ab96666f954baf258422d6ed277fc297b7ddeef (tree f3ffc295cec299bdc6126fcddffbc130c6629e54). Its immediate parent is the already-known PR476 head39ddc673, so six of the seven commits in that branch delta are previous aggregation. The new immediate-parent diff has107 paths:103 documentation/evidence paths and exactly four source/config/test paths.

The new production-related change is the producer-specific native pin796b→803e, with matching pin policy,32-image producer receipt and two expanded pin-regression cases. No application, native runtime, Android probe or workflow implementation changed in this new commit. The regression additions are not yet in our prep; the existing exact-pin predicate already rejects other revisions. Root can carry these narrow cases with its own eventual reviewed pin. The independent803e receipt is not evidence for our pending17f5 source and was not adopted or independently re-reviewed here.

## Preserved bytes and limits

originals/*.json.gz contains the24 exact unnormalized UTF-8 response bodies (20 PRs,2 refs,head commit and compare). requests.json records URL, retrieval interval, original/stored sizes and SHA256 plus a successful lossless gzip roundtrip. The two original transport containers remain unchanged as well. new-commit.json contains all107 immediate-parent file/blob identities. The seven-commit comparison reaches GitHub's300-file response cap; its file list is explicitly not treated as complete and is used only for ancestry. source-delta.patch is derived from the original commit patch fields and is not represented as a separately fetched Git patch.

Only this new evidence directory was written. No tests, installs, source changes, ref changes, CI retries, artifact downloads or PNG reviews were performed. Local-source-binding.json fingerprints the four corresponding prep paths at review time; it does not assert that the prep is otherwise clean. Producer status/review claims remain attributed to its source documents, not converted into integration acceptance.
