# PR466 pin regression cases — isolated adoption

Only the two authorized test hunks from published Host commit4ab96666f954baf258422d6ed277fc297b7ddeef (parent39ddc673577e31e76fb992a1b49ef67d1deee908) were copied into scripts/tests/test_candidate_2011_pin.py in the existing Host preparation worktree. The producer hunk that changes the native constant was excluded.

The new method rejects superseded796b explicitly. The existing unreserved/private-build method now checks each of its seven original build numbers with both the historical candidate revision and STUDIO_2019_REVISION. Every byte outside these two hunks remains unchanged, and all added code lines match the published hunks. The current constant remains993c145304c3e5f8aa947e1c7a949a8ef8685415. All seven protected config/policy/pubspec files are unchanged before/after.

Exactly those two unittest methods ran once using the primary Python runtime:2 PASS,0 FAIL,0 ERROR,0 SKIP,exit0. This is a regression-coverage addition against an already rejecting policy; no failing-before claim is invented. No full suite, device, engine, build, remote action, staging, commit or ref action occurred.

The complete original test file before and after, precise selected published hunks, actual local diff, source provenance, protected hashes, exact command/exit/times and unmodified combined stdout/stderr are included. External source-proof paths and hashes point to the already frozen20-PR incremental-check pack. Pins and receipts remain for Root's later exact-source review.
