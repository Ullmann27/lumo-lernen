# Verlustfreier Evidenztransport

Der ursprüngliche einzelne Base64-Blob wurde vom Connector mit HTTP 400 abgewiesen. Das unveränderte Archiv ist nun im freigegebenen Docs-Ordner in genau zwei Stücke von 8.467.800 und 8.467.799 Bytes geteilt. Alle 13 Publikationsdateien einschließlich SHA256 und Git-Blob stehen in publication-files.json.

Der tatsächliche Roundtrip, die komplette Archivprüfung, die unveränderte vorhandene Zieldatei und drei Fehlergrenzen (abweichendes Ziel, beschädigtes Teil, fehlendes Teil) sind in roundtrip-result.json samt ungekürzten stdout/stderr dokumentiert. Atomare Veröffentlichung erfolgt mit einem nicht überschreibenden Hardlink aus einer vollständig geprüften temporären Datei.

Alle 317 Dateien der eingefrorenen Assemblierung wurden vor/nachher bytegleich geprüft. Die ursprüngliche Beschreibung bleibt als ASSEMBLY_README.md erhalten. Nur die neu angelegte redundante vollständige Archivkopie im Docs-Ziel wurde nach erfolgreicher Prüfung entfernt. Kein GitHub-, Git-Index-, Commit-, Ref-, Source-, Pin-, Receipt- oder CI-Eingriff.
