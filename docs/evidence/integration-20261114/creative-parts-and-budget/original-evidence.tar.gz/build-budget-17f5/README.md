# Host build budget: completed Native 17f5 timing follow-up

The existing Host build limit remains 90 minutes. No source or deadline was changed and no extra CI/test/API operation was performed.

The historical Host 848/Native 993c build ran 69:06, including 42:23 for its sequential native gates; other phases used 26:43. It left 20:54 before 90 minutes. Native 17f5's new-worlds job now completed in 37:38 and its actual 48-mode core step in 31:56. The full parallel Native workflow duration is not substituted for Host-native time.

The old Host log contains exactly 43 sequential engine/probe modes. Those same probe/mode names occur in the same order in the new 48-mode source, with five additional Safe-Area modes. Comparing the first engine banner through final LumoNextgen PASS gives 1475.684s for the old Host sequence and 1915.593s for the new Native sequence: an observed difference of 439.908s, approximately 7:20. Original source hashes, exact log lines and their numbering are retained.

If—and only if—every other old Host phase takes the same time and that new standalone duration transfers to the Host runner, replacing just this sequence gives 4585.908s (76:25.9), leaving 814.092s (13:34.1). This is a stated-assumption scenario, not a measured new Host result or completion guarantee. The five new engine-banner→PASS spans are separately listed; they are not precise subprocess timers or Android performance measurements.

There is no observed timeout or demonstrated budget shortage supporting an increase. Keep 90 minutes and use the next actual Host run for the remaining uncertainty. Parallel graphics/preview/touch jobs and separate Android/Creative jobs must not be added as if they were serial operations in verify-and-build.

The earlier baseline-848.json and all original collectors remain unchanged. This folder is separate from the frozen late-followup and Creative multipart archives. Small raw API/timing JSONs are preserved losslessly; full logs remain at their already frozen original paths, identified by SHA256, with verbatim comparison boundaries copied here.
