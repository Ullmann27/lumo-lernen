# Native785: targeted contract validation

The exact published Native source `0e26153f0e58cc05739e72923b4c563a4cf380b8`, tree `5b5992487e60ae805d708965f1500954c6b0556d`, passed the42 explicitly authorized tests in one run:23 runner tests and19 Studio2020 raster tests, with zero errors, failures or skips. The original log reports106.146 seconds.

The authentic local commit object was hashed back to its exact commit ID. All1,435 materialized tracked files matched their Git blobs before and after the run, and the complete source manifests are byte-identical. Both original Git status outputs are empty. The seven previously frozen integration sources also match source-freeze `b816b4cc…`.

## Command and scope

The exact interpreter, command, environment and input files are in `invocation.json`. The test module search path explicitly includes `tools/tests` and `tools`; bytecode writing is disabled. The existing tests generate synthetic process, PNG and movie fixtures in temporary directories and exercise the actual runner and verifier. They include missing/wrong/ambiguous inputs, spatial HUD and avatar overlap, wrong capture state, readonly preservation and movie identity/dimension failures.

This result is not an engine execution of the52 native modes, a renderer capture, an Android tour, actual movie playback or measured device performance. Those separate gates remain required. No source, Git index, commit, branch, pin or CI state was changed. No additional tests were added or repeated.

## Original evidence

`logs/contracts-42.log` preserves the full combined unittest output. `original-commit.txt` contains the exact Git commit object. The before/after directories preserve original Git tree/status/identity outputs and source inventories. No generated test raster or synthetic movie is represented as product evidence.
