from pathlib import Path
import datetime,hashlib,json,os,platform,re,stat,subprocess,sys,time
import PIL
ROOT=Path("/workspace/scratch/b3485b7bb989/host-36274db-c4-preferences-validation-20261114")
CHECKOUT=Path("/workspace/scratch/b3485b7bb989/host-36274db-c4-preferences-checkout-20261114")
HEAD="36274db2941963c59b1f819ad7bc2358470d3a76"
TREE="39ee9cdf1567271599922d6b991399927affccae"
SOURCE_PACK=Path("/workspace/scratch/b3485b7bb989/host-pr493-preferences-read-repair-3fac-20261114")
ENV=dict(os.environ,PYTHONDONTWRITEBYTECODE="1",GIT_OPTIONAL_LOCKS="0")
def ident(b):return {"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()}
def put(name,b):
 p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open("xb") as f:f.write(b)
 return ident(b)
def dump(name,j):return put(name,(json.dumps(j,indent=2)+"\n").encode())
def git(*args):
 p=subprocess.run(["git",*args],cwd=CHECKOUT,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
 if p.returncode:raise RuntimeError("Read-only Git query failed: "+str(args)+" "+p.stderr.decode())
 return p.stdout
def snapshot(label):
 head=git("rev-parse","HEAD").decode().strip();tree=git("rev-parse","HEAD^{tree}").decode().strip()
 assert head==HEAD and tree==TREE
 stage=git("ls-files","--stage","-z");flags=git("ls-files","-t","-z");status=git("status","--porcelain=v1","--untracked-files=all")
 assert status==b"",status
 put(label+"/index-stage.raw",stage);put(label+"/index-flags.raw",flags);put(label+"/status.raw",status)
 index_path=Path(git("rev-parse","--git-path","index").decode().strip())
 if not index_path.is_absolute():index_path=CHECKOUT/index_path
 index=index_path.read_bytes();put(label+"/index.raw",index)
 skip={s[2:].decode() for s in flags.split(b"\0") if s.startswith(b"S ")}
 entries=[];materialized=[]
 for raw in stage.split(b"\0"):
  if not raw:continue
  meta,name=raw.split(b"\t",1);mode,blob,st=meta.decode().split();name=name.decode()
  assert st=="0";p=CHECKOUT/name;present=p.exists() or p.is_symlink()
  row={"path":name,"mode":mode,"blob":blob,"skip_worktree":name in skip,"materialized":present}
  if present:
   assert p.is_file() and not p.is_symlink(),name
   b=p.read_bytes();d=ident(b);assert d["git_blob"]==blob,name
   assert bool(p.stat().st_mode&0o111)==(mode=="100755"),name
   row.update(d);materialized.append(row)
  else:assert name in skip,name
  entries.append(row)
 assert len(entries)==4642,len(entries)
 freeze=json.loads((SOURCE_PACK/"source-freeze.json").read_text())
 for row in freeze["files"]:
  b=(CHECKOUT/row["path"]).read_bytes();assert ident(b)["git_blob"]==row["git_blob"]
 for rel in ["tools/android_qa/connect_four_android_evidence.py","tools/android_qa/tests/test_connect_four_android_evidence.py"]:
  assert (CHECKOUT/rel).read_bytes()==(SOURCE_PACK/"reference-source"/rel).read_bytes()
 data={"head":head,"tree":tree,"index_sha256":ident(index)["sha256"],"index_stage_sha256":ident(stage)["sha256"],
       "index_flags_sha256":ident(flags)["sha256"],"status":status.decode(),"tracked_count":len(entries),"materialized_count":len(materialized),
       "skip_worktree_count":len(skip),"tracked":entries}
 dump(label+"/sources.json",data)
 return data
dump("setup-interpretation.json",{"schema":1,"source_parent_checkout":"Read-only clone source and remote-URL lookup only; no write command addressed the parent checkout.",
 "parent_setup_flag_scope":"setup-result.json source_parent_checkout_unchanged records absence of parent-write operations; it is not a full independent before/after hash audit of a concurrently owned parent checkout.",
 "actual_integrity_gate":"The private exact-commit validation checkout receives the complete index and all-materialized-byte comparison before and after."})
assert PIL.__version__=="12.3.0",PIL.__version__
dump("environment.json",{"python":sys.version,"python_executable":sys.executable,"pillow":PIL.__version__,"platform":platform.platform(),
 "git":git("--version").decode().strip(),"environment":{"PYTHONDONTWRITEBYTECODE":"1","GIT_OPTIONAL_LOCKS":"0"},"no_installation_performed":True})
before=snapshot("before")
modules=["tools.android_qa.tests.test_connect_four_preferences_observation",
 "tools.android_qa.tests.test_connect_four_android_evidence",
 "tools.android_qa.tests.test_connect_four_probe_deadlines",
 "tools.android_qa.tests.test_connect_four_flutter_navigation"]
command=[sys.executable,"-m","unittest",*modules,"-v"]
runroot=ROOT/"run-45";runroot.mkdir(exist_ok=False)
started=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic()
dump("invocation.json",{"argv":command,"cwd":str(CHECKOUT),"started_at":started,"expected_methods":45,"whole_process_timeout_seconds":600,"source_head":HEAD,"source_tree":TREE,"one_execution_only":True})
timed_out=False
with (runroot/"stdout.original.log").open("xb") as stdout,(runroot/"stderr.original.log").open("xb") as stderr:
 try:
  p=subprocess.run(command,cwd=CHECKOUT,env=ENV,stdout=stdout,stderr=stderr,timeout=600)
  exit_code=p.returncode
 except subprocess.TimeoutExpired:
  timed_out=True;exit_code=None
elapsed=time.monotonic()-clock;finished=datetime.datetime.now(datetime.timezone.utc).isoformat()
stderr=(runroot/"stderr.original.log").read_bytes()
stdout=(runroot/"stdout.original.log").read_bytes()
after=snapshot("after")
same=before==after
counts=re.findall(rb"(?m)^Ran (\d+) tests? in ([0-9.]+)s$",stderr)
names=re.findall(rb"(?m)^(test_[^\n]+) \.\.\. ok$",stderr)
ok=bool(re.search(rb"(?m)^OK$",stderr))
fail_headers=[x.decode() for x in re.findall(rb"(?m)^(?:FAIL|ERROR): [^\n]+",stderr)]
skips=re.findall(rb"(?m)^test_[^\n]+ \.\.\. skipped[^\n]*$",stderr)
success=exit_code==0 and not timed_out and same and len(counts)==1 and int(counts[0][0])==45 and len(names)==45 and ok and not fail_headers and not skips
result={"schema":1,"status":"PASS" if success else "FAIL","head":HEAD,"tree":TREE,"started_at":started,"finished_at":finished,"wall_seconds":elapsed,
 "exit_code":exit_code,"timed_out":timed_out,"reported_counts":[{"tests":int(n),"seconds":float(t)} for n,t in counts],
 "successful_method_lines":len(names),"failures_or_errors":fail_headers,"skipped_method_lines":len(skips),"sources_and_index_identical":same,
 "tracked_index_paths":before["tracked_count"],"materialized_source_files":before["materialized_count"],"skip_worktree_paths":before["skip_worktree_count"],
 "stdout":ident(stdout),"stderr":ident(stderr),"modules":modules,
 "scope":"45 local C4 observer contracts on the published exact checkpoint; fake device/clock/screenshot boundaries. No Android, app recovery, engine, APK, CI or release acceptance."}
dump("result.json",result)
print(json.dumps(result,indent=2),flush=True)
raise SystemExit(0 if success else 1)
