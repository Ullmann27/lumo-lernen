from pathlib import Path
import ast,hashlib,json,re,datetime
r=Path("/workspace/scratch/b3485b7bb989/host-36274db-c4-preferences-validation-20261114")
checkout=Path("/workspace/scratch/b3485b7bb989/host-36274db-c4-preferences-checkout-20261114")
def ident(b):return {"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
def put(name,j):
 p=r/name
 with p.open("x") as out:out.write(json.dumps(j,indent=2)+"\n")
old_bytes=(r/"result.json").read_bytes();old=json.loads(old_bytes)
raw=(r/"run-45/stderr.original.log").read_bytes();text=raw.decode();lines=text.splitlines()
assert old["exit_code"]==0 and old["status"]=="FAIL" and old["successful_method_lines"]==44 and old["reported_counts"]==[{"tests":45,"seconds":46.699}]
expected=[]
for module in old["modules"]:
 source=checkout/Path(*module.split(".")).with_suffix(".py")
 tree=ast.parse(source.read_bytes())
 for cls in tree.body:
  if isinstance(cls,ast.ClassDef):
   for method in cls.body:
    if isinstance(method,ast.FunctionDef) and method.name.startswith("test_"):
     expected.append(module+"."+cls.name+"."+method.name)
starts=[]
pattern=re.compile(r"^(test_\w+) \(([^)]+)\) \.\.\. (.*)$")
for number,line in enumerate(lines):
 m=pattern.fullmatch(line)
 if m:starts.append((number,m.group(1),m.group(2),m.group(3)))
assert len(starts)==45 and len({row[2] for row in starts})==45
assert {row[2] for row in starts}==set(expected)
results=[]
for index,(line,name,identity,tail) in enumerate(starts):
 assert identity.endswith("."+name)
 end=starts[index+1][0] if index+1<len(starts) else len(lines)
 block=lines[line:end]
 if tail=="ok":
  results.append({"test":identity,"status":"ok","line":line+1,"warning_lines":[]})
 else:
  assert index==0
  expected_warning=str(checkout)+"/tools/android_qa/connect_four_android_evidence.py:339: DeprecationWarning: Image.Image.getdata is deprecated and will be removed in Pillow 14 (2027-10-15). Use get_flattened_data instead."
  assert tail==expected_warning
  assert block[1:]==["  sampled = list(image.crop(box).getdata())","ok"]
  results.append({"test":identity,"status":"ok","line":line+1,"completion_line":line+3,"warning_lines":[line+1,line+2],"exact_warning":tail,"warning_not_test_failure":True})
assert not re.search(r"(?m)^(?:FAIL|ERROR): ",text)
assert not re.search(r"\.\.\. skipped",text)
assert len(re.findall(r"(?m)^Ran 45 tests in 46\.699s$",text))==1
assert len(re.findall(r"(?m)^OK$",text))==1
assert (r/"run-45/stdout.original.log").read_bytes()==b""
before=(r/"before/sources.json").read_bytes();after=(r/"after/sources.json").read_bytes()
assert before==after and old["sources_and_index_identical"] is True
for name in ["index-stage.raw","index-flags.raw","status.raw","index.raw"]:
 assert (r/"before"/name).read_bytes()==(r/"after"/name).read_bytes()
for row in json.loads(before)["tracked"]:
 if row["materialized"]:
  p=checkout/row["path"];b=p.read_bytes();assert ident(b)["sha256"]==row["sha256"]
  target=r/"verified-source"/row["path"];target.parent.mkdir(parents=True,exist_ok=True)
  with target.open("xb") as out:out.write(b)
analysis={"schema":1,"kind":"Read-only corrected interpretation of the already completed original unittest stream",
 "status":"PASS","head":old["head"],"tree":old["tree"],"actual_test_process_exit":0,"original_harness_exit":1,
 "actual_method_count":45,"passed":45,"failures":0,"errors":0,"skips":0,
 "single_run_started_at":old["started_at"],"single_run_finished_at":old["finished_at"],"test_seconds":46.699,"wall_seconds":old["wall_seconds"],
 "original_stderr":ident(raw),"original_harness_result":ident(old_bytes),"original_harness_result_preserved":True,
 "parser_defect":"The first successful test prints a real Pillow DeprecationWarning between the method prefix and its standalone ok line. The original regex accepted only single-line completions and counted 44.",
 "correction":"Read each actual method block; verify the one exact warning block and its actual ok. Match all 45 fully qualified names against the unchanged source AST; require the one Ran45/OK summary and real child exit0.",
 "methods":results,"tracked_index_paths":old["tracked_index_paths"],"materialized_source_files":old["materialized_source_files"],"skip_worktree_paths":old["skip_worktree_paths"],
 "complete_before_after_source_and_index_bytes_identical":True,"new_test_processes_started_for_this_analysis":0,
 "scope":old["scope"]}
put("corrected-log-analysis.json",analysis)
put("handoff.json",{"schema":1,"status":"45_ACTUAL_CONTRACTS_PASS_ORIGINAL_HARNESS_PARSE_FAILURE_PRESERVED",
 "head":old["head"],"tree":old["tree"],"actual_test_count":45,"exit_code":0,"failures":0,"errors":0,"skips":0,"unittest_seconds":46.699,
 "wall_seconds":old["wall_seconds"],"original_harness_exit_code":1,"original_harness_report":"result.json","accepted_analysis":"corrected-log-analysis.json",
 "cause_of_harness_mismatch":"Exact observed Pillow warning interrupts first successful method's output line.",
 "sources_and_index_unchanged":True,"actual_test_invocations":1,"additional_tests_or_replay":0,
 "source_checkpoint":"36274db2941963c59b1f819ad7bc2358470d3a76","source_freeze":"ba77676bce3f2fecd97aa62e6c8514462635dc0255843b544b98ac23e47e45f1",
 "scope":"Local synthetic-boundary observer contracts only; old 51ec actual Android FAIL retained and active 5ad candidate unchanged."})
print(json.dumps({"head":old["head"],"actual_methods":45,"successful_actual_names":len(results),"errors":0,"skips":0,"child_exit":0,"outer_harness_exit":1,"source_identical":True,"analysis":ident((r/"corrected-log-analysis.json").read_bytes()),"handoff":ident((r/"handoff.json").read_bytes())},indent=2))
