# Enger Feature-Workflow für Host502 V2

Ein neuer Push-Workflow für `integration/lumo-feature-connections-20261114` in `Ullmann27/lumo-lernen`. Der von Root veröffentlichte Produktcheckpoint ist `a118409930ecdf605743382051e88f7e0898b8e9` (Tree `68573f0c40ce641a6443a5648fd664bc44ca6c95`). Die Workflowdatei wird erst als nächster eigener Quellencheckpoint angeschlossen; dieses Paket startet keinen Lauf.

## Konkreter Ausführungsumfang

Nur `wort_diktat_gesture_regression_test.dart`, `feature_permission_regression_test.dart` und `profile_screen_test.dart`. Nach der V2-Reparatur werden exakt **22** erfolgreiche, nicht versteckte Fälle verlangt, kein Skip, kein Fehler, ein erfolgreich beendeter Flutter-Runner und Exit0. Der unveränderte vorhandene `summarize()`-Parser aus `scripts/run_full_flutter_acceptance.py` wird nur importiert; dessen vollständige Suite wird nicht gestartet. Nicht-JSON-Zeilen werden im vollständigen Originalstdout erhalten und ihre Zeilennummern im Bericht ausgewiesen.

Checkout ist exakt `github.sha`, credentials bleiben ungespeichert, Berechtigung nur `contents: read`. Es gibt ausschließlich den exakten Push-Trigger, keinen PR-/Dispatch-/APK-/Releasepfad. Die drei gelesenen bisherigen breiten Workflow-Pushlisten enthalten diesen neuen Zweig nicht; ihre Dateien werden nicht geändert. Eine später anders veranlasste PR-Aktion ist nicht Teil dieses neuen Workflows oder dieser Aussage.

Flutter3.44.9, Pillow12.3.0, `flutter pub get --enforce-lockfile`, 60s je Test und zwei Flutter-Worker übernehmen die vorhandenen Repositorykonventionen. Fonts/Pillow/Packages werden nur in der späteren CI eingerichtet, hier nicht heruntergeladen. Der Job hat 20Minuten; eine Zeitüberschreitung ersetzt keinen fehlenden Erfolg.

## Originalbindung

Vor Setup und nach dem Versuch werden alle getrackten Pfade mit tatsächlichen Bytes, Dateityp/Modus, Git-Blob und SHA256 sowie Index, HEAD und Tree gebunden. Auch beide Pubspec-Dateien sind darin enthalten. Neue ungetrackte Laufzeitdateien gelten nicht als Quelle. Nachprüfung und Artefaktupload laufen auch nach Fehlern. Evidence und Venv liegen in RUNNER_TEMP außerhalb des Checkouts.

Setup, Assetprüfung und Widgetlauf behalten stdout/stderr getrennt. Das tatsächliche Flutter-Exitresultat wird separat erhalten. Die sechs vorhandenen Testassets werden zusätzlich gegen ihre zuvor gebundenen Originalblobs geprüft; PNG wird tatsächlich mit Pillow gelesen.

## Tatsächlicher lokaler Stand

Ein Actionlint-Lauf auf genau diesen Workflowbytes: Exit0, unveränderte Quelle, leere originale stdout/stderr. Kein Flutter-/Dart-/Pub-/Engine-/Widgetlauf und keine CI-Aktivierung. Der externe Quellenfreeze wurde vor Actionlint erstellt; sein damaliger PENDING-Lint-Status wird nicht umgeschrieben, der konkrete spätere Lintbeleg liegt daneben.

Das beiliegende read-only Preflight fand das vorhandene Flutter3.44.9-/Dart3.12.2-SDK, aber **99 von104 Paketverzeichnissen** und **alle sechs Originalassets** fehlen in der überlebenden Arbeitskopie. Die alten /tmp-Checkouts sind gelöscht. Diese Arbeitskopie ist ausdrücklich nicht als neuer a118-Testcheckout ausgegeben. Deshalb bleiben lokale Produktprüfungen NOT_RUN.

Der V2-Produktpack und der V1-Originalpack bleiben separat und unverändert. Der unabhängige Workflowreview wird von Pipeline außerhalb dieses Pakets erstellt; aus Actionlint folgt kein Widget-, UI-, Sensor- oder Android-PASS.
