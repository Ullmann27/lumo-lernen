# Creative QA repair — frozen source and bounded original replays

The two Creative probes are repaired and frozen before Root's separate same-APK diagnostic entry adapter. The source remains based on the actual **Host7b16 / Native17f5** observations. No app or native runtime change, new Android success, touch/persistence acceptance, video/FPS result or visual approval is inferred from these local tests.

## Exact delivery

`source-freeze.json` binds **63 owned files / 6,014,977 bytes**. `owned-source-paths.txt` is the exact integration list: the two probes, one focused test file, and selected byte-identical original PNG/JSON plus separately labelled local OCR TSV fixtures. `final-source/` preserves the three text sources before Root adapts the distinct QA/source checkouts. `creative-sources.patch` covers only the two existing probes. The other team's Cards/source changes were not touched.

The final helper SHA256 is `9a769e99d8671260f45dd86684f8d5fa3cadc20f11e2dc888ce0f63493133f0f`; the Studio probe is `05678c1812305acaf1ed53c791e05a5c1c175830e5029053bf4ab2febfb79f4b`. `unchanged-guards.json` proves the original candidate/source entry and real piece/rotation/resume guards were unchanged. Root owns the following separate entry-adapter delta.

## Changes and original causes

- **Jump:** the original whole-frame reader stopped on the instruction word “springen”. Explicit complete-region sampling now keeps the lower-right action and every spatially distinct equal caption for the existing ambiguity check. The published Gold-component reader is integrated without its first-match break; its former truncation of the candidate list is replaced by bounded complete processing. Ordinary successful caption reads still finish on their first successful variant.
- **Build:** the actual reentry shot was blank, yet the original probe sent Back after one title observation. The exact Android callback consumption is not logged and remains unproven. Before one Back, the new boundary requires two fresh complete editor observations. An existing pause requires the paired central “Deine Welt wartet auf dich” heading and “Weiterbauen” action; title alone and the identically named walk-mode switch do not suffice. Already paused sends no Back; a failed post-Back observation never retries input. Original save, placement, reward and replay assertions remain.
- **Puzzle:** the visible tone-mapped felt exceeded the former red-channel ceiling. Colour now only proposes candidates. A continuous filled trapezoid, straight perspective edges, both observed gold rims and an actually empty six-piece saved state must all agree. The actual homography, textured tray check and subsequent real saved-quarter-turn requirement are preserved.
- **Learning:** the same published Gold fallback recognizes the full visible caption missed by sparse OCR in the four earlier published originals and two newly captured QA61c originals. The 60s reader requests and actual live120s readiness contract were not enlarged. The live failed result stays failed.

## Verification and evidence limits

`final-tests.log`: **51 PASS /0 errors /0 skips** (13 new,38 existing). `final-before-manifest.json` and `final-after-manifest.json` are equal.

`final-original-replay/replay.json`: real deu+eng Tesseract on the current Jump original, actual Puzzle geometry, current blank Build frame and exact same-frame active Build PNG/OCR pair. All four pass their bounded local checks. Blank Build remains “no state”; it is never promoted to a ready scene. Synthetic pause transitions and negative contours/duplicate controls are unit boundary checks, not captured gameplay.

`published-learning-replay/report.json`: four exact published PR466-86445 PNGs, independently matched to their Git blobs, all recognized within60s. `current-learning-61c-replay/report.json`: first/last actual API35 originals from Run43551424080, Job132314688451, artifact14097450952, both recognized within60s (local7.51s/7.26s). These timings are local reader observations, not emulator performance or future-device guarantees.

The behavioral Reds are preserved in `original-red.log`, `build-original-red.log` and `producer-first-match-red.log`. The separate first attempt in `replay-prerequisite-failure.log` lacked the installed TSV output config; it is explicitly infrastructure setup, not a behavioral Red. Both required language models and the actual installed TSV config are hash-bound in `ocr-runtime/`; no English-only fallback was used.

`independent-review.json` is the peer's unchanged read-only review. It found no concrete blocker and did not run additional tests. No source change followed the final gate.

The full original Creative failure pack remains frozen at `../host-pr465-7b16f2f5-creative-evidence/`. The original Creative run remains FAIL and contains no Jump video because it stopped before recording. The new QA61c Learning run also remains FAIL. The next evidence must come from Root's isolated real run on the unchanged original APK with the separately bound repaired probe source.

## Compact transport

The compact archive preserves selected source, original and derived JSON/TSV/log bytes unchanged. Model payloads and generated OCR PNGs are excluded with a complete hash inventory; the selected original PNG fixtures are already in the explicit63-file source list. No signed transport URL or credentials are needed. The archive roundtrip checks every included byte and does not alter any existing original pack.
