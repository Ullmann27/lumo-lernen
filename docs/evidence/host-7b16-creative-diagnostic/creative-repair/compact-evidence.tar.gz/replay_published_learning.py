#!/usr/bin/env python3
"""Actual local OCR of exact published learning originals; no device result."""
import hashlib,json,sys,time,traceback
from pathlib import Path
from replay_current_originals import helper
root=Path('/workspace/scratch/b3485b7bb989')
repo=root/'lumo-host-creative-followup-7b16'
source=Path('/workspace/scratch/5987865ae883/qa/android-ocr-cards-recheck-4ab')
compare=json.loads((root/'host-producer-incremental-20261114-0320/originals/pr466-new-delta.json').read_text())
out=root/'host-7b16-creative-followup-repair/published-learning-replay';out.mkdir(exist_ok=True)
reader=helper(repo);results=[]
for row in compare['files']:
    if 'fixtures/native_caption_ocr/' not in row['filename']: continue
    path=source/row['filename'];raw=path.read_bytes();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    assert blob==row['sha']
    item={'source':str(path),'published_blob':blob,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'shared_deadline_seconds':60}
    started=time.monotonic()
    try:
        lines=reader.image_lines(out,path.stem,'einobjektzeigen',source_path=path,timeout=60,exact=True)
        matches=[r for r in lines if reader.normalized(r['text'])=='einobjektzeigen']
        assert matches
        assert all(70<r['bounds'][0]<r['bounds'][2]<502 and 1975<r['bounds'][1]<r['bounds'][3]<2112 for r in matches)
        assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256']
        item.update(status='PASS',matches=matches)
    except Exception as error: item.update(status='FAIL',error=str(error),traceback=traceback.format_exc())
    item['seconds']=time.monotonic()-started;results.append(item);print(json.dumps(item,ensure_ascii=False),flush=True)
result={'scope':'Real local deu+eng Tesseract on four exact Producer86445 Learning originals; fixed60s request budget; no new Android/runtime approval','reader_sha256':hashlib.sha256((repo/'.github/probes/creative_android_probe.py').read_bytes()).hexdigest(),'results':results,'status':'PASS' if all(r['status']=='PASS' for r in results) else 'FAIL'}
(out/'report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
raise SystemExit(0 if result['status']=='PASS' else 1)
