#!/usr/bin/env python3
"""Actual QA61c original replay, unchanged 7b APK; no new device approval."""
import hashlib,json,time,traceback
from pathlib import Path
from replay_current_originals import helper
root=Path('/workspace/scratch/b3485b7bb989');repo=root/'lumo-host-creative-followup-7b16'
source=root/'host-pr480-61c94cfb-android35-update-evidence/artifacts/14097450952/memory-originals/originals/nextgen'
out=root/'host-7b16-creative-followup-repair/current-learning-61c-replay';out.mkdir(exist_ok=True)
reader=helper(repo);rows=[]
expected={'learning-move-1-0.png':'4362e3030fb3a040e76ce90c6520eca15dba3617397ee497ca5054c1e7b45663','learning-move-1-6.png':'62efb3acfa21b2cfffc9faff07b13ffc81a330eee50db4524700a3022512685c'}
for name,wanted_sha in expected.items():
 path=source/name;before=hashlib.sha256(path.read_bytes()).hexdigest();assert before==wanted_sha
 row={'original':str(path),'original_sha256':before,'bytes':path.stat().st_size,'shared_deadline_seconds':60};started=time.monotonic()
 try:
  lines=reader.image_lines(out,path.stem,'einobjektzeigen',source_path=path,timeout=60,exact=True)
  matches=[line for line in lines if reader.normalized(line['text'])=='einobjektzeigen']
  assert matches and all(70<line['bounds'][0]<line['bounds'][2]<502 and 1975<line['bounds'][1]<line['bounds'][3]<2112 for line in matches)
  assert hashlib.sha256(path.read_bytes()).hexdigest()==before
  row.update(status='PASS',matches=matches)
 except Exception as error:row.update(status='FAIL',error=str(error),traceback=traceback.format_exc())
 row['seconds']=time.monotonic()-started;rows.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
originals={}
for name in ['learning-move-1-surface-readiness.json','native-surfaces-result.json','learning-move-1-0-ocr.json','learning-move-1-5-ocr.json']:
 path=source/name;data=path.read_bytes();originals[name]={'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
identity=json.loads((source/'native-surfaces-result.json').read_text())['apk_identity']
report={'scope':'Real local Tesseract on exact first/last failed QA61c/API35 originals; original live result remains FAIL, no input or Android success','run_id':43551424080,'job_id':132314688451,'artifact_id':14097450952,'apk_identity':identity,'original_failure_files':originals,'original_ready_status':'FAIL','original_elapsed_seconds':120.212278,'reader_sha256':hashlib.sha256((repo/'.github/probes/creative_android_probe.py').read_bytes()).hexdigest(),'rows':rows,'status':'PASS' if all(r['status']=='PASS' for r in rows) else 'FAIL'}
(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
raise SystemExit(0 if report['status']=='PASS' else 1)
