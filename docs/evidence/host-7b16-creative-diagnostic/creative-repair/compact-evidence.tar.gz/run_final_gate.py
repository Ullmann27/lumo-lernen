#!/usr/bin/env python3
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
root=Path('/workspace/scratch/b3485b7bb989');repo=root/'lumo-host-creative-followup-7b16';pack=root/'host-7b16-creative-followup-repair'
owned=['.github/probes/creative_android_probe.py','.github/probes/studio_creative_android_probe.py','scripts/tests/test_studio_creative_7b_repair.py']
owned += [str(path.relative_to(repo)) for path in sorted((repo/'tools/android_qa/tests/fixtures/studio_creative_7b').rglob('*')) if path.is_file()]
dependencies=['tools/android_qa/native_surface_readiness.py','tools/android_qa/native_ocr_tiles.py','scripts/tests/test_studio_creative_runtime_repair.py','scripts/tests/test_studio_creative_android_probe.py']
def stamp(paths):
 result=[]
 for relative in paths:
  data=(repo/relative).read_bytes();result.append({'path':relative,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()})
 return result
before={'owned_files':stamp(owned),'unchanged_test_dependencies':stamp(dependencies)}
(pack/'final-before-manifest.json').write_text(json.dumps(before,indent=2)+'\n')
env=os.environ.copy();env.update(TESSDATA_PREFIX=str(pack/'ocr-runtime'),OMP_THREAD_LIMIT='1',PYTHONDONTWRITEBYTECODE='1')
steps=[('final-original-replay.log',[sys.executable,str(pack/'replay_current_originals.py'),'--repo',str(repo),'--out',str(pack/'final-original-replay')]),('final-tests.log',[sys.executable,'-m','unittest','scripts.tests.test_studio_creative_7b_repair','scripts.tests.test_studio_creative_runtime_repair','scripts.tests.test_studio_creative_android_probe','-v'])]
results=[]
for name,command in steps:
 started=time.monotonic()
 with (pack/name).open('wb') as output: run=subprocess.run(command,cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT)
 results.append({'command':command,'log':name,'returncode':run.returncode,'seconds':time.monotonic()-started,'log_sha256':hashlib.sha256((pack/name).read_bytes()).hexdigest()});print(json.dumps(results[-1]),flush=True)
 if run.returncode:break
after={'owned_files':stamp(owned),'unchanged_test_dependencies':stamp(dependencies)}
(pack/'final-after-manifest.json').write_text(json.dumps(after,indent=2)+'\n')
result={'before_equals_after':before==after,'results':results,'status':'PASS' if before==after and len(results)==len(steps) and all(r['returncode']==0 for r in results) else 'FAIL'}
(pack/'final-gate.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['status'],flush=True);raise SystemExit(0 if result['status']=='PASS' else 1)
