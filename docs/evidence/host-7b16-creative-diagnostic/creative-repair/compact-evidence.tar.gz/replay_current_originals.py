#!/usr/bin/env python3
"""Real OCR/geometry replay of preserved 7b images; never an Android run."""
import argparse, ast, csv, hashlib, importlib.util, json, math, os, re, subprocess, sys, time, traceback, unicodedata
from collections import deque
from pathlib import Path
from types import ModuleType, SimpleNamespace
from PIL import Image, ImageChops

def load(name, path):
    spec=importlib.util.spec_from_file_location(name,path); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module

def helper(repo):
    sys.path.insert(0,str(repo/'tools/android_qa'))
    from native_ocr_tiles import observed_matches,read_tiled_word
    from native_surface_readiness import inspect_surface,target_observation
    ns=ModuleType('actual_creative_reader')
    def command(*args,timeout):
        completed=subprocess.run(args,timeout=timeout,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        if completed.returncode: raise RuntimeError(f'OCR command failed {completed.returncode}: {completed.stderr}')
        return completed.stdout+completed.stderr
    ns.__dict__.update(Path=Path,csv=csv,hashlib=hashlib,json=json,math=math,os=os,re=re,time=time,unicodedata=unicodedata,deque=deque,Image=Image,ImageChops=ImageChops,observed_matches=observed_matches,read_tiled_word=read_tiled_word,inspect_surface=inspect_surface,target_observation=target_observation,base=SimpleNamespace(command=command))
    tree=ast.parse((repo/'.github/probes/creative_android_probe.py').read_text())
    functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('digest','normalized','gold_caption_boxes','read_component_caption','image_lines')]
    exec(compile(ast.Module(body=functions,type_ignores=[]),str(repo/'.github/probes/creative_android_probe.py'),'exec'),ns.__dict__)
    return ns

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--repo',type=Path,required=True); parser.add_argument('--out',type=Path,required=True); args=parser.parse_args(); args.out.mkdir(parents=True,exist_ok=True)
    models=subprocess.check_output(['tesseract','--list-langs'],text=True)
    if not all(lang in models.splitlines() for lang in ('deu','eng')): raise RuntimeError('Actual replay requires both deu and eng; no language fallback')
    fixture=args.repo/'tools/android_qa/tests/fixtures/studio_creative_7b'; probe=load('actual_studio_reader',args.repo/'.github/probes/studio_creative_android_probe.py'); candidate=helper(args.repo)
    report={'scope':'Offline real Tesseract/geometry on unchanged failed API35 original pixels; no Android or visual approval','tesseract':subprocess.check_output(['tesseract','--version'],text=True),'languages':models,'source_files':{},'checks':[]}
    for relative in ('.github/probes/creative_android_probe.py','.github/probes/studio_creative_android_probe.py'):
        data=(args.repo/relative).read_bytes(); report['source_files'][relative]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    def check(name,call):
        started=time.monotonic()
        try: value=call(); row={'name':name,'status':'PASS','value':value}
        except Exception as error: row={'name':name,'status':'FAIL','error':str(error),'traceback':traceback.format_exc()}
        row['seconds']=time.monotonic()-started; report['checks'].append(row); print(json.dumps(row,ensure_ascii=False),flush=True)
    def jump():
        source=fixture/'0017-observe-springen.png'; im=probe.read_image(source); tour=probe.Tour.__new__(probe.Tour); tour.out=args.out; tour.counter=0; tour.surface_orientation='responsive'; tour.probe=candidate
        tour.shot=lambda label:(source,{'file':source.name,'width':im.width,'height':im.height,'sha256':probe.sha(source)})
        return tour.observe('SPRINGEN',exact=True,control='jump-action')
    check('current_jump_lower_action',jump)
    def puzzle():
        source=fixture/'0125-puzzle-observed-board.png'; saved=json.loads((fixture/'0122-puzzle-save-lumo_puzzle_p_0768095c1da522693b0639510a4d3037.json').read_text())
        return probe.puzzle_piece_target(probe.read_image(source),saved)
    check('current_empty_puzzle_board',puzzle)
    def build_state(name, expected):
        source=fixture/name
        lines=candidate.image_lines(args.out,source.stem,'mitlumolaufen',source_path=source,timeout=60,exact=True,all_caption_regions=True)
        state=probe.build_pause_observation(lines,candidate.inspect_surface(source),candidate.normalized)
        assert (state['state'] if state else None)==expected
        return {'observed_state':state,'original_sha256':probe.sha(source),'scope':'Actual single-frame state classification only; no input sent'}
    check('current_blank_build_waits_without_input',lambda:build_state('0081-entered-bauwelt.png',None))
    check('current_active_build_has_observed_editor_anchors',lambda:build_state('0082-native-weiterbauen-9.png','active'))
    report['status']='PASS' if all(row['status']=='PASS' for row in report['checks']) else 'FAIL'
    (args.out/'replay.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    return 0 if report['status']=='PASS' else 1
if __name__=='__main__': raise SystemExit(main())
