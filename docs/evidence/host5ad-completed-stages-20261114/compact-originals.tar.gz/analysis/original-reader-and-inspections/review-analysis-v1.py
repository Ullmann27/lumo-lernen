from pathlib import Path
import json,hashlib,zipfile,re
base=Path('/tmp/host-pr485-5ad005bd-pipeline-evidence-20261114')
dest=base/'early-stage-review';dest.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
ident=lambda p:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
host='5ad005bd080ac8c17f88eefcd3d2833c49be6d48';native='2281d990fb584db6f2cf786da8fec3badc2d9585'
initial=base/'initial-20261114T161409Z'
run=json.loads((initial/'run.original.json').read_text());commit=json.loads((initial/'commit.original.json').read_text());native_commit=json.loads((initial/'native-commit.original.json').read_text())
assert run['id']==43614047730 and run['run_attempt']==1 and run['head_sha']==host
assert commit['sha']==host and commit['tree']['sha']=='54a12aee5b76ea289e23546bee7ffc462e0dabdb'
assert native_commit['sha']==native and native_commit['tree']['sha']=='d7e0128afbda641cb92e29c41a8839d901ef5b43'
root=base/'runtime-artifact-14121382850';orig=root/'originals'
idx=json.loads((root/'archive-index.json').read_text());members={x['path']:x for x in idx['members']}
gate=json.loads((orig/'runtime/runtime-gate.json').read_text());nr=json.loads((orig/'runtime/native-result.json').read_text());dr=json.loads((orig/'runtime/dart-result.json').read_text())
before=(orig/'runtime/source-before.json').read_bytes();after=(orig/'runtime/source-after.json').read_bytes()
assert before==after
source=json.loads(before);assert source['host']['head']==host and source['native']['head']==native
pin=[x for x in source['host']['files'] if x['path']=='config/godot-source.json'];assert len(pin)==1 and pin[0]['sha256']==sha((initial/'native-pin.original.json').read_bytes())
assert gate['passed'] is True and gate['exit_codes']=={'dart':0,'godot':0} and nr['passed'] is True and dr['passed'] is True
assert nr['errors']==[] and gate['original_godot_log']['errors']==[]
assert sha((orig/'runtime/original-godot.log').read_bytes())==gate['original_godot_log']['sha256']
assert nr['checks']==gate['results']['native_checks']==170 and nr['frames']==len(nr['positions'])==gate['results']['frames']==250
moving=sum(bool(p['dropping']) for p in nr['positions']);winning=sum(p['win_rings']>0 for p in nr['positions'])
assert moving==gate['results']['observed_moving_frames'] and winning==gate['results']['observed_winning_frames']
assert dr['reopened_same_round'] is True and nr['final_state']['roundId']==dr['round']['id']
pngs={k:v for k,v in members.items() if k.endswith('.png')}
imagepaths=set()
for im in gate['results']['images']:
 path='runtime/'+im['path'];imagepaths.add(path);a=pngs[path]
 assert all(im[k]==a[k] for k in ['bytes','sha256','width','height']) and a['png_fully_decoded'] is True
assert imagepaths==set(pngs)
markers={}
for path,marker in [('return-recovery.log','CONNECT_FOUR_RETURN_PASS checks=21'),('wisps.log','[TreasureWisp] PASS checks=14')]:
 raw=(orig/path).read_text();lines=raw.splitlines();assert lines.count(marker)==1
 assert not re.search(r'ERROR:|SCRIPT ERROR:|Parse Error:|Assertion failed',raw)
 banners=[x for x in lines if x.startswith('Godot Engine v')]
 assert banners==['Godot Engine v4.6.3.stable.official.7d41c59c4 - https://godotengine.org']
 markers[path]={'marker':marker,'exact_count':1,'banner':banners[0],**ident(orig/path)}
selected=[]
with zipfile.ZipFile(root/'14121382850-original.zip') as z:
 for path in sorted(pngs):
  if path.count('/')!=1:continue
  data=z.read(path);assert sha(data)==pngs[path]['sha256']
  target=dest/'selected-original-pngs'/path;target.parent.mkdir(parents=True,exist_ok=True)
  with target.open('xb') as out:out.write(data)
  assert target.read_bytes()==data
  selected.append({'archive_path':path,'local_path':str(target),**pngs[path]})
assert len(selected)==9
cp=base/'compile-artifact-14120639904/originals'
compile_result=json.loads((cp/'result.json').read_text());classes=json.loads((cp/'connect-four-classes.json').read_text())
assert compile_result['status']=='PASS' and compile_result['flutter_source_commit']==host
assert classes['status']=='PASS' and classes['source']==host and set(classes['classes'])=={'ConnectFourGameActivity','ConnectFourAuthorityService','ConnectFourBridge'}
assert (cp/'source-sha.txt').read_text().strip()==host
ar=base/'curriculum-artifact-14122040074/originals'
bind=json.loads((ar/'source-binding.json').read_text());summary=json.loads((ar/'summary.json').read_text());issues=json.loads((ar/'issues.json').read_text())
assert bind['host_source']==bind['source']['commit']==host and bind['source']['tree']==commit['tree']['sha']
assert bind['run_id']==43614047730 and bind['run_attempt']==1
assert bind['workflow']=='.github/workflows/lumo-connect-four-2020.yml'
for path,v in bind['originals'].items():assert ident(ar/path)==v
assert bind['source']['files']['.github/workflows/lumo-connect-four-2020.yml']==ident(initial/'lumo-connect-four-2020.original.yml')
families=json.loads((ar/'task-families.json').read_text());samples=[json.loads(line) for line in (ar/'task-samples.jsonl').read_text().splitlines()]
assert len(families)==summary['familyCount']==236 and len(samples)==summary['generatedSamples']==7552 and issues==[] and summary['issues']==0
result={'schema':1,'kind':'new_current_run_original_integrity_review','source':{'host':host,'host_tree':commit['tree']['sha'],'native':native,'native_tree':native_commit['tree']['sha'],'run_id':43614047730,'attempt':1},'runtime':{'job_id':132505134338,'artifact_id':14121382850,'artifact_identity':ident(root/'14121382850-original.zip'),'all_member_count':len(members),'all_crc_sha_verified':idx['all_member_crc_and_sha_verified'],'png_count_fully_decoded':len(pngs),'report_image_inventory_exact':True,'native_checks':nr['checks'],'frames':nr['frames'],'moving_frames_recounted':moving,'winning_frames_recounted':winning,'source_before_after_byte_equal':True,'source_inventory':{k:{'head':v['head'],'files':len(v['files'])} for k,v in source.items()},'source_before_after_identity':ident(orig/'runtime/source-before.json'),'exit_codes':gate['exit_codes'],'markers':markers,'same_round_reopened_in_test_backend':True,'recording_format_fps':gate['results']['actual_recording_format_fps'],'device_fps_claim':False,'android_runtime_claim':False,'selected_pngs':selected},'compile':{'job_id':132505134116,'artifact_id':14120639904,'artifact_identity':ident(base/'compile-artifact-14120639904/14120639904-original.zip'),'result':compile_result,'c4_classes':classes,'scope':'Original CI compilation report and hashes; class payloads are not in this six-member artifact. No APK/Android runtime claim.'},'curriculum':{'artifact_id':14122040074,'artifact_identity':ident(base/'curriculum-artifact-14122040074/14122040074-original.zip'),'counts_recounted':{'families':len(families),'samples':len(samples),'issues':len(issues)},'summary':summary,'original_hashes_match_binding':True},'limits':['No engine, Flutter, Android, unit or integration tests were run locally for this review.','PNG pixels were fully decoded for integrity; no visual quality or real device FPS approval is asserted.','Source inventories are the original runtime gate selected inventories, not a claim of all tracked repository paths.','The build, Android, update and delivery stages are not covered by these completed-job results.','Old 0b7/baf results were not substituted for 5ad/2281 originals.','An initial read-only inspector assumed source.files was a dictionary and stopped with AttributeError; corrected inspection used its actual list schema. No original file or CI result changed.']}
p=dest/'review.json';p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'review':str(p),'identity':ident(p),'runtime':{k:v for k,v in result['runtime'].items() if k not in ['selected_pngs','markers']},'compile_classes':len(compile_result['classes'])+len(classes['classes']),'curriculum':result['curriculum']['counts_recounted'],'selected_png_count':len(selected)}),flush=True)
