# Host5ad / Native2281: abgeschlossene Runtime-, Compile- und Curriculum-Originale

Exakter Run43614047730, Versuch1, Host5ad005bd080ac8c17f88eefcd3d2833c49be6d48, Native2281d990fb584db6f2cf786da8fec3badc2d9585.

Der echte Desktop-Runtimejob132505134338 und der echte Android-Host-Compilejob132505134116 sind SUCCESS. Alle drei neuen Originalarchive wurden genau einmal übertragen, vollständig anhand Größe/SHA256 und sämtlicher Mitglieder anhand ZIP-CRC und SHA256 geprüft.

Runtime:399 Mitglieder,259 vollständig dekodierte PNGs; originaler Bericht170 Checks/250 Frames. Die Quellbytes der tatsächlich verwendeten Zählfunktion sind gebunden;90 bewegte und43 Gewinnframes wurden aus den ursprünglichen Geometriebeobachtungen nachgerechnet. Return21 und Wisp14 sind jeweils exakt einmal mit dem echten Enginebanner enthalten. Die ursprünglichen ausgewählten447Host-/1268Native-Quellinventare sind vor/nach bytegleich. Das ist ein echter lokaler Dart/Godot-Zweiprozessnachweis der CI mit SharedPreferences-Testbackend, keine Android- oder Geräte-FPS-Abnahme.

Compile: zwölf benannte Klassenberichte, davon drei C4-Klassen, an Host5ad gebunden. Die ursprünglichen Klassenbytes sind nicht in diesem kleinen Belegarchiv enthalten; die tatsächliche CI prüfte sie und lieferte Größen/Hashes. Kein APK-/Laufzeit-PASS wird abgeleitet.

Curriculum:236 Familien/7552 tatsächlich gesicherte Stichproben/0 gemeldete Probleme. Der Originalbericht begrenzt dies ausdrücklich auf den ExerciseFactory-Kern und bestätigt weder vollständige Variantenabdeckung noch amtliche Lehrplanfreigabe.

Enthalten sind vollständige Originaljoblogs, ursprüngliche APIs, alle Nicht-PNG-Runtimeoriginale, vollständige Compile-/Curriculumarchive, alle drei vollständigen Inventare, die neun benannten Runtime-PNGs sowie die unabhängige Integritätsauswertung. Die22-MB-Runtime-ZIP bleibt unverändert unter dem im Handoff genannten lokalen Pfad und im ursprünglichen GitHub-Artefakt; ihre250 Sequenz-PNGs werden nicht nochmals im kompakten Paket dupliziert.

Zwei frühe reine lokale Datenauswertungen hatten einen falschen Container-Typ bzw. die falsche Bewegungszählformel angenommen und stoppten. Ihre Ausgaben bleiben unverändert erhalten. Die korrigierte Auswertung bindet die Originalschemas und die tatsächliche unveränderte Readerformel; keine dieser Auswertungen startet Tests/Engine/Android oder verändert Originale.

Alle weiteren Build-, Android-, Update- und Delivery-Stufen bleiben für diesen Kandidaten gesondert nachzuweisen. Ergebnisse von0b7/baf wurden nicht übertragen.
