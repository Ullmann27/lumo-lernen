# Math491: exact-topic selection on Host0411

Status: SOURCE FROZEN; Dart and Flutter tests NOT RUN. Root must publish this
three-file source checkpoint before execution.

## Bound sources

Base: Ullmann27/lumo-lernen commit
0411b62f59425bc4f36226ca59e9ed5ef901709a, tree
6a439dddafaaf7319cfabe28a2149e8de8c363df.

Producer PR491: aab09275ec6b5808de9be539ca4e1a7e70921249, tree
baaa84b40b09e61d144f158e5b35a1c4dc5d2ef0.

The only proposed repository paths are:

- lib/core/math_task_templates.dart
- test/math_exact_topic_selection_test.dart
- test/support/math_exact_topic_selection_contract.dart

All three final files are the exact published Producer blobs. Both test files are
absent in the base. The production change is confined to generate(); every byte
before and after that method is unchanged. Source-freeze.json contains before and
after byte counts, SHA256 and Git blob identities. No other PR491 changes are
included.

## Concrete behavior and limits

The old ordering resolves current-grade templates before checking the requested
exact topic. Source-derived seed-1 examples are grade 2 Geld becoming Geld wechseln,
grade 3 Geometrie Formen becoming Umfang, and grade 4 Geometrie Formen becoming
Flaecheninhalt. These are source findings, not newly executed RED results.

The new ordering first finds all allowed exact-topic templates, then prefers the
current grade within that set for strict slots when available. Existing aliases,
general fallback, seed mixing, task construction and the current/review cadence
are unchanged. The existing ExerciseFactory.nextExact API and generator file are
not modified. The contract checks real template patterns and difficulty as well
as exact output labels; it also keeps same-topic earlier-grade review and legacy
aliases under observation.

There is one new Flutter test method, which calls the shared Dart contract.
That contract iterates the real cumulative curriculum; its actual check and
generator-call counts must be taken from a later execution, never inferred here.
No Flutter, Dart, analyzer, formatter, package, engine, device or CI execution was
performed for this pack. No product checkout, index, refs, pins, pubspec or lock
file was modified. No Android, rendering or educational-quality acceptance is
claimed.

## Inputs and later focused validation

Dependency-binding.json binds 13 unchanged direct dependencies/declarations,
including the existing generator, shape data and package declarations. Relative
Dart imports and the existing flutter_test dependency suffice; this change adds
no dependency. This is a direct-import/source audit, not a fresh package-resolution
or complete transitive-dependency validation.

After Root publishes the exact source checkpoint and verifies the toolchain:

    dart test/support/math_exact_topic_selection_contract.dart
    flutter test --no-pub test/math_exact_topic_selection_test.dart

Run the Flutter command only with the actual required dependencies available.
Preserve separate original stdout/stderr, exit codes and source identities.
A genuine original-source RED, if requested, must use a separate view with the
unchanged base math file and the same new contract. Do not overwrite the checkpoint.

## Evidence and completeness

Originals/producer491-compare.json is the complete unchanged API response held
from the bounded producer scan. It has 300 file entries, so it is not asserted to
be an exhaustive PR path inventory. All three selected paths and the Producer
commit/tree are explicitly present and match. The peer handoff and exact base
commit bytes are retained alongside it. No Producer CI success is transferred to
this integration; no new CI logs are invented.

Manifest.json inventories all payload files except itself and the archive wrapper.
Compact-originals.tar.gz includes that manifest plus every inventoried file.
Archive-binding.json records a full member-by-member byte/SHA/JSON readback.
These are evidence/transport checks only; they are not product tests.
