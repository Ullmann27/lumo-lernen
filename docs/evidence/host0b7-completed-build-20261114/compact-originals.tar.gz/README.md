# Host 0b7: completed build originals

Run 43604903064, attempt 1, build job 132478533146 completed SUCCESS at 2026-11-14 16:03:00 UTC. The full 1,864,894-byte original job log is included unchanged. Original API run/jobs/artifact responses and original immutable source bindings accompany it.

The separate review records actual 877-script and 994-Android-QA test completions, actual Native52/17, Dream5/7 and Discovery10/38/2 markers, and repeated identical APK/PCK/signature verifier reports. APK bytes were not independently downloaded here; both large APK artifact identities are preserved as API metadata. Godot owns the single separate native artifact export.

This pack is limited to completed build evidence. The Android tour/update/final candidate/delivery results were still open when it was frozen. It does not approve publication and does not remedy the separately proven missing Notice packaging in native baf. No tests or builds were rerun to produce this pack.

All listed source bytes were copied and compared exactly. compact-originals.tar.gz contains every listed original, review, README, handoff, manifest and SHA256SUMS; archive-verification.json records its complete byte roundtrip.
