# Actual c77 outer-build-budget validation

Exactly one invocation of the existing 71 Delivery unittest methods and exactly one actionlint invocation completed on published Host c77e2456ac8eb7e02a9950e7b764684da6f5eb7b / tree d124623c936de7d2fe142a22c2683dfbb1343ac2, with unchanged Native baf148b03a7a32c6ad9f737d731f900eb9113ea1. Both exit codes are0. All71 methods passed; no failure/error/skip. Both actionlint streams are empty.

The entire 4,460-entry index matches the published commit tree. All749 materialized file bytes and modes match their Git blobs, and3,711 absent paths have explicit sparse-checkout flags. HEAD/tree, full index bytes, materialized bytes/modes and clean status are identical before and after both commands. No existing checkout, index or ref changed; the validation used a new independent detached checkout.

Complete raw stdout/stderr, child start/end/elapsed times and exit codes, external runner, tool hash, original remote bytes for the two changed files, six selected source inputs and complete original before/after inventories are included. All other materialized source identities are explicitly retained in those inventories; bulk fixture pixels and checkout/Git caches are not duplicated into this compact evidence archive.

Only the outer verify-and-build150-minute budget and its two matching existing assertions changed. Android80 and every individual probe deadline are unchanged. The prior historical 90-minute timeout is separate from the active37 run, which this validation neither cancelled nor reclassified. No Pipeline17/Pin64 repeat, engine, Android, renderer or CI action occurred. Root controls subsequent documentation activation and actual fresh C4 run.
