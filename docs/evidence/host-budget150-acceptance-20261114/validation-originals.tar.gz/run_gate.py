import ast,datetime,hashlib,json,os,pathlib,platform,re,stat,subprocess,sys,time
PACK=pathlib.Path(__file__).resolve().parent
ROOT=PACK/"checkout"
HEAD="c77e2456ac8eb7e02a9950e7b764684da6f5eb7b"
TREE="d124623c936de7d2fe142a22c2683dfbb1343ac2"
ENV=dict(os.environ,PYTHONDONTWRITEBYTECODE="1",GIT_OPTIONAL_LOCKS="0",REQUIRE_ALL_TESTS="true")
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
def git(*args):
 p=subprocess.run(["git","-C",str(ROOT),*args],env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if p.returncode:raise RuntimeError("git read failed: "+repr(args)+" "+p.stderr.decode())
 return p.stdout
def snapshot(label):
 head=git("rev-parse","HEAD").decode().strip(); tree=git("rev-parse","HEAD^{tree}").decode().strip()
 assert (head,tree)==(HEAD,TREE)
 status=git("status","--porcelain=v1","-z","--untracked-files=all")
 assert status==b"",repr(status)
 index=git("ls-files","--stage","-z"); flags=git("ls-files","-v","-z"); rawtree=git("ls-tree","-r","-z","HEAD")
 flagmap={x[2:].decode():x[:1].decode() for x in flags.split(b"\0") if x}
 treemap={}
 for row in rawtree.split(b"\0"):
  if not row:continue
  meta,path=row.split(b"\t",1); mode,kind,oid=meta.decode().split()
  assert kind=="blob"
  treemap[path.decode()]=(mode,oid)
 indexed={}; present=[]; absent=[]
 for row in index.split(b"\0"):
  if not row:continue
  meta,path=row.split(b"\t",1); mode,oid,stage=meta.decode().split(); name=path.decode()
  assert stage=="0"
  indexed[name]=(mode,oid)
  p=ROOT/name
  if p.is_symlink():
   raw=os.readlink(p).encode(); actual_mode="120000"
  elif p.is_file():
   raw=p.read_bytes(); actual_mode="100755" if p.stat().st_mode&0o111 else "100644"
  elif not p.exists():
   assert flagmap[name]=="S",(name,flagmap.get(name))
   absent.append(name); continue
  else:raise AssertionError("Unexpected tracked file type: "+name)
  assert blob(raw)==oid,(name,blob(raw),oid)
  assert actual_mode==mode,(name,actual_mode,mode)
  present.append({"path":name,"mode":mode,"bytes":len(raw),"sha256":sha(raw),"git_blob":oid,"index_flag":flagmap[name]})
 assert indexed==treemap
 ip=pathlib.Path(git("rev-parse","--git-path","index").decode().strip())
 if not ip.is_absolute():ip=ROOT/ip
 ib=ip.read_bytes()
 raw={"index-stage.nul":index,"index-flags.nul":flags,"tree.nul":rawtree,"status.nul":status,"index.bin":ib,"commit.txt":git("cat-file","commit","HEAD")}
 for name,b in raw.items():(PACK/(label+"."+name)).write_bytes(b)
 out={"head":head,"tree":tree,"parent":git("rev-parse","HEAD^").decode().strip(),"index_sha256":sha(ib),"raw_bindings":{name:{"bytes":len(b),"sha256":sha(b)} for name,b in raw.items()},"indexed_count":len(indexed),"materialized_count":len(present),"sparse_absent_count":len(absent),"indexed":[{"path":name,"mode":mode,"git_blob":oid,"flag":flagmap[name]} for name,(mode,oid) in indexed.items()],"materialized":present,"sparse_absent":absent,"status_empty":True}
 (PACK/(label+"-source.json")).write_text(json.dumps(out,indent=2)+"\n")
 return out
before=snapshot("before")
module=ROOT/"scripts/tests/test_connect_four_delivery.py"
methods=[n for n in ast.walk(ast.parse(module.read_bytes())) if isinstance(n,ast.FunctionDef) and n.name.startswith("test_")]
assert len(methods)==71
cfg=json.loads((ROOT/"config/godot-source.json").read_text()); assert cfg["revision"]=="baf148b03a7a32c6ad9f737d731f900eb9113ea1"
lint=pathlib.Path("/tmp/lumo-root-recovery-1242/bin/actionlint"); assert lint.is_file() and os.access(lint,os.X_OK)
lint_identity={"path":str(lint),"bytes":lint.stat().st_size,"sha256":sha(lint.read_bytes())}
argv=[sys.executable,"-m","unittest","scripts.tests.test_connect_four_delivery","-v"]
lint_argv=[str(lint),".github/workflows/lumo-connect-four-2020.yml"]
environment={"python_executable":sys.executable,"python_version":sys.version,"platform":platform.platform(),"boot_id":pathlib.Path("/proc/sys/kernel/random/boot_id").read_text().strip(),"controlled_environment":{k:ENV[k] for k in ("PYTHONDONTWRITEBYTECODE","GIT_OPTIONAL_LOCKS","REQUIRE_ALL_TESTS")},"actionlint":lint_identity,"unittest_argv":argv,"actionlint_argv":lint_argv,"cwd":str(ROOT)}
(PACK/"environment.json").write_text(json.dumps(environment,indent=2)+"\n")
processes=[]
for label,cmd in [("unittest",argv),("actionlint",lint_argv)]:
 start=utc(); t=time.monotonic()
 with (PACK/(label+".stdout.log")).open("xb") as out,(PACK/(label+".stderr.log")).open("xb") as err:
  p=subprocess.run(cmd,cwd=ROOT,env=ENV,stdout=out,stderr=err)
 record={"label":label,"argv":cmd,"cwd":str(ROOT),"started_at":start,"ended_at":utc(),"elapsed_seconds":time.monotonic()-t,"exit_code":p.returncode,"invocations":1,"stdout":{"path":label+".stdout.log","bytes":(PACK/(label+".stdout.log")).stat().st_size,"sha256":sha((PACK/(label+".stdout.log")).read_bytes())},"stderr":{"path":label+".stderr.log","bytes":(PACK/(label+".stderr.log")).stat().st_size,"sha256":sha((PACK/(label+".stderr.log")).read_bytes())}}
 (PACK/(label+"-process-result.json")).write_text(json.dumps(record,indent=2)+"\n"); processes.append(record)
after=snapshot("after"); assert before==after,"Source/index/status changed"
assert lint_identity["sha256"]==sha(lint.read_bytes()),"Actionlint changed"
log=(PACK/"unittest.stderr.log").read_text(); match=re.search(r"^Ran (\d+) tests in ([0-9.]+)s$",log,re.M)
case_lines=re.findall(r"^test_\S+ \([^\n]+\) \.\.\. ok$",log,re.M)
ok=processes[0]["exit_code"]==0 and processes[1]["exit_code"]==0 and match and int(match[1])==71 and len(case_lines)==71 and re.search(r"^OK$",log,re.M)
result={"schema":1,"status":"PASS" if ok else "FAIL","host_commit":HEAD,"host_tree":TREE,"native_commit":cfg["revision"],"methods":int(match[1]) if match else None,"passed_method_lines":len(case_lines),"errors":len(re.findall(r"^ERROR:",log,re.M)),"failures":len(re.findall(r"^FAIL:",log,re.M)),"skipped_method_lines":len(re.findall(r"\.\.\. skipped ",log)),"actionlint_exit_code":processes[1]["exit_code"],"source_index_status_unchanged":before==after,"indexed_paths":before["indexed_count"],"materialized_paths":before["materialized_count"],"sparse_absent_paths":before["sparse_absent_count"],"index_sha256":before["index_sha256"],"processes":processes,"scope":"Exactly one71-method Delivery suite and one actionlint on the changed workflow. No Pipeline17/Pin64 repeat, no engine/device/CI action."}
(PACK/"result.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result));sys.exit(0 if ok else 1)
