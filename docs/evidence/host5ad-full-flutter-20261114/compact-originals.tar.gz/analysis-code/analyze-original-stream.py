from pathlib import Path
import ast,hashlib,json,collections
root=Path('/workspace/scratch/b3485b7bb989/host5ad-full-flutter-originals-20261114')
artifact=root/'artifact-14122735014';originals=artifact/'originals';binding=root/'binding'
out=root/'analysis';out.mkdir(exist_ok=False)
identity=lambda p:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
index=json.loads((artifact/'archive-index.json').read_text());summary=json.loads((originals/'acceptance-summary.json').read_text())
artifacts=json.loads((binding/'artifacts.original.json').read_text())['artifacts'];meta=next(x for x in artifacts if x['id']==14122735014)
run=json.loads((binding/'run.original.json').read_text());commit=json.loads((binding/'commit.original.json').read_text());jobs=json.loads((binding/'jobs.original.json').read_text())['jobs'];job=next(x for x in jobs if x['id']==132506515793)
assert meta['workflow_run']['id']==run['id']==43614047730 and run['run_attempt']==job['run_attempt']==1
assert meta['workflow_run']['head_sha']==run['head_sha']==commit['sha']==job['head_sha']=='5ad005bd080ac8c17f88eefcd3d2833c49be6d48'
assert commit['tree']['sha']=='54a12aee5b76ea289e23546bee7ffc462e0dabdb'
assert index['artifact_id']==meta['id'] and index['bytes']==meta['size_in_bytes'] and 'sha256:'+index['sha256']==meta['digest'] and index['all_member_crc_and_sha_verified']
machine=(originals/'flutter-machine.jsonl').read_text();events=[];nonjson=[]
for number,line in enumerate(machine.splitlines(),1):
 try:item=json.loads(line)
 except json.JSONDecodeError:nonjson.append({'line':number,'text':line});continue
 if isinstance(item,dict):events.append(item)
 else:nonjson.append({'line':number,'text':line})
tree=ast.parse((binding/'run_full_flutter_acceptance.original.py').read_text())
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='summarize')
namespace={};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<bound-original-summarize-only>','exec'),namespace)
capture_errors=sorted(x['path'] for x in index['members'] if x['path'].endswith('.error.txt'))
recomputed=namespace['summarize'](events,summary['flutter_exit_code'],capture_errors)
assert all(summary[k]==v for k,v in recomputed.items()),'Original summary differs from original function applied to original stream'
constants={}
for n in tree.body:
 if isinstance(n,ast.Assign):
  for target in n.targets:
   if isinstance(target,ast.Name) and target.id in ['CAPTURE_DIRECTORIES','CAPTURE_FILES']:constants[target.id]=ast.literal_eval(n.value)
pngs=[x for x in index['members'] if x['path'].endswith('.png')]
png_counts={key:{'directory':directory,'pngs':sum(x['path'].startswith(directory+'/') for x in pngs)} for key,directory in constants['CAPTURE_DIRECTORIES'].items()}
assert png_counts==summary['capture_png_counts']
assert len(pngs)==summary['rendered_png_count']
paths={x['path'] for x in index['members']}
file_outputs={key:{'path':path,'created':path in paths} for key,path in constants['CAPTURE_FILES'].items()}
assert file_outputs==summary['capture_file_outputs']
names={};suite_for={};suites={};finished={};duplicate_done=[];start_events=[];error_events=[];done_events=[]
for event in events:
 kind=event.get('type')
 if kind=='suite':suites[event['suite']['id']]=event['suite']
 elif kind=='testStart':
  t=event['test'];names[t['id']]=t['name'];suite_for[t['id']]=t.get('suiteID');start_events.append(event)
 elif kind=='testDone':
  i=event['testID']
  if i in finished:duplicate_done.append({'id':i,'previous':finished[i],'next':event})
  finished[i]=event
 elif kind=='error':error_events.append(event)
 elif kind=='done':done_events.append(event)
results=[]
for i,event in finished.items():
 results.append({'test_id':i,'name':names.get(i,str(i)),'suite':suites.get(suite_for.get(i),{}).get('path',suites.get(suite_for.get(i),{}).get('url')),'result':event.get('result'),'skipped':event.get('skipped',False),'hidden':event.get('hidden',False),'time_ms':event.get('time')})
visible_success=sum(x['result']=='success' and not x['skipped'] and not x['hidden'] for x in results)
hidden_success=sum(x['result']=='success' and not x['skipped'] and x['hidden'] for x in results)
all_failure_events=[e for e in events if e.get('type')=='testDone' and e.get('result')!='success']
all_skip_events=[e for e in events if e.get('type')=='testDone' and e.get('skipped') is True]
assert visible_success==summary['passed']
suite_counts={}
for r in results:
 key=r['suite'] or '(unknown suite)'
 s=suite_counts.setdefault(key,{'visible_success':0,'hidden_success':0,'failed':0,'skipped':0})
 s['visible_success']+=r['result']=='success' and not r['skipped'] and not r['hidden']
 s['hidden_success']+=r['result']=='success' and not r['skipped'] and r['hidden']
 s['failed']+=r['result']!='success';s['skipped']+=r['skipped']
related=[r for r in results if not r['hidden'] and any(k in ((r['suite'] or '')+' '+r['name']).lower() for k in ['diktat','dictation','progress_persistence'])]
data={'schema':1,'kind':'current_5ad_full_flutter_original_stream_analysis','source':{'host':run['head_sha'],'tree':commit['tree']['sha'],'run_id':run['id'],'attempt':run['run_attempt'],'job_id':job['id'],'workflow':run['path']},'stage':next(s for s in job['steps'] if s['number']==13),'upload':next(s for s in job['steps'] if s['number']==14),'artifact':{'id':meta['id'],'name':meta['name'],'bytes':index['bytes'],'sha256':index['sha256'],'member_count':len(index['members']),'all_member_crc_sha_verified':True,'full_zip_local':str(artifact/'14122735014-original.zip'),'all_png_count':len(pngs),'png_pixels_not_independently_decoded':True,'pngs_not_copied_out':True},'originals':{'machine':identity(originals/'flutter-machine.jsonl'),'summary':identity(originals/'acceptance-summary.json'),'reader':identity(binding/'run_full_flutter_acceptance.original.py')},'original_summary':summary,'recomputed_summary':recomputed,'all_base_fields_identical':True,'visible_success':visible_success,'hidden_success':hidden_success,'unique_test_done':len(finished),'all_failure_events':all_failure_events,'all_skip_events':all_skip_events,'machine_error_events':error_events,'done_events':done_events,'duplicate_test_done':duplicate_done,'non_json_lines':nonjson,'suite_counts':suite_counts,'related_dictation_or_progress_cases':related,'limits':['Only the current original machine stream/summary/archive were analyzed; no test or renderer was rerun.','The exact original summarize function was AST-extracted and executed only on saved original event data.','PNG integrity is established by archive CRC and SHA; this analysis makes no visual or physical-device FPS claim.','This stage does not certify APK, Android, update or final delivery.','No earlier candidate result was substituted.'],'status':'PASS' if recomputed['status']=='PASS' and not error_events and not all_failure_events and not all_skip_events and not duplicate_done and len(done_events)==1 and done_events[0].get('success') is True and summary.get('runner_errors')==[] else 'FAIL'}
(out/'full-stream-analysis.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
(out/'all-test-results.json').write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'analysis':str(out/'full-stream-analysis.json'),'identity':identity(out/'full-stream-analysis.json'),'status':data['status'],'visible_success':visible_success,'hidden_success':hidden_success,'failures':len(all_failure_events),'skips':len(all_skip_events),'machine_errors':len(error_events),'done':done_events,'duplicate_done':len(duplicate_done),'non_json_lines':len(nonjson),'pngs':len(pngs),'related_suites':{k:v for k,v in suite_counts.items() if any(x in k.lower() for x in ['progress','diktat','dictation'])},'related_names':[x['name'] for x in related]}),flush=True)
