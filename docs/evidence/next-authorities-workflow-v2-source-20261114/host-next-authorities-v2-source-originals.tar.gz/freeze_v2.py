from pathlib import Path
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
V1 = BASE / 'host-next-authorities-qualification-20261114'
TARGET = '.github/workflows/lumo-next-table-authorities.yml'
ENV = {**os.environ, 'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1'}

def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}

def put(relative, data):
    target = ROOT / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        raise ValueError('Refusing to replace an existing frozen file: ' + relative)
    target.write_bytes(data)
    if target.read_bytes() != data:
        raise ValueError('Roundtrip differs: ' + relative)
    return identity(data)

def put_json(relative, data):
    return put(relative, (json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode())

def source_state(root):
    def git(*args):
        return subprocess.check_output(['git', '-C', str(root), *args], env=ENV)
    index = Path(os.fsdecode(git('rev-parse', '--git-path', 'index')).strip())
    if not index.is_absolute():
        index = root / index
    return {'head': git('rev-parse', 'HEAD').decode().strip(),
            'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
            'index_sha256': hashlib.sha256(index.read_bytes()).hexdigest(),
            'tracked_diff': git('diff', '--name-only', 'HEAD', '--').decode()}

checkouts = {'host': BASE / 'host-3fac2cfa-focused-validation-20261114/checkout',
             'native': BASE / 'native-ce909c4-import-validation-20261114/checkout'}
before_state = {name: source_state(path) for name, path in checkouts.items()}
assert before_state['host']['head'] == '3fac2cfaf23b80a127e711130fc6d7692776d316'
assert before_state['native']['head'] == 'ce909c4d3bab3a5514b653bf945a0ef46adfa539'
assert not any(row['tracked_diff'] for row in before_state.values())
old_manifest_raw = (V1 / 'manifest.json').read_bytes()
assert hashlib.sha256(old_manifest_raw).hexdigest() == 'e3c2ff10386c305793a7a13d5744c61f3960c7957cee5ca491c644ca750f5eb3'
old_manifest = json.loads(old_manifest_raw)
for row in old_manifest['files']:
    assert identity((V1 / row['path']).read_bytes()) == {key: row[key] for key in ('bytes', 'sha256', 'git_blob')}
for source in sorted((V1 / 'originals').rglob('*')):
    if source.is_file():
        assert not source.is_symlink()
        put(str(Path('originals') / source.relative_to(V1 / 'originals')), source.read_bytes())

old = (ROOT / 'before' / TARGET).read_bytes()
new = (ROOT / 'final-source' / TARGET).read_bytes()
assert (V1 / 'final-source' / TARGET).read_bytes() == old
assert hashlib.sha256(old).hexdigest() == 'efe60d3b94da7ace00eeeab849ec5904b686afc92a3529d44802c7bb1c164ece'
assert b'\0' not in new
change_map = json.loads((ROOT / 'change-map.json').read_bytes())
assert change_map['inverse_reconstruction_equals_complete_v1'] is True
assert 'EXPECTED_HOST: ${{ github.sha }}' in new.decode()
assert 'group: [memory, quiz, english, android-host-compile, flutter-contracts]' in new.decode()
assert '3fac2cfaf23b80a127e711130fc6d7692776d316' not in new.decode()

reference_map = json.loads((ROOT / 'v1-originals/original-source-map.json').read_bytes())
for row in reference_map['references']:
    assert identity((ROOT / row['original_copy']).read_bytes()) == {key: row[key] for key in ('bytes', 'sha256', 'git_blob')}
    checkout = checkouts['native' if row['repository'].startswith('native') else 'host']
    assert identity((checkout / row['path']).read_bytes()) == {key: row[key] for key in ('bytes', 'sha256', 'git_blob')}

review_excerpts = [
    ('source_snapshot.py', '          import hashlib, importlib.util, json, os, subprocess, sys, tarfile\n', '          PY\n          "$LUMO_QUAL_PYTHON" "$LUMO_QUAL_ROOT/source_snapshot.py"'),
    ('flutter_focused_invocation.py', '          import hashlib, importlib.util, json, os, signal, subprocess, sys, time\n', '          PY\n      - name: "Preserve and require unchanged actual Pub'),
]
for name, start, finish in review_excerpts:
    text = new.decode()
    left = text.index(start)
    right = text.index(finish, left)
    excerpt = ''.join(line[10:] if line.startswith('          ') else line for line in text[left:right].splitlines(keepends=True))
    put('review-only-inline-code/' + name, excerpt.encode())

contract = json.loads((ROOT / 'v1-originals/qualification-contract.json').read_bytes())
contract['revision'] = 2
contract['v1_source'] = identity(old)
contract['corrections'] = [
    {'name': 'actual_pub_package_identity',
     'before': 'A fresh enforce-lockfile invocation runs in actual host-source before each group; the unchanged compile helper keeps its existing internal Pub calls',
     'original_inputs': ['.dart_tool/package_config.json', '.dart_tool/package_graph.json when present', 'pubspec.lock'],
     'checks': ['Exact current committed lockfile bytes, SHA256 and Git blob',
                'Config rootUri is resolved against its actual file URI, not a prior machine mapping',
                'lumo_lernen resolves exactly to current host-source and host-source/lib',
                'All actual dependency root directories must exist; third-party package/lib directories are observed, not required',
                'After the actual group, all input presence/bytes/hash identities and resolved package rows must equal before'],
     'evidence': ['tools/package_snapshot.py', 'packages/before/*', 'packages/after/*', 'package-before.log', 'package-after.log']},
    {'name': 'visible_success_per_requested_flutter_suite',
     'checks': ['Original suite.id/path and testStart.test.suiteID/test.id link actual testDone.testID',
                'Exactly the seven requested suite paths; every requested suite has at least one visible successful non-skipped completion',
                'Unknown, malformed or duplicate IDs and missing start/done pairs fail',
                'Original suite metadata, names, IDs and complete start/done objects remain in per-suite evidence',
                'The existing summarize function and global no-error/no-failure/no-skip/successful-final-done/exit-zero requirements are unchanged'],
     'static_test_count_assertion': None},
    {'name': 'prepared_fixed_artifact_path',
     'if': "always() && steps.prepare.outcome == 'success'",
     'path': '${{ runner.temp }}/lumo-next-authorities-${{ github.run_id }}-${{ github.run_attempt }}-${{ matrix.group }}/evidence/',
     'scope': 'All later success and failure originals upload; no upload runs before a successful Prepare, so empty env cannot expand to the filesystem root'},
]
contract['groups'][-1]['requirements'].append('At least one successful visible non-skipped original test completion in each of the seven requested suites')
contract['all_groups'][-1] = 'Complete fresh original evidence uploaded on every outcome after successful Prepare, using a fixed run/attempt/group-specific path, for 30 days'
contract['all_groups'].append('Actual Pub Config/optional Graph/Lock bytes and every resolved package root bound before and after; own package exactly current Host/lib')
put_json('qualification-contract.json', contract)

freeze = {'schema': 1, 'revision': 2, 'status': 'FROZEN_UNTESTED_EXTERNAL_SOURCE_BEFORE_ROOT_CHECKPOINT',
          'created_utc': datetime.now(timezone.utc).isoformat(),
          'reviewed_host_base': before_state['host'], 'immutable_native': before_state['native'],
          'future_host_execution': 'Actual github.sha, including the already authorized intervening QA-only correction',
          'source_count': 1, 'files': [{'path': TARGET, 'source_path': 'final-source/' + TARGET,
                                      'mode': '100644', 'v1_before': identity(old), 'after': identity(new)}],
          'scope': 'Exactly three Root-approved V1 review corrections; no other workflow or product change',
          'v1_preserved': True, 'git_mutations': False, 'remote_mutations': False,
          'tests_lint_imports_or_generated_code_execution': 0}
freeze_identity = put_json('source-freeze.json', freeze)
integration = ('diff --git a/' + TARGET + ' b/' + TARGET + '\nnew file mode 100644\n'
               + 'index 0000000000000000000000000000000000000000..' + identity(new)['git_blob'] + '\n'
               + ''.join(difflib.unified_diff([], new.decode().splitlines(keepends=True), fromfile='/dev/null', tofile='b/' + TARGET)))
put('integration.patch', integration.encode())
put_json('original-source-map.json', {'schema': 1, 'inherited_original_reference_map': reference_map,
    'v1': {'source': identity(old), 'source_freeze': identity((ROOT / 'v1-originals/source-freeze.json').read_bytes()),
           'manifest': identity(old_manifest_raw)},
    'observed_pub_format': json.loads((ROOT / 'observed-format-only/origin.json').read_bytes()),
    'observed_pub_scope': 'Historical local reference only. The V2 source has no hardcoded package mapping from this machine.'})

after_state = {name: source_state(path) for name, path in checkouts.items()}
assert after_state == before_state
for row in old_manifest['files']:
    assert identity((V1 / row['path']).read_bytes()) == {key: row[key] for key in ('bytes', 'sha256', 'git_blob')}
assert (V1 / 'manifest.json').read_bytes() == old_manifest_raw
put_json('static-self-review.json', {
    'schema': 1, 'kind': 'OWN_SOURCE_READING_AND_BYTE_BINDING_ONLY',
    'before': before_state, 'after': after_state,
    'v1_manifest_files_still_exact': len(old_manifest['files']),
    'inverse_changed_hunks_equal_complete_v1': True,
    'unchanged': ['Five original groups and trigger/repository/branch/permissions',
                  'Actual pushed Host and exact ce909 Native/tree',
                  'Original helper, compiler and summarizer hashes and functions',
                  'All Native import/engine/renderer/pair/PNG/sidecar checks and timeouts',
                  'Seven Flutter file arguments, concurrency one, one process, 1200 seconds, no retry',
                  'Full tracked source/index/mode binding and generated-import preservation',
                  'Active C4 workflow and candidate/delivery verifiers'],
    'assumptions_and_boundaries': ['package_config version 2 and local file URIs are required; every actual resolved dependency root must exist',
        'Optional package_graph absence is recorded and must remain absent; present graph bytes must remain identical',
        'Third-party lib directory existence is not a requirement; own current Host/lib must exist and match exactly',
        'Before/after snapshots prove observed input/path equality, not a continuous filesystem monitor or full third-party source-content audit',
        'No static per-suite case counts or linguistic labels are treated as test results',
        'Early checkout/setup failure before successful Prepare has no artifact upload; later failures retain their prepared originals'],
    'lint_test_import_engine_or_generated_code_execution': False,
    'independent_review_pending': True})
readme = '''# Five-group qualification V2: three source-only corrections

Only `.github/workflows/lumo-next-table-authorities.yml` is proposed. V1 remains frozen and byte-identical. `v1-to-v2.patch` is the complete narrow delta; reversing its five replacement hunks reproduces all V1 bytes. `integration.patch` is the complete new-file patch for Root's still uncommitted workflow.

## Corrections

1. Every group obtains its actual Pub resolution with `flutter pub get --enforce-lockfile` in `host-source`. A new observer preserves the full generated Config, optional Graph, and exact committed Lock bytes before and after. It resolves URIs from the actual Config location, requires `lumo_lernen` to target the actual checkout and its `lib`, records all canonical dependency package roots, and rejects any after-change. Platform packages may legitimately lack `lib`; only their actual package root is required. The compiler script stays byte-identical, including its existing internal Pub invocations. Its before-observer requires one extra initial Pub resolution in that group.
2. The focused Flutter machine stream links each original `testStart.test.suiteID` to original `suite.id/path` and matches `testDone.testID`. Every one of the seven requested files must contribute at least one successful visible non-skipped test completion. Names, IDs, original suite objects and both original test events are retained per suite. Duplicate/unknown IDs, unmatched events, all old no-skip/error/timeout/final-done checks and real exit zero remain mandatory. No case count is invented; the existing summarizer is unchanged.
3. Upload requires `always() && steps.prepare.outcome == 'success'` and uses the fixed runner-temp/run/attempt/group evidence path, not a potentially unset environment variable. This prevents an early checkout/setup failure from expanding an empty variable to `/`. Prepared evidence still uploads on every subsequent outcome.

## Preserved boundaries

The trigger, repository restriction, five groups, exact Native ce909/tree e2a374b2, actual Host `github.sha`, verified toolchain, unchanged actual renderer/authority/compiler commands, budgets, strict source/index/mode binding and all old raster/report checks remain unchanged. Existing C4 workflow and both delivery/candidate verifiers remain untouched. This remains separate desktop-pair, compilation and focused Flutter qualification: no APK, Android-device, physical FPS or release approval follows.

`observed-format-only/` contains the actual earlier local 3fac Pub files and the installed package_config parser as read-only format references. Their machine-specific mappings are never copied into the future CI binding. The new observer reads that future job's own real Pub outputs.

`review-only-inline-code/` contains verbatim excerpts only, not extra repository paths. No proposed inline Python, YAML, Dart, Flutter, compiler or Godot command has been imported, linted or executed. Root's source checkpoint and independent reviews precede all qualification runs.
'''
put('README.md', readme.encode())

manifest = {'schema': 1, 'status': 'FROZEN', 'files': []}
for path in sorted(ROOT.rglob('*')):
    if path.is_file():
        assert not path.is_symlink()
        manifest['files'].append({'path': str(path.relative_to(ROOT)), **identity(path.read_bytes())})
manifest_identity = put_json('manifest.json', manifest)
sums = ''.join(row['sha256'] + '  ' + row['path'] + '\n' for row in manifest['files'])
sums += manifest_identity['sha256'] + '  manifest.json\n'
put('SHA256SUMS', sums.encode())
archive = ROOT / 'host-next-authorities-v2-source-originals.tar.gz'
members = [row['path'] for row in manifest['files']] + ['manifest.json', 'SHA256SUMS']
with tarfile.open(archive, 'x:gz') as tar:
    for relative in members:
        tar.add(ROOT / relative, arcname=relative, recursive=False)
roundtrip = []
with tarfile.open(archive, 'r:gz') as tar:
    assert [member.name for member in tar.getmembers()] == members
    for member in tar.getmembers():
        assert member.isfile()
        data = tar.extractfile(member).read()
        assert data == (ROOT / member.name).read_bytes()
        roundtrip.append({'path': member.name, **identity(data)})
roundtrip_identity = put_json('roundtrip.json', {'schema': 1, 'scope': 'Every archive member fully byte-compared to the frozen original',
    'archive': {'path': archive.name, **identity(archive.read_bytes())}, 'member_count': len(members), 'members': roundtrip})
handoff = {'schema': 1, 'status': 'FROZEN_SOURCE_ONLY', 'root': str(ROOT), 'source_count': 1,
    'workflow': {'path': str(ROOT / 'final-source' / TARGET), **identity(new)},
    'freeze': {'path': str(ROOT / 'source-freeze.json'), **freeze_identity},
    'manifest': {'path': str(ROOT / 'manifest.json'), **manifest_identity},
    'archive': {'path': str(archive), **identity(archive.read_bytes()), 'members': len(members)},
    'roundtrip': {'path': str(ROOT / 'roundtrip.json'), **roundtrip_identity},
    'delta': str(ROOT / 'v1-to-v2.patch'), 'full_integration_patch': str(ROOT / 'integration.patch'),
    'v1_unchanged': True, 'review': 'Root, Flutter and Pipeline independent review pending',
    'tests_lint_imports_engine_or_CI': 'Not executed; Root checkpoint first'}
put_json('handoff.json', handoff)
print(json.dumps(handoff, indent=2))
