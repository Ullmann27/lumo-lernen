import hashlib, importlib.util, json, os, signal, subprocess, sys, time
from pathlib import Path
sys.dont_write_bytecode = True
host = Path.cwd()
proof = Path(os.environ['LUMO_QUAL_EVIDENCE']) / 'flutter-focused'
proof.mkdir(exist_ok=False)
tests = ['test/games/memory_native_entry_test.dart', 'test/games/memory_result_frame_test.dart',
         'test/quiz_native_roundtrip_lifecycle_test.dart', 'test/reward_wallet_queue_zone_test.dart',
         'test/table_games_launcher_binding_test.dart', 'test/table_games_wallet_profile_test.dart',
         'test/tutoring/native_english_activity_test.dart']
helper = host / 'scripts/run_full_flutter_acceptance.py'
raw = helper.read_bytes()
if hashlib.sha256(raw).hexdigest() != 'd51614e941cc3c8cec83da860aa9e6b47a0cc47fd5ec8df25c441b8a023c547d' or hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() != '9999632174044af584c87147c5347c167b830918':
    raise ValueError('Unapproved original no-skip summarizer')
if subprocess.check_output(['git', 'show', os.environ['EXPECTED_HOST'] + ':scripts/run_full_flutter_acceptance.py']) != raw:
    raise ValueError('Summarizer differs from actual Host commit')
(proof / 'summarizer-original.py').write_bytes(raw)
spec = importlib.util.spec_from_file_location('bound_flutter_summary', helper)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
command = ['flutter', 'test', '--no-pub', '--machine', '--concurrency=1', *tests]
started = time.monotonic()
invocation = {'schema': 1, 'host': os.environ['EXPECTED_HOST'], 'argv': command, 'cwd': str(host),
              'wall_timeout_seconds': 1200, 'timeout_scope': 'Single focused CI Flutter process; no retry',
              'summarizer_sha256': hashlib.sha256(raw).hexdigest()}
(proof / 'invocation.json').write_text(json.dumps(invocation, indent=2) + '\n')
timed_out = False
with (proof / 'flutter-machine.stdout').open('wb') as stdout, (proof / 'flutter.stderr').open('wb') as stderr:
    process = subprocess.Popen(command, stdout=stdout, stderr=stderr, start_new_session=True)
    try:
        exit_code = process.wait(timeout=1200)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            exit_code = process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            exit_code = process.wait(timeout=5)
events, unparsed = [], []
for number, line in enumerate((proof / 'flutter-machine.stdout').read_bytes().splitlines(), 1):
    try:
        event = json.loads(line)
    except (json.JSONDecodeError, UnicodeDecodeError):
        unparsed.append({'line': number, 'kind': 'non_json_original_line'})
        continue
    if not isinstance(event, dict):
        unparsed.append({'line': number, 'kind': 'non_object_original_line'})
        continue
    events.append(event)
errors = ['Focused Flutter process exceeded its 1200-second deadline'] if timed_out else []
error_events = [event for event in events if event.get('type') == 'error']
if error_events:
    errors.append('Actual machine stream contains error events')
suites, starts, finishes = {}, {}, {}
for event in events:
    if event.get('type') == 'suite':
        suite = event.get('suite')
        if not isinstance(suite, dict) or type(suite.get('id')) is not int or not isinstance(suite.get('path'), str):
            errors.append('Malformed original suite identity')
            continue
        if suite['id'] in suites:
            errors.append('Duplicate original suite ID')
        suites[suite['id']] = {'original': suite, 'resolved_path': str(Path(suite['path']).resolve())}
    elif event.get('type') == 'testStart':
        test = event.get('test')
        if not isinstance(test, dict) or type(test.get('id')) is not int or type(test.get('suiteID')) is not int or not isinstance(test.get('name'), str):
            errors.append('Malformed original test start identity')
            continue
        if test['id'] in starts:
            errors.append('Duplicate original test start ID')
        starts[test['id']] = event
    elif event.get('type') == 'testDone':
        if type(event.get('testID')) is not int:
            errors.append('Malformed original test completion identity')
            continue
        if event['testID'] in finishes:
            errors.append('Duplicate original test completion ID')
        finishes[event['testID']] = event
suite_paths = {suite['resolved_path'] for suite in suites.values()}
expected_paths = {str((host / path).resolve()): path for path in tests}
if suite_paths != set(expected_paths):
    errors.append('Actual machine stream did not execute precisely the seven requested file suites')
if set(starts) != set(finishes):
    errors.append('At least one actual started test lacks its completion event')
suite_results = {path: {'requested_file': relative, 'resolved_path': path,
                       'original_suites': [], 'test_events': [], 'visible_passed': 0}
                 for path, relative in expected_paths.items()}
for suite in suites.values():
    if suite['resolved_path'] in suite_results:
        suite_results[suite['resolved_path']]['original_suites'].append(suite['original'])
for test_id, start_event in starts.items():
    suite = suites.get(start_event['test']['suiteID'])
    if suite is None or suite['resolved_path'] not in suite_results:
        errors.append('Actual test start does not belong to a requested original suite')
        continue
    result = suite_results[suite['resolved_path']]
    done_event = finishes.get(test_id)
    result['test_events'].append({'start': start_event, 'done': done_event})
    if done_event is not None and done_event.get('result') == 'success' and not done_event.get('skipped') and not done_event.get('hidden'):
        result['visible_passed'] += 1
for result in suite_results.values():
    if result['visible_passed'] < 1:
        errors.append('No actual visible successful test completed in ' + result['requested_file'])
if sum(event.get('type') == 'done' for event in events) != 1:
    errors.append('Exactly one final done event is required')
summary = module.summarize(events, exit_code, errors)
summary.update({'schema': 1, 'host': os.environ['EXPECTED_HOST'], 'requested_files': tests,
                'suite_paths': sorted(suite_paths), 'suite_results': list(suite_results.values()), 'timed_out': timed_out,
                'elapsed_wall_seconds': time.monotonic() - started, 'non_event_original_lines': unparsed,
                'machine_error_events': error_events, 'source': 'Unmodified original stdout/stderr retained separately'})
(proof / 'acceptance-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(summary, ensure_ascii=False))
if summary['status'] != 'PASS' or summary['failed'] or summary['skipped'] or summary['passed'] < 1:
    raise SystemExit(1)
print('FOCUSED_FLUTTER_PASS files=7 skipped=0 passed=' + str(summary['passed']))
