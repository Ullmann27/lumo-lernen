import hashlib, json, os, sys
from pathlib import Path
from urllib.parse import unquote_to_bytes, urljoin, urlsplit

phase = sys.argv[1]
if phase not in ('before', 'after'):
    raise ValueError('Package binding phase must be before or after')
host = (Path(os.environ['GITHUB_WORKSPACE']) / 'host-source').resolve(strict=True)
proof = Path(os.environ['LUMO_QUAL_EVIDENCE'])
output = proof / 'packages' / phase
output.mkdir(parents=True, exist_ok=False)

def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}

inputs, raw_inputs = {}, {}
for relative in ('.dart_tool/package_config.json', '.dart_tool/package_graph.json', 'pubspec.lock'):
    path = host / relative
    if path.is_symlink():
        raise ValueError('Package-resolution input is a symlink: ' + relative)
    present = path.exists()
    inputs[relative] = {'source_path': str(path), 'present': present, 'original_name': path.name}
    if not present:
        if relative != '.dart_tool/package_graph.json':
            raise ValueError('Required actual Pub input is missing: ' + relative)
        continue
    if not path.is_file():
        raise ValueError('Package-resolution input is not a regular file: ' + relative)
    raw = path.read_bytes()
    (output / path.name).write_bytes(raw)
    if (output / path.name).read_bytes() != raw:
        raise ValueError('Original Pub input copy differs: ' + relative)
    inputs[relative].update(identity(raw))
    raw_inputs[relative] = raw

source = json.loads((proof / 'source/host/source-inventory-before.json').read_bytes())
lock = next(row for row in source['tracked'] if row['path'] == 'pubspec.lock')
if source['head'] != os.environ['EXPECTED_HOST'] or any(inputs['pubspec.lock'][key] != lock[key] for key in ('bytes', 'sha256', 'git_blob')):
    raise ValueError('Actual Pub lockfile is not the current committed Host lockfile')
config_path = host / '.dart_tool/package_config.json'
config = json.loads(raw_inputs['.dart_tool/package_config.json'])
if not isinstance(config, dict) or type(config.get('configVersion')) is not int or config['configVersion'] != 2:
    raise ValueError('Expected actual package_config version 2')
entries = config.get('packages')
if not isinstance(entries, list) or not entries:
    raise ValueError('Actual Pub package list is empty or malformed')
if '.dart_tool/package_graph.json' in raw_inputs:
    graph = json.loads(raw_inputs['.dart_tool/package_graph.json'])
    if not isinstance(graph, dict):
        raise ValueError('Actual optional package graph is not a JSON object')

def local_directory(uri, *, require_exists):
    parts = urlsplit(uri)
    if parts.scheme != 'file' or parts.netloc not in ('', 'localhost') or parts.query or parts.fragment:
        raise ValueError('Pub resolution must identify a local file directory')
    decoded = unquote_to_bytes(parts.path).decode('utf-8')
    if not decoded.startswith('/') or any(character in decoded for character in ('\0', '\r', '\n')):
        raise ValueError('Invalid local Pub directory URI')
    resolved = Path(decoded).resolve(strict=require_exists)
    if require_exists and not resolved.is_dir():
        raise ValueError('Actual dependency package root is not a directory: ' + str(resolved))
    return resolved

packages = {}
for entry in entries:
    if not isinstance(entry, dict):
        raise ValueError('Malformed actual Pub package entry')
    name, root_uri, package_uri = entry.get('name'), entry.get('rootUri'), entry.get('packageUri')
    if not isinstance(name, str) or not name or name in packages or not isinstance(root_uri, str):
        raise ValueError('Missing or duplicate actual Pub package identity')
    if package_uri is not None and not isinstance(package_uri, str):
        raise ValueError('Invalid actual Pub packageUri')
    if any(character in root_uri + (package_uri or '') for character in ('\0', '\r', '\n')):
        raise ValueError('Control character in actual Pub URI')
    absolute_root_uri = urljoin(config_path.as_uri(), root_uri)
    if not absolute_root_uri.endswith('/'):
        absolute_root_uri += '/'
    absolute_package_uri = urljoin(absolute_root_uri, package_uri) if package_uri is not None else absolute_root_uri
    root_path = local_directory(absolute_root_uri, require_exists=True)
    package_path = local_directory(absolute_package_uri, require_exists=False)
    packages[name] = {'name': name, 'rootUri': root_uri, 'packageUri': package_uri,
                      'absolute_root_uri': absolute_root_uri, 'absolute_package_uri': absolute_package_uri,
                      'resolved_root': str(root_path), 'resolved_package': str(package_path),
                      'package_directory_exists': package_path.is_dir()}
own = packages.get('lumo_lernen')
if own is None or own['resolved_root'] != str(host) or own['resolved_package'] != str((host / 'lib').resolve(strict=True)) or not (host / 'lib').is_dir():
    raise ValueError('lumo_lernen must resolve exactly to the current host-source and host-source/lib')
state = {'schema': 1, 'status': 'PASS', 'phase': phase, 'host': os.environ['EXPECTED_HOST'],
         'config_location': str(config_path), 'original_directory': str(output.relative_to(proof)),
         'inputs': inputs, 'own_package': own, 'packages': [packages[name] for name in sorted(packages)],
         'scope': 'Actual local Pub input bytes and all resolved package roots; third-party lib directories are recorded, not required',
         'errors': []}
if phase == 'after':
    previous = json.loads((proof / 'packages/before/binding.json').read_bytes())
    for key in ('host', 'config_location', 'inputs', 'own_package', 'packages'):
        if previous[key] != state[key]:
            state['errors'].append('Actual Pub binding changed: ' + key)
    if state['errors']:
        state['status'] = 'FAIL'
(output / 'binding.json').write_text(json.dumps(state, indent=2) + '\n')
if state['errors']:
    raise ValueError('; '.join(state['errors']))
print('PUB_PACKAGES_' + phase.upper() + '_BOUND packages=' + str(len(packages)) + ' own=' + own['resolved_package'])
