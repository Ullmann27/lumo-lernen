# C4 Preferences-Beobachtung: enger Quellenanschluss

Basis 3fac2cfaf23b80a127e711130fc6d7692776d316 / Tree e76ef3862a0b2c73706d425a2b92a484fda5f9f3; aktiver Kandidat 5ad005bd080ac8c17f88eefcd3d2833c49be6d48 bleibt unverändert.
Der vollständige Probe-Vorherstand ist auf 51ec, 5ad und 3fac bytegleich.

Der echte 51ec-Lauf 43605863655 / Job 132499595540 scheiterte um 16:11:36.3621745 UTC nach einem Touch an ET.ParseError.
Die 129 originalen Antwortbytes sind eine cat-ENOENT-Ausgabe bei ADB-Exit 0 und leerem stderr. Der alte Lauf enthält keine spätere Erholung.
Der vollständige Original-ZIP ist separat im Workspace erhalten; seine 1.199 Mitglieder wurden vollständig CRC/SHA-geprüft. Die kleine vollständige Jobausgabe, Originalmetadaten, der komplette Index und die relevanten Originalmitglieder sind in diesem Pack enthalten.

Neun Endpfade entsprechen exakt den veröffentlichten Producer-Blobs von 7c5bef2bc39024fc2c1018523cabc651820cf76b. Die einzige vorhandene Produktionsmethode mit AST-Änderung ist read_preferences; zusätzlich wird ElementTree als ET importiert. Nur ET.ParseError wird mit Originalpfad und cause in den schon begrenzt beobachteten ValueError umgewandelt. Sämtliche Zustands-/ACK-/Frische-/Touch-/Zeitgrenzen bleiben gleich.

Neun neue Behavioralmethoden sind unverändert übernommen, ausdrücklich NOT_RUN. Geräteantworten, Uhr und Bildproduktion sind dort synthetisch; XML-, Persistenz-, Layout-, Pixel-, Ziel- und ACK-Prüfer sind die tatsächlichen unveränderten Methoden. Die spätere erfolgreiche XML-Antwort im Positivfall ist abgeleitete Testdaten, kein behaupteter Gerätenerfolg.

Root veröffentlicht den Quellencheckpoint vor jeder Testausführung. Dieser Pack führt keinen Test, Emulator, Engine, APK-Build oder CI-Neustart aus und verändert keinen Checkout oder Ref.
