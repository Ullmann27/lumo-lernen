from pathlib import Path
import ast, datetime, difflib, hashlib, json, shutil, zipfile
ROOT=Path("/workspace/scratch/b3485b7bb989/host-pr493-preferences-read-repair-3fac-20261114")
ORIG=Path("/workspace/scratch/b3485b7bb989/host-pr493-preferences-read-51ec-originals-20261114/artifact-14121596843")
BASE="3fac2cfaf23b80a127e711130fc6d7692776d316"
TREE="e76ef3862a0b2c73706d425a2b92a484fda5f9f3"
ACTIVE="5ad005bd080ac8c17f88eefcd3d2833c49be6d48"
FAILED="51ec0ac43f3e2aaac065e285e13cf5db5b5875d2"
PRODUCER="7c5bef2bc39024fc2c1018523cabc651820cf76b"
PROBE=".github/probes/lumo_connect_four_android_probe.py"
def identity(b):
 return {"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()}
def put(name,b):
 p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open("xb") as f:f.write(b)
 assert p.read_bytes()==b
 return identity(b)
def dump(name,j):
 return put(name,(json.dumps(j,ensure_ascii=False,indent=2)+"\n").encode())
def defs(b):
 tree=ast.parse(b);return {n.name:ast.dump(n,include_attributes=False) for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
before=(ROOT/"before-source"/PROBE).read_bytes()
after=(ROOT/"final-source"/PROBE).read_bytes()
assert before==(ROOT/"reference-source/failed-51ec"/PROBE).read_bytes()==(ROOT/"reference-source/active-5ad"/PROBE).read_bytes()
assert identity(before)["git_blob"]=="681e25d4654ce9827db8f208da5a608b458fa958"
assert identity(after)["git_blob"]=="f8d4ae7cdd3c38f0240a2bc20c4d78b6108f9f5d"
old=b"        return contract.preferences(raw), source\n"
new=(b"        try:\n            return contract.preferences(raw), source\n"
 b"        except ET.ParseError as error:\n"
 b"            raise ValueError('Original SharedPreferences are not valid XML: ' + source) from error\n")
assert after.replace(b"import xml.etree.ElementTree as ET\n",b"",1).replace(new,old,1)==before
old_defs,new_defs=defs(before),defs(after)
assert set(old_defs)==set(new_defs)
changed=[n for n in old_defs if old_defs[n]!=new_defs[n]]
assert changed==["read_preferences"],changed
unchanged=[n for n in old_defs if old_defs[n]==new_defs[n]]
producer=json.loads((ROOT/"original-api/producer-7c5bef-commit.original.json").read_text())
assert producer["sha"]==PRODUCER and producer["parents"][0]["sha"]==FAILED
finals=[]
for f in producer["files"]:
 p=ROOT/"final-source"/f["filename"];b=p.read_bytes();d=identity(b)
 assert d["git_blob"]==f["sha"]
 finals.append({"path":f["filename"],"mode":"100644","type":"blob",**d,"producer_blob":f["sha"],"producer_commit":PRODUCER})
assert len(finals)==9
test_path="tools/android_qa/tests/test_connect_four_preferences_observation.py"
test_tree=ast.parse((ROOT/"final-source"/test_path).read_bytes())
tests=[n.name for n in ast.walk(test_tree) if isinstance(n,ast.FunctionDef) and n.name.startswith("test_")]
assert len(tests)==9
reference_test_tree=ast.parse((ROOT/"reference-source/tools/android_qa/tests/test_connect_four_android_evidence.py").read_bytes())
reference_symbols={n.name for n in ast.walk(reference_test_tree) if isinstance(n,(ast.ClassDef,ast.FunctionDef))}
for name in ("state","stored","layout","SyntheticEvidence"):assert name in reference_symbols,name
patch=[]
for row in finals:
 rel=row["path"];p=ROOT/"before-source"/rel
 bb=p.read_text() if p.exists() else ""
 aa=(ROOT/"final-source"/rel).read_text()
 patch.extend(difflib.unified_diff(bb.splitlines(keepends=True),aa.splitlines(keepends=True),fromfile="a/"+rel if p.exists() else "/dev/null",tofile="b/"+rel))
patch_id=put("integration.patch","".join(patch).encode())
index_bytes=(ORIG/"archive-index.json").read_bytes()
index=json.loads(index_bytes)
assert index["artifact_id"]==14121596843 and index["source"]==FAILED and index["run_id"]==43605863655
assert index["bytes"]==128234694 and index["sha256"]=="6b55e5424b4177b8daa5b342d8ac5c64e3b7b802bfdd84805cec3974b1f0506c"
assert index["all_member_crc_and_sha_verified"] is True and len(index["members"])==1199
members={x["path"]:x for x in index["members"]}
put("original-evidence/archive-index.json",index_bytes)
result_bytes=(ORIG/"originals/c4/c4-result.json").read_bytes()
result=json.loads(result_bytes)
assert result["status"]=="FAIL" and result["error"]=="ParseError: syntax error: line 1, column 0"
assert result["binding"]["host_source"]==FAILED and result["binding"]["native_source"]=="bebf7bba48f09afc834469db0ea3c5541a184f55"
assert result["binding"]["run_id"]==43605863655 and result["binding"]["run_attempt"]==1
assert result["observations"]==["initial-017","child-first-first-000","child-first-second-000"]
assert result["transitions"]==result["returns"]==[]
reported={x["path"]:x for x in result["originals"]}
fixture_dir=ROOT/"final-source/tools/android_qa/tests/fixtures/c4-preferences-read-51ec"
provenance=json.loads((fixture_dir/"source.json").read_text())
assert provenance["artifact_sha256"]==index["sha256"]
selected=["c4/c4-result.json","c4/child-first-touch.json",
 "c4/commands/0078-child-first-touch.json","c4/commands/0078-child-first-touch.stderr","c4/commands/0078-child-first-touch.stdout",
 "c4/commands/0079-child-first-confirmed-000-state.json","c4/commands/0079-child-first-confirmed-000-state.stderr","c4/commands/0079-child-first-confirmed-000-state.stdout"]
fixture_checks=[]
for row in provenance["files"]:
 name=row["archive_path"];b=(ORIG/"originals"/name).read_bytes();idx=members[name]
 assert b==(fixture_dir/row["path"]).read_bytes()
 assert identity(b)["sha256"]==row["sha256"]==idx["sha256"] and len(b)==row["bytes"]==idx["bytes"]
 assert int(idx["crc32"],16)==row["zip_crc32"]
 original=reported[name.removeprefix("c4/")]
 assert original["sha256"]==row["sha256"] and original["bytes"]==row["bytes"]
 fixture_checks.append({"path":row["path"],"archive_path":name,"bytes":len(b),"sha256":row["sha256"],"crc32":idx["crc32"],"result_inventory_match":True})
 selected.append(name)
with zipfile.ZipFile(ORIG/"14121596843-original.zip") as z:
 for name in selected:
  b=z.read(name);idx=members[name]
  assert len(b)==idx["bytes"] and hashlib.sha256(b).hexdigest()==idx["sha256"]
  put("original-evidence/"+name,b)
touch=json.loads((ROOT/"original-evidence/c4/commands/0078-child-first-touch.json").read_text())
state=json.loads((ROOT/"original-evidence/c4/commands/0079-child-first-confirmed-000-state.stdout").read_text())
assert touch["command"][:4]==["adb","shell","input","swipe"] and touch["command"][-1]=="120"
assert touch["command"][4:6]==touch["command"][6:8]
assert touch["returncode"]==0
assert state["ack"]==0 and state["revision"]==2 and state["recordRevision"]==1 and state["columns"]==[]
bad=json.loads((fixture_dir/"0087-child-first-confirmed-000-preferences.json").read_text())
assert bad["returncode"]==0 and bad["stdout_bytes"]==129 and bad["stderr_bytes"]==0
run=json.loads((ROOT/"original-api/failed-run-43605863655.original.json").read_text())
jobs=json.loads((ROOT/"original-api/failed-jobs-43605863655.original.json").read_text())
artifacts=json.loads((ROOT/"original-api/failed-artifacts-43605863655.original.json").read_text())
assert run["id"]==43605863655 and run["head_sha"]==FAILED and run["run_attempt"]==1 and run["conclusion"]=="failure"
job=next(j for j in jobs["jobs"] if j["id"]==132499595540)
assert job["head_sha"]==FAILED and job["run_id"]==run["id"] and job["run_attempt"]==1 and job["conclusion"]=="failure"
artifact=next(a for a in artifacts["artifacts"] if a["id"]==14121596843)
assert artifact["digest"]=="sha256:"+index["sha256"] and artifact["size_in_bytes"]==index["bytes"] and artifact["workflow_run"]["head_sha"]==FAILED
full_log=(ROOT/"original-api/job-132499595540.original.log").read_bytes()
lines=full_log.decode().splitlines()
hits=[{"line":i+1,"text":v} for i,v in enumerate(lines) if "[ConnectFourAndroid]" in v and "ParseError: syntax error: line 1, column 0" in v]
assert len(hits)==1
diagnosis={
 "schema":1,"assessment":"IDENTICAL_OBSERVER_EXCEPTION_ROUTING_DEFECT; NOT_AN_APK_PRODUCT_FAILURE_FINDING",
 "failed_host":FAILED,"active_host":ACTIVE,"integration_base":BASE,"identical_complete_probe":identity(before),
 "original_run":43605863655,"attempt":1,"job":132499595540,"original_job_conclusion":"failure",
 "artifact":{"id":14121596843,"bytes":index["bytes"],"sha256":index["sha256"],"members":1199,"all_crc_and_sha_verified":True,
             "retained_zip":str(ORIG/"14121596843-original.zip"),"pngs_decoded":0},
 "first_c4_error":hits[0],"full_job_log":identity(full_log),"result":identity(result_bytes),
 "exact_traceback":result["traceback"],
 "chronology":{"pre_touch_valid_xml_bytes":2485,"one_recorded_touch":touch,"post_touch_state":{"ack":state["ack"],"revision":state["revision"],"recordRevision":state["recordRevision"],"columns":state["columns"]},
               "post_touch_preferences":bad,"accepted_observations":result["observations"],"confirmed_transitions":[],"returns":[]},
 "fixture_checks":fixture_checks,
 "cause":"ET.ParseError from contract.preferences is outside the existing ValueError/RuntimeError/JSONDecodeError observation exception tuple.",
 "change":"Catch only ET.ParseError in read_preferences and raise ValueError containing the exact saved original path, with the original exception chained as cause.",
 "limits":["The old device run did not recover; no later valid preferences or confirmed drop is inferred.",
           "Future successful replies in the new tests are explicitly synthetic derived data.",
           "Persistent malformed/missing preferences still fail at the unchanged observation deadline.",
           "No tests, application import, ADB, emulator, engine, source checkout edit or Git/ref mutation was performed for this pack.",
           "Current 5ad/2281 remains running and is not modified by this proposal."]
}
dump("diagnosis.json",diagnosis)
preservation={"schema":1,"complete_before_identical_for":[FAILED,ACTIVE,BASE],"before":identity(before),"after":identity(after),
 "exactly_two_hunks_reversed_reproduce_before_bytes":True,"changed_function_names":changed,"unchanged_function_names":unchanged,
 "all_other_definitions_ast_identical":True,"all_final_files_exact_published_producer_blobs":True,"added_test_count":len(tests),"added_test_names":tests,
 "preserved":["original stdout/stderr/metadata bytes","900-second whole-probe budget","90-second observation default","120-second transition observation deadline",
 "one existing dispatched touch","fresh state/layout/frame/PID/owner/durable-round checks","two stable observations before a touch","positive exact ACK validation",
 "30-second Flutter destination observer","45-second native-return observer","runtime_errors final all-buffer validation"],
 "validation_status":"NOT_RUN; sources and AST read only"}
dump("source-preservation.json",preservation)
freeze={"schema":1,"base_commit":BASE,"base_tree":TREE,"active_host_unchanged":ACTIVE,"producer_commit":PRODUCER,
 "source_count":len(finals),"files":finals,"new_test_methods":len(tests),"tests_executed":False,"patch":patch_id}
freeze_id=dump("source-freeze.json",freeze)
dump("upload-plan.json",{"schema":1,"repository":"Ullmann27/lumo-lernen","branch":"integration/lumo-next-table-authorities-20261114",
 "expected_parent":BASE,"expected_tree":TREE,"source_count":9,"entries":[{"path":x["path"],"mode":"100644","type":"blob","sha":x["git_blob"]} for x in finals],
 "mutations_performed":False,"publication_owner":"Root only","test_gate":"After source checkpoint: exact nine new preferences methods, bounded original-positive replay against before-source; unchanged relevant C4 neighbors only if explicitly assigned.",
 "active_candidate_ref_untouched":True,"no_workflow_pin_product_or_budget_changes":True})
dump("original-api/base-ls-tree.json",{"command":["git","ls-tree",BASE,"--",PROBE,test_path,"tools/android_qa/tests/fixtures/c4-preferences-read-51ec"],
 "exit_code":0,"stdout":"100644 blob 681e25d4654ce9827db8f208da5a608b458fa958\t"+PROBE+"\n","stderr":"",
 "conclusion":"Probe exists as 100644; new test and fixture directory absent on exact base."})
readme=f"""# C4 Preferences-Beobachtung: enger Quellenanschluss\n\nBasis {BASE} / Tree {TREE}; aktiver Kandidat {ACTIVE} bleibt unverändert.\nDer vollständige Probe-Vorherstand ist auf 51ec, 5ad und 3fac bytegleich.\n\nDer echte 51ec-Lauf 43605863655 / Job 132499595540 scheiterte um 16:11:36.3621745 UTC nach einem Touch an ET.ParseError.\nDie 129 originalen Antwortbytes sind eine cat-ENOENT-Ausgabe bei ADB-Exit 0 und leerem stderr. Der alte Lauf enthält keine spätere Erholung.\nDer vollständige Original-ZIP ist separat im Workspace erhalten; seine 1.199 Mitglieder wurden vollständig CRC/SHA-geprüft. Die kleine vollständige Jobausgabe, Originalmetadaten, der komplette Index und die relevanten Originalmitglieder sind in diesem Pack enthalten.\n\nNeun Endpfade entsprechen exakt den veröffentlichten Producer-Blobs von {PRODUCER}. Die einzige vorhandene Produktionsmethode mit AST-Änderung ist read_preferences; zusätzlich wird ElementTree als ET importiert. Nur ET.ParseError wird mit Originalpfad und cause in den schon begrenzt beobachteten ValueError umgewandelt. Sämtliche Zustands-/ACK-/Frische-/Touch-/Zeitgrenzen bleiben gleich.\n\nNeun neue Behavioralmethoden sind unverändert übernommen, ausdrücklich NOT_RUN. Geräteantworten, Uhr und Bildproduktion sind dort synthetisch; XML-, Persistenz-, Layout-, Pixel-, Ziel- und ACK-Prüfer sind die tatsächlichen unveränderten Methoden. Die spätere erfolgreiche XML-Antwort im Positivfall ist abgeleitete Testdaten, kein behaupteter Gerätenerfolg.\n\nRoot veröffentlicht den Quellencheckpoint vor jeder Testausführung. Dieser Pack führt keinen Test, Emulator, Engine, APK-Build oder CI-Neustart aus und verändert keinen Checkout oder Ref.\n"""
put("README.md",readme.encode())
handoff={"schema":1,"status":"SOURCE_FROZEN_NOT_RUN","root":str(ROOT),"source_freeze":freeze_id,"base_commit":BASE,"base_tree":TREE,
 "source_count":9,"test_methods":9,"final_production":identity(after),"producer_commit":PRODUCER,"active_5ad_unchanged":True,
 "original_failure_scope":"51ec/bebf actual Android FAIL; same observer bytes on 5ad and 3fac. No 5ad device verdict from these originals.",
 "full_original_zip_retained":str(ORIG/"14121596843-original.zip"),"full_original_zip_sha256":index["sha256"],
 "requested_next_step":"Root source checkpoint; no test performed yet."}
handoff_id=dump("handoff.json",handoff)
print(json.dumps({"root":str(ROOT),"source_count":9,"source_freeze":freeze_id,"handoff":handoff_id,"changed_functions":changed,"unchanged_definitions":len(unchanged),"tests_written":len(tests),"tests_run":0,"all_fixture_bytes_archive_exact":True},indent=2))
