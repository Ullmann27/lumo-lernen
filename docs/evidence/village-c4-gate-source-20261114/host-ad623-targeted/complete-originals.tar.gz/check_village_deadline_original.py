import hashlib,importlib.util,json,sys,unittest
from pathlib import Path
sys.dont_write_bytecode=True
repo=Path('/tmp/lumo-root-recovery-1105/host-village')
sys.path.insert(0,str(repo/'tools/android_qa/tests'))
import test_village_android_evidence as cases
original=Path('/workspace/scratch/b3485b7bb989/host-pr497-village-qa-proposal-a118-20261114/original-source/.github/probes/lumo_village_android_probe.py')
data=original.read_bytes()
assert hashlib.sha256(data).hexdigest()=='941176f413db24b78471bb2e374f7366236615d1599745e35afbf3bd92d3d59d'
spec=importlib.util.spec_from_file_location('village_original_for_regression',original)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
cases.village_probe=module
suite=unittest.defaultTestLoader.loadTestsFromTestCase(cases.VillageProcessDeadlineTests)
result=unittest.TextTestRunner(verbosity=2).run(suite)
failures=[{'test':case.id(),'traceback':traceback} for case,traceback in result.failures]
expected=('test_late_process_arrival_is_rejected_while_global_budget_remains','test_arrival_exactly_at_deadline_is_rejected_like_existing_c4_return')
correct=(result.testsRun==3 and len(failures)==4 and not result.errors and not result.skipped and all('TimeoutError not raised' in item['traceback'] for item in failures) and all(sum(name in item['test'] for item in failures)==2 for name in expected))
print(json.dumps({'original_blob':'97434207488900ac8f9364d5120f163cbc3ff0d5','original_sha256':hashlib.sha256(data).hexdigest(),'actual_methods_run':result.testsRun,'expected_failing_methods':2,'actual_failing_subtests':len(failures),'errors':len(result.errors),'skips':len(result.skipped),'timely_case_passed':all('timely_arrival' not in item['test'] for item in failures),'expected_original_defect_confirmed':correct,'failures':failures},indent=2))
raise SystemExit(0 if correct else 1)
