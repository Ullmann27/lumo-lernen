from datetime import datetime,timezone
import hashlib,importlib.util,json,os,re,subprocess,sys,time
from pathlib import Path
os.environ.update(PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',GIT_TERMINAL_PROMPT='0')
sys.dont_write_bytecode=True
repo=Path('/tmp/lumo-root-recovery-1105/host-village')
output=Path('/tmp/host-ad623b8-village-targeted-validation-20261114');output.mkdir(exist_ok=False)
(output/'runner.py').write_bytes(Path(__file__).read_bytes())
red=Path('/tmp/lumo-root-recovery-1105/check_village_deadline_original.py')
(output/'check_village_deadline_original.py').write_bytes(red.read_bytes())
original=Path('/workspace/scratch/b3485b7bb989/host-pr497-village-qa-proposal-a118-20261114/original-source/.github/probes/lumo_village_android_probe.py')
(output/'original-producer-probe.py').write_bytes(original.read_bytes())
source_helper=Path('/tmp/lumo-root-recovery-1105/native-discovery/tools/verify_dream_rasters.py')
assert hashlib.sha256(source_helper.read_bytes()).hexdigest()=='f7296a802d15c382dbcc77640373a0f53e30306fcaab3de869549ff1656de89d'
spec=importlib.util.spec_from_file_location('source_inventory',source_helper);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
before=helper.snapshot_source(repo,output,'before')
assert before['head']=='ad623b8a149caf5e4339fd544cef4c4736c0d218'
assert before['tree']=='af2e6f6d68f64c1274d9355bdc52b523489d83a1'
results=[]
commands=[('original-deadline-counterexample',[sys.executable,str(red)],60),('village-34',[sys.executable,'-m','unittest','discover','-s','tools/android_qa/tests','-p','test_village_android_evidence.py','-v'],240)]
for name,command,budget in commands:
 start=datetime.now(timezone.utc).isoformat();tick=time.monotonic();argv=['timeout','--signal=TERM','--kill-after=5s',str(budget)+'s',*command]
 proc=subprocess.run(argv,cwd=repo,capture_output=True)
 (output/(name+'.stdout.log')).write_bytes(proc.stdout);(output/(name+'.stderr.log')).write_bytes(proc.stderr)
 success=proc.returncode==0
 if name=='village-34':
  log=(proc.stdout+b'\n'+proc.stderr).decode();success=success and re.search(r'Ran 34 tests in [0-9.]+s\s+OK\s*$',log) is not None and re.search(r'\b(?:skipped|FAILED|ERROR)\b',log) is None
 else:
  if success:
   value=json.loads(proc.stdout);success=value['expected_original_defect_confirmed'] is True and value['actual_failing_subtests']==4
 record={'name':name,'argv':argv,'started_at_utc':start,'finished_at_utc':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-tick,'returncode':proc.returncode,'expected_result_observed':bool(success)}
 results.append(record);(output/(name+'.result.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
after=helper.snapshot_source(repo,output,'after')
same=all(before[x]==after[x] for x in ('head','tree','index_sha256','tracked','untracked_import_inventory'))
summary={'schema':1,'head':before['head'],'tree':before['tree'],'status':'PASS' if same and all(x['expected_result_observed'] for x in results) else 'FAIL','results':results,'new_source_verifier_methods_run':34,'new_source_skips':0,'original_control_methods_run':3,'original_expected_failing_subtests':4,'tracked_source_entries':len(before['tracked']),'materialized_source_entries':sum(x['materialized'] for x in before['tracked']),'explicit_sparse_entries':sum(x['skip_worktree'] for x in before['tracked']),'source_index_and_untracked_inventory_unchanged':same,'widget_runs':0,'android_device_runs':0,'scope':'Exact ad623b8: 31 original Village evidence cases plus3 real deadline-method cases on synthetic inputs. The original immutable producer probe is separately expected to fail both late and boundary cases for60/90-second local budgets; no device or renderer success is inferred.'}
(output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
raise SystemExit(0 if summary['status']=='PASS' else 1)
