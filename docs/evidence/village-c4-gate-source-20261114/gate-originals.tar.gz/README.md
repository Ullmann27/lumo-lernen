# Verpflichtender Dorfanschluss im bestehenden C4-Abnahmelauf

Dieser additive Quellenpack basiert exakt auf Host 4f5d66f96c5ad84939e4cd09bc66fb4744ae2a6b, Tree 0e89490ea5d877c8249c8d461270b8e364d2c986. Vollständige Vorherbytes der fünf Anschlussdateien, das rohe Commitobjekt, der originale rekursive Gitbaum und die Index-/Statusbindung liegen unter before/ und originals/. Der Commit-SHA wurde aus seinen Rohbytes unabhängig nachberechnet.

## Voraussetzungen und Umfang

Die vorherigen 16 Dorf-Produktdateien und drei QA-V2-Dateien müssen bereits vorhanden sein. Root hat sie inzwischen getrennt als f44ec248fc73be1fc0032f35bf41199400e7a5b5 und ad623b8a149caf5e4339fd544cef4c4736c0d218 veröffentlicht. Diese fünf Anschlussdateien sind dort unverändert gegenüber der hier eingefrorenen 4f-Basis.

Der Pack schreibt ausschließlich:
- .github/workflows/lumo-connect-four-2020.yml
- scripts/verify_connect_four_candidate.py
- scripts/verify_connect_four_delivery.py
- scripts/tests/test_connect_four_pipeline.py
- scripts/tests/test_connect_four_delivery.py

Native-Pin/Policy, Produktdateien, Versionsangaben, Branchzulassungen, API37 und Releaseaktivierung gehören nicht zu diesem Patch. Die Verbindung zum freigegebenen Native-c300-Stand bleibt bei Root.

## Ablauf mit derselben tatsächlichen APK

Der bestehende API35-Job behält seinen Checkout, sein Kandidatenartefakt, seine APK-/PCK-/Provenienz-/Signerbindung und seine Emulatorparameter. Zwischen der unveränderten vollständigen Haupttour und C4 wird genau einmal lumo_village_android_probe.py ausgeführt.

Die neue Zeile verwendet dieselben APK-/Provenienz-/Summenpfade und dieselben SOURCE_SHA-, NATIVE_REVISION-, Run-/Attempt-/Artifact-ID-/Digestwerte wie C4. Sie verlangt den Originalbericht tour/main/tour-result.json. Ihre vollständigen Originale liegen unter tour/village und werden durch das unveränderte always()-Artefakt tour/ mitgesichert.

Die vorhandene vollständige Flutter-Suite benutzt bereits REQUIRE_ALL_TESTS=true und run_full_flutter_acceptance.py. Mit dem vorherigen Dorf-Mapping erzeugt sie alle sechs obligatorischen Dorf-Captures. Die vorhandene komplette Android-QA-Discovery nimmt die 34 Dorfverträge ebenfalls auf. Es gibt keinen Zusatzworkflow und keinen zweiten gezielten34er-Aufruf im neuen Workflow.

## Candidate und Delivery

Der Candidate-Verifier verlangt den Hash genau derselben vorherigen Haupttour und führt village.verify_report mit der aktuellen Runbindung und der bereits bytegeprüften Geräte-APK-Identität aus. Damit bleiben der reale Portalweg, native Dorf-/Owner-/Save-/PID-Nachweise, der beobachtete Rücktouch, frischer games-ACK, Native-Ende, echte Flutter-Rückkehr und unveränderter Lern-/Profilzustand verpflichtend. Ein gemeldetes PASS ersetzt die Originalprüfung nicht.

Der vollständige neue Candidate-Verifier ist bytegleich zum veröffentlichten Producerblob bb496435fe24ecd34fd24809e12d51df6c2952be.

Delivery führt weiterhin den vollständigen Candidate-Verifier frisch aus. Vor jeder Ausgabe verlangt es zusätzlich Dorf-PASS und den exakten Originalbericht-Hash. VILLAGE-ANDROID-RESULT.json wird bytegleich zu den nun elf Pflichtassets aufgenommen. Die vorbereiteten Fakten enthalten die Dorfbindung; API37-, physische ARM64-, hörbare PCM-, FPS-, Visualreceipt- und Releasefreigaben bleiben unverändert falsch beziehungsweise nicht behauptet.

## Schutz der bestehenden Abnahme

Entfernen ausschließlich des neuen Compile-Arguments und der neuen Village-Zeile stellt die vollständigen ursprünglichen Workflowbytes wieder her. Alle Jobnamen, needs-/if-Bedingungen, Budgets, Credentials, Uploads und vorhandenen Aufrufe bleiben erhalten.

Im Delivery-Verifier sind alle 29 Funktionen außerhalb prepare und alle Konstanten außer dem einen zusätzlichen Pflichtasset unverändert. Die bestehenden52 Modi/17 Raster, Dream und Discovery10/38/2, PCM, Curriculum, zusätzliche Return-/Wisp-Gates, Android-Garage und Updateprüfungen werden nicht abgeschwächt.

Alle 80 bisherigen Testmethoden bleiben byte- und AST-identisch:11 Pipeline plus69 Delivery. Nur der synthetische gemeinsame Delivery-Fixturehelfer erhält die neue Reportdatei und deren Faktenhash. Acht neue Methoden ergänzen die echte Dorf-Replaygrenze, vorherigen Main-Hash, fehlenden Frame, noch lebenden Nativeprozess, Workflowpaarung und Delivery-Fehlerfälle einschließlich fehlender, abweichender oder symbolisch verlinkter Originale.

## Ausführungsstatus

Für diesen fünfteiligen Anschluss wurden keine Tests, Imports, Actionlint- oder Geräteaufrufe ausgeführt. Pipeline prüft den festen Stand unabhängig lesend. Die statische Testzahl ist17 Pipeline plus71 Delivery, zusammen88; sie ist kein Testergebnis.

references/prior-qa-ad623b8 enthält separate echte Root-Originale: die vorherige QA-V2-Abnahme mit34 Fällen sowie die Producer-Grenzgegenprobe. Diese Ergebnisse gelten ausschließlich für ihren ad623b8-Quellstand und werden nicht als Prüfung des neuen Anschlusses ausgegeben.

Nach Root-Checkpoint sind die betroffenen Pipeline-/Deliveryverträge und Actionlint der einen geänderten Workflowdatei zu prüfen. Der folgende vollständige C4-Lauf bleibt die kombinierte echte APK-/API35-/Updateabnahme. Ein zusätzlicher Dorfworkflow ist nicht erforderlich.
