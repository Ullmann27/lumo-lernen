# Host51e cup-caption selector repair

The original Host run 43502594333 failed on API35, API37 and the 2017-to-2019 update at the same cup-caption observation. This is a QA repair on the unchanged Host51e base. It is not a new device acceptance or a retry of that failed run.

## Cause and exact change

Each original OCR result contains a decorated `= Grand Prix` line with bounds `[62,240,385,455]` and two real title observations around `[170,397,385,426]`. The general alphanumeric normalizer removed `=`, promoting the decorated line to a title candidate. Its oversized rectangle then correctly failed the existing 0.6 intersection-over-union requirement. Root personally viewed the API35 original and the independent Godot reviewer viewed API37: each contains exactly one real Grand Prix title on the yellow cup card. The update reviewer also confirmed its original image.

The single changed QA matcher normalizes Unicode compatibility, case and whitespace for the complete cup caption, retaining other characters. `Grand Prix`, `GrandPrix` and `Pokal` remain accepted. A decorated composite cannot substitute for an actual caption. The shared normalizer, navigation-region bounds, 0.6 overlap threshold, two stable observations, screenshot hash check, real race identity/mode/vehicle, driving and pause/continue requirements remain unchanged. Separate genuine caption regions still fail closed.

## Focused verification

`red-original-selector.log` is the actual new regression against the original helper: 7 tests, 8 failing subtests and 6 expected ambiguity errors, exit 1. All three complete original OCR recordings reproduce the failure, in either observation order. Decorated-only negative cases demonstrate why a first-match fallback would be unsafe.

`green-focused-cup.log` is the actual corrected helper plus the five existing CupObservedLabelTests: 12 tests, 0 failures, 0 skips, exit 0. Existing tests retain stable-frame, caption-change, missing/conflicting target and changed-screenshot rejection. Exact commands, timings and before/after hashes are in the adjacent JSON results. No additional engine/device/full-suite run was performed. The original run remains FAILURE and its Verify/Publisher jobs remain SKIPPED.

## Contents and provenance

`before/` preserves the original helper and unchanged neighboring tour/test source. `after/` contains the exact nine patch files, including six byte-identical OCR/readiness JSON originals and their source/job/artifact/PNG identity manifest. `selector.diff` is the complete tracked helper change; added files are listed in `source-after.json`. The original PNG payloads and full CI logs remain at the exact hashed paths in `original-ci-references.json`. The fixture manifest binds API35, API37 and update recordings to their individual original artifact digests, not to another run. `diff-check.log` is empty because the actual git whitespace check passed. No files were staged or committed by this agent.
