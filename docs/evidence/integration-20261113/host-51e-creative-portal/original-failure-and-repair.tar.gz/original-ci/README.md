# Original Creative QA6dcc — FAIL before native game entry

Run43513179062 / job132188311296 / attempt1 completed FAILURE. The QA source is6dcc5f5de7b313a387fce7654d73f620fae4a746 (tree5b48c96a244bbba474aee5028ac0dcbc133afd56). The tested unchanged APK was built from51e92fb5afab232a29850ffefef5637359af08f7 and contains Native993c145304c3e5f8aa947e1c7a949a8ef8685415. These identities remain separate.

The actual APK/provenance/certificate/version/x86_64 checks, direct embedded PCK hash, API35/Android15 runtime, install, fictional profile onboarding, offline check and visible games hub were reached. Each game then failed in the same portal selector: 22 original hub observations and20 scroll gestures per game; no portal touch was issued. The four correct visible cards export full text, android.widget.Button, enabled/focusable/visible-to-user=true and clickable=false. The old QA assumed clickable=true. Exact51e _GameTile explains the observed split: outer Semantics(button:true, excludeSemantics:true) over an actual InkWell.

Jump reached no native entry, video or checkpoint. Bauwelt reached no placement, undo/redo, reward or save. Puzzle reached no menu choices, rotation or save. Schatzsuche reached no movement, clue, inventory or save. The original run stays FAIL. Root's independent original PNG/XML inspection is recorded separately and establishes only visible cards and actual metadata, not a successful touch or accessibility interaction.

The complete unchanged276,006,399-byte ZIP14080093476 is retained, SHA256a4e522645784830298b0635d7cd30b7cae3d277e8af103f5c91de6f717017903. All323 entries were fully read with CRC and SHA256; all312 tour-manifest rows match. The full334,283-byte original joblog, official final run/jobs/artifacts,18 source snapshots, actual13 source-file bindings and selective unchanged originals are retained. See review.json and original-zip-manifest.json.

The scoped subsequent QA correction is documented separately at ../host-creative-portal-repair-6dcc/. Its23 local contracts do not modify or promote the failed Android result. No pass is transferred to the independent new main84865ce2 build.
