# Narrow creative portal QA repair — exact original6dcc failure

Only the separate QA probe, its targeted tests and four byte-exact UI XML fixtures with provenance changed. The built APK remains51e92fb5afab232a29850ffefef5637359af08f7, Native993c145304c3e5f8aa947e1c7a949a8ef8685415. The unchanged workflow is not part of the patch. No source, pin or result from the new main848 build is used here.

## Cause and scope

The original API35 run43513179062 / job132188311296 failed for all four games before a portal touch. The correct games hub and targets were visible. Its _GameTile exports a full title/tagline/status and android.widget.Button with enabled/focusable/visible-to-user=true but clickable=false. The immutable51e Flutter source uses Semantics(button:true, excludeSemantics:true) above the physical InkWell. The old QA incorrectly required an accessibility click action for every physical pointer target.

The fix preserves the ordinary clickable=true path. A second path accepts only the four exact current full captions together with observed clickable=false, Button class, visibility and focusability. Package, enabled, exact unique target, in-screen bounds and72px minimum at the original density remain required. The event records actual clickability and the source-bound pointer-target basis. This is not screenreader/accessibility acceptance. Activity/process/header checks and all native gameplay, save, reward, resume and video checks remain byte-identical.

## Validation

Four tests replay each game's actual original XML through Tour.portal. Before the fix they reproduce the four exact current-live-hub failures; the ambiguity guard case also fails because no role target is recognized. Focused red:7 tests,4 errors,1 failure. After the fix all7 pass: each original target is selected from its observed bounds with one observation, no scrolling and one recorded physical-touch dispatch through the stubbed transport. Image IO is stubbed only to the actual original PNG dimensions; no synthetic image is claimed as an Android proof.

All23 tests in the affected module pass, including16 unchanged original test bodies. Negative cases retain rejection of wrong package, disabled/invisible/nonfocusable/wrong-class/missing-role/wrong-caption targets, clipping, undersized targets and real ambiguity. git diff --check is clean. The full7-file patch also passes a read-only reverse git-apply check against the actual final files. No extra suite or Android run was executed by this agent.

## Evidence

before/ and after/ retain original/final source bytes as deterministic gzip; handoff.json binds identities and logs. source.patch.gz contains the exact complete patch including four new XMLs and provenance.json. The original unchanged CI ZIP and final metadata live separately in ../host-pr474-6dcc5f5d-creative-evidence/. Its final review is FAIL_BEFORE_PORTAL_TOUCH for each game and remains so. A fresh actual QA run is needed to prove touch and native entry; Root owns review, commit and publication.
