#!/usr/bin/env python3
"""Bind completed original graphics evidence; never approve or install a receipt."""
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parent
HEAD = '993c145304c3e5f8aa947e1c7a949a8ef8685415'
TREE = 'f13dd5fc5540ecb7705c5f18bf3cf8ba6e79d7a6'
RUN = 43489950655
AREAS = ('home', 'worlds', 'feedback')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads((ROOT / path).read_bytes())


def write(path, data):
    dest = ROOT / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')


def main():
    run = read('proofs/run.json')
    jobs = read('proofs/jobs.json')
    artifacts = read('proofs/artifacts.json')
    commit = read('initial/commit.json')
    assert run['id'] == RUN and run['head_sha'] == HEAD and run['run_attempt'] == 1
    assert run['status'] == 'completed' and run['conclusion'] == 'success'
    assert run['event'] == 'pull_request'
    assert run['path'] == '.github/workflows/lumo-kart-experience.yml'
    assert commit['sha'] == HEAD and commit['tree']['sha'] == TREE
    assert jobs['total_count'] == len(jobs['jobs']) == 3
    assert {j['name'] for j in jobs['jobs']} == {'Actual ' + area + ' scene and interaction' for area in AREAS}
    assert all(j['run_id'] == RUN and j['head_sha'] == HEAD and j['status'] == 'completed' and j['conclusion'] == 'success' for j in jobs['jobs'])
    assert artifacts['total_count'] == len(artifacts['artifacts']) == 3
    inputs = read('recorder-inputs-ready.json')
    assert inputs['recorder_input_set_complete'] and inputs['head_sha'] == HEAD and inputs['source_tree'] == TREE
    source = read('immutable-source/manifest.json')
    for row in source:
        path = ROOT / row['file']
        assert row['ref'] == HEAD and sha(path) == row['sha256']
        raw = path.read_bytes()
        assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == row['git_blob']
    verifications = {area: read(area + '-verified.json') for area in AREAS}
    job_logs = {}
    warnings = {}
    indexes = {}
    for area, result in verifications.items():
        assert result['head_sha'] == HEAD and result['source_tree'] == TREE and result['run_id'] == RUN
        assert result['all_checked_gates_clean'] and not result['errors']
        artifact = read('proofs/' + area + '-artifact.json')
        assert artifact == next(a for a in artifacts['artifacts'] if a['id'] == artifact['id'])
        archive = ROOT / (area + '-' + str(artifact['id']) + '.zip')
        assert artifact['digest'] == 'sha256:' + sha(archive)
        assert artifact['size_in_bytes'] == archive.stat().st_size
        entries = []
        with zipfile.ZipFile(archive) as zipped:
            for info in zipped.infolist():
                if not info.is_dir():
                    payload = zipped.read(info)
                    assert len(payload) == info.file_size
                    entries.append({'file': info.filename, 'bytes': len(payload), 'compressed_bytes': info.compress_size, 'crc32': format(info.CRC, '08x'), 'sha256': hashlib.sha256(payload).hexdigest()})
        target = 'archive-indexes/' + area + '-members.json'
        write(target, {'artifact_id': artifact['id'], 'archive_sha256': sha(archive), 'files': entries})
        indexes[area] = {'file': target, 'sha256': sha(ROOT / target), 'files': len(entries)}
        if area != 'feedback':
            capture = 'home-capture.gd' if area == 'home' else 'worlds-capture.gd'
            assert (ROOT / area / 'baseline/harness-sha256.txt').read_text().split()[0] == sha(ROOT / 'immutable-source' / capture)
        log = ROOT / (area + '-job.log')
        text = log.read_text()
        actual_errors = []
        for line in text.splitlines():
            payload = re.sub(r'^\ufeff?\d{4}-\d\d-\d\dT\S+Z ', '', line)
            if payload.startswith(('ERROR:', 'SCRIPT ERROR:', 'Parse Error:', '##[error]')):
                actual_errors.append(line)
        assert not actual_errors
        assert HEAD in text
        job_logs[area] = {'file': log.name, 'sha256': sha(log), 'bytes': log.stat().st_size, 'actual_error_lines': actual_errors, 'format': 'Complete original job log decoded as UTF-8 by the GitHub connector; BOM retained'}
        warnings[area] = [line for line in (ROOT / area / 'project-validation.log').read_text().splitlines() if '[WARN]' in line or line.startswith('SUMMARY:')]
    selection = []
    for area, entry, label in [('home', 'images/home-1280x720.png', 'home'), ('home', 'images/home-412x915.png', 'home'), ('worlds', 'images/winter_sprint/02_world_landmark.png', 'winter_sprint'), ('worlds', 'images/crystal_canyon/02_world_landmark.png', 'crystal_canyon'), ('feedback', 'images/03_drift_release.png', 'feedback')]:
        result = verifications[area]
        image = next(row for row in result['images'] if row['file'] == entry)
        assert image['current'] and sha(ROOT / area / entry) == image['sha256']
        selection.append({'path': str(ROOT / area / entry), 'artifact_entry': entry, 'area': label, 'artifact_id': result['artifact_id'], 'archive_sha256': result['archive_sha256'], 'source_head': HEAD, 'source_tree': TREE, 'run_id': RUN, **{key: image[key] for key in ('sha256', 'bytes', 'width', 'height')}})
    write('required-current-image-paths.json', {'scope': 'Exact fresh original image selection for Root inspection; this catalog supplies no findings and grants no approval.', 'images': selection})
    counts = {area: {'current_png': result['current_png_count'], 'baseline_png': result['baseline_png_count'], 'logs': len(result['logs'])} for area, result in verifications.items()}
    loop = read('loop-integration-current-run.json')
    assert loop['head_sha'] == HEAD and loop['run_id'] == RUN and loop['actual_audio_release']['before_success_marker']
    original_root_reviews = []
    for path in sorted(ROOT.glob('root-current-*-viewed.json')):
        original_root_reviews.append({'file': path.name, 'sha256': sha(path), 'bytes': path.stat().st_size, 'scope': 'Unchanged Root-authored observation; no receipt created by this collector'})
    handoff = {
        'schema': 'lumo.graphics_ci_handoff.v1', 'repository': 'Ullmann27/lumo-godot', 'pull_request': 160,
        'head_sha': HEAD, 'source_tree': TREE, 'run_id': RUN, 'run_attempt': run['run_attempt'],
        'event': run['event'], 'status': run['status'], 'conclusion': run['conclusion'],
        'run_updated_at': run['updated_at'], 'run_url': run['html_url'],
        'jobs': [{key: row[key] for key in ('id', 'name', 'status', 'conclusion', 'started_at', 'completed_at')} for row in jobs['jobs']],
        'archives': inputs['archives'], 'proofs_directory': str(ROOT / 'proofs'),
        'counts': counts, 'current_png_count': sum(row['current_png'] for row in counts.values()),
        'baseline_png_count': sum(row['baseline_png'] for row in counts.values()),
        'artifact_logs_checked': sum(row['logs'] for row in counts.values()),
        'all_original_checked_gates_clean': True, 'current_and_prior_imports_successful': True,
        'baseline_head': 'ada5ed81ad62339f15289da62670c0a4f9f7f2b9', 'baseline_tree': '2e93cc5587b477ceee2d159c8aa981ff5188171b',
        'engine': (ROOT / 'home/engine.txt').read_text().strip(),
        'renderer_identity': loop['renderer_identity_lines'],
        'png_decoder': verifications['home']['png_decoder'],
        'project_validation_warnings': warnings, 'original_complete_job_logs': job_logs,
        'archive_member_indexes': indexes,
        'required_gate_markers': {area: {name: result['logs'][name]['markers'] for name in inputs['archives'][list(AREAS).index(area)]['original_required_files'] if name.endswith('.log')} for area, result in verifications.items()},
        'required_current_image_paths': str(ROOT / 'required-current-image-paths.json'),
        'root_authored_observation_files': original_root_reviews,
        'visual_inspection_performed_by_collector': False,
        'loop_integration': {'file': 'loop-integration-current-run.json', 'sha256': sha(ROOT / 'loop-integration-current-run.json'), 'actual_current_renderer_result': loop['rendered_result'], 'historical_headless_56_reused': False, 'actual_audio_release': loop['actual_audio_release']},
        'receipt_created_by_this_task': False, 'source_or_ref_mutations_by_graphics_task': False,
        'overall_native_acceptance': False,
        'limits': ['Only this exact Graphics run is attested; Nextgen and Android are separate.', 'Earlier 90d/cce/4f pixels and observations are not current-run evidence.', 'World images are stationary production scenes with staged player/cameras; landmark frames use context cameras.', 'No physical Android device, APK/AAR acceptance or measured frame-rate claim.', 'Original project-validator warnings remain unchanged.', 'Recorder artifact.json is the separately supplied original REST artifact object, not a ZIP member.'],
    }
    write('handoff.json', handoff)
    readme = f'''# PR160: Originaler Grafiknachweis für 993c1453

Grafiklauf {RUN} ist mit SUCCESS abgeschlossen. Alle drei Jobs gehören exakt
zu Head {HEAD} und Tree {TREE}. Run, Jobs und Artefaktliste unter proofs/
sind die vollständigen unveränderten REST-Antworten dieses Versuchs 1.

## Archive und Prüfung

| Bereich | Artefakt | Aktuelle PNG | Baseline-PNG | Geprüfte Logs |
|---|---:|---:|---:|---:|
'''
    for area in AREAS:
        result = verifications[area]
        row = counts[area]
        readme += f"| {area} | {result['artifact_id']} | {row['current_png']} | {row['baseline_png']} | {row['logs']} |\n"
    readme += f'''
Alle ZIPs wurden aus diesem Lauf frisch geladen und gegen die originalen
REST-Digests und Größen geprüft. CRC, reguläre sichere Archivpfade, vollständige
PNG-Manifestzuordnung, Originalbytes und Hashes wurden geprüft. Jeder PNG wurde
mit Pillow Image.verify() und Image.load() vollständig dekodiert. Alle enthaltenen
Engine-/Testlogs sind frei von den geprüften Script-, Parse-, Ressourcen- und
Leakfehlern. Originale Projektvalidator-Warnungen bleiben erhalten.

Die frisch ausgeführte historische Vergleichsquelle ist ada5ed81ad62339f15289da62670c0a4f9f7f2b9,
Tree 2e93cc5587b477ceee2d159c8aa981ff5188171b. Ihre Capture-Harness-Hashes
stimmen mit den frisch geladenen unveränderlichen aktuellen Dateien überein.
Alle aktuellen und historischen Imports sowie Pflichtprüfungen sind erfolgreich.

## Aktueller Loop- und Ownership-Nachweis

Die tatsächliche gerenderte Feedbackprobe meldet PASS 75. Ihre vier veröffentlichten
Loop-Assertions sind an den aktuellen Immutable-Blob gebunden. Drei tatsächliche
Audio-Playbacks wurden laut Originalprotokoll nach {loop['actual_audio_release']['elapsed_ms']} ms und vor PASS freigegeben.
Der frühere lokale Headless-56-Nachweis wird hier nicht wiederverwendet; ein
separater aktueller Nextgen-Feedback-56-Aufruf wird nicht behauptet.

## Sichtung und Recorder-Eingaben

required-current-image-paths.json nennt fünf frisch extrahierte Originale:
Home 1280×720 und 412×915, Winter/Crystal Landmark 02 und Feedback Drift 03.
Jeder Eintrag enthält Run, Head, Tree, Artefakt, ZIP-Hash und PNG-Hash. Der
Katalog selbst dokumentiert keine Sichtprüfung. Eventuelle root-current-*-viewed.json
sind separat gehashte unveränderte Beobachtungen von Root.

recorder-inputs-ready.json dokumentiert ausschließlich die Prüfung durch die
vorhandenen read-only Recorder-Eingabeleser. record_review und Receipt-Installation
wurden nicht ausgeführt. Proofs enthalten run.json, jobs.json und die vollständigen
home/worlds/feedback-artifact.json-Objekte, bytegenau aus der originalen REST-Liste
ausgeschnitten. artifact-metadata-provenance.json bindet Quelle und Bytepositionen.
artifact.json bezeichnet dabei das separate REST-Objekt, keinen ZIP-Eintrag.

## Aufbewahrung und Grenzen

Alle drei vollständigen Joblogs sind als unveränderte, vom Connector dekodierte
UTF-8-Ausgabe mit BOM gesichert. archive-indexes/ bindet jeden regulären ZIP-Eintrag
mit Originalgröße, CRC und SHA-256. Original-ZIPs und extrahierte PNG bleiben im
Scratch-Pack. SHA256SUMS bindet die relevanten Originale und Auswertungen.

Dieser Nachweis betrifft ausschließlich den angegebenen Grafiklauf und bedeutet
keine Native-Gesamtfreigabe. Separate
Nextgen-/Androidjobs, physische Geräte und gemessene 60-FPS-Leistung sind damit
nicht abgenommen. Kein Rerun, keine Produkt-/Host-/Ref-/Pinänderung und kein
Receipt wurden durch diese Sammlung erzeugt. Frühere 90d-/cce-/4f-Bilder oder
Beobachtungen wurden nicht als aktuelle Nachweise übernommen.
'''
    (ROOT / 'README.md').write_text(readme)
    files = set()
    for path in ROOT.iterdir():
        if path.is_file() and path.name != 'SHA256SUMS':
            files.add(path)
    for dirname in ('proofs', 'initial', 'immutable-source', 'archive-indexes'):
        files.update(path for path in (ROOT / dirname).rglob('*') if path.is_file())
    for directory in ROOT.glob('watch*'):
        if directory.is_dir():
            files.update(path for path in directory.rglob('*') if path.is_file())
    for area, result in verifications.items():
        for name in result['logs']:
            files.add(ROOT / area / name)
        for row in result['images']:
            files.add(ROOT / area / row['file'])
        for name in result['reports']:
            files.add(ROOT / area / name)
        for name in ('source-sha.txt', 'source-tree.txt', 'source-dirty.txt', 'engine.txt', 'image-manifest.json'):
            files.add(ROOT / area / name)
        if area != 'feedback':
            for name in ('source-sha.txt', 'source-tree.txt', 'harness-sha256.txt'):
                files.add(ROOT / area / 'baseline' / name)
    for path in files:
        assert path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(ROOT)
    (ROOT / 'SHA256SUMS').write_text(''.join(sha(path) + '  ' + str(path.relative_to(ROOT)) + '\n' for path in sorted(files)))
    print(json.dumps({'handoff_sha256': sha(ROOT / 'handoff.json'), 'sums_sha256': sha(ROOT / 'SHA256SUMS'), 'bound_files': len(files), 'counts': counts, 'root_observations': original_root_reviews}, ensure_ascii=False))


if __name__ == '__main__':
    main()
