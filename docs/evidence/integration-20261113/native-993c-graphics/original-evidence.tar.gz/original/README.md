# PR160: Originaler Grafiknachweis für 993c1453

Grafiklauf 43489950655 ist mit SUCCESS abgeschlossen. Alle drei Jobs gehören exakt
zu Head 993c145304c3e5f8aa947e1c7a949a8ef8685415 und Tree f13dd5fc5540ecb7705c5f18bf3cf8ba6e79d7a6. Run, Jobs und Artefaktliste unter proofs/
sind die vollständigen unveränderten REST-Antworten dieses Versuchs 1.

## Archive und Prüfung

| Bereich | Artefakt | Aktuelle PNG | Baseline-PNG | Geprüfte Logs |
|---|---:|---:|---:|---:|
| home | 14068903423 | 24 | 20 | 19 |
| worlds | 14069811657 | 6 | 6 | 15 |
| feedback | 14068797425 | 6 | 0 | 6 |

Alle ZIPs wurden aus diesem Lauf frisch geladen und gegen die originalen
REST-Digests und Größen geprüft. CRC, reguläre sichere Archivpfade, vollständige
PNG-Manifestzuordnung, Originalbytes und Hashes wurden geprüft. Jeder PNG wurde
mit Pillow Image.verify() und Image.load() vollständig dekodiert. Alle enthaltenen
Engine-/Testlogs sind frei von den geprüften Script-, Parse-, Ressourcen- und
Leakfehlern. Originale Projektvalidator-Warnungen bleiben erhalten.

Die frisch ausgeführte historische Vergleichsquelle ist ada5ed81ad62339f15289da62670c0a4f9f7f2b9,
Tree 2e93cc5587b477ceee2d159c8aa981ff5188171b. Ihre Capture-Harness-Hashes
stimmen mit den frisch geladenen unveränderlichen aktuellen Dateien überein.
Alle aktuellen und historischen Imports sowie Pflichtprüfungen sind erfolgreich.

## Aktueller Loop- und Ownership-Nachweis

Die tatsächliche gerenderte Feedbackprobe meldet PASS 75. Ihre vier veröffentlichten
Loop-Assertions sind an den aktuellen Immutable-Blob gebunden. Drei tatsächliche
Audio-Playbacks wurden laut Originalprotokoll nach 10 ms und vor PASS freigegeben.
Der frühere lokale Headless-56-Nachweis wird hier nicht wiederverwendet; ein
separater aktueller Nextgen-Feedback-56-Aufruf wird nicht behauptet.

## Sichtung und Recorder-Eingaben

required-current-image-paths.json nennt fünf frisch extrahierte Originale:
Home 1280×720 und 412×915, Winter/Crystal Landmark 02 und Feedback Drift 03.
Jeder Eintrag enthält Run, Head, Tree, Artefakt, ZIP-Hash und PNG-Hash. Der
Katalog selbst dokumentiert keine Sichtprüfung. Eventuelle root-current-*-viewed.json
sind separat gehashte unveränderte Beobachtungen von Root.

recorder-inputs-ready.json dokumentiert ausschließlich die Prüfung durch die
vorhandenen read-only Recorder-Eingabeleser. record_review und Receipt-Installation
wurden nicht ausgeführt. Proofs enthalten run.json, jobs.json und die vollständigen
home/worlds/feedback-artifact.json-Objekte, bytegenau aus der originalen REST-Liste
ausgeschnitten. artifact-metadata-provenance.json bindet Quelle und Bytepositionen.
artifact.json bezeichnet dabei das separate REST-Objekt, keinen ZIP-Eintrag.

## Aufbewahrung und Grenzen

Alle drei vollständigen Joblogs sind als unveränderte, vom Connector dekodierte
UTF-8-Ausgabe mit BOM gesichert. archive-indexes/ bindet jeden regulären ZIP-Eintrag
mit Originalgröße, CRC und SHA-256. Original-ZIPs und extrahierte PNG bleiben im
Scratch-Pack. SHA256SUMS bindet die relevanten Originale und Auswertungen.

Dieser Nachweis betrifft ausschließlich den angegebenen Grafiklauf und bedeutet
keine Native-Gesamtfreigabe. Separate
Nextgen-/Androidjobs, physische Geräte und gemessene 60-FPS-Leistung sind damit
nicht abgenommen. Kein Rerun, keine Produkt-/Host-/Ref-/Pinänderung und kein
Receipt wurden durch diese Sammlung erzeugt. Frühere 90d-/cce-/4f-Bilder oder
Beobachtungen wurden nicht als aktuelle Nachweise übernommen.
