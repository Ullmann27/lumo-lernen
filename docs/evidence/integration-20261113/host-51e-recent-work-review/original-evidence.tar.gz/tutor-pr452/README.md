# PR452: begrenzter Quellenvergleich gegen Host 51e92fb5

**Ergebnis:** In den genau fünf beauftragten abweichenden Dateien ist kein verlorener Anschluss der alten Tutor-Wiedergabe, Tutor-Nachweise oder des auf Tutorbeobachtungen begrenzten Eltern-Resets erkennbar. Daraus ergibt sich kein konkret wieder einzuspielender PR452-Produktdelta.

Alte Quelle: `98698f4fc2df0e8e081bc8521cf40f6148cc5577`, Tree `4009839b6581813dc795a33b6ad44c003c66276e`.
Aktuelle Quelle: `51e92fb5afab232a29850ffefef5637359af08f7`, Tree `a13ab981d917c7788f35318cf10d962c1bf657f7`; lokaler treegleicher Commit `488ef9b11f6d3c2e3164953ea82f445ef09b72ac`.

## Konkreter Befund

- AppState, ProfileEngine und Repository behalten die Evidence-Queue, Eigentümerbindung und dauerhafte Tutor-Reset-Kette. Zwölf relevante zusammenhängende Quellblöcke sind ohne Normalisierung bytegleich gebunden.
- Wiederholen, phasenweise Sprache sowie deren Profil-/Aufgaben-/Dispose-Schutz bleiben vorhanden. Der 3D-Einstieg ist zusätzlich angeschlossen und kennzeichnet die angeforderte Hilfe vor dem Start.
- Die heutigen Dateien ändern die Bewertung ausdrücklich: Übungszahlen bleiben erhalten; selbstständige Kompetenz, Streaks und Schwächensignale werden von begleiteter Übung getrennt. Das ist eine fachliche Weiterentwicklung und keine Behauptung vollständiger Verhaltensgleichheit.
- Nach leichterer Übung beginnt die sichtbare Tippfolge wieder bei null, während die bereits erfolgte Begleitung für die Evidence erhalten bleibt.
- Die Runtime-Testquelle enthält sämtliche alten Zeilen in ursprünglicher Reihenfolge, zusätzlich 39 neue Zeilen. Kein Test wurde für diesen Vergleich ausgeführt.

## Originale und Nachvollziehbarkeit

`old/` und `current/` enthalten die zehn vollständigen Quelldateien verlustfrei als gzip. `source-binding.json` bindet Länge, SHA-256 und echten Git-Blob jeder unkomprimierten Datei; `diffs/` enthält alle fünf vollständigen Diffs. Die ursprünglichen Commit-API-Antworten liegen ebenfalls als gzip vor. `preserved-blocks.json` enthält exakte Block-Hashes und beide Zeilenpositionen. `review.json` hält die abgegrenzten Befunde und Grenzen fest. `manifest.json` bindet jedes Packobjekt und bei gzip zusätzlich seine Originalbytes.

Die 18 PR-Pfade und 13 bytegleichen weiteren Dateien stammen ausschließlich aus dem benannten vorhandenen Inventar; sie wurden hier nicht zusätzlich funktional untersucht. Keine allgemeine Vollständigkeits-, Geräte-, Test- oder CI-Freigabe. Keine Änderungen am Hostcode, Index, Ref, Pin, Receipt oder an vorhandenen CI-Packs.
