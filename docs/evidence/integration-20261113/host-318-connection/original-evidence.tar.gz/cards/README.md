# Additive Cards lifecycle integration from published 31883868

## Result and ownership

The five explicitly assigned Host files are frozen and ready for Root review. The final focused run passed **32 tests, zero failures, zero errors, zero skips**: 13 published lifecycle/dependency cases, four existing window cases, three existing return-wiring contracts and 12 bounded diagnostic contracts. This is a local source/JVM verification, not a new Android/APK or Binder-process acceptance. Root retains exclusive ownership of commits, index, refs, pins, receipts and the separate API37/workflow integration. Flutter owns the separate scroll-observation contract repair.

The input is published Host `31883868bac56699dbf3b3d60a7cdb7afc496a8b` / tree `5ca2eeee9ea3af3f67acbee83f19934942c1c5d5`. Our original Host is published `38a49f7dda404923da3955592ccb213871f2027d`, locally `44dfd78d8a998cccb09d20bc974fb699dddd925e`, with the same tree `625b7940d9e8a4ddf32203126721efd97b3e8c2e`. The producer source snapshots and published-blob checks are separately retained in `../producer-recheck-20261113-200408/`.

## Actual change

The producer's exact `CardsLifecycleHeartbeat` renews the visible Cards lease on the Android main looper every 500 ms. It stops on pause, stop, destroy, return, lost authority or a closed mailbox. Generation and terminal-close guards reject stale callbacks. `getCardsState()` checks authority and reads state without renewing lifecycle timestamps. The existing 2500-ms Dart lease, explicit resume, Binder authority and saved-child-data contracts were not changed.

Our AndroidX edge-to-edge initialization, command-line flag, window appearance methods, late-engine UI callback and learning-plus-build speech setup remain byte-identical in the relevant complete blocks. `activity-preservation.json` and `activity-vs-producer.diff` show the preserved existing wiring; the latter contains only our existing window/speech additions relative to the published producer Activity.

The probe adds one optional bounded read-only lifecycle observation after an existing state read. Missing diagnostics cannot replace the original state failure or produce a passing readiness result. All 15 original top-level probe functions and the other mailbox methods remain unchanged; see `probe-preservation.json`.

## Red, green and test adaptations

The original current Activity was compiled successfully after adding the test-only boundary stubs for our existing window APIs. Its unchanged producer harness then ran 13 cases: nine real behavioral failures and four passes. `heartbeat-red.log` preserves that complete result; no stub compilation failure was counted as a product counterexample. The production heartbeat patch then passed the same 13 cases.

The original probe did not emit the new observation files. The first diagnostic run also detected an existing difference between the Studio and Nextgen text of exactly one missing-Pause error. The test now asserts both exact existing messages, then compares every other AST field of the four full guard functions. Both original diagnostic logs are retained; the initial fixture mismatch is not represented as a product regression.

The unchanged four-case window suite compiled and had one failure: the delayed-engine fixture expected an inactive pulse without starting or binding the activity. With Root's explicit fifth-path authorization, only that fixture now calls `onStart`, proves no active pulse before its observed service connection, then proves an active lease while the engine is still absent. Its original late-engine, queued UI dispatch and exact window-call assertions remain. The other three cases are byte-identical. See `existing-window-contract.log` and `window-test-preservation.json`.

The final run repeats all 13 lifecycle cases, the four window cases and three existing return-wiring contracts (20 PASS), followed by the 12 diagnostic cases (12 PASS). Commands, full raw logs, start times and source manifests are saved. The 12 explicitly bound source/dependency files were unchanged before and after the final runs; this is not a blanket freeze of concurrently edited Root-owned workflow files.

## Evidence and limits

`handoff.json` lists the exact five final Git blobs and SHA-256 values. `changes.diff` contains only those authorized paths. Full original before/after logs and byte-preservation reports are retained without trimming. The independent read-only review covers the first four files before the later window-fixture adaptation and does not claim extra test execution.

The existing pinned test-only org.json JAR was fetched from the exact URL and verified against its pre-existing SHA-256. `dependencies/json-dependency.json` records the bytes; the JAR itself is only a local test cache and is excluded from the text/source handoff manifest. The manifest includes every other file except itself and `SHA256SUMS`; checksums additionally bind the manifest.

Actual AAR/APK compilation and fresh API35/API37 Android runs belong to the next combined Host validation. No old Android result, native receipt or visual approval is relabeled by this patch.
