# PR473: zusätzliche Android-Eingaben, begrenzter Quellenreview

**Ergebnis:** Die veröffentlichte Quelle `2fdd038d00ed7706971786400e3e1a42f5290c88` (Tree `fce279641787a405e1818dcfb99b34d69835297e`) ergänzt genau17 QA-/Test-/Fixture-/Evidenzpfade über31883868. Kein bestehender Produktpfad wird verändert. Die Originale sind vollständig und gegen die veröffentlichten Git-Blobs geprüft.

Der Workflow prüft ausdrücklich das bereits gebaute Host318-/Native796b-APK. Für unseren unveränderten Host51e-/Native993c-Kandidaten müssen die engen Quellen-, Run-, Artefakt-, APK- und PCK-Identitäten nach dem echten Build neu gebunden werden. Die CLI trennt QA-Quelle, APK-Quelle und Native-Quelle bereits. `integration-plan.json` enthält die konkreten bestehenden Eingaben und den begrenzten Anschlussplan; fehlende Artefaktwerte sind ausdrücklich ausstehend und nicht geschätzt.

## Zwei konkrete QA-Lücken

1. Puzzle startet im echten unveränderten Produkt bei Motiv3. Die Probe nimmt dagegen0 an, tippt einmal auf Bild und verlangt anschließendMotiv1. Tatsächlich ergibt der eine TouchMotiv4. Das muss über echte sichtbare Menüauswahl korrigiert werden; die bestehende strenge Save-/Vierteldrehungsprüfung bleibt.
2. Der Toolbar-Suchloop führt bis zu sieben Wischgesten aus, beobachtet aber den Zustand nach der siebten nicht mehr. Sieben Gesten benötigen acht Beobachtungen. Das ist eine statisch belegte Budgetlücke, kein behaupteter Android-Ausfall.

Der bestehende Creative-Helper und beide Hub-Dateien sind bytegleich. Der vollständige aktuelle APK-Verifier hat einen neuen Hash; seine zentrale Identitätsfunktion ist unverändert. Sieben gelesene Native-Dateien sind bytegleich; die beiden Build-Dateien enthalten unsere größere Bauwelt und angepasste Werkzeugleiste. Kamerarechnung, initialer Sandstein, Saveformat und Zielbelohnung sind erhalten; echte aktuelle Pixel und Saves müssen den Anschluss später bestätigen.

## Grenzen

Original-REST-Metadaten bestätigen den alten318-Kandidaten und seinen erfolgreichen Build. Der alte Gesamtlauf ist FAILURE wegen seiner API35-/API37-Touren. Die neun mitgelieferten lokalen Tests bleiben ausschließlich Producer-Vorbereitungsbelege. Hier wurde kein Test, APK, SDK oder Godot ausgeführt und kein APK heruntergeladen. Kein APK-Neubau, keine Veröffentlichung, kein Produkt-/Ref-/Pin-/Receipt-/CI-Eingriff. Eine spätere technisch erfolgreiche Jump-Aufnahme erfordert weiterhin tatsächliche menschliche Bild-/Videosichtung.
