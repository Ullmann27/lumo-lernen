# Drei begrenzte Host-Anschlusskorrekturen für 2019

## Quellen und unveränderte Grenzen

Arbeitskopie: `/workspace/scratch/b3485b7bb989/lumo-host-published-followups`.
Basis: `851554036f1e78ca5123fcede92bab88ab9458fc`, Tree
`99f25c730a9a062d9529fea1979f3196e5831692`.

Der geprüfte veröffentlichte Producer-Nachtrag ist
`3022777fba84618a1915f98fdcf6a6ccda9f4db1`, Tree
`b5d940b7794ad16cac33e3eb88c3c2f04f72a2ad`, Parent
`e3d161cb2f79b732ac2dbafc2764b151247f018b`. Dessen vollständiger
Root-Tree-Vergleich ändert ausschließlich `docs/`. Der dort veröffentlichte
`android35/scroll-followup/candidate.patch` wurde als ausdrücklich beauftragte
Quellkorrektur übernommen; der gesamte Producer-Branch wurde nicht gemergt.

Version, alle drei Native-Identitäten, vorhandene Receipts, Laufidentitäten,
Branch-/Forkbedingungen und Publishergrenzen wurden nicht geändert. Die
2019-Integration bleibt auf `integration/lumo-connections-20261113` zur Prüfung
zugelassen; der Publisher bleibt dem ursprünglichen Grafikproducer vorbehalten.
Die fremde 2020-Releasepipeline wurde nicht übernommen. Es gab keinen Commit,
Ref-Move, Workflow-Rerun oder Android-/SDK-Installationsversuch durch diesen Agenten.

## Exakte Änderungen

1. `.github/probes/creative_android_probe.py`: der unveränderte veröffentlichte
   Patch ergänzt eine letzte Live-Beobachtung nach höchstens N Scrollgesten pro
   Richtung. Der letzte Beobachtungsdurchlauf erzeugt keine zusätzliche Geste.
   Alle vorhandenen Ziel-, Sichtbarkeits-, Touch- und Zustimmungsprüfungen bleiben.
   Enddatei SHA256 `2b4da491c7a348e85d0ace0d6ab96154be059692310a263b8f3998fe8ebc9c4e`.
2. `tools/android_qa/tests/test_flutter_tap_scroll_budget.py`: alle sechs
   veröffentlichten Gegenfälle bytegleich übernommen, SHA256
   `886247df7bcf68e811b401db6f804b502d4e8e9b06aabba072606b1035600781`.
3. `.github/workflows/lumo-kart-graphics-2019.yml` und
   `.github/workflows/lumo-studio-2019.yml`: im Native-Validierungsschritt wird der
   bereits installierte `.ci-python`-Venv über seinen absoluten Workspace-Pfad
   exportiert. Der nach dem Wechsel in den Native-Checkout ausgeführte
   Pillow-Import prüft die tatsächlich verwendete Python-Umgebung. Beide
   Android-Matrizen verwenden für API37 den SDK-Paketselektor `37.0`; Matrixwert,
   `--expected-api`, die unabhängigen Plattformbelege und API35 bleiben erhalten.
4. `scripts/tests/test_kart_graphics_delivery.py`: der vorhandene Workflowvertrag
   folgt dem korrigierten Paketselektor. Zwei neue Methoden prüfen beide echten
   Workflow-Ausdrücke und führen ihre tatsächlichen PATH-/Verzeichniswechsel in
   einem realen isolierten Venv aus. Dies ist kein simulierter Emulatorlauf.

## Originale Producer-Befunde, getrennt von lokalen Gegenprüfungen

`producer-originals/` enthält unveränderte veröffentlichte Bytes. Die acht
größeren Originale wurden zusätzlich gegen ihre ursprünglichen Git-Blob-IDs
geprüft; `original-blob-verification.json` enthält Bytes, SHA256 und Git-Blob.

- Hostrun `43461547945` auf e3d: API35-Job `132049288587` scheiterte nach
  erfolgreicher normaler Tour im Studio-Sprachfreigabepfad. Der ursprüngliche
  Helper und die Studio-Probe sind bytegleich zu den lokalen Ausgangsquellen.
  Vollständiges Originaljoblog SHA256
  `95a08f5fa569c90488f47d4b4036baf5d26c6ead5eb261d806204e424cfff6ed`.
- API37-Job `132049288677` scheiterte vor Emulatorstart am nicht gefundenen
  `platforms;android-37`. Vollständiges Originaljoblog SHA256
  `2af4af8d849ae0404a88598f7c64c91797369169e02071fa71a606381f217258`.
- Producer-SDK-Inventar: Run `43476259207`, Job `132060744959`, Originalartefakt
  `14064150357`, SHA256
  `318e0ea8e3e72e9be7961943d5cdbfe4b9f4019855f2b82a180342b1875aa216`.
  Beide zusätzlich unabhängig gelesenen vollständigen Stable-Kataloge enthalten
  `platforms;android-37.0` und
  `system-images;android-37.0;google_apis;x86_64`; die entsprechenden Namen ohne
  `.0` fehlen. Die Katalogprüfung hat keine App gestartet.
- `scroll-producer-before.log` und `scroll-producer-after.log` sind die früheren
  Producer-Läufe. Sie werden nicht als eigene neue Läufe ausgegeben.

Die frische Tagauflösung unter `action-source/` bindet `@v2` über den annotierten
Tag `4c44018e59b437e86cdfc41da381398f93ed8808` an
`a421e43855164a8197daf9d8d40fe71c6996bb0d`. `action.yml`, `main.ts`,
`input-validator.ts`, `sdk-installer.ts` und `emulator-manager.ts` wurden am
exakten SHA gelesen. Der Eingabewert bleibt ein String und wird tatsächlich in
Plattform-, Systemimage- und AVD-Paketnamen eingesetzt. Der beobachtete
Laufzeitwert SDK37/Release17 bleibt eine eigenständige Pflicht des realen Gates.

## Tatsächliche lokale Red-/Green-Prüfungen

Alle folgenden unveränderten Rohlogs und Befehle stehen unter `local-tests/`.

| Aufruf | Tatsächliches Ergebnis |
| --- | --- |
| Veröffentlichte sechs Scrollmethoden vor dem Helperpatch | 6 Methoden, 7 Assertionsfehler einschließlich Unterfällen; Exit1 |
| Neue Workflowverträge gegen beide ursprünglichen Workflows | 2 Methoden, 4 Unterfallfehler; Exit1 |
| Dieselben sechs Scrollmethoden nach dem Helperpatch | 6 PASS, 0 Fehler/Skips; 0,103 s |
| Gesamtes betroffenes Grafik-Delivery-Testmodul plus sechs bestehende strikte Plattformmethoden | 25 PASS, 0 Fehler/Skips; 17,747 s |
| Bestehende Android-Nachbarverträge; die bereits geprüften sechs neuen Methoden ausdrücklich ausgeschlossen | 126 PASS, 0 Fehler/Skips; 19,480 s |
| actionlint für beide geänderten 2019-Workflows | Exit0, leeres unverändertes Log |
| git diff --check | Exit0, leeres unverändertes Log |

Die Green-Logs enthalten keine ResourceWarning-, DeprecationWarning-,
RuntimeWarning- oder UserWarning-Zeile. Die Testdateien waren zwischen ihren
jeweiligen Red- und Green-Aufrufen unverändert. Die tatsächlichen Erfolge der
beiden neuen Workflowmethoden stehen im vollständigen 25er-Green-Log.

Die übergeordnete Root-Abnahme mit 434 Script- und 794 Android-QA-Verträgen
gehört zum vorherigen Quellcheckpoint. Sie wurde hier nicht wiederholt und ist
kein Ergebnis dieses neuen Fünf-Dateien-Patches.

## Hashbindung und Übergabe

`before-manifest.json` bindet 1.852 bestehende Quell-, Asset- und Konfigpfade.
`test-sources-before.json` und `after-manifest.json` binden nach dem Patch
1.853 Pfade einschließlich des neuen Tests. Alle 1.853 blieben während der
fokussierten Prüfungen unverändert. Gegen die Basis sind exakt vier bestehende
Dateien geändert und genau eine neue Testdatei hinzugefügt. Alle übrigen
gebundenen Pfade bleiben bytegleich. Die vollständigen Vorher-/Nachher-Dateien
und der vollständige Patch sind erhalten.

Die fünf genannten Quelldateien sind eingefroren. Root besitzt Index, Commit,
veröffentlichten Checkpoint und endgültige Übernahme. Diese Belege erzeugen
keine neue Bildfreigabe, keinen APK-Receipt und keinen bestandenen API37-Boot.
