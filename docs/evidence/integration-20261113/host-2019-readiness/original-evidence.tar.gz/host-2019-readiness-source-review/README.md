# Quellenreview der drei Host-Anschlüsse

**Ergebnis: kein konkreter Integrationsblocker im geprüften Delta.** Der Review
bindet die fünf von Flutter nach seinen Tests eingefrorenen Dateien im eigenen
Host-Followup-Baum an die Basis `851554036f1e78ca5123fcede92bab88ab9458fc`
(Tree `99f25c730a9a062d9529fea1979f3196e5831692`). Der endgültige Hashsatz
wurde erst nach Flutters ausdrücklicher Fertig- und Freeze-Meldung erfasst.
Die Dateien sind zu diesem Zeitpunkt noch nicht als neuer Host-Commit bewertet.

## 1. Letzte erlaubte Scrollgeste

`creative_android_probe.py:flutter_tap` liest jetzt pro Richtung höchstens
`N+1` aktuelle Accessibility-Beobachtungen. Vor der möglichen nächsten
Scrollgeste beendet `attempt == scroll_attempts` den Durchlauf. Damit bleibt
die Obergrenze bei `N` Scrollgesten pro Richtung; der vorhandene Aufrufer in
`lumo_studio_surfaces_android_probe.py:tap_flutter` verwendet unverändert
`N=16`, beide Richtungen und mindestens 48 sichtbare Pixel Höhe.

Der zusätzliche Durchlauf verwendet dieselbe echte `live.live_nodes`-Abfrage
und dieselben beobachteten Zielrechtecke. Er fügt keinen festen Klickpunkt,
keinen zusätzlichen Scroll und keine Änderung an Richtung, Budgetgrenzen,
Wartezählern oder Recovery-Grenzen ein. Die vorhandene kurze Fingerberührung
mit `swipe` und 120 ms erfolgt weiterhin aus den gelesenen Zielkoordinaten.
Die ebenfalls vorhandene Systemdialog-Recovery bleibt an den beobachteten
Android-Dialog und genau einen aktivierten, klickbaren Aktionsknopf gebunden.

Der neue Test lädt die tatsächliche Funktion per AST. Seine sechs Fälle
decken das Ziel nach der letzten Geste, ein fehlendes Ziel, ein deaktiviertes
Ziel, einen abgeschnittenen Zielstreifen, ein noch gleitendes Ziel am letzten
Beobachtungspunkt und ein bereits sichtbares Ziel ab. Die Erfolgsvariante
prüft Budgets 1, 2 und 16. Die Transportdaten sind synthetisch; sie sind kein
Emulatornachweis. Das Review behauptet keine neue globale Absicherung des
unveränderten älteren Settle-Verhaltens außerhalb dieser Fälle.

## 2. API-37-Paketwahl

Beide 2019-Workflows behalten die numerische Matrix `[35, 37]`. Nur das
Paketargument der Emulator-Action lautet für Matrixwert 37 jetzt `'37.0'`;
für 35 bleibt es 35. `--expected-api ${{ matrix.api }}`, `google_apis`,
`x86_64`, Geräteprofil, API35-Emulatorbuild, RAM-Vorgaben und Artefaktnamen
bleiben unverändert. APK-, Provenienz-, Prüfsummen- und vorherige Tourdateien
werden in denselben Pfaden an die unveränderten Prüfprogramme übergeben.

Die gelesene aktuelle Action-Bindung ist `@v2` → annotierter Tag
`4c44018e59b437e86cdfc41da381398f93ed8808` → Commit
`a421e43855164a8197daf9d8d40fe71c6996bb0d`. In den eingefrorenen
Implementierungsquellen bleibt `api-level` ein String. `main.ts` übernimmt
ihn bei fehlendem separatem Systemimage-Eingang auch für das Systemimage;
`sdk-installer.ts` und `emulator-manager.ts` setzen diesen Wert unverändert
in die Plattform-, Systemimage- und AVD-Paketnamen ein. Für das API-Argument
wird dort keine Ganzzahl-Konvertierung durchgeführt.

Der bereitgestellte veröffentlichte SDK-Diagnosebericht bezeichnet
`platforms;android-37.0` und
`system-images;android-37.0;google_apis;x86_64` als in den vollständigen
Katalogen vorhanden. Zusätzlich wurden die beiden erhaltenen stabilen
Originalkataloge unmittelbar gelesen und nach verlustfreier Dekompression
an ihre veröffentlichten `3022777f`-Git-Blobs gebunden: Beide enthalten genau
diese Paketbezeichner; die beiden entsprechenden Bezeichner ohne `.0`
fehlen. Die originalen Fundstellen und Hashes stehen im Review-JSON.
Der Diagnosebericht trennt ausdrücklich Katalogprüfung von Installation
und Boot. Diese Grenze bleibt erhalten: Die unveränderte Surface-Probe liest
weiter `ro.build.version.sdk`, Release und Fingerprint vom laufenden Gerät,
verlangt ganzzahlig API 37 und für diesen Fall tatsächlich Android 17.
Die Paketnamenkorrektur erklärt keinen späteren Emulatorlauf vorab für grün.

## 3. Venv und Pillow nach dem Repository-Wechsel

Beide Workflows erstellen zuvor im Host-Arbeitsverzeichnis `.ci-python` und
installieren dort `Pillow==12.3.0`. Der Native-Schritt setzt jetzt ausdrücklich
`PATH="$GITHUB_WORKSPACE/.ci-python/bin:$PATH"`. Das ist ein absoluter
Verzeichnispfad und bleibt nach `cd "$native_source"` gültig. Die gestarteten
Bash-Runner und ihre `python3`-Unterprozesse erben diesen exportierten Pfad.

Unmittelbar nach dem Verzeichniswechsel importiert der Schritt Pillow mit
dem tatsächlich ausgewählten Python. Ein fehlendes oder falsch aufgelöstes
Pillow beendet wegen `set -euo pipefail` den Schritt vor den Native-Gates.
Es gibt keine Änderung an den Native-Revisionen, deren Checkout-Vergleich,
den Gate-Kommandos oder deren Fehlerpolitik.

Der neue Workflow-Vertrag führt die tatsächlichen PATH-/cd-Zeilen mit einer
echten temporären Venv und Verzeichnisnamen mit Leerzeichen aus und prüft
`sys.prefix`. Er prüft die Interpreterauswahl; die Installation und der
Pillow-Import in GitHub Actions bleiben eigenständige reale Laufbedingungen.

## Gelesene vorhandene Testergebnisse

Die folgenden Tests führte Flutter aus. Dieser Reviewer hat sie nicht erneut
gestartet und keine Produkt-, Probe-, Test-, Workflow-, Index- oder Ref-Datei
verändert:

| Nachweis | Gelesenes Ergebnis |
| --- | --- |
| Ursprünglicher Scrollhelper mit derselben neuen Fixture | Sechs Methoden ausgeführt, sieben fehlgeschlagene Assertions/Subtests |
| Ursprüngliche Workflow-Verträge | Zwei Methoden, vier fehlgeschlagene Subtests |
| Eingefrorener Scrollhelper | Sechs Tests bestanden |
| Workflow- und strikte Plattformverträge | 25 Tests bestanden |
| Bestehende Android-Nachbarverträge | 126 Tests bestanden |
| actionlint, beide 2019-Workflows | Exit 0 |

Die abschließenden Logs melden keine Fehler oder Skips. Die Originaldatei-
und Loghashes stehen in `review.json`. Die dort referenzierte vollständige
1.853-Dateien-Bindung stammt von Flutter; der unabhängige Quellenvergleich
dieses Reviews umfasst die fünf Änderungen und die ausdrücklich aufgelisteten
unveränderten Identitäts-/Aufrufdateien.

**Freigabeumfang:** Quellenintegration dieser konkreten Anschlüsse. Kein
neuer APK-, Android-17-Boot-, Geräte-FPS-, visueller oder Native-Receipt wird
hier erzeugt. Der nächste reale CI-/Emulatorlauf muss die vorhandenen strengen
Identitäts- und Verhaltensgates weiter vollständig bestehen.
