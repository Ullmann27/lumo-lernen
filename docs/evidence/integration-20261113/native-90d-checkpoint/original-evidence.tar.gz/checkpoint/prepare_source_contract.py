"""Freeze the actual 90d source contract without running production probes."""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
REPO = BASE / "lumo-native-puzzle-followups"
LOCAL = "64202e88e979b110cc3fdca511d4644be7f12ea7"
HEAD = "90d34181409c15d1b1ad3a6a9643539453155c1d"
TREE = "9b407d61633a6421dc47b6858e6a6fb3fa60bea5"
HOST = "2fa3b3d346c9d53930782bf6b9f0ad035ada7ac0"
HOST_TREE = "99f25c730a9a062d9529fea1979f3196e5831692"
HOST_MANIFEST = "c7c6641fa3737aa6aedf2296faac401f4d08188ffa118d6f4c02bf9658b67723"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git_blob(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def original(path: str) -> bytes:
    return subprocess.check_output(["git", "show", LOCAL + ":" + path], cwd=REPO)


def main() -> None:
    source_commit = json.loads((ROOT / "source-commit.json").read_bytes())
    host_commit = json.loads((ROOT / "host-reference-commit.json").read_bytes())
    assert source_commit["sha"] == HEAD and source_commit["tree"]["sha"] == TREE
    assert host_commit["sha"] == HOST and host_commit["tree"]["sha"] == HOST_TREE
    assert subprocess.check_output(["git", "rev-parse", LOCAL + "^{tree}"], cwd=REPO).decode().strip() == TREE

    frozen = BASE / "godot-nextgen-host-2fa3b3d3"
    raw_manifest = (frozen / "manifest.json").read_bytes()
    assert sha(raw_manifest) == HOST_MANIFEST
    manifest = json.loads(raw_manifest)
    assert manifest["host_review_commit"] == HOST and manifest["host_tree"] == HOST_TREE
    assert len(manifest["objects"]) == 4
    snapshot = ROOT / "validator-2fa3b3d3"
    snapshot.mkdir(exist_ok=True)
    for item in manifest["objects"]:
        data = (frozen / item["path"]).read_bytes()
        assert len(data) == item["bytes"] and sha(data) == item["sha256"]
        assert git_blob(data) == item["git_blob"]
        (snapshot / item["path"]).write_bytes(data)
    (ROOT / "validator-2fa3b3d3-source-manifest.json").write_bytes(raw_manifest)

    sys.dont_write_bytecode = True
    sys.path.insert(0, str(snapshot))
    import verify_studio_delivery as verifier
    runner = original("tools/validate_nextgen.sh").decode()
    probes = []
    for line in runner.splitlines():
        if line.startswith("check_probe "):
            fields = shlex.split(line)
            probes.append({"probe": fields[1], "marker": fields[2], "mode": fields[3], "arguments": fields[4:]})
    assert len(probes) == 43
    assert {(item["probe"], item["mode"]) for item in probes} == verifier.NEXTGEN_REQUIRED_PROBES
    assert len(verifier.NEXTGEN_STUDIO_PNGS) == 24
    assert len(verifier.NEXTGEN_VILLAGE_PNGS) == 4
    assert len(verifier.NEXTGEN_PUZZLE_MENU_PNGS) == 6
    assert sum(len(value) for value in verifier.NEXTGEN_TOUCH_PNGS.values()) == 32

    # Only the explicit path list is reused as an inventory. Every byte and hash
    # below comes from the new immutable local source object, never old evidence.
    prior_inventory = json.loads((BASE / "godot-pr160-ccebbe24-nextgen-evidence/expected-contract.json").read_bytes())
    source_paths = set(prior_inventory["source_blobs"])
    source_paths.update("scripts/tests/" + item["probe"] + ".gd" for item in probes)
    source_paths.update({"scenes/creative/puzzle_world.tscn", "tools/verify_puzzle_menu_rasters.py", "tools/validate_studio.sh"})
    scene = original("scenes/creative/puzzle_world.tscn").decode()
    source_paths.update(re.findall(r'\[ext_resource type="Script" path="res://([^"\n]+)"', scene))
    blobs, hashes = {}, {}
    for path in sorted(source_paths):
        data = original(path)
        blobs[path] = git_blob(data)
        hashes[path] = sha(data)
        if path.startswith("tools/") or path == ".github/workflows/lumo-nextgen-2018.yml":
            output = ROOT / "native-contract" / path
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_bytes(data)

    helpers = ROOT / "native-contract/tools"
    sys.path.insert(0, str(helpers))
    import verify_village_rasters
    import verify_puzzle_menu_rasters
    assert verify_village_rasters.EXPECTED_PNGS == dict(verifier.NEXTGEN_VILLAGE_PNGS)
    assert verify_puzzle_menu_rasters.EXPECTED_PNGS == dict(verifier.NEXTGEN_PUZZLE_MENU_PNGS)
    workflow = original(".github/workflows/lumo-nextgen-2018.yml").decode()
    baseline = re.search(r'fetch --depth 1 origin ([0-9a-f]{40})', workflow).group(1)
    assert baseline == "1d5c5cb45a323228f627ec529e6ff1ddd86f1c57"
    profile = verifier.native_review_profile("nextgen-2019")
    report = {
        "schema": 1, "status": "EXPECTED_CONTRACT_ONLY_NOT_CI_EVIDENCE",
        "head": HEAD, "tree": TREE, "local_equal_tree_commit": LOCAL,
        "run_id": 43483977169, "run_attempt": 1,
        "required_jobs": sorted(profile.jobs), "archive_job": "archive-evidence",
        "core_probe_modes_and_markers": probes, "core_probe_count": len(probes),
        "studio_pngs": sorted(verifier.NEXTGEN_STUDIO_PNGS), "studio_png_count": 24,
        "village_pngs": dict(verifier.NEXTGEN_VILLAGE_PNGS), "village_roster": "village-images.json",
        "puzzle_menu_pngs": dict(verifier.NEXTGEN_PUZZLE_MENU_PNGS), "puzzle_menu_roster": "puzzle-menu-images.json",
        "touch_probe_mode_count": 6,
        "touch_png_counts": {prefix: len(images) for prefix, images in verifier.NEXTGEN_TOUCH_PNGS.items()},
        "touch_pngs": {prefix: dict(images) for prefix, images in verifier.NEXTGEN_TOUCH_PNGS.items()},
        "source_prefixes": list(profile.sources), "native_artifact_name": profile.artifact,
        "host_validator_revision": HOST, "host_validator_tree": HOST_TREE,
        "host_validator_manifest_sha256": HOST_MANIFEST,
        "host_commit_original_sha256": sha((ROOT / "host-reference-commit.json").read_bytes()),
        "original_comparison_baseline": baseline,
        "source_blobs": blobs, "source_sha256": hashes,
        "source_hash_coverage": "Only these explicitly listed immutable current-source files; no blanket repository review claim.",
        "explicit_village_and_puzzle_menu_visual_review_required": True,
        "scope": ["No production test, renderer, CI retry, source/ref/index/pin or receipt action.",
                  "This freezes the expected new43 contract; no older result or PNG has been copied as evidence."],
    }
    output = ROOT / "expected-contract.json"
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "source": HEAD, "tree": TREE,
                      "host": HOST, "core": 43, "studio": 24, "village": 4,
                      "puzzle_menu": 6, "touch_modes": 6, "touch_pngs": 32,
                      "source_files": len(source_paths), "expected_contract_sha256": sha(output.read_bytes())}, indent=2))


if __name__ == "__main__":
    main()
