"""Inspect one original 90d Touch ZIP without claiming complete Native acceptance."""
from __future__ import annotations

import argparse
import hashlib
from io import BytesIO
import json
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import zipfile

from PIL import Image

ROOT = Path(__file__).resolve().parent
HEAD = "90d34181409c15d1b1ad3a6a9643539453155c1d"
TREE = "9b407d61633a6421dc47b6858e6a6fb3fa60bea5"
RUN = 43483977169


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def require(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("scope", choices=("workshop", "treasure", "build"))
    parser.add_argument("artifact_id", type=int)
    args = parser.parse_args()
    kind = "touch-" + args.scope
    run = json.loads((ROOT / "workflow-run.json").read_bytes())
    jobs = json.loads((ROOT / "workflow-jobs.json").read_bytes())["jobs"]
    artifacts = json.loads((ROOT / "workflow-artifacts.json").read_bytes())["artifacts"]
    require(run["id"] == RUN and run["head_sha"] == HEAD and run["head_commit"]["tree_id"] == TREE,
            "Wrong original source/run/tree")
    require(run["event"] == "pull_request" and run["run_attempt"] == 1, "Wrong original event/attempt")
    found = [item for item in artifacts if item["id"] == args.artifact_id]
    require(len(found) == 1, "Missing or duplicate artifact")
    artifact = found[0]
    require(artifact["name"] == "lumo-nextgen-2019-" + kind and not artifact["expired"], "Wrong component artifact")
    require(artifact["workflow_run"]["id"] == RUN and artifact["workflow_run"]["head_sha"] == HEAD,
            "Wrong component source/run")
    matches = [item for item in jobs if item["name"] == kind]
    require(len(matches) == 1 and matches[0]["status"] == "completed" and matches[0]["conclusion"] == "success",
            "Component producer job did not complete successfully")

    manifest_bytes = (ROOT / "validator-2fa3b3d3-source-manifest.json").read_bytes()
    require(sha(manifest_bytes) == "c7c6641fa3737aa6aedf2296faac401f4d08188ffa118d6f4c02bf9658b67723",
            "Frozen Host manifest changed")
    manifest = json.loads(manifest_bytes)
    scripts = ROOT / "validator-2fa3b3d3"
    for item in manifest["objects"]:
        require(sha((scripts / item["path"]).read_bytes()) == item["sha256"], "Frozen Host source changed")
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(scripts))
    import verify_studio_delivery as verifier
    expected = dict(verifier.NEXTGEN_TOUCH_PNGS["touch-evidence/" + args.scope])
    probe = verifier.NEXTGEN_TOUCH_PROBES["touch-evidence/" + args.scope]

    path = ROOT / f"{kind}-{args.artifact_id}.zip"
    data = path.read_bytes()
    require(len(data) == artifact["size_in_bytes"] and "sha256:" + sha(data) == artifact["digest"],
            "Original ZIP bytes/digest mismatch")
    unpacked = path.with_suffix("")
    images, logs, sources, trees, dirty = [], {}, {}, {}, {}
    with zipfile.ZipFile(BytesIO(data)) as zipped:
        names = set()
        for info in zipped.infolist():
            name = PurePosixPath(info.filename)
            require(info.filename not in names and not name.is_absolute() and ".." not in name.parts and
                    "\\" not in info.filename and not stat.S_ISLNK(info.external_attr >> 16),
                    "Unsafe or duplicate ZIP member")
            names.add(info.filename)
        require(zipped.testzip() is None, "Original ZIP CRC failure")
        zipped.extractall(unpacked)
        for info in zipped.infolist():
            if info.is_dir():
                continue
            raw = zipped.read(info)
            require((unpacked / info.filename).read_bytes() == raw, "Extracted bytes changed")
            if info.filename.endswith("source-sha.txt"):
                sources[info.filename] = raw.decode().strip()
                require(sources[info.filename] == HEAD, "Wrong component source stamp")
            if info.filename.endswith("source-tree.txt"):
                trees[info.filename] = raw.decode().strip()
                require(trees[info.filename] == TREE, "Wrong component tree stamp")
            if info.filename.endswith(("source-dirty.txt", "source-dirty-after.txt")):
                dirty[info.filename] = raw.decode().strip()
                require(not dirty[info.filename], "Source changed during component run")
            if info.filename.endswith(".log"):
                errors = [line for line in raw.decode(errors="replace").splitlines()
                          if re.search(r"SCRIPT ERROR|Parse Error|ERROR:|Leaked instance|ObjectDB instances leaked", line)]
                logs[info.filename] = {"sha256": sha(raw), "error_lines": errors}
                require(not errors, "Actual component log contains an engine/script/resource error: " + info.filename)
            if info.filename.endswith(".png"):
                with Image.open(BytesIO(raw)) as image:
                    require(image.format == "PNG", "Invalid raster format")
                    size = list(image.size)
                    image.verify()
                with Image.open(BytesIO(raw)) as image:
                    image.load()
                images.append({"path": info.filename, "dimensions": size, "bytes": len(raw), "sha256": sha(raw), "baseline": False})
        prefix = args.scope + "/"
        require(sources.get(prefix + "source-sha.txt") == HEAD and trees.get(prefix + "source-tree.txt") == TREE,
                "Missing mandatory component stamps")
        require(all(prefix + name in dirty for name in ("source-dirty.txt", "source-dirty-after.txt")),
                "Missing component before/after dirty stamp")
        require(zipped.read(prefix + "engine.txt").decode().startswith("4.6.3.stable."), "Wrong component engine")
        rows = [line.split("\t") for line in zipped.read(prefix + "results.tsv").decode().splitlines()]
        require(rows[0] == ["probe", "mode", "result"] and len(rows) == 3 and
                set(tuple(row) for row in rows[1:]) == {(probe, "headless", "PASS"), (probe, "rendered", "PASS")},
                "Both exact component modes must pass once")
        roster = json.loads(zipped.read(prefix + "renderer-images.json"))
        seen = set()
        require(isinstance(roster.get("images"), list) and len(roster["images"]) == len(expected), "Incomplete component roster")
        for item in roster["images"]:
            relative = item.get("path")
            require(relative in expected and relative not in seen, "Unexpected/duplicate component raster")
            seen.add(relative)
            raw = zipped.read(prefix + relative)
            require(type(item.get("bytes")) is int and len(raw) == item["bytes"] and sha(raw) == item.get("sha256"),
                    "Component raster bytes/digest mismatch")
            size = verifier.png_dimensions(raw)
            require(all(type(item.get(key)) is int for key in ("width", "height")) and
                    size == [item["width"], item["height"]] == list(expected[relative]), "Component raster size mismatch")
        require(seen == set(expected), "Missing required component PNG")
    report = {
        "status": "ORIGINAL_TOUCH_COMPONENT_VERIFIED_NOT_FULL_NATIVE_ACCEPTANCE",
        "head_sha": HEAD, "tree": TREE, "run_id": RUN, "scope": kind,
        "artifact_id": args.artifact_id, "artifact_name": artifact["name"],
        "zip_sha256": sha(data), "zip_bytes": len(data), "job_id": matches[0]["id"],
        "sources": sources, "trees": trees, "tracked_dirty": dirty, "images": images, "logs": logs,
        "verified_probe_mode_count": 2, "verified_required_png_count": len(expected),
        "validator_revision": manifest["host_review_commit"],
        "validator_sha256": sha((scripts / "verify_studio_delivery.py").read_bytes()),
        "full_native_acceptance_claim": False, "root_visual_review_claim": False,
        "scope_limits": ["One successful original Touch component only.",
                         "The complete43-Core contract and separate auxiliary geometry blocker remain separate."]}
    output = ROOT / f"{kind}-artifact-verification.json"
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "report": output.name, "images": len(images), "logs": len(logs),
                      "probe_modes": 2, "required_pngs": len(expected), "zip_sha256": sha(data)}, indent=2))


if __name__ == "__main__":
    main()
