# Native PR160 — 90d Nextgen checkpoint

This checkpoint records only `90d34181409c15d1b1ad3a6a9643539453155c1d`, tree `9b407d61633a6421dc47b6858e6a6fb3fa60bea5`, original pull-request run `43483977169`, attempt 1. All eight Nextgen jobs finished successfully. Overall Native acceptance is withheld because the separate Kart geometry auxiliary workflow on the same source reports success despite real missing-preload and compile errors. The original error log and source-pack manifest are preserved separately; the later geometry repair is not attributed to 90d.

## Verified original contract

The unchanged four-file Host parser from `2fa3b3d346c9d53930782bf6b9f0ad035ada7ac0` verifies the downloaded original bundle: 43 Core probe/mode pairs, the exact 24 Studio PNG roster, four Village PNGs, six new Puzzle menu PNGs, and six Touch pairs with 32 Touch PNGs. The Core and three Touch source-tree stamps equal the exact workflow tree. Both before/after Touch source-dirty stamps are present and empty. The ten comparison PNGs retain their explicitly separate historical baseline identity.

The bundle contains 146 fully decoded PNG files (136 current and 10 baseline) and 108 strictly clean artifact logs. All eight complete original job logs and all seven original artifact ZIPs are preserved. The member index records every ZIP member hash; bundled component copies must not be counted as additional unique images. The raw Gameplay log contains the actual KartTests release-before-resume/final-release markers and PASS 8000; raw engine output from the eight jobs has no engine-error line. The successful original Worlds run records Puzzle menu checks 720 headless and 732 rendered, and BuildNextgen checks 71 headless and 79 rendered.

## Actual visual observations

Root directly opened exactly the six new Puzzle-menu/play PNGs recorded byte-for-byte in `root-puzzle-menu-six-viewed.json`. Each hash matches both the original Worlds artifact and the final original bundle. At 640x360 the final menu item is partly below the vertical scroll viewport and the toolbar scrolls horizontally. Neither a natural scroll gesture nor simultaneous visibility of every control is claimed. Other module families have complete raster identities but no complete current Root visual approval is claimed here. The agent's separate two-frame Puzzle and one-frame preview observations are explicitly scoped.

## Published evidence archive

The release metadata, tag reference, original archive-job log and verification are preserved. Release 444628239 / ZIP asset 744828465 declares the same 176,564,239 bytes and SHA-256 `744949fb597d7a7f9442db0cee16740f241adcee3c515f6fd4154ebd2dec6800` as the locally verified original Actions bundle. The successful archive job downloaded the public ZIP and compared it with `cmp`. No second independent local public-release download is claimed. The API's `immutable` flag is false; the captured digest binds the observed bytes. This archive contains evidence, not an APK.

## Provenance and limits

Raw API JSON and complete job logs are unchanged. Individual artifact metadata files are exact byte slices of the original complete API response, with byte offsets and source hash recorded. The four frozen parser files remain byte-identical. A locally attempted preview collection before its download finished is retained as a collection-order event, separately from actual CI results; it was resolved after the original bytes arrived without retrying CI.

`manifest.json` and `SHA256SUMS` cover saved metadata, source snapshots, collectors, all original ZIPs and the full member-hash index. Reproducible extracted ZIP directories are excluded from this outer manifest; their exact bytes were checked against the ZIPs during extraction and their member identities remain in the index. No source, Git reference, index, commit, receipt or pin was changed. The later 993c source requires its own original CI and visual observations.
