from pathlib import Path
import datetime,hashlib,json,sys
base=Path('/workspace/scratch/b3485b7bb989/host-pr465-51e92fb5-android-evidence')
now=datetime.datetime.now(datetime.timezone.utc)
folder=base/'snapshots'/now.strftime('%Y%m%dT%H%M%SZ')
folder.mkdir(parents=True,exist_ok=False)
entries=[];summary={}
for item in json.loads(sys.argv[1]):
 data=item['raw'].encode('utf-8');obj=json.loads(item['raw']);p=folder/(item['kind']+'.json');p.write_bytes(data)
 entries.append({'file':str(p.relative_to(base)),'url':item['url'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 if item['kind']=='run':
  assert obj['head_sha']=='51e92fb5afab232a29850ffefef5637359af08f7' and obj['head_commit']['tree_id']=='a13ab981d917c7788f35318cf10d962c1bf657f7' and obj['event']=='pull_request' and obj['run_attempt']==1
  summary['run']={k:obj[k] for k in ('id','status','conclusion','head_sha','run_attempt')}
 if item['kind']=='jobs':
  assert all(j['head_sha']=='51e92fb5afab232a29850ffefef5637359af08f7' and j['run_attempt']==1 for j in obj['jobs'])
  summary['jobs']=[{'id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],'current':[s['name'] for s in j['steps'] if s['status']=='in_progress' or s['conclusion']=='failure']} for j in obj['jobs']]
 if item['kind']=='artifacts':
  summary['artifact_count']=obj['total_count']
  summary['uncollected_artifacts']=[{k:a[k] for k in ('id','name','size_in_bytes','digest')} for a in obj['artifacts'] if not (base/'artifacts'/str(a['id'])/'verification.json').exists()]
(folder/'provenance.json').write_text(json.dumps({'retrieved_at_utc':now.isoformat(),'method':'Unmodified github_fetch structuredContent.content UTF-8 bytes','entries':entries},indent=2)+'\n')
print(json.dumps({'snapshot':str(folder),'utc':now.isoformat(),**summary},indent=2))
