# Host 51e: API37-Lauf mit gescheiterter Cup-Auswahl

Der originale Job **132181019099** im Hauptlauf **43502594333**, Versuch 1, ist **FAILURE**. Host `51e92fb5` / Tree `a13ab981` und der eingebettete Native `993c` sind exakt gebunden. CLI22 und der Frameworkstart sind erfolgreiche Teilnachweise. Eine gesamte Android- oder Hostfreigabe liegt nicht vor.

## Tatsächlicher Erstfehler

Am 13. November 2026 um 21:36:15 UTC scheitert `start-kart-race` mit `RuntimeError: Ambiguous cup-caption regions on the current landing`. Das aktuelle Originalbild wurde von `/root/godot_integration` geöffnet: Es enthält genau einen sichtbaren Grand-Prix-Titel. Die contrast-OCR liefert zusätzlich `= Grand Prix` mit einer großen gemischten Region; die zwei sauberen Titelvarianten liegen auf demselben Text. Die alte allgemeine Symbolentfernung behandelt auch diesen Verbund als Cup-Alias. Der genaue Bildhash, alle drei Originalbounds, beide IoUs und die unveränderte Native-UI-Quelle stehen in `godot-integration-cup-observation.json`. Die Aufnahme behauptet keine Root-Sichtung oder ausgeführte Auswahlgeste.

Die Probe meldet 16 erfolgreiche ausgeführte Schritte und einen Fehler, `crashes=0`. Rennen, Fahrfortschritt und Pause wurden nicht erreicht. Der anschließende Studio-/Cards-Probe startete deshalb nicht; der neue Heartbeat ist in dieser echten Laufzeit weder bestätigt noch widerlegt. Keine Prüfung wurde wiederholt und kein Quellcode geändert.

## Erfolgreicher API37-Unterbau

Die originalen CI-Berichte binden 141 tatsächlich installierte CLI22-Dateien an dieselben offiziellen Hashes. Der ausgeführte SDK-Manager meldet 22.0. Das offizielle Archiv hat SHA256 `4e4c464f145a7512b57d088ac6c278c03c9eea610886b35a5e0804e74eedf583`. Die mit CLI12 erzeugte Vergleichs-AVD hatte das Ziel `android-0` und eine Partition von `800M`; die tatsächlich gebootete CLI22-AVD hat `android-37.0` und `10G`. Alle weiteren erzeugten Konfigurationsunterschiede sind erhalten; keine einzelne Eigenschaft wird als alleinige Ursache ausgegeben. Die tatsächliche AVD-Konfiguration ist vor dem Boot, im Guard und danach unverändert. `package.xml` des Images meldet Revision 8, während die unveränderte eingebettete `source.properties` Revision 7 enthält. Diese beiden Angaben werden getrennt erhalten.

Der Framework-Guard beobachtet dreimal SDK 37 / Release 17, denselben system_server-PID 627 / start_count 1 und alle fünf notwendigen Dienste über 10,488 Sekunden. Abschluss: 21:32:34 UTC. Dieser Nachweis betrifft den beobachteten Frameworkstart. Alle Rohlogs einschließlich Emulatorwarnungen bleiben erhalten; es gibt keine pauschale Behauptung fehlerfreier Logs oder gemessener physischer Geräte-/FPS-Leistung.

## Originale und Grenzen

`artifacts/14078303745.zip` ist das vollständige Originalarchiv: 43.440.046 Bytes, SHA256 `7c125864835f2f91903f0942c4db7659c38aff6d5246eaba5ab8b53e7a949ef7`. Alle 379 Dateien wurden CRC-/hashgeprüft und alle 26 PNG vollständig dekodiert. Alle Nicht-PNG-Originale und nur das tatsächlich gesichtete Cup-Bild sind zusätzlich unter `artifact-original/` ausgepackt; die restlichen PNG bleiben im ZIP. Vollständige Indizes und originale API-/Jobdaten sind beigefügt.

Die getestete x86-APK hat SHA256 `cb93173e3b80669609dbb4cd13b178be22c9cf53fe86fa61a94cb1db82936665`; der PCK hat `dd57b17ec8bba6aac7c29f2116bff643b015592096f360f6ae460dbe2b2f1e6f`. Diese Werte sind zwischen ursprünglichem Buildlog und aktueller tatsächlicher CI-Identitätsprüfung gebunden. Das gemeinsame Candidate-ZIP mit 648.153.033 Bytes überschreitet das Connectorlimit und wurde hier nicht lokal geprüft. Der volle Original-Buildlog ist verlustfrei gzip erhalten; es wird kein lokaler x86-APK-Download behauptet.

`verification.json` dokumentiert Abdeckung und Grenzen, `handoff.json` die Übergabe. Manifest und `SHA256SUMS` binden alle gespeicherten Original-/Analysebytes. Dieses Paket verändert keine Sources, Branches, Pins, Receipts oder Producer-Arbeitsbäume.
