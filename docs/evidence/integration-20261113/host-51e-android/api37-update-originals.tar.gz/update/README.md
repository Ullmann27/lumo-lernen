# Actual 2017 → 2019 Update: failed original run, preserved partial evidence

## Exact source

- Host: `51e92fb5afab232a29850ffefef5637359af08f7`; tree `a13ab981d917c7788f35318cf10d962c1bf657f7`.
- Native: `993c145304c3e5f8aa947e1c7a949a8ef8685415`.
- Run `43502594333`, attempt 1; Update job `132181019088`, **FAILURE**.
- Complete original artifact `14078383602`: 49,699,411 bytes, SHA256 `b9a34af78be372699f7d390b7ee09970e96c7bc50131dcf197f3a10ece38d447`.

## What the original run proves

The actual 2017 baseline was downloaded from artifact 13948686178 / run 43220602252, with host 47889f74a651b073965def70743417cf320b1eb9 and native 1d5c5cb45a323228f627ec529e6ff1ddd86f1c57. The actual candidate is artifact 14078786114 / run 43502594333, host51e/native993c. The original Update log verifies both archive digests. Its actual APK hash checks and stored provenance match the two independently preserved build-verifier outputs for each x86_64 APK, including package, certificate, version, native PCK digest/size and ABI.

The baseline fictional child answered 5 + 1 = 6, earned one star and five XP, saved the result and restored it after a baseline restart. The candidate installed with `install -r`: the package UID and first installation time remained unchanged. It launched after the original probe disabled wifi/data and checked airplane mode. The visible retained profile and original preferences prove seven protected learning keys survived, including one correct answer and the same reward. The only permitted skill-record addition is the already reviewed independentEvidence-v1 conversion. This saved-data comparison was independently re-evaluated with the frozen exact51e validator and unchanged original XML.

The baseline journey also records two failed additional subject-navigation subchecks (Deutsch and Englisch). They remain explicit in review.json and the original journey result; its core math/reward/restart PASS does not promote these subchecks.

## Actual failure and missing phases

At 21:36:32.9680524 UTC the original probe fails with `Ambiguous cup-caption regions on the current landing`. The direct original screenshot shows one Grand Prix banner on a fully rendered landing. Tight raw/teal OCR bounds [170,397,385,426] conflict with a much larger contrast box [62,240,385,455] in the existing IoU selector. The original frame, all seven OCR TSVs, full OCR JSON, readiness record and traceback are retained unchanged.

The race-start/drive/pause/Flutter-return phase, after-Kart preservation, candidate2019 offline restart, candidate cover/open/landscape preservation and final crash/offline acceptance were **not reached**. The successful baseline2017 restart/Fold checks are not candidate2019 results. Overall Update acceptance remains **FAIL**.

## Files and boundaries

`review.json` contains explicit per-phase reached/not-reached results and exact identity bindings. `saved-originals-verification.json` contains the saved-data/metadata comparison. `original-zip-manifest.json` binds all 132 complete ZIP entries; every entry was read and CRC/SHA256 checked, and extracted copies match the originals. `source/` contains immutable exact51e sources; `.gz` objects are lossless and the final manifest records their original-byte hashes. Full original job logs and official run/jobs/artifacts metadata are retained.

The two combined candidate APK archives exceed the connector's 512MiB export limit. This review uses the actual CI download/byte-check records and original build outputs; it does not claim a new local x86 APK binary inspection. No source, ref, pin, receipt or workflow was changed, no new test/emulator/CI run was started, and no old proof was relabelled.
