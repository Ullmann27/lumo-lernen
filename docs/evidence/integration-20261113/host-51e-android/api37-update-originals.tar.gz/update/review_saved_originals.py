#!/usr/bin/env python3
"""Recheck saved CI evidence only; never install, launch, or modify the APK."""
from __future__ import annotations

import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import types
import xml.etree.ElementTree as ET
import zipfile

from PIL import Image

BASE = Path(__file__).resolve().parent
HOST = '51e92fb5afab232a29850ffefef5637359af08f7'
TREE = 'a13ab981d917c7788f35318cf10d962c1bf657f7'
NATIVE = '993c145304c3e5f8aa947e1c7a949a8ef8685415'
sys.dont_write_bytecode = True


def raw(path: str) -> bytes:
    data = (BASE / path).read_bytes()
    return gzip.decompress(data) if path.endswith('.gz') else data


def document(path: str):
    return json.loads(raw(path))


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write_new(path: str, value) -> None:
    with (BASE / path).open('x') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def prefs(path: str) -> dict:
    # Identical parsing to creative_android_probe.prefs; original XML is retained.
    return {node.get('name'): node.text for node in ET.fromstring(raw(path))}


def load_frozen(name: str):
    path = f'source/tools/android_qa/{name}.py.gz'
    module = types.ModuleType(name)
    module.__file__ = str(BASE / path)
    sys.modules[name] = module
    exec(compile(raw(path), module.__file__, 'exec'), module.__dict__)
    return module


def package_identity(tag: str) -> dict:
    text = raw(f'originals/{tag}-package.txt').decode()
    uid = re.search(r'^package:dev\.ullmann\.lumo\.lumo_lernen\.coachpreview\s+uid:(\d+)',
                    raw(f'originals/{tag}-package-uid.txt').decode(), re.M)
    assert uid is not None
    result = {'userId': uid.group(1)}
    for key in ('firstInstallTime', 'versionCode', 'versionName'):
        match = re.search(r'\b' + key + r'=([^\n]+)', text)
        assert match is not None
        result[key] = match[1].strip()
    assert 'primaryCpuAbi=x86_64' in text
    return result


def main() -> None:
    original_roots = {'source', 'originals', 'baseline-original', 'candidate-original',
                      'initial-originals', 'final-job-originals', 'snapshots'}
    original_files = {'source-binding.json', 'transferred-originals.json',
                      'additional-originals.json', 'update-job-132181019088.log.gz',
                      'update-original-14078383602.zip'}
    inputs = {str(path.relative_to(BASE)): sha(path.read_bytes())
              for path in sorted(BASE.rglob('*')) if path.is_file() and
              (path.relative_to(BASE).parts[0] in original_roots or path.name in original_files)}
    result = document('originals/update-result.json')
    run = document('final-job-originals/run.json.gz')
    commit = document('candidate-original/commit.json.gz')
    jobs = document('final-job-originals/jobs.json.gz')['jobs']
    job = next(item for item in jobs if item['id'] == 132181019088)
    assert run['id'] == job['run_id'] == 43502594333
    assert run['head_sha'] == job['head_sha'] == commit['sha'] == HOST
    assert run['head_commit']['tree_id'] == commit['tree']['sha'] == TREE
    assert run['run_attempt'] == job['run_attempt'] == 1
    assert job['status'] == 'completed' and job['conclusion'] == 'failure'
    assert result['status'] == 'FAIL' and result['candidate_source'] == HOST
    assert result['error'] == 'Ambiguous cup-caption regions on the current landing'

    artifact = next(item for item in document('final-job-originals/artifacts.json.gz')['artifacts']
                    if item['id'] == 14078383602)
    archive_path = BASE / 'update-original-14078383602.zip'
    archive_sha = sha(archive_path.read_bytes())
    assert artifact['workflow_run']['head_sha'] == HOST
    assert artifact['workflow_run']['id'] == run['id']
    assert artifact['size_in_bytes'] == archive_path.stat().st_size == 49699411
    assert artifact['digest'] == 'sha256:' + archive_sha
    entries = []
    with zipfile.ZipFile(archive_path) as archive:
        assert len(set(archive.namelist())) == len(archive.infolist()) == 132
        for info in archive.infolist():
            data = archive.read(info)  # Complete read checks each entry's original CRC.
            item = {'path': info.filename, 'bytes': len(data), 'sha256': sha(data),
                    'zip_crc32': f'{info.CRC:08x}', 'compressed_bytes': info.compress_size}
            local = BASE / 'originals' / info.filename
            if local.is_file():
                assert local.read_bytes() == data
                item['extracted_original_equal'] = True
            if info.filename in ('21_stage_mode_cup-0.png', '99_fehler.png'):
                with Image.open(io.BytesIO(data)) as image:
                    image.load()
                    item['decoded_pixels'] = list(image.size)
            entries.append(item)
        for capture in result['learning_journey']['captures']:
            assert sha(archive.read('baseline-learning/' + capture['file'])) == capture['sha256']

    load_frozen('kart_tour_evidence')
    preservation = load_frozen('update_preservation')
    before = prefs('originals/before-update-preferences.xml')
    after = prefs('originals/after-update-preferences.xml')
    preserved = preservation.require_learning_preserved(before, after, migration_versions=(2017, 2019))
    assert preserved == result['after_update']
    installed = preservation.require_in_place_update(package_identity('baseline'), package_identity('updated'), 2019)
    assert installed == result['installation']
    baseline_restart = preservation.require_learning_preserved(
        prefs('originals/baseline-learning/10-before-restart-preferences.xml'),
        prefs('originals/baseline-learning/11-after-restart-preferences.xml'))
    assert 'LumoTest' in raw('originals/updated-profile-offline-0.xml').decode()
    assert document('originals/updated-profile-offline-render-readiness.json')['status'] == 'PASS'

    original_log = raw('update-job-132181019088.log.gz').decode()
    assert f'git checkout --progress --force {HOST}' in original_log
    bindings = []
    for name, index_path, log_path, expected_host, expected_native, expected_version, artifact_id, run_id in (
        ('baseline', 'baseline-original/build-apk-identities.json', 'baseline-original/verify-and-build-131192088702.log.gz',
         '47889f74a651b073965def70743417cf320b1eb9', '1d5c5cb45a323228f627ec529e6ff1ddd86f1c57', 2017, 13948686178, 43220602252),
        ('candidate', 'candidate-original/build-apk-identities.json.gz', 'candidate-original/verify-and-build-132151952145.log.gz',
         HOST, NATIVE, 2019, 14078786114, 43502594333),
    ):
        index = document(index_path)
        log = raw(log_path)
        log_lines = log.splitlines(keepends=True)
        assert sha(log) == index.get('source_log_sha256', index.get('source_log_original_sha256'))
        selected = []
        for entry in index['reports']:
            chunk = b''.join(log_lines[entry['original_first_line'] - 1:entry['original_last_line']])
            assert sha(chunk) == entry['original_timestamped_slice_sha256']
            parsed = json.loads(re.sub(rb'^\d{4}-\d{2}-\d{2}T\S+ ', b'', chunk, flags=re.M))
            assert parsed == entry['ci_verification']
            if parsed['abis'] == ['x86_64']:
                assert all(result[name][key] == value for key, value in parsed.items())
                selected.append(entry['original_first_line'])
        assert len(selected) == 2
        actual = result[name]
        assert actual['flutter_source_commit'] == expected_host and actual['tracked_source_clean'] is True
        assert actual['godot']['revision'] == expected_native and actual['versionCode'] == expected_version
        assert actual['abis'] == ['x86_64']
        assert 'Success' in raw(f"originals/{'baseline' if name == 'baseline' else 'update'}-install.txt").decode()
        meta = (next(item for item in document('baseline-original/artifacts.json.gz')['artifacts'] if item['id'] == artifact_id)
                if name == 'baseline' else document('candidate-original/artifact.json.gz'))
        assert meta['workflow_run']['head_sha'] == expected_host and meta['workflow_run']['id'] == run_id
        digest = meta['digest'].removeprefix('sha256:')
        assert f'SHA256 digest of downloaded artifact is {digest}' in original_log
        bindings.append({'role': name, 'artifact_id': artifact_id, 'run_id': run_id,
                         'artifact_sha256': digest, 'artifact_bytes': meta['size_in_bytes'],
                         'apk_source': expected_host, 'native_source': expected_native,
                         'version_code': expected_version, 'apk_sha256': actual['sha256'],
                         'apk_bytes': actual['bytes'], 'package': actual['package'], 'abis': actual['abis'],
                         'certificate_sha256': actual['signingCertificateSha256'], 'pck': actual['godot'],
                         'matched_original_build_report_first_lines': selected,
                         'ci_download_digest_matches_original_metadata': True})
    assert result['baseline']['signingCertificateSha256'] == result['candidate']['signingCertificateSha256']
    assert raw('originals/tested-apk-sha256.txt').decode().split()[0] == result['candidate']['sha256']
    absent = ['native_tour', 'after_kart', 'after_restart', 'fold', 'offline', 'fatal_crashes']
    assert all(key not in result for key in absent)
    for path, digest in inputs.items():
        assert sha((BASE / path).read_bytes()) == digest
    write_new('original-zip-manifest.json', {'artifact_id': artifact['id'], 'sha256': archive_sha,
              'bytes': archive_path.stat().st_size, 'entry_count': len(entries),
              'uncompressed_bytes': sum(item['bytes'] for item in entries),
              'all_entries_crc_and_sha256_read': True, 'entries': entries})
    write_new('saved-originals-verification.json', {
        'scope': 'Read-only analysis of saved original CI metadata, ZIP, package records and preferences; no new test, APK install or emulator run.',
        'source': {'host': HOST, 'tree': TREE, 'native': NATIVE, 'run_id': run['id'], 'job_id': job['id'], 'attempt': 1},
        'job_status': 'FAILURE', 'artifact_integrity': 'PASS', 'identity_bindings': bindings,
        'in_place_installation': installed, 'initial_offline_learning_preservation': preserved,
        'initial_offline_evidence': 'Source lines 149-159 require wifi/data disabled, airplane_mode_on == 1 and a visible rendered profile before writing after_update.',
        'baseline_2017_restart_preservation': baseline_restart,
        'baseline_optional_tour_failures': {key: value for key, value in result['learning_journey']['tour'].items() if value.startswith('FAIL')},
        'terminal_error': result['error'], 'not_reached_result_fields': absent,
        'input_files_unchanged': len(inputs), 'original_input_sha256': inputs,
        'binary_boundary': 'The oversized candidate and baseline ZIPs were downloaded and hash-checked in CI; their x86_64 APK bytes were checked by the actual CI update probe. Local review matches original reports; it does not claim a new local x86 APK binary inspection.',
    })
    print(json.dumps({'status': 'ORIGINALS_VERIFIED_JOB_REMAINS_FAILURE', 'zip_entries': len(entries),
                      'unchanged_inputs': len(inputs), 'learning_keys': preserved['learning_keys_compared'],
                      'correct_answers': preserved['correct_answers_preserved'], 'stars': preserved['earned_stars'],
                      'xp': preserved['earned_xp']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
