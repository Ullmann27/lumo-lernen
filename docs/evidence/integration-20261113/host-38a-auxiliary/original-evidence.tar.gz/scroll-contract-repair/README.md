# Bounded Flutter scroll contract repair

## Source and observed failure

Published Host PR465 source: 38a49f7dda404923da3955592ccb213871f2027d, tree 625b7940d9e8a4ddf32203126721efd97b3e8c2e. Local source twin: 44dfd78d8a998cccb09d20bc974fb699dddd925e. The failed CI checkout was PR merge e2181cdbbc94d771865763144039f82de6b996ea; the raw Git commit metadata binds the same tree.

Original workflow run 43497829047 / job 132135469969 completed with one failure in 436 tests (108.504 seconds). The default-search test expected 24 accessibility reads but the actual accepted helper now performs 26. The complete original job log and original artifact 14073430687 are preserved in the parent directory; the ZIP is unchanged and its official digest is checked. No CI outcome is relabelled.

## Exact correction

Only scripts/tests/test_android_voice_scroll.py changes. The fixture now records the actual helper's observation tag, cumulative gesture count, and current position. The existing bounded-default test requires exactly 24 total gestures, 13 observations per direction, the first direction's final (12, 0) state and the second direction's final (24, 12) state. Its original missing-target error, position, no-control-touch, and diagnostic capture expectations remain.

The product helper allows 12 gestures per direction, with an initial read and a read after the last allowed gesture. The two direction loops therefore allow 26 observations, without adding any gesture. The test executes the real source function through its existing AST fixture. It does not copy a replacement search algorithm.

## Validation and scope

- targeted-red.log: the unchanged existing default test reproduces the same 26 != 24 failure locally; exit 1.
- targeted-green.log: all seven tests in the existing voice-scroll module plus the six unchanged final-scroll neighbor tests pass together; 13 tests, no failures or skips, exit 0.
- before-manifest.json and after-manifest.json bind the test, actual helper, neighbor tests, recovery and both 2019 workflows, all three pin files, both 2019 receipts, and the 2018 receipt. Only the authorized test differs.
- All twelve scoped files are unchanged during the green execution. Product, workflow, pin, receipt, index, and refs are not edited by this repair.
- This is a synthetic transport contract check, not a new Android emulator or audio result. The original 38a49f7d CI failure remains a failure; a later source-bound CI result must stand on its own.

Source snapshots and the exact patch are unmodified. Logs are complete. The outer CI collection may continue independently of this frozen repair folder.
