class StudioUpdateWrapperExecutionTests(unittest.TestCase):
    """Execute the real wrapper and identity gates; stop before Android I/O."""
    source = 'a' * 40
    baseline_source = '47889f74a651b073965def70743417cf320b1eb9'
    baseline_native = '1d5c5cb45a323228f627ec529e6ff1ddd86f1c57'
    package = 'dev.ullmann.lumo.lumo_lernen.coachpreview'
    certificate = 'a6b1ef61bf59db4e0794c742aeb3b5506d130f4d21175c9975140e6acdb80702'
    boundary = 'TEST BOUNDARY: no Android device was contacted'

    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)
        self.native = json.loads((_ROOT / 'config/godot-source.json').read_text())['revision']
        self.paths = {}
        for label, version, source, native in (
            ('baseline', 2017, self.baseline_source, self.baseline_native),
            ('candidate', 2019, self.source, self.native),
        ):
            folder = self.directory / label
            folder.mkdir()
            apk = folder / 'synthetic-metadata-fixture.apk'
            apk.write_bytes(f'METADATA VALIDATOR FIXTURE {version}; NOT AN APK'.encode())
            (folder / 'BUILD-PROVENANCE.json').write_text(json.dumps({
                'flutter_source_commit': source, 'tracked_source_clean': True,
                'versionCode': version, 'package': self.package,
                'signingCertificateSha256': self.certificate,
                'sha256': hashlib.sha256(apk.read_bytes()).hexdigest(),
                'abis': ['x86_64'], 'godot': {'revision': native},
            }))
            self.paths[label] = apk

    def run_wrapper(self):
        # Only external device boundaries are replaced. The real wrapper,
        # reviewed-pin policy, main() and APK identity validators all execute.
        tour = types.ModuleType('modernization_android_tour')
        tour.PACKAGE = self.package
        tour.probe = types.SimpleNamespace(
            CERT=self.certificate,
            ensure_rooted_emulator=mock.Mock(side_effect=RuntimeError(self.boundary)),
            capture=mock.Mock(),
        )
        tour.base = types.SimpleNamespace(adb=mock.Mock(return_value=''))
        tour.live = types.SimpleNamespace()
        name = 'lumo_2003_update_android_probe'
        spec = importlib.util.spec_from_file_location(
            name, _ROOT / '.github/probes/lumo_2003_update_android_probe.py')
        module = importlib.util.module_from_spec(spec)
        output = self.directory / 'result'
        arguments = ['lumo_2019_update_android_probe.py',
                     '--baseline', str(self.paths['baseline']),
                     '--candidate', str(self.paths['candidate']), '--out', str(output)]
        with mock.patch.dict(sys.modules, {'modernization_android_tour': tour, name: module}), \
                mock.patch.dict(os.environ, {'LUMO_CANDIDATE_SOURCE_SHA': self.source}), \
                mock.patch.object(sys, 'argv', arguments), \
                contextlib.redirect_stdout(io.StringIO()):
            spec.loader.exec_module(module)
            with self.assertRaises(SystemExit) as stopped:
                runpy.run_path(str(_ROOT / '.github/probes/lumo_2019_update_android_probe.py'),
                               run_name='__main__')
        # This unit probe deliberately cannot issue Android PASS.
        self.assertEqual(stopped.exception.code, 1)
        tour.base.adb.assert_called_once_with('logcat', '-d', timeout=60)
        report = json.loads((output / 'update-result.json').read_text())
        self.assertEqual(report['status'], 'FAIL')
        return report, tour.probe.ensure_rooted_emulator

    def test_actual_2019_wrapper_validates_both_artifacts_before_device_boundary(self):
        report, boundary = self.run_wrapper()
        self.assertEqual(report['error'], self.boundary)
        self.assertEqual(report['baseline']['versionCode'], 2017)
        self.assertEqual(report['candidate']['versionCode'], 2019)
        self.assertEqual(report['candidate_source'], self.source)
        boundary.assert_called_once()

    def test_actual_wrapper_does_not_bypass_baseline_or_candidate_identity(self):
        invalid = [
            ('baseline', {'versionCode': 2016}),
            ('baseline', {'flutter_source_commit': 'b' * 40}),
            ('candidate', {'versionCode': 2018}),
            ('candidate', {'tracked_source_clean': False}),
            ('candidate', {'flutter_source_commit': 'b' * 40}),
            ('candidate', {'signingCertificateSha256': 'untrusted'}),
            ('candidate', {'package': 'another.app'}),
            ('candidate', {'sha256': '0' * 64}),
            ('candidate', {'abis': ['arm64-v8a']}),
            ('candidate', {'godot': {'revision': self.baseline_native}}),
        ]
        for label, changes in invalid:
            path = self.paths[label].parent / 'BUILD-PROVENANCE.json'
            original = path.read_bytes()
            with self.subTest(label=label, changes=changes):
                try:
                    path.write_text(json.dumps({**json.loads(original), **changes}))
                    report, boundary = self.run_wrapper()
                    self.assertIn(report['error'], (
                        'Artifact provenance does not identify the expected APK',
                        'Update gate requires the actual x86_64 native APK',
                        'Native source is not the reviewed pin',
                    ))
                    boundary.assert_not_called()
                finally:
                    path.write_bytes(original)

