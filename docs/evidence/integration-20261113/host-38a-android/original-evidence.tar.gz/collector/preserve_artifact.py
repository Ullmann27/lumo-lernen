#!/usr/bin/env python3
"""Preserve one original Actions archive; never assert device acceptance."""
from pathlib import Path, PurePosixPath
import datetime, hashlib, io, json, re, stat, sys, urllib.request, zipfile
from PIL import Image
base=Path(__file__).resolve().parents[1]
aid=int(sys.argv[1]); source=Path(sys.argv[2]); export=json.loads(sys.argv[3])
raw=source.read_text(); decoder=json.JSONDecoder()
pos=raw.index('[',raw.index('"artifacts"'))+1
while True:
 while raw[pos] in ' \n\r\t,': pos+=1
 if raw[pos]==']': raise RuntimeError('Artifact absent from original REST response')
 item,end=decoder.raw_decode(raw,pos)
 if item['id']==aid: break
 pos=end
objraw=raw[pos:end].encode()
run=item['workflow_run']
assert run['id']==43497829121 and run['head_sha']=='38a49f7dda404923da3955592ccb213871f2027d'
assert not item['expired'] and re.fullmatch(r'sha256:[0-9a-f]{64}',item['digest'])
folder=base/'artifacts'/str(aid); folder.mkdir(parents=True,exist_ok=True)
metadata=folder/'artifact.json'
assert not metadata.exists() or metadata.read_bytes()==objraw
metadata.write_bytes(objraw)
name=re.sub('[^a-zA-Z0-9_.-]','_',item['name'])
archive=base/'archives'/f'{name}-{aid}.zip'; archive.parent.mkdir(parents=True,exist_ok=True)
if not archive.exists():
 part=archive.with_suffix('.zip.part')
 with urllib.request.urlopen(export['download_url'],timeout=120) as incoming, part.open('wb') as out:
  while chunk:=incoming.read(1024*1024): out.write(chunk)
 assert part.stat().st_size==item['size_in_bytes'],'ZIP size differs'
 with part.open('rb') as incoming: actual=hashlib.file_digest(incoming,'sha256').hexdigest()
 assert actual==item['digest'][7:],'ZIP digest differs'
 part.rename(archive)
with archive.open('rb') as incoming: actual=hashlib.file_digest(incoming,'sha256').hexdigest()
assert archive.stat().st_size==item['size_in_bytes'] and actual==item['digest'][7:]
entries=[]; pngs=[]; logs=[]; extracted=[]
with zipfile.ZipFile(archive) as zipped:
 assert len(set(zipped.namelist()))==len(zipped.namelist()),'Duplicate members'
 assert zipped.testzip() is None,'ZIP CRC failure'
 for info in zipped.infolist():
  rel=PurePosixPath(info.filename)
  assert not rel.is_absolute() and '..' not in rel.parts and not stat.S_ISLNK(info.external_attr>>16),'Unsafe member'
  if info.is_dir(): continue
  with zipped.open(info) as member: digest=hashlib.file_digest(member,'sha256').hexdigest()
  entry={'path':info.filename,'bytes':info.file_size,'compressed_bytes':info.compress_size,'crc32':format(info.CRC,'08x'),'sha256':digest}
  entries.append(entry)
  if rel.suffix.lower()=='.png':
   data=zipped.read(info)
   with Image.open(io.BytesIO(data)) as image: image.verify()
   with Image.open(io.BytesIO(data)) as image:
    image.load(); pngs.append({**entry,'dimensions':list(image.size),'mode':image.mode,'decode':'Pillow verify plus full load'})
  if rel.suffix.lower()=='.log': logs.append(entry)
  if rel.suffix.lower() in ('.json','.log','.txt','.png','.xml','.tsv','.csv','.md','.sha256'):
   target=folder/'original'/Path(*rel.parts); target.parent.mkdir(parents=True,exist_ok=True)
   target.write_bytes(zipped.read(info))
   assert hashlib.sha256(target.read_bytes()).hexdigest()==digest
   extracted.append(str(target.relative_to(base)))
report={'schema':1,'verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Transport, ZIP CRC/member SHA256 and PNG decoding only; no runtime acceptance claim.',
 'source_commit':run['head_sha'],'run_id':run['id'],'artifact_id':aid,'artifact_name':item['name'],
 'original_metadata_list':str(source.relative_to(base)),'original_metadata_list_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'original_metadata_object_sha256':hashlib.sha256(objraw).hexdigest(),'download_file_id':export.get('file_id'),
 'archive':str(archive.relative_to(base)),'archive_bytes':archive.stat().st_size,'archive_sha256':actual,
 'original_digest':item['digest'],'zip_crc':'PASS','entries':entries,'pngs':pngs,'logs':logs,'extracted_files':extracted}
result=folder/'verification.json'; result.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ('artifact_id','artifact_name','archive','archive_bytes','archive_sha256','zip_crc')}|{'files':len(entries),'pngs':len(pngs),'logs':len(logs),'verification_sha256':hashlib.sha256(result.read_bytes()).hexdigest()}))
