#!/usr/bin/env python3
"""Explicitly authorized new validation after loss of transient /tmp evidence."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/b3485b7bb989/lumo-host-jump-joystick-repair-7b16')
OUT = Path(__file__).resolve().parent
PYTHON = '/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python'
LINT = '/workspace/scratch/e0abce7d2838/toolchain/actionlint/actionlint'
HEAD = '230f3a8a3460576fd63d0ae64cb870fec53ba177'
TREE = 'ea36060e04ee619bcd7a0a67aee8eba11e61bc5d'
BRANCH = 'validation/lumo-console-printf-source-20261114'
OLD_INPUT = 'docs/evidence/host-console-start-final-validation-20261114/source-before.json'
PRINTF_INPUT = 'docs/evidence/host-pr486-console-printf-repair-20261114/source-freeze.json'
WORKFLOW = '.github/workflows/lumo-console-start-7b16.yml'
ROOT_CHANGES = {WORKFLOW, 'scripts/tests/test_console_start_workflow.py'}
ENV = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'GIT_OPTIONAL_LOCKS': '0',
       'TMPDIR': '/tmp', 'LUMO_PRINTF_CONTRACT_EVIDENCE': str(OUT/'local-shell')}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def utc():
    return datetime.now(timezone.utc).isoformat()


def write(name, obj):
    with (OUT/name).open('x') as stream:
        stream.write(json.dumps(obj, indent=2, ensure_ascii=False)+'\n')


def record(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': sha(raw)}


def git(*args):
    proc = subprocess.run(['git', '-C', str(ROOT), *args], env=ENV,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
    if proc.stderr:
        raise RuntimeError('Unexpected read-only Git stderr')
    return proc.stdout


def snapshot(name, paths):
    index_path = Path(git('rev-parse', '--git-path', 'index').decode().strip())
    if not index_path.is_absolute():
        index_path = ROOT/index_path
    data = {
        'observed_at_utc': utc(), 'head': git('rev-parse', 'HEAD').decode().strip(),
        'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
        'branch': git('branch', '--show-current').decode().strip(),
        'status_porcelain': git('status', '--porcelain=v1', '--untracked-files=all').decode(),
        'index': record(index_path),
        'index_entries': git('ls-files', '--stage', '--', *sorted(paths)).decode(),
        'head_entries': git('ls-tree', '-r', HEAD, '--', *sorted(paths)).decode(),
        'files': {},
    }
    entries = {}
    for line in data['head_entries'].splitlines():
        mode_kind_oid, path = line.split('\t', 1)
        mode, kind, oid = mode_kind_oid.split()
        if kind != 'blob' or mode not in ('100644', '100755'):
            raise RuntimeError('Nonregular committed input: '+path)
        entries[path] = oid
    if set(entries) != set(paths):
        raise RuntimeError('Incomplete committed input set')
    for path in sorted(paths):
        full = ROOT/path
        if not full.is_file() or full.is_symlink():
            raise RuntimeError('Missing regular input: '+path)
        raw = full.read_bytes()
        oid = hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        if oid != entries[path]:
            raise RuntimeError('Input differs from committed blob: '+path)
        data['files'][path] = {'bytes': len(raw), 'sha256': sha(raw), 'git_blob': oid}
    write(name+'.json', data)
    return data


def run(name, argv, limit):
    start, clock = utc(), time.monotonic()
    error = None
    with (OUT/(name+'.log')).open('xb') as stream:
        try:
            result = subprocess.run(argv, cwd=ROOT, env=ENV, stdin=subprocess.DEVNULL,
                                    stdout=stream, stderr=subprocess.STDOUT, timeout=limit)
            rc = result.returncode
        except subprocess.TimeoutExpired:
            rc, error = None, 'TIMEOUT'
    result = {'command': argv, 'cwd': str(ROOT), 'timeout_seconds': limit,
              'environment_overrides': {key: ENV[key] for key in (
                  'PYTHONDONTWRITEBYTECODE', 'GIT_OPTIONAL_LOCKS', 'TMPDIR', 'LUMO_PRINTF_CONTRACT_EVIDENCE')},
              'started_at_utc': start, 'finished_at_utc': utc(),
              'elapsed_seconds': time.monotonic()-clock, 'returncode': rc, 'error': error,
              'raw_log': {'path': name+'.log', **record(OUT/(name+'.log'))}}
    write(name+'-execution.json', result)
    return result, (OUT/(name+'.log')).read_text()


def main():
    if (OUT/'result.json').exists() or (OUT/'combined-contracts.log').exists():
        raise RuntimeError('This one-time recovery validation already has execution evidence')
    original = git('show', HEAD+':'+OLD_INPUT)
    printf_raw = git('show', HEAD+':'+PRINTF_INPUT)
    with (OUT/'original-27-input-snapshot.json').open('xb') as stream:
        stream.write(original)
    with (OUT/'original-printf-freeze.json').open('xb') as stream:
        stream.write(printf_raw)
    expected = json.loads(original)['files']
    expected.update({row['path']: row for row in json.loads(printf_raw)['files']})
    if len(expected) != 41 or sha(printf_raw) != '73c42515a10bbd2dd40345942fd010ed75d076dc57433fa3b3ff2df94cd0bcd9':
        raise RuntimeError('Frozen inputs differ')
    write('input-provenance.json', {
        'committed_source': HEAD,
        'base_27_input_snapshot': {'git_path': OLD_INPUT, 'bytes': len(original), 'sha256': sha(original)},
        'printf_freeze': {'git_path': PRINTF_INPUT, 'bytes': len(printf_raw), 'sha256': sha(printf_raw)},
        'root_committed_workflow_changes': sorted(ROOT_CHANGES),
    })
    history = {
        'kind': 'Historical observed run with lost transient raw files; not reconstructed',
        'source': HEAD, 'tree': TREE, 'actually_reported_before_environment_disconnect': {
            'tests': 15, 'passed': 15, 'errors': 0, 'failures': 0, 'skips': 0,
            'actionlint_workflows': 1, 'actionlint_exit': 0, 'source_count': 41,
            'source_and_git_unchanged': True},
        'previous_reported_handoff_sha256': '5b206da1f96ee0880fcee70c55b2ff6f95514b834f614a152d12b90781d9ff35',
        'previous_reported_manifest_sha256': '411e8260247888732588f6d0861515a859bc1380102a44b3d824416c0a0a94c2',
        'previous_directory': '/tmp/host-console-230f3a8a-targeted-validation-20261114',
        'loss': 'After exec-server disconnection/recovery, the previous /tmp directory was observed absent. No old raw log, timestamp or hash is recreated.',
        'new_execution_authorization': 'Root explicitly authorized one distinct new 9+6 run plus actionlint1 on unchanged published 230f.',
    }
    write('previous-observation-and-loss.json', history)
    tool_rows = []
    for name, argv in [('python-version', [PYTHON, '--version']),
                       ('actionlint-version', [LINT, '-version']),
                       ('git-version', ['git', '--version'])]:
        info, raw = run(name, argv, 15)
        if info['returncode'] != 0:
            raise RuntimeError('Environment version probe failed: '+name)
        tool_rows.append({'name': name, 'execution': info, 'version_output': raw})
    environment = {'observed_at_utc': utc(), 'python_sys_version': sys.version,
                   'platform': platform.platform(), 'uname': list(platform.uname()),
                   'tools': tool_rows, 'executables': []}
    for p in [Path(PYTHON), Path(LINT), Path(shutil.which('git')), Path(shutil.which('sh'))]:
        environment['executables'].append({'path': str(p), 'resolved': str(p.resolve()), **record(p)})
    if Path('/etc/os-release').is_file():
        environment['os_release'] = Path('/etc/os-release').read_text()
    write('environment.json', environment)
    before = snapshot('source-before', expected)
    if (before['head'], before['tree'], before['branch'], before['status_porcelain']) != (HEAD, TREE, BRANCH, ''):
        raise RuntimeError('Actual checkout is not the authorized clean committed source')
    for name, row in expected.items():
        if name not in ROOT_CHANGES and any(before['files'][name][key] != row[key] for key in ('bytes', 'sha256')):
            raise RuntimeError('Unexpected changed input: '+name)
    tests, raw = run('combined-contracts', [PYTHON, '-B', '-m', 'unittest', '-v',
        'scripts.tests.test_console_start_workflow', 'scripts.tests.test_console_logger_printf'], 180)
    lint, lint_raw = run('actionlint', [LINT, '-color', WORKFLOW], 120)
    after = snapshot('source-after', expected)
    unchanged = all(before[k] == after[k] for k in (
        'head', 'tree', 'branch', 'status_porcelain', 'index', 'index_entries', 'head_entries', 'files'))
    counts = re.findall(r'^Ran (\d+) tests in ', raw, re.M)
    passes = len(re.findall(r'^test_[^\n]+ \.\.\. ok$', raw, re.M))
    skip_lines = re.findall(r'^.*(?:\.\.\. skipped |^OK \(skipped=|^FAILED.*skipped=).*$', raw, re.M)
    green = (tests['returncode'] == 0 and counts == ['15'] and passes == 15
             and re.findall(r'^OK$', raw, re.M) == ['OK'] and not skip_lines)
    passed = green and lint['returncode'] == 0 and unchanged
    result = {'schema': 1, 'status': 'PASS' if passed else 'FAIL', 'execution_kind': 'NEW_RECOVERY_VALIDATION',
              'head': HEAD, 'tree': TREE, 'branch': BRANCH, 'worktree': str(ROOT),
              'input_source_count': len(expected), 'source_and_git_unchanged': unchanged,
              'tests': {'executed': int(counts[0]) if len(counts) == 1 else None, 'passed': passes,
                        'errors': 0 if green else None, 'failures': 0 if green else None,
                        'skips': 0 if not skip_lines else None, 'skip_lines': skip_lines, 'execution': tests},
              'actionlint': {'workflow_count': 1, 'execution': lint, 'empty_output': not lint_raw},
              'limits': ['Exactly one separately authorized recovery 9+6 invocation and actionlint1.',
                         'No 86-case rerun, device, SDK, emulator, Android, APK, renderer or release execution.',
                         'Local POSIX writer fragments are not an Android mksh or root-continuity result.',
                         'Historical execution and lost raw bytes remain separate from all new timestamps and hashes.']}
    write('result.json', result)
    write('handoff.json', {'schema': 1, 'status': result['status'], 'pack': str(OUT), 'head': HEAD, 'tree': TREE,
          'execution_kind': result['execution_kind'],
          'tests': {k: result['tests'][k] for k in ('executed', 'passed', 'errors', 'failures', 'skips')},
          'actionlint_exit': lint['returncode'], 'source_count': len(expected), 'source_and_git_unchanged': unchanged,
          'result': {'path': 'result.json', **record(OUT/'result.json')},
          'historical_loss': {'path': 'previous-observation-and-loss.json', **record(OUT/'previous-observation-and-loss.json')},
          'scope': 'New authorized focused local validation after environment recovery. Actual API37 execution remains required.'})
    (OUT/'README.md').write_text(
        '# New Console printf recovery validation\n\n'
        f'Actual committed source {HEAD}; tree {TREE}; clean branch {BRANCH}.\n\n'
        'This is a distinct, explicitly authorized execution after the environment disconnected and the prior '
        '/tmp validation directory disappeared. The prior observed 15-PASS result and its reported hashes are '
        'documented only as history; its raw logs are not reconstructed or assigned to this run.\n\n'
        'One combined invocation executes nine workflow and six literal printf contracts. One actionlint '
        'invocation checks only lumo-console-start-7b16.yml. The new environment and actual tool versions '
        'are recorded. All 41 input files, Git HEAD/tree/branch, full porcelain status, index entries and '
        'index bytes are bound before and after. Inputs are independently compared with actual committed blobs.\n\n'
        'Raw stdout/stderr, exact commands, timings, exit codes and local writer fragment outputs are retained. '
        'No full 86-case, SDK, emulator, Android or APK run occurs. Original PR486 remains failure. '
        'No source, index, branch, ref or workflow was modified.\n')
    rows = [{'path': str(path.relative_to(OUT)), **record(path)}
            for path in sorted(OUT.rglob('*')) if path.is_file()]
    write('manifest.json', {'schema': 1, 'files': rows})
    (OUT/'SHA256SUMS').write_text(''.join(row['sha256']+'  '+row['path']+'\n' for row in rows)
                                +sha((OUT/'manifest.json').read_bytes())+'  manifest.json\n')
    for row in rows:
        if record(OUT/row['path']) != {key: row[key] for key in ('bytes', 'sha256')}:
            raise RuntimeError('Evidence roundtrip failed')
    print(json.dumps({'status': result['status'], 'tests': result['tests']['executed'], 'passed': passes,
                      'actionlint_exit': lint['returncode'], 'sources': len(expected), 'unchanged': unchanged,
                      'started_at_utc': tests['started_at_utc'], 'finished_at_utc': tests['finished_at_utc'],
                      'handoff': str(OUT/'handoff.json'), 'handoff_sha256': sha((OUT/'handoff.json').read_bytes()),
                      'manifest_sha256': sha((OUT/'manifest.json').read_bytes())}, indent=2))
    return 0 if passed else 1


if __name__ == '__main__':
    sys.exit(main())
