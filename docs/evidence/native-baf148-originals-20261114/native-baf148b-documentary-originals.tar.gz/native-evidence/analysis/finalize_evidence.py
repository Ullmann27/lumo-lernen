#!/usr/bin/env python3
"""Freeze derived handoff/index documents without changing collected originals."""
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def identity(path):
    sha = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            sha.update(block)
    return {'path': str(path.relative_to(ROOT)), 'bytes': path.stat().st_size,
            'sha256': sha.hexdigest()}


def save(name, value):
    path = ROOT / name
    assert not path.exists(), name
    data = (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()
    path.write_bytes(data)
    assert path.read_bytes() == data
    return identity(path)


def read(name):
    return json.loads((ROOT / name).read_bytes())


def main():
    archive = read('verification/archive-verification.json')
    replay = read('verification/original-replay.json')
    run = read('snapshots/20261114T140219Z/run.json')
    job = read('snapshots/20261114T140219Z/jobs.json')['jobs'][0]
    artifact = read('artifacts/14116698243/artifact-object-original-slice.json')
    assert replay['status'] == 'PASS' and replay['originals_unchanged'] is True
    common = {'repository': 'Ullmann27/lumo-godot',
              'native_source': replay['native_source'], 'native_tree': replay['native_tree'],
              'run_id': run['id'], 'attempt': run['run_attempt'], 'job_id': job['id'],
              'artifact_id': artifact['id']}
    timings = []
    for step in job['steps']:
        start = datetime.datetime.fromisoformat(step['started_at'].replace('Z', '+00:00'))
        end = datetime.datetime.fromisoformat(step['completed_at'].replace('Z', '+00:00'))
        timings.append({**step, 'elapsed_seconds': (end - start).total_seconds()})
    save('timings.json', {**common, 'kind': 'derived only from final original job API timestamps',
                         'source': identity(ROOT / 'snapshots/20261114T140219Z/jobs.json'),
                         'steps': timings})
    images = []
    for row in archive['decoded_pngs']:
        images.append({'original_entry': row['path'],
                       'original_path': str(ROOT / 'verification/originals' / row['path']),
                       **{k: v for k, v in row.items() if k != 'path'}})
    save('root-review-candidates-60.json', {**common, 'archive_sha256': archive['archive']['sha256'],
                                         'png_count': 60, 'images': images,
                                         'visual_review': 'Not performed or claimed by this collector',
                                         'scope': replay['scope']})
    save('transfer-history.json', {**common,
         'kind': 'Derived transport account; not an original service response',
         'github_artifact_exports': 1,
         'exported_file_id': 'file_0000000050ec81f4b322c93f414715fe',
         'exported_file_name': 'native-baf148b-14116698243.zip',
         'initial_transport_issue': 'After successful export, the local JavaScript URL class was unavailable. No local ZIP transfer had started and the signed URL was not retained.',
         'recovery': 'The exact same file_id and file_name were resolved once with prepare_materialize. Its returned transfer was consumed once by the current Library transfer helper.',
         'new_github_export_for_recovery': False,
         'ci_or_test_retries': 0,
         'zip_identity': identity(ROOT / 'artifacts/14116698243/native-baf148b-14116698243.zip'),
         'original_api_size_and_digest_match': True,
         'signed_download_urls_saved_or_published': False})
    save('original-retention.json', {**common,
         'actions_artifact': {'name': artifact['name'], 'size_in_bytes': artifact['size_in_bytes'],
                              'digest': artifact['digest'], 'created_at': artifact['created_at'],
                              'updated_at': artifact['updated_at'], 'expires_at': artifact['expires_at'],
                              'expired_at_collection': artifact['expired'],
                              'metadata': 'snapshots/20261114T140219Z/artifacts.json'},
         'local_retention': {'full_original_zip': 'artifacts/14116698243/native-baf148b-14116698243.zip',
                             'all_original_members': 'verification/originals',
                             'member_count': archive['zip_entries'],
                             'member_index': 'verification/archive-verification.json',
                             'complete_job_log': 'jobs/job-132464933411.log'},
         'limits': 'Local files are current workspace copies, not a claim of durable publication. The original Actions expiration is preserved. Full transport and all members are presently retained; no PNG or ZIP was substituted.'})
    groups = {'python': {'methods': 47, 'groups': [12, 24, 11], 'skips': 0},
              'existing_headless': {'modes': 4, 'checks': [21, 14, 92, 5347]},
              'dream': {'modes': 5, 'pngs': 7, 'reports': 2},
              'discovery': {'modes': 10, 'pngs': 38, 'reports': 2},
              'village': {'modes': 3, 'headless_checks': [339, 42], 'rendered_checks': 46, 'pngs': 2},
              'mobile': {'mode': 'rendered', 'checks': 428, 'controls': 15,
                         'safe_area_pngs': 4, 'minimap_pngs': 9, 'layouts': 7, 'hint_transitions': 2,
                         'historical_380': 'The 380-check result belongs only to the earlier local 4d2cbb6 headless validation, not this CI run.'}}
    save('handoff.json', {'schema': 1, 'status': 'FROZEN', **common,
         'workflow': run['path'], 'branch': run['head_branch'], 'event': run['event'],
         'parent_source': '4d2cbb6ea235c7bf519aa5f3873a16f6b177be2b',
         'run_conclusion': run['conclusion'], 'job_conclusion': job['conclusion'],
         'all_steps_success': all(s['conclusion'] == 'success' for s in job['steps']),
         'technical_original_acceptance': 'PASS', 'groups': groups,
         'integrity': {'zip': archive['archive'], 'zip_members': archive['zip_entries'],
                       'all_crc_sha_and_local_readbacks': True, 'fully_decoded_pngs': 60,
                       'tracked_entries_bound_to_actual_api_tree': replay['tracked_entries'],
                       'head_tree_index_tracked_before_after_unchanged': True,
                       'originals_unchanged_by_replay': True, 'new_engine_invocations': 0,
                       'new_test_suite_invocations': 0},
         'reports': [identity(ROOT / p) for p in ('verification/archive-verification.json',
              'verification/original-replay.json', 'analysis/verification-invocation.json',
              'root-review-candidates-15.json', 'root-review-candidates-60.json', 'timings.json',
              'jobs/job-132464933411.log', 'transfer-history.json', 'original-retention.json')],
         'final_original_api_directory': 'snapshots/20261114T140219Z',
         'source_identity_directory': 'source-identity', 'bound_reader_sources': 'frozen-source/manifest.json',
         'replay_method': 'Unchanged hash-bound Dream and strict Discovery readers use write=False. The exact workflow Village/Mobile Python is retained separately; minimal documented read-only adapters compare original JSON and remap only the archived absolute capture prefix. All original bytes are rehashed after replay.',
         'visual_review': 'Root reviews original images separately. This collector makes no visual-review assertion.',
         'scope': 'Successful exact separate Native Discovery/Dream/Village/Mobile desktop-renderer CI. No Android, device FPS, complete52/17, Host build, APK, release or publication acceptance.'})
    readme = '''# Native baf148b — vollständiger Originalnachweis

Der separate Native-Lauf **43600806315**, Versuch **1**, Job **132464933411**, ist auf
`baf148b03a7a32c6ad9f737d731f900eb9113ea1` / Tree
`0c18a0ca5200ade267cfedb4c12d5c4b0a761a00` vollständig erfolgreich abgeschlossen.
Die technische Prüfung der Originale und die reinen Nachberechnungen sind bestanden.

## Tatsächlicher Umfang

| Gruppe | Originaler Nachweis |
| --- | --- |
| Python | 47 Methoden: 12 + 24 + 11, keine Skips |
| Vier bestehende Headless-Gates | Return21, Wisp14, Treasure92, Learning5347 |
| Dream | 5 Modi, 7 PNGs, 2 Originalberichte |
| Discovery | 10 Modi in vorgeschriebener Reihenfolge, 38 PNGs, 2 Originalberichte |
| Village | Economy339, Scaling42 headless und Scaling46 gerendert; 2 PNGs à 1280×720 |
| Mobile | Tatsächlich gerendert: 428 Prüfungen, 15 Controls, 4 vorhandene Safe-Area-PNGs plus 9 neue Minimap-PNGs; 7 Layouts und 2 Hinweiswechsel |

Die **380** Prüfungen stammen ausschließlich aus dem früheren lokalen
4d2cbb6-Headlesslauf. Sie werden hier nicht als gerenderte oder erneute Headless-Abnahme ausgegeben.

## Originale und Bindung

Das unveränderte ZIP `artifacts/14116698243/native-baf148b-14116698243.zip`
hat **66.871.509 Bytes**, SHA256
`cc04dd13121a2663cf5c6ae3f21e0da8f1105c566fa13fe59fd9c66f038d49db`.
Alle **1.516** Mitglieder wurden vollständig auf CRC, SHA und lokalen Readback geprüft;
alle **60** PNGs wurden vollständig dekodiert. Die vollständigen unveränderten
Mitglieder liegen unter `verification/originals/`.

Die finalen API-Originale liegen unter `snapshots/20261114T140219Z/`.
Das einzelne Artefaktobjekt wurde als exakter Byteausschnitt aus der originalen
API-Liste erhalten; seine Herkunft wird separat dokumentiert. Der vollständige
Joblog liegt unter `jobs/job-132464933411.log`.

Die vor/nach erhaltenen HEAD-, Tree-, Index- und Byteinventare binden alle
**3.689** getrackten Einträge an den aktuellen vollständigen API-Tree. Generierte
UID-/Importdateien sind in den Originalinventaren getrennt dokumentiert.

## Reine Nachprüfung

`verification/original-replay.json` enthält die vollständigen Nachberechnungen.
Die unveränderten Dream-/Discovery-Prüfer wurden vor Import gegen ihre Git-Blobs
und SHA256 gebunden und mit `write=False` ausgeführt. Die beiden ursprünglichen
Workflow-Prüfblöcke für Village und Mobile liegen zusätzlich bytegleich unter
`analysis/`; die kleinen, dokumentierten Adapter vergleichen die gespeicherten
Originalberichte, statt sie zu überschreiben. Nur der ursprüngliche absolute
Capturepfad wird beim Lesen auf den lokalen Archivort abgebildet.
Alle Originaldateien wurden danach erneut unverändert bestätigt. Es wurde keine
Engine, Testsuite, CI-Wiederholung oder Quelländerung gestartet.

## Sichtprüfung und Grenzen

`root-review-candidates-15.json` benennt die zwei Village-, vier Safe-Area- und
neun Minimap-Originale; `root-review-candidates-60.json` enthält den gesamten
aktuellen Bildsatz mit absoluten Pfaden und Originalhashes. Die direkte Sichtprüfung
durch Root wird separat dokumentiert und hier nicht behauptet.

Dieser Lauf belegt den genannten separaten Desktop-Renderer-Vertrag. Er belegt
keine Android-Geräteprüfung, keine FPS-Zusage, keinen vollständigen52/17-Lauf,
keinen Host-APK-Bau und keine Veröffentlichung. Frühere c300-/4d-Ergebnisse
werden nicht auf diese neue Quelle umetikettiert.

## Transport und Retention

Der erste GitHub-Export war erfolgreich. Der anschließende lokale Transporthelfer
scheiterte vor dem Download an einer nicht verfügbaren JavaScript-URL-Klasse.
Dieselbe exportierte Dateireferenz wurde danach erfolgreich materialisiert;
es gab keinen zweiten GitHub-Export und keinen CI-/Testretry. Signierte Downloadlinks
sind nicht Teil dieses Packs. `transfer-history.json` dokumentiert diese Grenze.

Das vollständige Actions-Original läuft laut finalen Metadaten am
**2026-12-14T14:01:59Z** ab. Das gesamte Original-ZIP und sämtliche Mitglieder sind
derzeit lokal erhalten. `original-retention.json` unterscheidet diese aktuelle
Aufbewahrung von einer dauerhaften Veröffentlichung.

## Freeze

`manifest.json` bindet jede reguläre Datei mit relativer Pfadangabe, Bytezahl und
SHA256. `SHA256SUMS` bindet zusätzlich das Manifest. Beide wurden nach Erstellung
vollständig zurückgelesen und geprüft. Der Pack wird danach nicht verändert;
spätere Sichtbelege gehören in einen getrennten Ordner.
'''
    path = ROOT / 'README.md'
    assert not path.exists()
    path.write_bytes(readme.encode())
    assert path.read_bytes() == readme.encode()
    rows = []
    for path in sorted(ROOT.rglob('*')):
        assert not path.is_symlink(), str(path)
        if path.is_file() and path.relative_to(ROOT).as_posix() not in ('manifest.json', 'SHA256SUMS'):
            rows.append(identity(path))
    manifest = {'schema': 1, 'state': 'FROZEN', **common,
                'scope': 'Complete original evidence and explicitly identified derived audit documents',
                'files': rows, 'manifest_self_hash_location': 'SHA256SUMS',
                'checksums_self_hash': 'Reported separately in the handoff message, not recursively embedded'}
    manifest_row = save('manifest.json', manifest)
    checksum_rows = sorted(rows + [manifest_row], key=lambda x: x['path'])
    sums = ''.join(f"{x['sha256']}  {x['path']}\n" for x in checksum_rows).encode()
    sums_path = ROOT / 'SHA256SUMS'
    assert not sums_path.exists()
    sums_path.write_bytes(sums)
    assert sums_path.read_bytes() == sums
    for row in checksum_rows:
        assert identity(ROOT / row['path']) == row, row['path']
    print(json.dumps({'state': 'FROZEN', 'manifest': manifest_row,
                      'checksums': identity(sums_path), 'file_count': len(rows) + 2,
                      'handoff': identity(ROOT / 'handoff.json'),
                      'all_frozen_files_readback_verified': True}))


if __name__ == '__main__':
    main()
