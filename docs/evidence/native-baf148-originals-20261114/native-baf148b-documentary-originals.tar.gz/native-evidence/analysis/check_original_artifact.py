#!/usr/bin/env python3
"""Audit the one original baf148b Native artifact; never invoke an engine."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import zipfile
import zlib

sys.dont_write_bytecode = True
HEAD = "baf148b03a7a32c6ad9f737d731f900eb9113ea1"
TREE = "0c18a0ca5200ade267cfedb4c12d5c4b0a761a00"
RUN = 43600806315
JOB = 132464933411
ATTEMPT = 1
REPOSITORY = "Ullmann27/lumo-godot"
WORKFLOW = ".github/workflows/lumo-discovery-connections.yml"
BRANCH = "integration/lumo-discovery-bd-20261114"
ARTIFACT_NAME = f"lumo-discovery-connections-native-evidence-{RUN}-{ATTEMPT}"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def identity(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}


def json_file(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "Duplicate JSON key: " + key)
            result[key] = value
        return result
    return json.loads(path.read_bytes().decode("utf-8"), object_pairs_hook=unique)


def write_report(path, value):
    require(not path.exists(), "Analysis report already exists: " + str(path))
    data = (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()
    path.write_bytes(data)
    require(path.read_bytes() == data, "Analysis report readback differs")


def bound_module(path, sha, blob, name):
    data = path.read_bytes()
    require(identity(data)["sha256"] == sha and identity(data)["git_blob"] == blob,
            "Reader source identity differs before import: " + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def inventory_archive(archive, metadata, destination, output):
    from PIL import Image
    artifact = json_file(metadata)
    require(artifact["name"] == ARTIFACT_NAME and artifact["expired"] is False,
            "Foreign or expired original artifact")
    require(artifact["workflow_run"]["id"] == RUN and
            artifact["workflow_run"]["head_sha"] == HEAD, "Foreign artifact source/run")
    digest = hashlib.sha256()
    size = 0
    with archive.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            digest.update(block)
            size += len(block)
    require(size == artifact["size_in_bytes"], "Original ZIP byte count differs from API")
    require(artifact["digest"] == "sha256:" + digest.hexdigest(), "Original ZIP digest differs from API")
    require(not destination.exists(), "Original extraction directory must be new")
    destination.mkdir(parents=True)
    records, pngs, seen = [], [], set()
    with zipfile.ZipFile(archive) as zf:
        members = zf.infolist()
        require(0 < len(members) <= 20000, "Unexpected ZIP member count")
        require(sum(x.file_size for x in members) <= 2147483648, "Unexpected ZIP expansion")
        for info in members:
            name = info.filename.rstrip("/") if info.is_dir() else info.filename
            path = PurePosixPath(name)
            require(name and not path.is_absolute() and ".." not in path.parts and
                    str(path) == name and "\\" not in name and
                    all(ord(c) >= 32 and ord(c) != 127 for c in name), "Unsafe ZIP member")
            require(name not in seen, "Duplicate ZIP member: " + name)
            seen.add(name)
            mode = info.external_attr >> 16
            require(not stat.S_ISLNK(mode), "Symlink in original archive")
            target = destination.joinpath(*path.parts)
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            require(info.file_size <= 268435456, "Unexpected individual original size")
            target.parent.mkdir(parents=True, exist_ok=True)
            count, crc, sha = 0, 0, hashlib.sha256()
            with zf.open(info) as original, target.open("xb") as local:
                for block in iter(lambda: original.read(1048576), b""):
                    local.write(block)
                    count += len(block)
                    crc = zlib.crc32(block, crc)
                    sha.update(block)
            require(count == info.file_size and (crc & 0xffffffff) == info.CRC,
                    "Original member size/CRC differs: " + name)
            local_sha = hashlib.sha256()
            with target.open("rb") as local:
                for block in iter(lambda: local.read(1048576), b""):
                    local_sha.update(block)
            require(local_sha.hexdigest() == sha.hexdigest(), "Original local readback differs: " + name)
            record = {"path": name, "bytes": count, "sha256": sha.hexdigest(),
                      "crc32": f"{info.CRC:08x}", "compressed_bytes": info.compress_size}
            records.append(record)
            if name.lower().endswith(".png"):
                with Image.open(target) as image:
                    require(image.format == "PNG", "A .png original is not PNG")
                    dimensions = image.size
                    image.verify()
                with Image.open(target) as image:
                    image.load()
                    pixels = image.convert("RGBA")
                    decoded = hashlib.sha256(pixels.tobytes()).hexdigest()
                    pixels.close()
                pngs.append({**record, "width": dimensions[0], "height": dimensions[1],
                             "decoded_rgba_sha256": decoded})
    report = {"schema": 1, "artifact_id": artifact["id"], "artifact_name": artifact["name"],
              "run": RUN, "attempt": ATTEMPT, "native_source": HEAD, "native_tree": TREE,
              "archive": {"bytes": size, "sha256": digest.hexdigest()},
              "zip_entries": len(members), "regular_files": records, "decoded_pngs": pngs,
              "all_members_crc_sha_readback_verified": True,
              "scope": "Original transport and full raster decoding only; gate acceptance is separate"}
    write_report(output / "archive-verification.json", report)
    return report


def verify_originals(evidence, original, run_path, jobs_path, archive_report, output):
    run, jobs = json_file(run_path), json_file(jobs_path)
    require(run["id"] == RUN and run["head_sha"] == HEAD and run["run_attempt"] == ATTEMPT and
            run["repository"]["full_name"] == REPOSITORY and run["path"] == WORKFLOW and
            run["head_branch"] == BRANCH and run["event"] == "push", "Foreign final run")
    require(run["status"] == "completed" and run["conclusion"] == "success", "Run did not succeed")
    require(jobs["total_count"] == 1 and len(jobs["jobs"]) == 1, "Unexpected job set")
    job = jobs["jobs"][0]
    require(job["id"] == JOB and job["run_id"] == RUN and job["head_sha"] == HEAD and
            job["run_attempt"] == ATTEMPT and job["conclusion"] == "success", "Foreign or failed final job")
    require(all(s["status"] == "completed" and s["conclusion"] == "success" for s in job["steps"]),
            "A required job step did not succeed")
    source = evidence / "frozen-source"
    frozen = json_file(source / "manifest.json")
    tree = json_file(evidence / "source-identity/tree.json")
    require(tree["sha"] == TREE and tree["truncated"] is False, "Incomplete expected Git tree")
    expected = {x["path"]: x for x in tree["tree"] if x["type"] == "blob"}
    for row in frozen["files"]:
        actual = identity((source / row["path"]).read_bytes())
        require(actual["git_blob"] == row["git_blob"] == expected[row["path"]]["sha"] and
                actual["sha256"] == row["sha256"], "Frozen source differs from final tree")
    dream = bound_module(source / "tools/verify_dream_rasters.py",
                         "f7296a802d15c382dbcc77640373a0f53e30306fcaab3de869549ff1656de89d",
                         "da8eed7d6383fcbc82a03596518a5fcc3b9a00c5", "baf_dream_reader")
    discovery = bound_module(source / "tools/verify_discovery_connections.py",
                             "5edab9f77acaa4114281b74166eec3dbf306eb5b574f677c03190a379081dfaf",
                             "c00ca9873106c974d66282cddfdcfaf5eb3bbebc", "baf_discovery_reader")
    initial = {r["path"]: r["sha256"] for r in archive_report["regular_files"]}
    source_root = original / "source"
    context = (source_root / "workflow-context.txt").read_text()
    require(context == f"repository={REPOSITORY}\nref=refs/heads/{BRANCH}\nsource={HEAD}\nrun={RUN}\nattempt={ATTEMPT}\njob=discovery-native-acceptance\n",
            "Original workflow context differs")
    for field, wanted in (("sha", HEAD), ("tree", TREE)):
        for phase in ("before", "after"):
            require((source_root / f"{field}-{phase}.txt").read_bytes() == (wanted + "\n").encode(),
                    "Foreign global source stamp")
    for phase in ("before", "after"):
        require((source_root / f"status-{phase}.txt").read_bytes() == b"", "Dirty tracked sources")
    for name in ("index", "index-sha256"):
        require((source_root / f"{name}-before.txt").read_bytes() ==
                (source_root / f"{name}-after.txt").read_bytes(), "Global index changed")
    before, after = (json_file(source_root / f"source-inventory-{phase}.json") for phase in ("before", "after"))
    for field in ("head", "tree", "index_sha256", "tracked"):
        require(before[field] == after[field], "Global tracked snapshot changed")
    require(before["head"] == HEAD and before["tree"] == TREE, "Global snapshot source differs")
    require((source_root / "index-sha256-before.txt").read_bytes() ==
            (before["index_sha256"] + "\n").encode(), "Global index stamp and inventory disagree")
    require({x["path"] for x in before["tracked"]} == set(expected), "Global inventory omits or adds tracked paths")
    for row in before["tracked"]:
        require(row["materialized"] is True and row["actual_blob"] == row["git_blob"] == expected[row["path"]]["sha"] and
                row["mode"] == expected[row["path"]]["mode"], "Global tracked bytes/mode differ")
    tests = []
    for name, count in (("dream-raster-tests.log", 12), ("discovery-originals-tests.log", 24),
                        ("discovery-producer-reader-tests.log", 11)):
        data = (original / "tests" / name).read_bytes()
        text = data.decode()
        require(len(re.findall(rf"^Ran {count} tests in [0-9.]+s$", text, re.M)) == 1 and
                text.splitlines().count("OK") == 1 and
                not re.search(r"^FAILED|\.\.\. skipped |^OK \(", text, re.M), "Original Python test result differs")
        tests.append({"path": "tests/" + name, "tests": count, **identity(data)})
    headless = []
    for name, marker in (
        ("connect_four_return_regression", "CONNECT_FOUR_RETURN_PASS checks=21"),
        ("treasure_wisp_regression", "[TreasureWisp] PASS checks=14"),
        ("treasure_exploration_regression", "[TreasureExploration] PASS 92 checks: branching, actual location questions, movement, legacy saves and original rewards"),
        ("learning_world_regression", "[LearningWorld] PASS checks=5347")):
        data = (original / "headless" / (name + ".log")).read_bytes()
        text = data.decode()
        require(text.splitlines().count(marker) == 1 and not dream.ERRORS.search(text), "Original headless gate differs")
        require(sum(l.startswith("Godot Engine v" + dream.ENGINE + " - ") for l in text.splitlines()) == 1,
                "Headless gate has no unique original engine invocation")
        headless.append({"path": "headless/" + name + ".log", "marker": marker, **identity(data)})
    require((original / "headless/runner.log").read_bytes() ==
            b"".join((original / row["path"]).read_bytes() for row in headless), "Combined headless runner differs")
    dream_result = dream.verify(original / "dream", write=False)
    require(dream_result == json_file(original / "dream/dream-images.json"), "Original Dream acceptance differs")
    discovery_result = discovery.verify(original / "discovery", expected_native_sha=HEAD,
                                        expected_native_tree=TREE, write=False)
    require(discovery_result == json_file(original / "discovery/discovery-acceptance.json"),
            "Original Discovery acceptance differs")
    collection = json_file(original / "discovery/collection-context.json")
    original_evidence = PurePosixPath(collection["output"]).parent
    require(original_evidence.name == "evidence" and original_evidence.parent.name == f"lumo-discovery-{RUN}-{ATTEMPT}" and
            PurePosixPath(collection["output"]).name == "discovery", "Foreign original output prefix")
    adapters = json_file(evidence / "analysis/workflow-replay-provenance.json")
    replay_results = {}
    old_env = os.environ.copy()
    try:
        os.environ.update(GITHUB_WORKSPACE=str(source), LUMO_EXPECTED_NATIVE_SHA=HEAD,
                          LUMO_EXPECTED_NATIVE_TREE=TREE, LUMO_VILLAGE_OUTPUT=str(original / "village-scaling"),
                          LUMO_MINIMAP_OUTPUT=str(original / "mobile-minimap"),
                          LUMO_ORIGINAL_MINIMAP_OUTPUT=str(original_evidence / "mobile-minimap"))
        for row in adapters["adapters"]:
            path = evidence / "analysis" / (row["name"] + "-read-only-replay.py")
            data = path.read_bytes()
            require(identity(data)["sha256"] == row["replay_sha256"], "Read-only adapter differs")
            namespace = {"__name__": "_original_replay_" + row["name"]}
            exec(compile(data, str(path), "exec"), namespace)
            replay_results[row["name"]] = namespace["replay_result"]
    finally:
        os.environ.clear()
        os.environ.update(old_env)
    image_paths = {"dream/" + r["path"] for r in dream_result["original_pngs"]}
    image_paths |= {"discovery/" + r["path"] for r in discovery_result["original_pngs"]}
    image_paths |= {"village-scaling/" + r["path"] for r in replay_results["village"]["images"]}
    image_paths |= {"mobile-minimap/" + r["path"] for key in ("safe_area_images", "minimap_images")
                    for r in replay_results["mobile"][key]}
    require(len(image_paths) == 60 and image_paths == {r["path"] for r in archive_report["decoded_pngs"]},
            "The complete 7+38+2+4+9 raster set differs from original ZIP")
    for path, sha in initial.items():
        require(identity((original / path).read_bytes())["sha256"] == sha, "Original mutated during read-only replay")
    report = {"schema": 1, "status": "PASS", "run": RUN, "job": JOB, "attempt": ATTEMPT,
              "native_source": HEAD, "native_tree": TREE, "python_tests": tests, "python_count": 47,
              "headless": headless, "dream": dream_result, "discovery": discovery_result,
              "village": replay_results["village"], "mobile": replay_results["mobile"],
              "all_original_pngs": archive_report["decoded_pngs"], "png_count": 60,
              "tracked_entries": len(before["tracked"]), "originals_unchanged": True,
              "scope": "Exact separate Native CI and original renderer evidence; no visual review, Android, FPS or full52 acceptance",
              "new_engine_invocations_by_replay": 0}
    write_report(output / "original-replay.json", report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", required=True, type=Path)
    parser.add_argument("--archive", required=True, type=Path)
    parser.add_argument("--artifact-metadata", required=True, type=Path)
    parser.add_argument("--run", required=True, type=Path)
    parser.add_argument("--jobs", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--inventory-only", action="store_true")
    args = parser.parse_args()
    require(not args.output.exists(), "Fresh verification output required")
    args.output.mkdir(parents=True)
    original = args.output / "originals"
    archive_report = inventory_archive(args.archive, args.artifact_metadata, original, args.output)
    print(json.dumps({"archive_verified": True, "entries": archive_report["zip_entries"],
                      "pngs_decoded": len(archive_report["decoded_pngs"])}), flush=True)
    if not args.inventory_only:
        report = verify_originals(args.evidence, original, args.run, args.jobs, archive_report, args.output)
        print(json.dumps({"status": report["status"], "native_source": HEAD, "python": 47,
                          "dream": [5, 7, 2], "discovery": [10, 38, 2], "village": [339, 42, 46],
                          "rendered_mobile_checks": report["mobile"]["checks"], "pngs": 60,
                          "originals_unchanged": True}), flush=True)


if __name__ == "__main__":
    main()
