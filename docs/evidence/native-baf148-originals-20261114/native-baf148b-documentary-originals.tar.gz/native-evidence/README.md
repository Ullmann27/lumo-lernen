# Native baf148b — vollständiger Originalnachweis

Der separate Native-Lauf **43600806315**, Versuch **1**, Job **132464933411**, ist auf
`baf148b03a7a32c6ad9f737d731f900eb9113ea1` / Tree
`0c18a0ca5200ade267cfedb4c12d5c4b0a761a00` vollständig erfolgreich abgeschlossen.
Die technische Prüfung der Originale und die reinen Nachberechnungen sind bestanden.

## Tatsächlicher Umfang

| Gruppe | Originaler Nachweis |
| --- | --- |
| Python | 47 Methoden: 12 + 24 + 11, keine Skips |
| Vier bestehende Headless-Gates | Return21, Wisp14, Treasure92, Learning5347 |
| Dream | 5 Modi, 7 PNGs, 2 Originalberichte |
| Discovery | 10 Modi in vorgeschriebener Reihenfolge, 38 PNGs, 2 Originalberichte |
| Village | Economy339, Scaling42 headless und Scaling46 gerendert; 2 PNGs à 1280×720 |
| Mobile | Tatsächlich gerendert: 428 Prüfungen, 15 Controls, 4 vorhandene Safe-Area-PNGs plus 9 neue Minimap-PNGs; 7 Layouts und 2 Hinweiswechsel |

Die **380** Prüfungen stammen ausschließlich aus dem früheren lokalen
4d2cbb6-Headlesslauf. Sie werden hier nicht als gerenderte oder erneute Headless-Abnahme ausgegeben.

## Originale und Bindung

Das unveränderte ZIP `artifacts/14116698243/native-baf148b-14116698243.zip`
hat **66.871.509 Bytes**, SHA256
`cc04dd13121a2663cf5c6ae3f21e0da8f1105c566fa13fe59fd9c66f038d49db`.
Alle **1.516** Mitglieder wurden vollständig auf CRC, SHA und lokalen Readback geprüft;
alle **60** PNGs wurden vollständig dekodiert. Die vollständigen unveränderten
Mitglieder liegen unter `verification/originals/`.

Die finalen API-Originale liegen unter `snapshots/20261114T140219Z/`.
Das einzelne Artefaktobjekt wurde als exakter Byteausschnitt aus der originalen
API-Liste erhalten; seine Herkunft wird separat dokumentiert. Der vollständige
Joblog liegt unter `jobs/job-132464933411.log`.

Die vor/nach erhaltenen HEAD-, Tree-, Index- und Byteinventare binden alle
**3.689** getrackten Einträge an den aktuellen vollständigen API-Tree. Generierte
UID-/Importdateien sind in den Originalinventaren getrennt dokumentiert.

## Reine Nachprüfung

`verification/original-replay.json` enthält die vollständigen Nachberechnungen.
Die unveränderten Dream-/Discovery-Prüfer wurden vor Import gegen ihre Git-Blobs
und SHA256 gebunden und mit `write=False` ausgeführt. Die beiden ursprünglichen
Workflow-Prüfblöcke für Village und Mobile liegen zusätzlich bytegleich unter
`analysis/`; die kleinen, dokumentierten Adapter vergleichen die gespeicherten
Originalberichte, statt sie zu überschreiben. Nur der ursprüngliche absolute
Capturepfad wird beim Lesen auf den lokalen Archivort abgebildet.
Alle Originaldateien wurden danach erneut unverändert bestätigt. Es wurde keine
Engine, Testsuite, CI-Wiederholung oder Quelländerung gestartet.

## Sichtprüfung und Grenzen

`root-review-candidates-15.json` benennt die zwei Village-, vier Safe-Area- und
neun Minimap-Originale; `root-review-candidates-60.json` enthält den gesamten
aktuellen Bildsatz mit absoluten Pfaden und Originalhashes. Die direkte Sichtprüfung
durch Root wird separat dokumentiert und hier nicht behauptet.

Dieser Lauf belegt den genannten separaten Desktop-Renderer-Vertrag. Er belegt
keine Android-Geräteprüfung, keine FPS-Zusage, keinen vollständigen52/17-Lauf,
keinen Host-APK-Bau und keine Veröffentlichung. Frühere c300-/4d-Ergebnisse
werden nicht auf diese neue Quelle umetikettiert.

## Transport und Retention

Der erste GitHub-Export war erfolgreich. Der anschließende lokale Transporthelfer
scheiterte vor dem Download an einer nicht verfügbaren JavaScript-URL-Klasse.
Dieselbe exportierte Dateireferenz wurde danach erfolgreich materialisiert;
es gab keinen zweiten GitHub-Export und keinen CI-/Testretry. Signierte Downloadlinks
sind nicht Teil dieses Packs. `transfer-history.json` dokumentiert diese Grenze.

Das vollständige Actions-Original läuft laut finalen Metadaten am
**2026-12-14T14:01:59Z** ab. Das gesamte Original-ZIP und sämtliche Mitglieder sind
derzeit lokal erhalten. `original-retention.json` unterscheidet diese aktuelle
Aufbewahrung von einer dauerhaften Veröffentlichung.

## Freeze

`manifest.json` bindet jede reguläre Datei mit relativer Pfadangabe, Bytezahl und
SHA256. `SHA256SUMS` bindet zusätzlich das Manifest. Beide wurden nach Erstellung
vollständig zurückgelesen und geprüft. Der Pack wird danach nicht verändert;
spätere Sichtbelege gehören in einen getrennten Ordner.
