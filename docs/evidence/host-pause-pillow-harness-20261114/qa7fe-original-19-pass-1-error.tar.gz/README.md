# Actual QA7fe targeted validation: FAIL preserved
+
+Executed once on published7fe0b85dd3b51384efed5c94af0618951574b857/tree3c3232daf3c14e8819f639128ededabb5fc603ec. The authorized20-method command returned19PASS/1ERROR/0SKIP in4.287 reported seconds. The separate single-file actionlint returned0. All2,173 materialized tracked source blobs, HEAD/tree/index and clean status remained identical. Before/after source lists are deterministic gzip with verified original-byte roundtrips.
+
+The first new positive Caption test failed at actual PIL.Image.open before selection. The eight subsequent new Caption tests, all nine workflow methods and both previously missing-wrapper methods passed. This is not an Android or resumed-race acceptance. The original PNG/fixture hashes passed setup; the later reversed-order positive original replay passes.
+
+Read-only source diagnosis identifies PIL's initial import inside patch.dict(sys.modules). Python's actual mock implementation removes newly added modules when restoring the dictionary, while probe objects keep references. No correction has been executed here, and no source was changed. The local runtime is Python3.12.14/Pillow13.0.0; the workflow's existing Pillow12.3.0 pin is unchanged. No installation was performed.
+
+The optional old-source positive Red replay was not run after this harness error. No old or lost log was recreated. The three AF_UNIX EPERM cases were not repeated or skipped; this separately authorized run simply contains the named20 methods. The earlier104-method FAIL remains unchanged.
+