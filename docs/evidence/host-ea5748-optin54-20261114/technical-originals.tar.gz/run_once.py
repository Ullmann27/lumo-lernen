#!/usr/bin/env python3
"""Run only the authorized three unittest modules once; retain both streams."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import time

import PIL

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'source'


def identity(data):
    return {'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest(),
            'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}


def write(name, value):
    data=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
    with (ROOT/name).open('xb') as stream:
        stream.write(data)
    assert (ROOT/name).read_bytes()==data


def inventory():
    rows=[]
    for path in sorted(SOURCE.rglob('*')):
        if path.is_file():
            assert not path.is_symlink()
            rows.append({'path':path.relative_to(SOURCE).as_posix(),
                         'filesystem_mode':oct(stat.S_IMODE(path.stat().st_mode)),
                         **identity(path.read_bytes())})
    return rows


def main():
    binding=json.loads((ROOT/'checkpoint-binding.json').read_bytes())
    before=inventory()
    assert len(before)==11
    expected_sources={row['path']:row for row in binding['materialized']}
    for row in before:
        expected=expected_sources[row['path']]
        assert all(row[key]==expected[key] for key in ('bytes','sha256','git_blob'))
        assert row['filesystem_mode']=='0o644'
    write('inventories/before.json',before)
    argv=[sys.executable,'-B','-m','unittest',
          'tools.android_qa.tests.test_connect_four_flutter_navigation',
          'tools.android_qa.tests.test_connect_four_android_evidence',
          'tools.android_qa.tests.test_connect_four_probe_deadlines','-v']
    environment=os.environ.copy()
    removed=[key for key in ('LUMO_C4_PROBE_SOURCE','PYTHONPATH','PYTHONHOME') if key in environment]
    for key in ('LUMO_C4_PROBE_SOURCE','PYTHONPATH','PYTHONHOME'):
        environment.pop(key,None)
    environment.update(PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(ROOT/'temporary'))
    start=datetime.now(timezone.utc).isoformat()
    write('runs/invocation.json',{
        'argv':argv,'cwd':str(SOURCE),'start_utc':start,'outer_timeout_seconds':600,
        'host':binding['host'],'tree':binding['tree'],
        'python':{'version':sys.version,'executable':sys.executable,
                  'resolved_executable':str(Path(sys.executable).resolve())},
        'pillow':{'version':PIL.__version__,'module':PIL.__file__},
        'environment_changes':{'removed_override_names':removed,'PYTHONDONTWRITEBYTECODE':'1',
                               'TMPDIR':str(ROOT/'temporary')},
        'probe_deadlines_unchanged':True,'no_device_engine_flutter_or_ci_execution':True,
    })
    began=time.monotonic()
    timed_out=False
    with (ROOT/'runs/stdout.original').open('xb') as stdout, (ROOT/'runs/stderr.original').open('xb') as stderr:
        process=subprocess.Popen(argv,cwd=SOURCE,env=environment,stdout=stdout,stderr=stderr,
                                 start_new_session=True)
        try:
            returncode=process.wait(timeout=600)
        except subprocess.TimeoutExpired:
            timed_out=True
            os.killpg(process.pid,signal.SIGTERM)
            try:
                returncode=process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL)
                returncode=process.wait()
    ended=datetime.now(timezone.utc).isoformat()
    elapsed=time.monotonic()-began
    after=inventory()
    write('inventories/after.json',after)
    stdout=(ROOT/'runs/stdout.original').read_bytes()
    stderr=(ROOT/'runs/stderr.original').read_bytes()
    text=stderr.decode('utf-8')
    methods=json.loads((ROOT/'expected-methods.json').read_bytes())
    completed=re.findall(r'^test_[^\n]+ \(([^()\n]+)\) \.\.\. ok$',text,re.MULTILINE)
    summary=re.findall(r'^Ran (\d+) tests in ([0-9.]+)s$',text,re.MULTILINE)
    checks={'exit_zero':returncode==0,'no_outer_timeout':not timed_out,'sources_unchanged':before==after,
            'all_54_unique_methods_ok':len(completed)==54 and len(set(completed))==54
                                      and set(completed)==set(methods),
            'summary_54':len(summary)==1 and summary[0][0]=='54',
            'final_ok':re.search(r'\nOK\s*\Z',text) is not None,
            'no_failures_errors_skips_expected_failures':not re.search(
                r'(?m)(\.\.\. (?:FAIL|ERROR|skipped|expected failure|unexpected success)|^FAILED|^OK \()',text)}
    write('runs/result.json',{'status':'PASS' if all(checks.values()) else 'FAIL',
        'actual_returncode':returncode,'termination_signal':-returncode if returncode<0 else None,
        'outer_timeout':timed_out,'start_utc':start,'end_utc':ended,'elapsed_seconds':elapsed,
        'checks':checks,'actual_successful_method_ids':completed,'original_summary':summary,
        'stdout':identity(stdout),'stderr':identity(stderr),
        'scope':'Local synthetic Python contracts on exact published source only. No Android, Widget, engine, FPS or release acceptance.'})
    print(json.dumps({'root':str(ROOT),'returncode':returncode,'elapsed_seconds':elapsed,
                      'checks':checks,'passed_methods':len(completed)},ensure_ascii=False))
    return 0 if all(checks.values()) else 1


if __name__=='__main__':
    raise SystemExit(main())
