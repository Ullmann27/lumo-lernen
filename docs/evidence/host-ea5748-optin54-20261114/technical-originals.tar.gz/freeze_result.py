#!/usr/bin/env python3
"""Archive the completed single-run originals and byte-compare every member."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

ROOT=Path(__file__).resolve().parent


def identity(data):
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
            'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}


def write(name,value):
    data=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
    with (ROOT/name).open('xb') as stream:
        stream.write(data)
    assert (ROOT/name).read_bytes()==data
    return identity(data)


def main():
    binding=json.loads((ROOT/'checkpoint-binding.json').read_bytes())
    actual=json.loads((ROOT/'runs/result.json').read_bytes())
    reconciled_path=ROOT/'original-result-reconciliation.json'
    reconciled=json.loads(reconciled_path.read_bytes()) if reconciled_path.is_file() else None
    result=reconciled if reconciled is not None else actual
    # Always retain the first outer-counter diagnosis and actual subprocess exit.
    sources=[]
    before=json.loads((ROOT/'inventories/before.json').read_bytes())
    for row in before:
        source=ROOT/'source'/row['path']
        assert identity(source.read_bytes())=={key:row[key] for key in ('bytes','sha256','git_blob')}
        sources.append({'path':row['path'],**identity(source.read_bytes())})
    handoff=write('handoff.json',{
        'status':result['status'],'host':binding['host'],'tree':binding['tree'],
        'native_unchanged':'f9d9772bb932d7ee8702eeb5bca6d98c286f3b98',
        'run_count':1,'actual_unittest_exit_code':actual['actual_returncode'],
        'start_utc':actual['start_utc'],'end_utc':actual['end_utc'],
        'elapsed_seconds':actual['elapsed_seconds'],'outer_timeout':actual['outer_timeout'],
        'original_outer_counter_status':actual['status'],
        'outer_counter_diagnostic_preserved':True,
        'reconciliation':identity(reconciled_path.read_bytes()) if reconciled is not None else None,
        'actual_methods':result.get('completed_methods'),
        'counts':result.get('counts_by_module'),
        'source_files':sources,'all_materialized_source_bytes_and_modes_unchanged':actual['checks']['sources_unchanged'],
        'exact_git_tree_reconstructed':binding['full_tree_reconstructed_from_all_leaves'],
        'tree_leaves':4925,'materialized_files':11,'explicitly_unmaterialized_paths':4914,
        'source_view':'source/; exact partial checkpoint view, not a full Git checkout or index check',
        'environment':{'python':'3.12.14','pillow':'13.0.0'},
        'scope':'Synthetic local Python navigation/evidence/deadline contracts only; no Widget, Android, Native engine, FPS, release, CI or ref action.',
    })
    readme='''# C4 opt-in V2: one exact-checkpoint Python contract run

The eleven materialized files in source/ match their Git blob IDs in the complete published ea5748f42c82b8f0690ce32f42dc3a01342af392 tree. Rebuilding all 4,925 tree leaves independently gives 65f2d0aa1fec45cd4c875154fe230a1f8c8e0aa9. The remaining 4,914 paths are explicitly not materialized. This is a partial source view, not a fabricated full Git checkout/index result.

Exactly one subprocess executes the three authorized unittest modules. runs/invocation.json contains the actual argv, cwd, start time, interpreter/dependency identities, explicit environment handling and the 600-second outer limit. runs/stdout.original and runs/stderr.original are complete unchanged streams. runs/result.json preserves the actual subprocess exit, elapsed/end time and the initial outer report. All eleven source files and modes are inventoried before and after; no test source was altered during execution.

Pillow 13.0.0 emits one getdata DeprecationWarning inside the first complete evidence test's verbose result line. The original single-line accounting regex consequently misses that method's genuine standalone following ok. The first counter result is retained unchanged. When present, original-result-reconciliation.json reads the same original stream, binds both line numbers and every expected method ID, and accounts for that split result without rerunning, modifying or suppressing anything. read_original_result.py is included in full.

No Flutter, Android, engine, gameplay or release acceptance is claimed. Synthetic unit-test temporary images are fixture inputs created and disposed by the unchanged tests, not device originals. Every archive member is read back fully and compared to the local original bytes; large unrelated packs and existing worktrees are untouched.
'''
    with (ROOT/'README.md').open('x') as stream:
        stream.write(readme)
    excluded={'technical-originals.tar.gz','archive-roundtrip.json','manifest.json','SHA256SUMS'}
    paths=[path for path in sorted(ROOT.rglob('*')) if path.is_file()
           and path.name not in excluded and 'temporary' not in path.relative_to(ROOT).parts]
    rows=[{'path':path.relative_to(ROOT).as_posix(),**identity(path.read_bytes())} for path in paths]
    archive=ROOT/'technical-originals.tar.gz'
    with archive.open('xb') as stream:
        with gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as compressed:
            with tarfile.open(fileobj=compressed,mode='w') as tar:
                for path,row in zip(paths,rows):
                    data=path.read_bytes();member=tarfile.TarInfo(row['path'])
                    member.size=len(data);member.mode=0o644;member.mtime=0
                    tar.addfile(member,io.BytesIO(data))
    with tarfile.open(archive,'r:gz') as tar:
        members=tar.getmembers()
        assert [item.name for item in members]==[row['path'] for row in rows]
        for item,row,path in zip(members,rows,paths):
            assert item.isfile()
            data=tar.extractfile(item).read();assert data==path.read_bytes()
            assert identity(data)=={key:row[key] for key in ('bytes','sha256','git_blob')}
    write('archive-roundtrip.json',{'status':'ALL_MEMBERS_BYTE_EQUAL','archive':identity(archive.read_bytes()),
        'members':rows,'member_count':len(rows),'test_process_runs':1})
    manifest=write('manifest.json',{'schema':1,'status':'FROZEN','files':[
        {'path':path.relative_to(ROOT).as_posix(),**identity(path.read_bytes())}
        for path in sorted(ROOT.rglob('*')) if path.is_file()
        and path.name not in ('manifest.json','SHA256SUMS') and 'temporary' not in path.relative_to(ROOT).parts]})
    data=json.loads((ROOT/'manifest.json').read_bytes())
    with (ROOT/'SHA256SUMS').open('x') as stream:
        stream.write(''.join(row['sha256']+'  '+row['path']+'\n' for row in data['files'])+
                     manifest['sha256']+'  manifest.json\n')
    print(json.dumps({'root':str(ROOT),'status':result['status'],'handoff':handoff,'manifest':manifest,
                      'archive':identity(archive.read_bytes()),'members':len(rows)}))


if __name__=='__main__':
    main()
