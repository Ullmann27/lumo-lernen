# C4 pressed target and observed state follow-up

Base: Host2b586530. Four source paths only. The production change is `pressedScale: 1` on the existing column control. The current 491 common scroll region, adaptive phone padding, board inset, owner/save/native bridge logic are preserved. Three producer test files add genuine bounded readiness, six observed moves, pressed target geometry and delayed native-refusal observations; existing `ensureVisible` calls remain.

No local test ran on this combination. The original producer18c12 CI job actually completed 2,562 Flutter cases without failures/skips, then failed its Python suite at the historical unchanged-APK source-pin fixture. This is separate producer evidence, not acceptance of this new combination. No APK or large screenshot artifact was downloaded or reviewed.

`source-freeze.json` binds before/producer/final blobs; `integration.patch` is the exact change against2b; `original-bindings.json` binds every complete original compressed file. All archive members were read back byte-for-byte. Root owns application, commit and fresh CI.
