"""One authorized nine-method run and one bound original positive-case Red replay."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import time

OUT = Path(__file__).resolve().parent
ROOT = Path('/tmp/lumo-root-recovery-0900/host-qa')
PYTHON = Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3')
OLD = Path('/workspace/scratch/b3485b7bb989/host-pr486-pause-caption-repair-20261114/before')
HEAD = '1cc5cf4fb7da382fb9833b9d52cf53540306b405'
TREE = '14a111981a80b629b533a22ad519a858fdadc989'
ENV = os.environ.copy()
ENV.update(PYTHONDONTWRITEBYTECODE='1', REQUIRE_ALL_TESTS='true', GIT_OPTIONAL_LOCKS='0',
           PYTHONPATH=str(ROOT / 'tools/android_qa/tests'))
for key in ('LUMO_PAUSE_SOURCE_ROOT', 'LUMO_RUNTIME_ANR_SOURCE_ROOT', 'LUMO_SPEECH_SECTION_SOURCE_ROOT'):
    ENV.pop(key, None)


def utc():
    return datetime.now(timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save_json(name, value):
    path = OUT / name
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def git(*args):
    return subprocess.run(['git', *args], cwd=ROOT, env=ENV, check=True,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout


def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': digest(data)}


def snapshot(label):
    head = git('rev-parse', 'HEAD').decode().strip()
    tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
    status = git('-c', 'core.quotepath=false', 'status', '--porcelain=v1', '--untracked-files=all')
    assert head == HEAD and tree == TREE and status == b'', (head, tree, status)
    indexed = git('ls-files', '-s', '-z')
    rows = []
    for entry in indexed.split(b'\0'):
        if not entry:
            continue
        meta, name = entry.split(b'\t', 1)
        mode, blob, stage = meta.decode().split()
        assert stage == '0'
        relative = name.decode()
        path = ROOT / relative
        if not path.exists() and not path.is_symlink():
            continue
        data = os.readlink(path).encode() if path.is_symlink() else path.read_bytes()
        actual_blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert actual_blob == blob, relative
        rows.append({'path': relative, 'mode': mode, 'git_blob': blob,
                     'bytes': len(data), 'sha256': digest(data)})
    index = Path(git('rev-parse', '--git-path', 'index').decode().strip())
    if not index.is_absolute():
        index = ROOT / index
    report = {'head': head, 'tree': tree, 'status': status.decode(),
              'git_index_sha256': digest(index.read_bytes()), 'ls_files_sha256': digest(indexed),
              'materialized_tracked_files': rows,
              'red_before_sources': [identity(OLD / '.github/probes' / name)
                                     for name in ('creative_android_probe.py', 'modernization_android_tour.py')]}
    raw = (json.dumps(report, sort_keys=True, indent=2) + '\n').encode()
    packed = gzip.compress(raw, mtime=0)
    assert gzip.decompress(packed) == raw
    (OUT / (label + '-sources.json.gz')).write_bytes(packed)
    (OUT / (label + '-git-status.txt')).write_bytes(status)
    binding = {'observed_at': utc(), 'source_count': len(rows), 'original_bytes': len(raw),
               'original_sha256': digest(raw), 'gzip_bytes': len(packed),
               'gzip_sha256': digest(packed), 'roundtrip_byte_equal': True,
               'head': head, 'tree': tree, 'git_index_sha256': report['git_index_sha256']}
    save_json(label + '-binding.json', binding)
    return report, binding


def phase(name, argv, *, extra_env=None, seconds=180):
    env = ENV.copy()
    env.update(extra_env or {})
    started = utc()
    tick = time.monotonic()
    try:
        result = subprocess.run(argv, cwd=ROOT, env=env, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, timeout=seconds)
        raw, code, timeout = result.stdout, result.returncode, False
    except subprocess.TimeoutExpired as error:
        raw, code, timeout = error.stdout or b'', None, True
    path = OUT / (name + '.log')
    path.write_bytes(raw)
    text = raw.decode('utf-8', errors='replace')
    counts = re.findall(r'^Ran (\d+) tests? in ([^\n]+)', text, re.M)
    status = re.findall(r'^(OK(?: \([^\n]+\))?|FAILED(?: \([^\n]+\))?)$', text, re.M)
    row = {'phase': name, 'argv': argv, 'cwd': str(ROOT), 'started_at': started,
           'completed_at': utc(), 'elapsed_seconds': time.monotonic() - tick,
           'exit_code': code, 'timeout': timeout, 'timeout_seconds': seconds,
           'log': identity(path), 'reported_runs': counts, 'reported_summary': status,
           'environment_overrides': extra_env or {}}
    save_json(name + '-result.json', row)
    print(json.dumps(row), flush=True)
    return row, text


save_json('execution-environment.json', {
    'created_at': utc(), 'platform': platform.platform(), 'python_path': str(PYTHON),
    'python_version': subprocess.run([str(PYTHON), '--version'], check=True, capture_output=True, text=True).stdout.strip(),
    'pillow_version': subprocess.run([str(PYTHON), '-B', '-c', 'from importlib.metadata import version; print(version("Pillow"))'], check=True, capture_output=True, text=True).stdout.strip(),
    'base_environment': {key: ENV[key] for key in ('PYTHONDONTWRITEBYTECODE', 'REQUIRE_ALL_TESTS', 'GIT_OPTIONAL_LOCKS', 'PYTHONPATH')},
    'scope': 'Only nine Pause contracts and the one separately bound original Red. No actionlint, passed neighbors, sockets, installation, device, Git mutation or CI action.'})
for relative in ('.github/probes/creative_android_probe.py', '.github/probes/modernization_android_tour.py'):
    assert (OLD / relative).read_bytes() == git('show', '0d7ea79cd02b921ed685abc79b27df8a5f6b4ccb:' + relative), relative
assert identity(ROOT / 'tools/android_qa/tests/test_kart_continue_caption.py')['sha256'] == 'fb7ff4ed94b61bd266b9eb2ec6dd2d1fb9de6c08891a909cf875af40165101e9'
before, before_binding = snapshot('before')
green, green_text = phase('pause-nine', [str(PYTHON), '-B', '-m', 'unittest', '-v', 'tools.android_qa.tests.test_kart_continue_caption'])
clean_green = green['exit_code'] == 0 and bool(re.search(r'^Ran 9 tests in ', green_text, re.M)) and green['reported_summary'] == ['OK']
red = None
if clean_green:
    red, red_text = phase('original-caption-red', [str(PYTHON), '-B', '-m', 'unittest', '-v', 'tools.android_qa.tests.test_kart_continue_caption.KartContinueCaptionTests.test_actual_two_frame_continue_targets_the_independent_caption'], extra_env={'LUMO_PAUSE_SOURCE_ROOT': str(OLD)})
    red['expected_original_misclick_observed'] = (red['exit_code'] == 1 and "('1694', '282', '1694', '282')" in red_text and "('1262', '408', '1262', '408')" in red_text and red['reported_summary'] == ['FAILED (failures=1)'])
    red['original_production_source'] = '0d7ea79cd02b921ed685abc79b27df8a5f6b4ccb'
    red['scope'] = 'Same current test and original PNG/OCR fixtures, with only the two production modules loaded from their verified0d before bytes. Synthetic mocked-ADB replay, not a real device result.'
    save_json('original-caption-red-result.json', red)
after, after_binding = snapshot('after')
save_json('result.json', {'status': 'PASS' if clean_green and red and red.get('expected_original_misclick_observed') and before == after else 'FAIL', 'source': HEAD, 'tree': TREE, 'source_unchanged': before == after, 'before': before_binding, 'after': after_binding, 'targeted': green, 'separate_original_red': red, 'three_AF_UNIX_methods_repeated': False, 'actionlint_repeated': False, 'previous11_passed_neighbors_repeated': False, 'new_Android_or_resume_claim': False})
print((OUT / 'result.json').read_text(), flush=True)
