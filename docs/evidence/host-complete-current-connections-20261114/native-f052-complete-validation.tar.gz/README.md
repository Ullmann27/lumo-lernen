# Native Magic validation on the exact combined f052 source

**Result: original engine import and all three authorized Headless regressions PASS; local rendered validation blocked before Godot starts.**

Source: `f052c2795b765265dbb6f5c27b9e92b557d39a39`, tree `35492eec16cac6774bc546b6e57628900bef61cb`. Godot binary/version and SHA256, strict runner blob/hash, original argv, isolated XDG environments, timestamps and deadlines are preserved in the original reports. `tools/run_godot_probe.py` was used unchanged (blob `c23859ece2d62101d000d7a89556fda5d3fe4105`).

| Actual execution | Result | Elapsed seconds |
|---|---|---:|
| Original `--headless --editor --import --quit` | clean exit, no strict error | 9.592106 |
| `treasure_wisp_regression` | `[TreasureWisp] PASS checks=14` | 0.465080 |
| `treasure_exploration_regression`, Headless | `[TreasureExploration] PASS 92 checks` | 1.877838 |
| `learning_world_regression`, Headless | `[LearningWorld] PASS checks=5347` | 19.722632 |

The Wisp deadline was 180 seconds; Treasure and Learning retained their actual existing core Headless budgets of 420 seconds. Every actual engine log and runner console log is retained in full. These runs contain no strict engine/GDScript error lines or WARNING lines. No C4 return test and no complete 52-mode suite was repeated.

## Actual renderer setup failure

The one authorized Xorg dummy attempt selected unused display `:186`, with a private mode0600 Xauthority cookie, an output-local configuration, `-nolisten tcp`, its own process session and a 2560×2560 dummy screen. Xorg exited with code 1 before it established a display. Its original log says that both local and Unix listeners could not open, followed by `Cannot establish any listening sockets`. The log does not expose the syscall errno. A specific EPERM, port conflict or GPU driver cause is therefore not asserted.

The Godot rendered probe was **not started**. No current PNG was produced; the three expected filenames remain `treasure_choose_route.png`, `treasure_garden_first.png` and `treasure_route_complete.png`. No historical or Producer image is substituted. No retry, package installation, alternate TCP path, foreign-session modification or renderer success is claimed. The only owned Xorg process is stopped and its ephemeral cookie was removed. The red setup result and full original logs are retained unchanged.

## Source and generated UID integrity

All 1439 materialized tracked files, 2139 sparse-absent index entries, HEAD, tree, tracked status and index hash are unchanged across import, Headless probes and the failed renderer setup. The import generated exactly 330 untracked `.uid` files. Their paths, sizes and hashes are recorded in the snapshots and `uid-inventory.json`; the exact original bytes are separately preserved in `generated-untracked-uids.tar.gz`. None was deleted and no `git clean`, checkout, reset, index write or source repair was performed.

The complete source snapshots and all original command reports are stored losslessly. `original-storage-map.json` binds raw and stored hashes. Only the reproducible editor documentation cache is excluded from this compact package, with an exact hash inventory; it remains in the original output directory. No import cache, APK, large binary asset or private Xauthority credential is included.

## Acceptance boundary

This is new local evidence on the actual combined f052 source. It establishes the three stated Headless results and source integrity. It does not establish the complete 52-mode/17-raster acceptance, rendered Magic pixels, Android input, physical-device performance, 60 FPS, visual approval, release approval or a new native pin. Current combined renderer evidence remains required.

All commands were run under `/tmp/lumo-root-recovery-0900/native-magic-validation` for outputs and the exact separate native checkout for source. This compact package is ready for immediate Git-backed preservation by Root.
