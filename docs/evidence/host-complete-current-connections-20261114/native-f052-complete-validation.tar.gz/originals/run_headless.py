#!/usr/bin/env python3
"""Execute only the explicitly authorized Native Magic import/headless gates."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import signal
import subprocess
import sys
import time

ROOT = Path('/tmp/lumo-root-recovery-0900/native')
OUT = Path('/tmp/lumo-root-recovery-0900/native-magic-validation')
EXPECTED_HEAD = 'f052c2795b765265dbb6f5c27b9e92b557d39a39'
EXPECTED_TREE = '35492eec16cac6774bc546b6e57628900bef61cb'
GODOT = '/opt/godot/4.6.3/Godot_v4.6.3-stable_linux.x86_64'
ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1')


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write_json(name, data):
    target = OUT / name
    if target.exists():
        raise RuntimeError(f'Refusing to replace evidence: {target}')
    target.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, env=ENV)


def snapshot(name):
    files = []
    missing = []
    for entry in git('ls-files', '--stage', '-z').split(b'\0'):
        if not entry:
            continue
        info, raw_path = entry.split(b'\t', 1)
        mode, blob, stage = info.decode().split()
        path = raw_path.decode()
        if stage != '0':
            raise RuntimeError(f'Unmerged index entry: {path}')
        target = ROOT / path
        if not target.is_file():
            missing.append({'path': path, 'blob': blob, 'mode': mode})
            continue
        files.append({'path': path, 'blob': blob, 'mode': mode,
                      'bytes': target.stat().st_size, 'sha256': digest(target)})
    raw_index = git('rev-parse', '--git-path', 'index').decode().strip()
    index = Path(raw_index)
    if not index.is_absolute():
        index = ROOT / index
    untracked = git('ls-files', '--others', '--exclude-standard', '-z').split(b'\0')
    generated = []
    for raw_path in untracked:
        if not raw_path:
            continue
        path = raw_path.decode()
        target = ROOT / path
        generated.append({'path': path, 'bytes': target.stat().st_size,
                          'sha256': digest(target), 'uid': path.endswith('.uid')})
    report = {
        'captured_at': utc(), 'root': str(ROOT),
        'head': git('rev-parse', 'HEAD').decode().strip(),
        'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
        'tracked_status': git('status', '--porcelain=v1', '--untracked-files=no').decode(),
        'index_path': str(index), 'index_sha256': digest(index),
        'materialized_files': files, 'materialized_count': len(files),
        'sparse_absent_files': missing, 'sparse_absent_count': len(missing),
        'untracked_files': generated,
    }
    write_json(name, report)
    return report


def same_sources(before, after):
    fields = ('head', 'tree', 'tracked_status', 'index_sha256',
              'materialized_files', 'sparse_absent_files')
    return {key: before[key] == after[key] for key in fields}


def case(case_id, command, timeout, engine_log=None, required=None):
    env = dict(ENV)
    for key, suffix in [('XDG_DATA_HOME', 'data'), ('XDG_CONFIG_HOME', 'config'),
                        ('XDG_CACHE_HOME', 'cache')]:
        directory = OUT / 'xdg' / case_id / suffix
        directory.mkdir(parents=True)
        env[key] = str(directory)
    console = OUT / f'{case_id}-console.log'
    if console.exists():
        raise RuntimeError(f'Existing case evidence: {case_id}')
    start = time.monotonic()
    result = {'case': case_id, 'command': command, 'cwd': str(ROOT),
              'environment': {k: env[k] for k in ['XDG_DATA_HOME', 'XDG_CONFIG_HOME',
                                                 'XDG_CACHE_HOME', 'PYTHONDONTWRITEBYTECODE',
                                                 'GIT_OPTIONAL_LOCKS']},
              'started_at': utc(), 'outer_deadline_seconds': timeout,
              'console_log': console.name, 'required_marker': required}
    print(f'START {case_id} {result["started_at"]}', flush=True)
    with console.open('xb') as output:
        process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=output,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        try:
            result['returncode'] = process.wait(timeout=timeout)
            result['outer_timeout'] = False
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            result['returncode'] = process.returncode
            result['outer_timeout'] = True
    result['completed_at'] = utc()
    result['duration_seconds'] = round(time.monotonic() - start, 6)
    result['console_sha256'] = digest(console)
    inspected = OUT / engine_log if engine_log else console
    text = inspected.read_text(errors='replace')
    result['engine_log'] = str(inspected.relative_to(OUT))
    result['engine_log_sha256'] = digest(inspected)
    result['strict_error_lines'] = [line for line in text.splitlines()
                                    if re.search(r'SCRIPT ERROR|Parse Error|ERROR:|Assertion failed', line)]
    result['pass_lines'] = [line for line in text.splitlines() if 'PASS' in line]
    result['warnings'] = [line for line in text.splitlines() if 'WARNING:' in line]
    result['success'] = (result['returncode'] == 0 and not result['outer_timeout']
                         and not result['strict_error_lines']
                         and (required is None or required in text))
    write_json(f'{case_id}-result.json', result)
    print(json.dumps({k: result[k] for k in ['case', 'returncode', 'duration_seconds',
                                           'success', 'pass_lines', 'strict_error_lines']},
                     ensure_ascii=False), flush=True)
    return result


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    before = snapshot('before.json')
    if before['head'] != EXPECTED_HEAD or before['tree'] != EXPECTED_TREE or before['tracked_status']:
        raise RuntimeError('Actual combined source identity or tracked cleanliness differs')
    freeze_path = Path('/workspace/scratch/b3485b7bb989/native-pr172-174-magic-integration-f0c19-20261114/source-freeze.json')
    freeze = json.loads(freeze_path.read_text())
    for item in freeze['source_files']:
        path = ROOT / item['path']
        if digest(path) != item['sha256']:
            raise RuntimeError(f'Frozen product source differs: {item["path"]}')
    runner = ROOT / 'tools/run_godot_probe.py'
    data = runner.read_bytes()
    runner_blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    if runner_blob != 'c23859ece2d62101d000d7a89556fda5d3fe4105':
        raise RuntimeError('Strict probe runner differs')
    write_json('execution-binding.json', {
        'head': EXPECTED_HEAD, 'tree': EXPECTED_TREE,
        'source_freeze_sha256': digest(freeze_path),
        'strict_runner_blob': runner_blob, 'strict_runner_sha256': digest(runner),
        'godot': GODOT, 'godot_sha256': digest(Path(GODOT)),
        'python': sys.executable, 'python_version': sys.version,
        'c4_return_regression_repeated': False,
        'purpose': 'Authorized original import and three actual Headless Magic regressions only.',
    })
    results = []
    imported = case('import', [GODOT, '--headless', '--editor', '--import', '--quit'], 600)
    results.append(imported)
    after_import = snapshot('after-import.json')
    import_binding = same_sources(before, after_import)
    write_json('after-import-source-comparison.json', import_binding)
    if imported['success'] and all(import_binding.values()):
        for name, timeout, marker in [
            ('treasure_wisp_regression', 180, '[TreasureWisp] PASS'),
            ('treasure_exploration_regression', 420, '[TreasureExploration] PASS'),
            ('learning_world_regression', 420, '[LearningWorld] PASS'),
        ]:
            log = name + '-headless.log'
            command = [sys.executable, '-B', 'tools/run_godot_probe.py', '--log', str(OUT / log),
                       '--timeout', str(timeout), '--required', marker, '--', GODOT,
                       '--headless', '--path', '.', '--audio-driver', 'Dummy',
                       '--script', 'scripts/tests/' + name + '.gd']
            result = case(name, command, timeout + 15, log, marker)
            result['probe_deadline_seconds'] = timeout
            results.append(result)
            if not result['success']:
                break
    after = snapshot('after-headless.json')
    comparison = same_sources(before, after)
    report = {'head': EXPECTED_HEAD, 'tree': EXPECTED_TREE, 'cases': results,
              'source_comparison': comparison,
              'success': len(results) == 4 and all(x['success'] for x in results)
                         and all(comparison.values()),
              'generated_untracked_uid_count': sum(x['uid'] for x in after['untracked_files']),
              'no_generated_files_deleted': True, 'renderer_started': False,
              'android_or_device_fps_claim': False}
    write_json('headless-results.json', report)
    print(json.dumps({'headless_complete': report['success'],
                      'source_comparison': comparison,
                      'generated_uid_count': report['generated_untracked_uid_count']},
                     ensure_ascii=False), flush=True)
    return 0 if report['success'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
