#!/usr/bin/env python3
"""One authorized rendered Treasure probe on a private existing Xorg dummy server."""
from pathlib import Path
import importlib.util
import json
import os
import secrets
import shutil
import signal
import subprocess
import sys
import time

HERE = Path('/tmp/lumo-root-recovery-0900/native-magic-validation')
spec = importlib.util.spec_from_file_location('magic_validation', HERE / 'run_headless.py')
validation = importlib.util.module_from_spec(spec)
spec.loader.exec_module(validation)

CONFIG = '''Section "ServerFlags"
    Option "AutoAddDevices" "false"
    Option "AllowMouseOpenFail" "true"
    Option "DontVTSwitch" "true"
EndSection

Section "Device"
    Identifier "MagicPrivateDummy"
    Driver "dummy"
    VideoRam 256000
EndSection

Section "Monitor"
    Identifier "MagicPrivateMonitor"
    HorizSync 5.0-1000.0
    VertRefresh 5.0-200.0
    Modeline "2560x2560" 430.85 2560 2608 2640 2720 2560 2563 2568 2640 +HSync -VSync
EndSection

Section "Screen"
    Identifier "MagicPrivateScreen"
    Device "MagicPrivateDummy"
    Monitor "MagicPrivateMonitor"
    DefaultDepth 24
    SubSection "Display"
        Depth 24
        Modes "2560x2560"
        Virtual 2560 2560
    EndSubSection
EndSection
'''


def main():
    before = validation.snapshot('before-rendered.json')
    if (before['head'] != validation.EXPECTED_HEAD
            or before['tree'] != validation.EXPECTED_TREE
            or before['tracked_status']):
        raise RuntimeError('Combined source changed before rendered validation')
    if not shutil.which('Xorg') or not shutil.which('xauth'):
        raise RuntimeError('Existing Xorg/xauth prerequisite unavailable; no installation allowed')
    number = next((n for n in range(186, 220)
                   if not Path(f'/tmp/.X{n}-lock').exists()
                   and not Path(f'/tmp/.X11-unix/X{n}').exists()), None)
    if number is None:
        raise RuntimeError('No unused private display number in the bounded range')
    display = ':' + str(number)
    config = HERE / 'xorg-dummy.conf'
    config.write_text(CONFIG)
    auth = HERE / 'private-Xauthority'
    auth.touch(mode=0o600, exist_ok=False)
    cookie = secrets.token_hex(16)
    xauth_command = ['xauth', '-f', str(auth), 'add', display, 'MIT-MAGIC-COOKIE-1', cookie]
    xauth = subprocess.run(xauth_command, capture_output=True, timeout=10)
    (HERE / 'xauth.stdout').write_bytes(xauth.stdout)
    (HERE / 'xauth.stderr').write_bytes(xauth.stderr)
    if xauth.returncode:
        raise RuntimeError('Private Xauthority preparation failed')
    command = [shutil.which('Xorg'), display, '-config', str(config),
               '-logfile', str(HERE / f'Xorg.{number}.log'),
               '-nolisten', 'tcp', '-noreset', '-auth', str(auth)]
    report = {'head': before['head'], 'tree': before['tree'], 'display': display,
              'xorg_command': command, 'xorg_config_sha256': validation.digest(config),
              'private_authorization': 'Ephemeral MIT-MAGIC-COOKIE-1, mode0600; never included in evidence.',
              'xauth_command': xauth_command[:-1] + ['[PRIVATE COOKIE OMITTED]'],
              'xauth_returncode': xauth.returncode, 'started_at': validation.utc(),
              'server_started': False, 'probe_started': False,
              'foreign_display_or_process_modified': False, 'installed_packages': False,
              'device_or_fps_claim': False}
    server = None
    console = None
    try:
        console = (HERE / 'xorg-console.log').open('xb')
        server = subprocess.Popen(command, stdout=console, stderr=subprocess.STDOUT,
                                  env=validation.ENV, start_new_session=True)
        report['server_pid'] = server.pid
        report['server_process_stat'] = Path(f'/proc/{server.pid}/stat').read_text()
        ready_deadline = time.monotonic() + 15
        socket_path = Path(f'/tmp/.X11-unix/X{number}')
        while time.monotonic() < ready_deadline and server.poll() is None:
            if socket_path.exists():
                break
            time.sleep(0.1)
        report['server_started'] = socket_path.exists() and server.poll() is None
        if not report['server_started']:
            report['setup_failure'] = 'Private Xorg did not establish its own display socket.'
        else:
            validation.ENV.update({'DISPLAY': display, 'XAUTHORITY': str(auth),
                                   'LIBGL_ALWAYS_SOFTWARE': '1',
                                   'TREASURE_EXPLORATION_CAPTURE_DIR': str(HERE / 'images')})
            report['renderer_environment'] = {k: validation.ENV[k] for k in
                ['DISPLAY', 'XAUTHORITY', 'LIBGL_ALWAYS_SOFTWARE', 'TREASURE_EXPLORATION_CAPTURE_DIR']}
            xdpyinfo = shutil.which('xdpyinfo')
            if xdpyinfo:
                info = subprocess.run([xdpyinfo, '-display', display], env=validation.ENV,
                                      capture_output=True, timeout=15)
                (HERE / 'xdpyinfo.stdout').write_bytes(info.stdout)
                (HERE / 'xdpyinfo.stderr').write_bytes(info.stderr)
                report['display_query_command'] = [xdpyinfo, '-display', display]
                report['display_query_returncode'] = info.returncode
                if info.returncode:
                    raise RuntimeError('Private authenticated display query failed')
            images = HERE / 'images'
            images.mkdir()
            log = 'treasure_exploration_regression-rendered.log'
            probe = [sys.executable, '-B', 'tools/run_godot_probe.py', '--log', str(HERE / log),
                     '--timeout', '600', '--required', '[TreasureExploration] PASS', '--',
                     validation.GODOT, '--rendering-method', 'gl_compatibility',
                     '--audio-driver', 'Dummy', '--path', '.', '--script',
                     'scripts/tests/treasure_exploration_regression.gd']
            report['probe_started'] = True
            report['probe'] = validation.case('treasure_exploration_rendered', probe, 615,
                                              log, '[TreasureExploration] PASS')
            report['probe']['probe_deadline_seconds'] = 600
            from PIL import Image
            image_rows = []
            expected = ['treasure_choose_route.png', 'treasure_garden_first.png',
                        'treasure_route_complete.png']
            for name in expected:
                file = images / name
                if not file.exists():
                    image_rows.append({'path': str(file.relative_to(HERE)), 'missing': True})
                    continue
                with Image.open(file) as image:
                    image.verify()
                with Image.open(file) as image:
                    image.load()
                    dimensions, mode = list(image.size), image.mode
                image_rows.append({'path': str(file.relative_to(HERE)), 'bytes': file.stat().st_size,
                                   'sha256': validation.digest(file), 'dimensions': dimensions,
                                   'mode': mode, 'complete_png_decode': True,
                                   'source_window_size_matches': dimensions == [1280, 720]})
            report['images'] = image_rows
            report['all_three_images_decoded'] = all(x.get('complete_png_decode') for x in image_rows)
    except Exception as error:
        report['exception'] = {'type': type(error).__name__, 'message': str(error)}
    finally:
        if server is not None:
            report['server_returncode_before_cleanup'] = server.poll()
            if server.poll() is None:
                os.killpg(server.pid, signal.SIGTERM)
                try:
                    server.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(server.pid, signal.SIGKILL)
                    server.wait()
                    report['own_server_required_sigkill'] = True
            report['server_final_returncode'] = server.returncode
            report['own_server_stopped'] = server.poll() is not None
        if console is not None:
            console.close()
        if auth.exists():
            auth.unlink()
        report['private_cookie_removed'] = not auth.exists()
        after = validation.snapshot('after-rendered.json')
        report['source_comparison'] = validation.same_sources(before, after)
        report['completed_at'] = validation.utc()
        report['success'] = (report.get('probe', {}).get('success', False)
                             and report.get('all_three_images_decoded', False)
                             and all(report['source_comparison'].values())
                             and report.get('own_server_stopped', False)
                             and 'exception' not in report)
        validation.write_json('rendered-results.json', report)
    print(json.dumps({k: report.get(k) for k in ['success', 'server_started', 'probe_started',
                                                'setup_failure', 'exception', 'images',
                                                'source_comparison', 'own_server_stopped']},
                     ensure_ascii=False, indent=2), flush=True)
    return 0 if report['success'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
