from pathlib import Path
import datetime, difflib, hashlib, json, re

ROOT = Path('/workspace/scratch/b3485b7bb989/host-pr502-product-integration-32e7-20261114')
def ident(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode('ascii') + b'\0' + data).hexdigest()}
def read(rel):
    return (ROOT / rel).read_bytes()
def put(rel, obj):
    raw = (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    with (ROOT / rel).open('xb') as out:
        out.write(raw)
    return ident(raw)
def textphase(phase, path):
    return read(phase + '/' + path).decode('utf-8')
inputs = json.loads(read('integration-input.json'))
plan = json.loads(read('materialization-readback-input.json'))
for entry in plan:
    actual = ident(read(entry['path']))
    assert actual == {k: entry[k] for k in ('bytes', 'sha256', 'git_blob')}, entry['path']
tree = json.loads(read('base-tree-binding.json'))
assert tree['base_tree'] == inputs['base_tree'] and tree['truncated'] is False
entries = {e['path']: e for e in tree['entries']}
commit = json.loads(read('originals/host32-commit.json'))
assert commit['sha'] == inputs['base_host'] and commit['tree']['sha'] == inputs['base_tree']
compare = json.loads(read('originals/producer502-cf259-to-c3f44-compare.json'))
assert compare['commits'][-1]['sha'] == inputs['producer_head']
assert compare['commits'][-1]['commit']['tree']['sha'] == inputs['producer_tree']
producer_files = {e['filename']: e for e in compare['files']}
exact_paths = sorted(x['path'] for x in inputs['source_changes'])
actual_paths = sorted(str(x.relative_to(ROOT / 'final-source')) for x in (ROOT / 'final-source').rglob('*') if x.is_file())
assert actual_paths == exact_paths
rows, patches = [], []
for change in inputs['source_changes']:
    path = change['path']
    after = read('final-source/' + path)
    assert ident(after) == change['after'], path
    assert producer_files[path]['sha'] == change['after']['git_blob'], path
    if change['before'] is None:
        assert path in tree['absent_selected_paths']
        assert path not in entries
        before = b''
    else:
        before = read('original-source/' + path)
        assert ident(before) == change['before'], path
        assert entries[path]['sha'] == change['before']['git_blob']
        assert entries[path]['mode'] == change['mode']
        assert entries[path]['size'] == len(before)
    a, b = before.decode('utf-8').splitlines(True), after.decode('utf-8').splitlines(True)
    ops = difflib.SequenceMatcher(a=a, b=b, autojunk=False).get_opcodes()
    added = sum(j2-j1 for tag,i1,i2,j1,j2 in ops if tag in ('insert','replace'))
    removed = sum(i2-i1 for tag,i1,i2,j1,j2 in ops if tag in ('delete','replace'))
    rows.append({'path':path,'added_lines':added,'removed_lines':removed,
                 'published_blob_equal':True,'before':change['before'],'after':change['after']})
    header = 'diff --git a/' + path + ' b/' + path + '\n'
    if change['before'] is None:
        header += 'new file mode 100644\n'
    header += 'index ' + (change['before']['git_blob'] if change['before'] else '0'*40) + '..' + change['after']['git_blob'] + ' 100644\n'
    patches.append(header + ''.join(difflib.unified_diff(a,b,fromfile=('a/'+path if change['before'] else '/dev/null'),tofile='b/'+path)))

# Exact deltas for already locked dependency; no resolver or package command.
yaml_before = textphase('original-source','pubspec.yaml')
yaml_after = textphase('final-source','pubspec.yaml')
anchor = '  flutter_lints: ^4.0.0\n'
assert yaml_before.count(anchor) == 1
assert yaml_after == yaml_before.replace(anchor, anchor + '  image_picker_platform_interface: ^2.11.1\n', 1)
lock_before = textphase('original-source','pubspec.lock')
lock_after = textphase('final-source','pubspec.lock')
old = '  image_picker_platform_interface:\n    dependency: transitive\n'
new = '  image_picker_platform_interface:\n    dependency: "direct dev"\n'
assert lock_before.count(old) == 1
assert lock_after == lock_before.replace(old,new,1)
node = lock_after.split('  image_picker_platform_interface:\n',1)[1].split('\n  ',1)[0]
# The whole node is recovered by top-level package indentation, not the first inner field.
node = re.search(r'^  image_picker_platform_interface:\n(?:^ {4}.*\n)+', lock_after, re.M).group(0)
assert 'version: "2.11.1"' in node
assert '567e056716333a1647c64bb6bd873cff7622233a5c3f694be28a583d4715690c' in node

# Anchored source slices only: this is a text-preservation check, not a Dart AST/compile test.
def block(source, declaration):
    assert source.count(declaration) == 1, declaration
    start = source.index(declaration)
    end = source.index('\n  }\n', start) + len('\n  }\n')
    return source[start:end]
preserved_blocks = []
checks = {
 'lib/features/learning_modules/wort_diktat/wort_diktat_screen.dart': [
  '  void initState() {\n', '  void dispose() {\n', '  void _sayWord() {\n',
  '  void _repeatWord() {\n','  void _onFinish() {\n',
  '  void _onSelfRate(bool wasCorrect) async {\n','  void _showFinish() async {\n'],
 'lib/features/live/lumo_live_pro_screen.dart': [
  '  void initState() {\n', '  void dispose() {\n',
  '  Future<void> _onSpeechDone(LearningProfileLease owner) async {\n',
  '  Future<void> _handleSafariAnswer(LearningProfileLease owner) async {\n'],
 'lib/widgets/profile_screen.dart': [
  '  void initState() {\n', '  Widget _buildReportEntry() {\n', '  Widget _buildRewards() {\n']
}
for path, declarations in checks.items():
    before, after = textphase('original-source',path), textphase('final-source',path)
    for decl in declarations:
        a,b=block(before,decl),block(after,decl)
        assert a == b, (path,decl)
        preserved_blocks.append({'path':path,'declaration':decl.rstrip(),
                                 'bytes':len(a.encode('utf-8')),'sha256':hashlib.sha256(a.encode('utf-8')).hexdigest(),
                                 'comparison':'exact source text'})
profile_path='lib/widgets/profile_screen.dart'
a,b=textphase('original-source',profile_path),textphase('final-source',profile_path)
decl='  Widget _buildExtras() {\n'
assert a.replace(block(a,decl),'',1) == b.replace(block(b,decl),'',1)
live_path='lib/features/live/lumo_live_pro_screen.dart'
a,b=textphase('original-source',live_path),textphase('final-source',live_path)
decl='  Future<void> _handleWordMagic(LearningProfileLease owner) async {\n'
assert block(a,decl).replace('      _generatedImageUrl = null;\n','',1) == block(b,decl)

old_test_preservation=[]
for path in ['test/feature_permission_regression_test.dart','test/profile_screen_test.dart']:
    row=next(x for x in rows if x['path']==path)
    assert row['removed_lines'] == 0
    old_test_preservation.append({'path':path,'all_original_lines_preserved_in_order':True,
                                 'added_lines':row['added_lines'],'removed_lines':0})
dependency_copies=[]
for file in sorted((ROOT/'dependency-source').rglob('*')):
    if not file.is_file(): continue
    path=str(file.relative_to(ROOT/'dependency-source'))
    identity=ident(file.read_bytes())
    assert identity['git_blob']==entries[path]['sha']
    assert identity['bytes']==entries[path]['size']
    assert path not in exact_paths
    dependency_copies.append({'path':path,**identity,'selected_for_change':False})

word=textphase('final-source','test/wort_diktat_gesture_regression_test.dart')
permission=textphase('final-source','test/feature_permission_regression_test.dart')
profile=textphase('final-source','test/profile_screen_test.dart')
assert len(re.findall(r'\btestWidgets\(',word))==4
assert 'for (final size in const [Size(430, 600), Size(640, 360)])' in word
assert len(re.findall(r'\btestWidgets\(',permission))==9
assert 'for (final pro in [true])' in permission
assert len(re.findall(r'\btestWidgets\(',profile))==2
assert len(re.findall(r'(?<![A-Za-z])test\(',profile))==1

time=datetime.datetime.now(datetime.timezone.utc).isoformat()
preservation={
 'schema':1,'checked_at_utc':time,'status':'SOURCE_READBACK_COMPLETE_TESTS_NOT_RUN',
 'inspection_method':'UTF-8 byte hashes, preserved Git API blob mapping, exact source slices and line diffs. No Dart parser/compiler/widget run.',
 'readback_objects':len(plan),'sources':rows,'exact_preserved_source_blocks':preserved_blocks,
 'profile_change_confined_to_buildExtras':True,
 'word_magic_handler_otherwise_byte_equal_after_dead_field_removal':True,
 'old_test_preservation':old_test_preservation,'unchanged_dependency_copies':dependency_copies,
 'pubspec_change':{'only_added_dev_entry':'image_picker_platform_interface: ^2.11.1','production_version_unchanged':True},
 'lock_change':{'only_field':'packages.image_picker_platform_interface.dependency','before':'transitive','after':'direct dev',
                'version':'2.11.1','package_sha256':'567e056716333a1647c64bb6bd873cff7622233a5c3f694be28a583d4715690c',
                'other_lock_bytes_unchanged':True,'resolver_invoked':False},
 'static_test_registration':{'test/wort_diktat_gesture_regression_test.dart':5,
                             'test/feature_permission_regression_test.dart':9,
                             'test/profile_screen_test.dart':3,'total_expected_from_source':17,
                             'actual_discovery_and_execution':'NOT_RUN'},
 'scope_notes':[
  'The production LumoInkSurface at blob 123c13786584c3f9c487ae1b71317841d2995420 is not replaced.',
  'No handwriting-trainer, journal, permission-helper, app-state, original-Lumo, pin, workflow, version or device source is selected for change.',
  'Camera picker results require the captured revision and current learning-profile lease before accepting the file.',
  'No combined-source Flutter/Android/audio/visual/accessibility acceptance is claimed.',
  'The new tests use platform-interface substitutes for camera/speech; no physical sensor claim is derived.'
 ]}
with (ROOT/'integration.patch').open('xb') as f:f.write(''.join(patches).encode('utf-8'))
preservation_id=put('preservation.json',preservation)
freeze={
 'schema':1,'status':'FROZEN_SOURCE_PROPOSAL_NOT_EXECUTED','created_at_utc':time,
 'repository':'Ullmann27/lumo-lernen','base':{'commit':inputs['base_host'],'tree':inputs['base_tree']},
 'producer':{'pr':502,'head':inputs['producer_head'],'tree':inputs['producer_tree'],'parent':inputs['producer_parent'],'compare_base':inputs['compare_base']},
 'source_count':len(inputs['source_changes']),'source_root':'final-source',
 'sources':inputs['source_changes'],'protected_dependencies':inputs['protected'],
 'source_preservation':{'path':'preservation.json',**preservation_id},
 'patch':{'path':'integration.patch',**ident(read('integration.patch'))},
 'actual_executions':{'flutter_tests':'NOT_RUN','engine':'NOT_RUN','package_resolution':'NOT_RUN','git_mutation':'NONE','worktree_writes':'NONE'},
 'checkpoints_required_before_tests':True
}
freeze_id=put('source-freeze.json',freeze)
print(json.dumps({'source_count':len(rows),'source_freeze':freeze_id,'preservation':preservation_id,'patch':ident(read('integration.patch')),
 'static_test_cases':17,'source_deltas':[{'path':r['path'],'added':r['added_lines'],'removed':r['removed_lines']} for r in rows]},ensure_ascii=False,indent=2))
