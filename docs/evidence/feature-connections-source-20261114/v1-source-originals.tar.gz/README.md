# Host502: begrenzter Produktanschluss auf Host32e7

Status: **Quellen eingefroren; keine Produktprüfung ausgeführt.**

Basis: Host `32e7efbff427fef64e90b3a1fcecd3b52f00af42`, Tree `10234debe8d5f2f9577ac28aa05ae99322d9190f`.
Veröffentlichte Lieferung: PR502, Head `c3f44ea7acdfe2ee8be68e8c37ad5fa25f2a1e23`, Tree `7341eecf3d036c1cfba660f5a38f38500bd56f84`.

## Acht ausgewählte Quellen

- Wort-Diktat verbindet seine vier Eingabezeilen mit dem vorhandenen LumoInkSurface. Erst ein beendeter, nicht abgebrochener Strich mit mehr als einem Punkt wird übernommen; der aktive Strich bleibt Vorschau.
- Live-Pro verbindet „Foto machen“ tatsächlich mit dem Kameraaufruf. Die bestehende gespeicherte Elternfreigabe bleibt vorgeschaltet; erfolgreiche Kameraantworten müssen zur ursprünglichen Modusrevision und zum aktuellen Lernprofil gehören. Safari zeigt sein bereits vorhandenes Tier. Die nicht implementierte Bildversprechung und ihr ungenutzter Netzwerkbildpfad entfallen.
- Die Profil-Extras öffnen die bestehenden Einstellungen über den vorhandenen Callback.
- Drei veröffentlichte Testdateien decken diese Eingaben ab. Die zwei bestehenden Testdateien erhalten sämtliche bisherigen Zeilen.
- In pubspec.yaml kommt nur `image_picker_platform_interface: ^2.11.1` als direkte Entwicklungsabhängigkeit hinzu. Im Lockfile wechselt ausschließlich die Einstufung dieses schon gesperrten Pakets von `transitive` zu `direct dev`. Version 2.11.1, Paketdigest, Quelle und alle übrigen Lockbytes bleiben gleich.

Alle acht Enddateien sind bytegleich zu den ausgewählten veröffentlichten Producer-Blobs. Die beiden Abhängigkeitsdateien wurden dennoch ausschließlich durch die belegten minimalen Änderungen aus unserer Basis hergeleitet; es wurde kein fremdes Lockfile als Basis übernommen.

## Erhaltene Anschlüsse

Der bestehende LumoInkSurface, Blob `123c13786584c3f9c487ae1b71317841d2995420`, bleibt unverändert. Sein bestehender Callbackvertrag passt zu Wort-Diktat. Schreibtrainer, Journal, AppState, Elternfreigabe-Helfer, Original-Lumo, Quellenpins, Version und Workflows sind nicht Teil dieses Änderungssatzes.

`preservation.json` dokumentiert 14 exakt gleiche Methoden-Textblöcke, die unveränderte übrige Profilquelle, den erhaltenen Wort-Magie-Handler nach Entfernung nur der toten Bildfeldzuweisung sowie die ausschließlich additiven vorhandenen Testdateien. Dies ist ein Quelltextvergleich, keine Dart-AST- oder Laufzeitprüfung.

Vier unveränderte Abhängigkeiten sind als kleine Quellkopien enthalten. Vierzehn geschützte Pfade und die sechs nötigen echten Bild-/Schriftdateien sind mit ihren Basis-Gitblobs verzeichnet. Es wurden keine Assets, SDKs oder Pakete kopiert.

## Noch ausstehende Prüfung

Die Quellen enthalten statisch 17 Fälle: Wort-Diktat 5, Permission/Live 9, Profil 3. Davon sind 13 neu; 4 bisherige Fälle bleiben erhalten. Das ist eine Zählung anhand des Quelltextes und keine Test-Discovery oder Erfolgsaussage.

Erst nach dem Root-Checkpoint ist dieser enge Aufruf vorgesehen:

```sh
flutter test --no-pub --reporter expanded test/wort_diktat_gesture_regression_test.dart test/feature_permission_regression_test.dart test/profile_screen_test.dart
```

Der spätere Lauf benötigt die im Quellenvertrag genannten originalen Fuchs-Bilder und Nunito-Schriften sowie die bereits vorhandenen Flutter-Abhängigkeiten. Vor diesem Freeze wurden weder Flutter, Engine, Paketauflösung noch Geräteprüfungen ausgeführt. Frühere Producer- oder andere Integrationsprüfungen werden nicht auf dieses Kombinat übertragen.

## Vollständige Nachvollziehbarkeit

- `source-freeze.json`: alle acht Vorher-/Nachheridentitäten und der feste Producerbezug.
- `integration.patch`: vollständiger achtteiliger Unterschied gegen 32e7.
- `original-source/`, `final-source/`, `dependency-source/`: unveränderte Quellbytes.
- `originals/`: ursprünglicher Git-Commit, vollständiger unveränderlicher Producervergleich und der Index der bereits gesicherten Original-API-Antworten.
- `base-tree-binding.json`: ausdrücklich abgeleiteter relevanter Ausschnitt des erhaltenen vollständigen Basis-Trees; dessen Originalobjekt ist über den API-Index gebunden.
- `assembly-history/`: erster Fehler ausschließlich im neuen Packassembler (nicht vorhandenes Compare-Feld `head_commit`) und der korrigierte Readback. Dabei entstand noch kein Quellenfreeze; Produktquellen blieben identisch. Das tatsächliche letzte Commitobjekt der vollständigen Compare-Antwort wird nun geprüft.
- `manifest.json` und `archive-binding.json`: vollständiges Dateiinventar und vollständig zurückgelesenes verlustfreies Kompaktarchiv.

Sämtliche Schreibvorgänge dieses Anschlusses betreffen ausschließlich dieses externe Paket. Kein Checkout, Index, Gitobjekt, Ref, PR oder CI-Lauf wurde verändert.
