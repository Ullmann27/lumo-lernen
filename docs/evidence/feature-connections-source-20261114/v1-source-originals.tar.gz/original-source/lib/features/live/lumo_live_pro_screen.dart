// ════════════════════════════════════════════════════════════════════════
// LUMO LIVE PRO — Voice + Foto-Quiz mit Lumo-Companion
// ════════════════════════════════════════════════════════════════════════
// Premium-Wert fuer 10 Euro/Monat Abo.
//
// 3 MODI:
//   1. WORT-MAGIE: Kind sagt Wort -> Lumo malt + erklaert
//   2. FOTO-QUIZ:  Kind macht Foto -> Lumo stellt 3 Fragen drum
//   3. SAFARI:     Lumo zeigt Tier -> Kind muss raten und sprechen
// ════════════════════════════════════════════════════════════════════════

import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/lumo_speech_listener.dart';

import '../../app/app_state.dart';
import '../../core/lumo_brain.dart';
import '../../core/lumo_feature_permissions.dart';
import '../../core/lumo_voice.dart';
import '../../theme/lumo_design_tokens.dart';
import '../../widgets/lumo_mirror.dart';
import '../../widgets/design/lumo_design_system.dart';
import '../../widgets/premium/lumo_magic_background.dart';
import '../../widgets/premium/lumo_premium_card.dart';
import '../../widgets/premium/lumo_reward_burst.dart';

enum LiveMode {
  wordMagic, // Sprich ein Wort -> Bild + Erklaerung
  photoQuiz, // Foto -> 3 Fragen
  safari, // Lumo zeigt Tier -> Kind raet
}

extension LiveModeMeta on LiveMode {
  String get title {
    switch (this) {
      case LiveMode.wordMagic:
        return 'Wort-Magie';
      case LiveMode.photoQuiz:
        return 'Foto-Quiz';
      case LiveMode.safari:
        return 'Tier-Safari';
    }
  }

  String get subtitle {
    switch (this) {
      case LiveMode.wordMagic:
        return 'Sag ein Wort - ich male es!';
      case LiveMode.photoQuiz:
        return 'Mach ein Foto - ich frage dich!';
      case LiveMode.safari:
        return 'Erkennst du das Tier?';
    }
  }

  IconData get icon {
    switch (this) {
      case LiveMode.wordMagic:
        return Icons.auto_fix_high_rounded;
      case LiveMode.photoQuiz:
        return Icons.camera_alt_rounded;
      case LiveMode.safari:
        return Icons.pets_rounded;
    }
  }
}

class LumoLiveProScreen extends StatefulWidget {
  const LumoLiveProScreen({super.key, required this.appState});
  final LumoAppState appState;

  @override
  State<LumoLiveProScreen> createState() => _LumoLiveProScreenState();
}

class _LumoLiveProScreenState extends State<LumoLiveProScreen>
    with WidgetsBindingObserver {
  final LumoSpeechListener _stt = LumoSpeechListener();
  final ImagePicker _picker = ImagePicker();
  final _rng = math.Random();

  LiveMode _mode = LiveMode.wordMagic;
  bool _sttReady = false;
  bool _listening = false;
  String _recognized = '';
  String? _generatedImageUrl;
  String? _capturedImagePath;
  String? _lumoMessage;
  LumoMirrorMood _mood = LumoMirrorMood.idle;
  bool _speaking = false;

  // Safari-Modus state
  String? _safariAnimal;
  int _safariScore = 0;
  int _safariRound = 0;
  int _safariTotal = 0;

  // Photo-Quiz state - nutzt jetzt _extendedPhotoQuestions
  int _photoQuizQuestionIdx = 0;

  // Lumo redet
  bool _lumoCurrentlySpeaking = false;

  static const _animalPictures = <String, String>{
    'Loewe': '🦁',
    'Elefant': '🐘',
    'Giraffe': '🦒',
    'Zebra': '🦓',
    'Affe': '🐒',
    'Tiger': '🐯',
    'Baer': '🐻',
    'Wolf': '🐺',
    'Eule': '🦉',
    'Pinguin': '🐧',
    'Delfin': '🐬',
    'Schmetterling': '🦋',
    'Hund': '🐕',
    'Katze': '🐈',
    'Pferd': '🐎',
    'Kuh': '🐄',
    'Schaf': '🐑',
    'Schwein': '🐖',
    'Krokodil': '🐊',
    'Nashorn': '🦏',
    'Flusspferd': '🦛',
    'Kaenguru': '🦘',
    'Koala': '🐨',
    'Faultier': '🦥',
    'Hai': '🦈',
    'Wal': '🐳',
    'Robbe': '🦭',
    'Eisbaer': '🐻‍❄️',
    'Rentier': '🦌',
    'Fuchs': '🦊',
    'Eichhoernchen': '🐿️',
    'Igel': '🦔',
    'Frosch': '🐸',
    'Schildkroete': '🐢',
    'Adler': '🦅',
    'Papagei': '🦜',
    'Biene': '🐝',
    'Marienkaefer': '🐞',
  };

  /// Photo-Quiz-Fragen mit etwas mehr Variation.
  static const List<String> _extendedPhotoQuestions = [
    'Was siehst du da auf dem Foto?',
    'Welche Farbe hat das?',
    'Wo findet man so etwas?',
    'Ist das gross oder klein?',
    'Mag das jemand essen?',
    'Hast du das schon einmal gesehen?',
    'Wie fuehlt sich das an, glaubst du?',
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    LumoVoice.instance.status.addListener(_voiceStatusChanged);
    _stt.addListener(_speechStatusChanged);
    // Mood Wechsel demo
    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) {
        setState(() => _mood = LumoMirrorMood.happy);
        _speak('Hallo! Was sollen wir heute spielen?');
      }
    });
  }

  Future<void> _initStt() async {
    try {
      final ok = await _stt.initialize();
      if (mounted) setState(() => _sttReady = ok);
    } catch (e) {
      debugPrint('STT init error: $e');
    }
  }

  void _speechStatusChanged() {
    if (mounted) setState(() => _listening = _stt.listening);
  }

  void _switchMode(LiveMode m) {
    setState(() {
      _mode = m;
      _recognized = '';
      _generatedImageUrl = null;
      _capturedImagePath = null;
      _lumoMessage = null;
      _safariAnimal = null;
      _safariScore = 0;
      _safariRound = 0;
      _safariTotal = 0;
      _photoQuizQuestionIdx = 0;
      _mood = LumoMirrorMood.curious;
    });
    HapticFeedback.lightImpact();
    if (m == LiveMode.safari) {
      _nextSafariAnimal();
    } else if (m == LiveMode.wordMagic) {
      _speak('Sag mir ein Wort und ich male es fuer dich!');
    } else if (m == LiveMode.photoQuiz) {
      _speak('Mach ein Foto und ich stelle dir kluge Fragen!');
    }
  }

  Future<void> _speak(String text) async {
    if (!mounted) return;
    setState(() {
      _lumoMessage = text;
    });
    await widget.appState.ensureSettingsLoaded();
    if (!mounted || !widget.appState.state.settings.voiceEnabled) return;
    try {
      LumoVoice.instance.speak(text);
    } catch (_) {}
  }

  void _voiceStatusChanged() {
    if (!mounted) return;
    final speaking = LumoVoice.instance.status.value == VoiceStatus.speaking;
    setState(() {
      _speaking = speaking;
      _lumoCurrentlySpeaking = speaking;
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) {
      _stt.cancel();
      LumoVoice.instance.stop();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    LumoVoice.instance.status.removeListener(_voiceStatusChanged);
    _stt.removeListener(_speechStatusChanged);
    _stt.dispose();
    LumoVoice.instance.stop();
    super.dispose();
  }

  Future<void> _startListening() async {
    if (_listening) return;
    final source = widget.appState.captureLearningProfile();
    LearningProfileLease owner;
    try {
      owner = await source;
      await widget.appState.prepareLearningLease(owner);
    } catch (_) {
      return;
    }
    if (!mounted || !widget.appState.isCurrentLearningLease(owner)) return;
    if (!await LumoFeaturePermissions.microphone(context, widget.appState) ||
        !mounted) {
      return;
    }
    if (!_sttReady) await _initStt();
    if (!mounted || !widget.appState.isCurrentLearningLease(owner)) return;
    if (!_sttReady) {
      _speak('Ich brauch dein Mikrofon - bitte erlauben!');
      return;
    }
    if (_listening) return;
    HapticFeedback.lightImpact();
    setState(() {
      _listening = true;
      _recognized = '';
      _mood = LumoMirrorMood.curious;
    });
    try {
      await _stt.startListening(
        onResult: (words) {
          if (mounted && widget.appState.isCurrentLearningLease(owner)) {
            setState(() => _recognized = words);
          }
        },
        onFinalResult: (_) => _onSpeechDone(owner),
      );
    } catch (e) {
      if (mounted) setState(() => _listening = false);
    }
  }

  Future<void> _onSpeechDone(LearningProfileLease owner) async {
    if (!mounted || !widget.appState.isCurrentLearningLease(owner)) return;
    setState(() {
      _listening = false;
      _mood = LumoMirrorMood.think;
    });
    if (_recognized.isEmpty) {
      _speak('Hmm, ich hab nichts gehoert. Probier nochmal!');
      setState(() => _mood = LumoMirrorMood.sad);
      return;
    }
    // Mode-spezifische Behandlung
    switch (_mode) {
      case LiveMode.wordMagic:
        await _handleWordMagic(owner);
        break;
      case LiveMode.photoQuiz:
        await _handlePhotoQuiz(owner);
        break;
      case LiveMode.safari:
        await _handleSafariAnswer(owner);
        break;
    }
  }

  // ────────────────────────────────────────────────────────────────
  // MODE 1: WORT-MAGIE
  // ────────────────────────────────────────────────────────────────
  Future<void> _handleWordMagic(LearningProfileLease owner) async {
    final word = _recognized.trim();
    final reply =
        LumoBrain.instance.ask('Was ist ein $word?', topicId: 's1_tiere');
    setState(() {
      _generatedImageUrl = null;
      _mood = LumoMirrorMood.happy;
    });
    widget.appState.addStars(1);
    widget.appState.addXp(5);
    widget.appState.grantCosmosReward(
      lease: owner,
      subjectId: 'live_word',
      isMath: false,
      isPerfect: false,
    );
    _speak(reply.text);
  }

  // ────────────────────────────────────────────────────────────────
  // MODE 2: FOTO-QUIZ
  // ────────────────────────────────────────────────────────────────
  Future<void> _capturePhoto() async {
    if (!await LumoFeaturePermissions.camera(context, widget.appState) ||
        !mounted) {
      return;
    }
    try {
      final photo = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 60,
        maxWidth: 800,
      );
      if (photo == null || !mounted) return;
      setState(() {
        _capturedImagePath = photo.path;
        _photoQuizQuestionIdx = 0;
        _mood = LumoMirrorMood.curious;
      });
      _speak(_extendedPhotoQuestions[0]);
    } catch (e) {
      _speak('Das Foto hat nicht geklappt. Probier nochmal!');
    }
  }

  Future<void> _handlePhotoQuiz(LearningProfileLease owner) async {
    // Nach jeder Antwort: naechste Frage oder Ende
    setState(() {});
    widget.appState.addStars(1);
    widget.appState.addXp(5);
    widget.appState.grantCosmosReward(
      lease: owner,
      subjectId: 'live_photo',
      isMath: false,
      isPerfect: false,
    );
    if (_photoQuizQuestionIdx + 1 < _extendedPhotoQuestions.length) {
      _photoQuizQuestionIdx++;
      setState(() => _mood = LumoMirrorMood.happy);
      await Future.delayed(const Duration(milliseconds: 1500));
      if (!mounted || !widget.appState.isCurrentLearningLease(owner)) return;
      _speak(_extendedPhotoQuestions[_photoQuizQuestionIdx]);
    } else {
      setState(() => _mood = LumoMirrorMood.cheer);
      _speak('Super! Du hast alle Fragen beantwortet! '
          'Du hast 3 Sterne verdient!');
      if (mounted) showLumoRewardBurst(context, stars: 3, xp: 15);
      widget.appState.addStars(2);
      widget.appState.addXp(10);
    }
  }

  // ────────────────────────────────────────────────────────────────
  // MODE 3: TIER-SAFARI
  // ────────────────────────────────────────────────────────────────
  void _nextSafariAnimal() {
    _safariRound++;
    _safariTotal = _safariRound;
    final animals = _animalPictures.keys.toList(growable: false);
    final animal = animals[_rng.nextInt(animals.length)];
    setState(() {
      _safariAnimal = animal;
      _generatedImageUrl = null;
      _recognized = '';
      _mood = LumoMirrorMood.curious;
    });
    _speak('Welches Tier siehst du? Sag mir den Namen!');
  }

  Future<void> _handleSafariAnswer(LearningProfileLease owner) async {
    if (_safariAnimal == null) return;
    final said = _recognized.toLowerCase().trim();
    final correct = _safariAnimal!.toLowerCase();
    // Levenshtein-Toleranz nach Wortlaenge: kurze Tiere ('Hai') haben
    // Toleranz 1, lange ('Schildkroete') Toleranz 3 - statt fixer 2.
    // Sonst sind 5-Jaehrige mit Schmetterling vs Schildkroete im Vorteil
    // oder bei Bar/Baer ungerecht 'falsch'.
    final tol = (correct.length / 4).floor().clamp(1, 3);
    final isRight = said.contains(correct) ||
        correct.contains(said) ||
        _levenshtein(said, correct) <= tol;
    if (isRight) {
      _safariScore++;
      setState(() => _mood = LumoMirrorMood.cheer);
      _speak('Richtig! Das ist ein $_safariAnimal!');
      widget.appState.addStars(2);
      widget.appState.addXp(10);
      widget.appState.grantCosmosReward(
      lease: owner,
        subjectId: 'live_safari',
        isMath: false,
        isPerfect: true,
      );
      if (mounted) showLumoRewardBurst(context, stars: 2, xp: 10);
      await Future.delayed(const Duration(milliseconds: 2200));
      if (mounted && widget.appState.isCurrentLearningLease(owner)) _nextSafariAnimal();
    } else {
      setState(() => _mood = LumoMirrorMood.sad);
      _speak('Hmm, nicht ganz. Es ist ein $_safariAnimal. Versuch noch eins!');
      await Future.delayed(const Duration(milliseconds: 2500));
      if (mounted && widget.appState.isCurrentLearningLease(owner)) _nextSafariAnimal();
    }
  }

  int _levenshtein(String a, String b) {
    if (a == b) return 0;
    if (a.isEmpty) return b.length;
    if (b.isEmpty) return a.length;
    final dp =
        List.generate(a.length + 1, (_) => List<int>.filled(b.length + 1, 0));
    for (int i = 0; i <= a.length; i++) {
      dp[i][0] = i;
    }
    for (int j = 0; j <= b.length; j++) {
      dp[0][j] = j;
    }
    for (int i = 1; i <= a.length; i++) {
      for (int j = 1; j <= b.length; j++) {
        final cost = a[i - 1] == b[j - 1] ? 0 : 1;
        dp[i][j] = [
          dp[i - 1][j] + 1,
          dp[i][j - 1] + 1,
          dp[i - 1][j - 1] + cost,
        ].reduce(math.min);
      }
    }
    return dp[a.length][b.length];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: LumoTokens.colors.creme,
      body: LumoMagicBackground(
        child: SafeArea(
          child: Column(
            children: [
              _buildTopBar(),
              _buildModePicker(),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(LumoTokens.space16),
                  child: Column(
                    children: [
                      // Original-Lumo remains the lead character; the expressive
                      // mirror is a live reaction indicator, not the sole mascot.
                      Center(
                        child: SizedBox(
                          height: 195,
                          width: 260,
                          child: Stack(alignment: Alignment.center, children: [
                            const LumoFoxPose(
                              pose: LumoDesignFoxPose.armsOpen, size: 178),
                            Positioned(
                              right: 0,
                              bottom: 0,
                              child: LumoMirror(
                                mood: _mood, size: 105,
                                isSpeaking: _speaking),
                            ),
                          ]),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Container(
                        key: const ValueKey('live-mode-instruction'),
                        width: double.infinity,
                        padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFF16395E), Color(0xFF4A3F87)]),
                          border: Border.all(
                            color: const Color(0xFF7FD9F1).withOpacity(.65)),
                          borderRadius: BorderRadius.circular(22),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(_mode.title,
                              style: const TextStyle(fontFamily: 'Nunito',
                                fontWeight: FontWeight.w900, fontSize: 18,
                                color: Colors.white)),
                            const SizedBox(height: 4),
                            Text(_mode.subtitle,
                              style: const TextStyle(fontFamily: 'Nunito',
                                fontWeight: FontWeight.w700, fontSize: 14,
                                color: Color(0xFFE2F2FD))),
                          ],
                        ),
                      ),
                      const SizedBox(height: LumoTokens.space12),
                      // Lumo-Nachricht
                      if (_lumoMessage != null)
                        LumoPremiumCard(
                          gradient: LumoTokens.colors.heroLila,
                          child: Row(children: [
                            const Text('🦊', style: TextStyle(fontSize: 28)),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(_lumoMessage!,
                                  style: LumoTokens.typo.bodyLarge.copyWith(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w700)),
                            ),
                          ]),
                        ),
                      const SizedBox(height: LumoTokens.space12),
                      // Erkanntes Wort
                      if (_recognized.isNotEmpty)
                        LumoPremiumCard(
                          gradient: LumoTokens.colors.heroOrange,
                          child: Column(children: [
                            Text('Du hast gesagt:',
                                style: LumoTokens.typo.bodyMedium.copyWith(
                                    color: Colors.white.withOpacity(0.85))),
                            Text('"$_recognized"',
                                style: LumoTokens.typo.headlineMedium
                                    .copyWith(color: Colors.white)),
                          ]),
                        ),
                      if (_listening)
                        Padding(
                          padding: const EdgeInsets.all(8),
                          child: Row(children: [
                            Icon(Icons.mic_rounded,
                                color: LumoTokens.colors.lumoOrange),
                            const SizedBox(width: 8),
                            Text('Ich hoere...',
                                style: LumoTokens.typo.titleMedium),
                          ]),
                        ),
                      const SizedBox(height: LumoTokens.space12),
                      // Safari-Score
                      if (_mode == LiveMode.safari && _safariRound > 0)
                        _buildSafariScore(),
                      // Generiertes / Captured Bild
                      if (_generatedImageUrl != null ||
                          _capturedImagePath != null)
                        _buildImagePane(),
                    ],
                  ),
                ),
              ),
              _buildActionBar(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.all(LumoTokens.space12),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.close_rounded),
            onPressed: () => Navigator.pop(context),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Lumo LIVE ✨', style: LumoTokens.typo.headlineMedium),
                Text(_mode.subtitle,
                    style: LumoTokens.typo.bodyMedium
                        .copyWith(color: LumoTokens.colors.textMuted)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildModePicker() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: LumoTokens.space12),
      child: Row(
        children: LiveMode.values.map((m) {
          final active = m == _mode;
          return Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: GestureDetector(
                onTap: () => _switchMode(m),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    gradient: active ? LumoTokens.colors.heroOrange : null,
                    color: active ? null : Colors.white,
                    borderRadius: LumoTokens.brMedium,
                    border: Border.all(
                      color: active
                          ? Colors.transparent
                          : LumoTokens.colors.outline,
                      width: 2,
                    ),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(m.icon,
                          color: active
                              ? Colors.white
                              : LumoTokens.colors.lumoOrange,
                          size: 22),
                      const SizedBox(height: 2),
                      Text(m.title,
                          style: LumoTokens.typo.labelMedium.copyWith(
                              color: active
                                  ? Colors.white
                                  : LumoTokens.colors.textDark),
                          textAlign: TextAlign.center),
                    ],
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildSafariScore() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        gradient: LumoTokens.colors.heroGold,
        borderRadius: LumoTokens.brPill,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.star_rounded, color: Colors.white),
          const SizedBox(width: 4),
          Text('$_safariScore von $_safariTotal',
              style: LumoTokens.typo.titleMedium.copyWith(color: Colors.white)),
        ],
      ),
    );
  }

  Widget _buildImagePane() {
    final url = _generatedImageUrl;
    final path = _capturedImagePath;
    if (_mode == LiveMode.safari && _safariAnimal != null) {
      return AspectRatio(
        aspectRatio: 1,
        child: LumoPremiumCard(
            child: Center(
          child: Text(_animalPictures[_safariAnimal]!,
              style: const TextStyle(fontSize: 112)),
        )),
      );
    }
    return AspectRatio(
      aspectRatio: 1,
      child: LumoPremiumCard(
        padding: EdgeInsets.zero,
        child: ClipRRect(
          borderRadius: LumoTokens.brLarge,
          child: url != null
              ? Image.network(
                  url,
                  fit: BoxFit.cover,
                  loadingBuilder: (_, child, p) {
                    if (p == null) return child;
                    return Container(
                      decoration:
                          BoxDecoration(gradient: LumoTokens.colors.bgMagic),
                      alignment: Alignment.center,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Text('🎨', style: TextStyle(fontSize: 56)),
                          const SizedBox(height: 12),
                          Text('Lumo malt...',
                              style: LumoTokens.typo.titleMedium
                                  .copyWith(color: Colors.white)),
                          const SizedBox(height: 12),
                          const CircularProgressIndicator(color: Colors.white),
                        ],
                      ),
                    );
                  },
                  errorBuilder: (_, __, ___) => Container(
                    decoration:
                        BoxDecoration(gradient: LumoTokens.colors.bgMagic),
                    alignment: Alignment.center,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text('🎨', style: TextStyle(fontSize: 64)),
                        const SizedBox(height: 8),
                        Text('Bild konnte nicht laden',
                            style: LumoTokens.typo.bodyMedium
                                .copyWith(color: Colors.white)),
                      ],
                    ),
                  ),
                )
              : path != null
                  ? Image.file(File(path), fit: BoxFit.cover)
                  : Container(
                      color: LumoTokens.colors.cremeDeep,
                      alignment: Alignment.center,
                      child: const Text('📷', style: TextStyle(fontSize: 80)),
                    ),
        ),
      ),
    );
  }

  Widget _buildActionBar() {
    return Container(
      padding: const EdgeInsets.all(LumoTokens.space16),
      decoration: BoxDecoration(
        color: LumoTokens.colors.surface,
        boxShadow: LumoTokens.shadows.floating,
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            Expanded(
              child: SizedBox(
                height: 64,
                child: ElevatedButton.icon(
                  onPressed: _listening || _lumoCurrentlySpeaking
                      ? null
                      : _startListening,
                  icon: Icon(
                      _mode == LiveMode.photoQuiz ? Icons.camera_alt_rounded
                           : (_listening ? Icons.hearing_rounded : Icons.mic_rounded),
                      size: 28),
                  label: Text(_mode == LiveMode.photoQuiz
                       ? 'Foto machen' : (_listening ? 'Hoere...' : 'Sprechen')),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: LumoTokens.colors.lumoOrange,
                    foregroundColor: Colors.white,
                    disabledBackgroundColor:
                        LumoTokens.colors.outline.withOpacity(0.5),
                    textStyle: LumoTokens.typo.titleLarge,
                    shape: RoundedRectangleBorder(
                        borderRadius: LumoTokens.brLarge),
                  ),
                ),
              ),
            ),
            if (_mode == LiveMode.safari && _safariAnimal != null) ...[
              const SizedBox(width: 12),
              SizedBox(
                width: 64,
                height: 64,
                child: ElevatedButton(
                  onPressed: _nextSafariAnimal,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: LumoTokens.colors.gold,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: LumoTokens.brLarge),
                    padding: EdgeInsets.zero,
                  ),
                  child: const Icon(Icons.skip_next_rounded, size: 28),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
