# Host502 V2: zwei begrenzte Reparaturen nach dem unabhängigen Quellenreview

Status: **Quellen eingefroren, sämtliche Tests NOT_RUN.**

V1 bleibt unverändert unter `host-pr502-product-integration-32e7-20261114`, Source-Freeze SHA256 `5850bd374da9bcdf74507e8929af8741d55b6a40caea54b2cb65af496d08d24b`. V1 enthält die acht ausgewählten PR502-Quellen auf Host32e7. Dieses Paket ersetzt davon ausschließlich zwei Produktdateien und zwei Testdateien. Profilquelle, Profiltest und beide minimalen Pubspec-Dateien werden aus V1 unverändert übernommen. Das vollständige kombinierte Acht-Dateien-Mapping steht im neuen Freeze.

## Beobachtete Quellenlücken

1. Jede der vier vorhandenen LumoInkSurface-Instanzen schützt ihren eigenen Pointer. Der Diktat-Screen hatte dagegen nur ein gemeinsames aktives Zeilen-/Strichpaar und überschrieb dieses beim Start auf einer zweiten Zeile. Das ist ein konkret nachvollzogener Kontrollfluss, kein ausgeführter Geräte- oder Widgetfehler.
2. Der Kamera-Fehlerzweig prüfte nur Modusrevision und mounted. Eine verspätete PlatformException konnte deshalb nach einem Profilwechsel noch die generische Fehlermeldung anzeigen. Erfolgreiche veraltete Fotos wurden bereits korrekt verworfen. Die neue Reparatur erweitert ausschließlich diese fehlende Kontextbindung und das zugehörige Aufräumen.

## Reparaturumfang

- Wort-Diktat weist einen weiteren Zeilenstart ab, solange irgendeine Zeile bereits einen aktiven Strich besitzt. Der unveränderte InkSurface-Helfer bleibt auf Blob `123c13786584c3f9c487ae1b71317841d2995420`.
- Eine Kameraoperation besitzt ein eigenes Object. catch prüft dieses Object, Modusrevision und die tatsächlich erfasste LearningLease. finally kann ausschließlich das eigene, noch identische Operation-Object freigeben.
- Das bisher serielle Pickerverhalten bleibt erhalten: Ein laufender Picker blockiert einen weiteren Start bis zu seinem Ende. Bei Leasewechsel wird sein Inhalt verworfen; das Ende gibt trotzdem ausschließlich den eigenen Busy-Zustand frei.
- Die beiden Kameraansagen übergeben ihren Owner an den vorhandenen privaten Sprachhelfer. Dieser prüft den Owner vor dem Setzen der Nachricht und nochmals nach dem Settings-await vor Sprache. Alle anderen Aufrufer behalten den bisherigen owner=null-Pfad.
- Die Elternfreigabe liegt weiterhin vor ImagePicker. Kameraoptionen, Erfolgsannahme, Belohnung, Lernstandsabläufe, Schreibtrainer und Journal bleiben außerhalb der Reparatur.

## Fünf zusätzliche Widgetfälle

Zwei echte Multi-Pointer-Sequenzen beginnen auf unterschiedlichen sichtbaren Diktatzeilen. Sie prüfen beide Loslassreihenfolgen, die fortgesetzten Punkte des ursprünglichen Strichs, das fehlende Übernehmen des fremden Kontakts und einen späteren gültigen neuen Strich.

Drei Kamera-Sequenzen lassen den tatsächlichen platform-interface-Picker-Future zunächst offen und wechseln danach über vorhandene Produktions-APIs das Profil, setzen die LearningLease zurück oder wechseln den Modus hin und zurück. Erst anschließend wird der alte Kamera-Fehler ausgelöst. Die Tests verlangen ausbleibende veraltete Meldungen, unveränderte Belohnungen und einen anschließend eigenständig geschützten aktuellen Versuch, dessen echter Fehler weiterhin angezeigt werden muss.

Alle bisherigen Testzeilen bleiben erhalten. Statisch ergeben sich jetzt **22 Fälle**: Wort-Diktat 7, Permission/Live 12, Profil 3. Die fünf neuen Fälle wurden noch nicht ausgeführt. Die behauptete V1-Fehlerfolge ist bis zum autorisierten Lauf ausschließlich quellenbasiert.

## Prüfung und Übergabe

`preservation.json` bindet den unveränderten V1-Dateiinhalt und den engen Umfang: Diktat nur zwei neue Zeilen; Live außerhalb der Operation-Kennzeichnung, _capturePhoto und _speak bytegleich. `v1-to-v2.patch` ist der vollständige Vier-Dateien-Diff. Originale V1-Quellen und die unveränderte SchoolRepository-API liegen daneben.

Root muss zuerst den kombinierten Quellenstand checkpointen. Danach ist derselbe enge Drei-Dateien-Testaufruf vorgesehen, jetzt mit 22 erwarteten Fällen:

```sh
flutter test --no-pub --reporter expanded test/wort_diktat_gesture_regression_test.dart test/feature_permission_regression_test.dart test/profile_screen_test.dart
```

Kein Flutter-, Engine-, Paket-, Geräte-, Git-, Index-, Ref-, PR- oder CI-Aufruf wurde für diese Reparatur gestartet. Alle Writes liegen ausschließlich im neuen externen Paket. Das Archiv enthält den vollständigen V2-Teil; für die vier unveränderten Endquellen gehört der eingefrorene V1-Pack weiterhin zur vollständigen Übergabe.
