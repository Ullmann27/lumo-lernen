from pathlib import Path
import ast,json,hashlib,collections,datetime
root=Path('/tmp/host-pr485-0b7bacad-pipeline-evidence-20261114')
p=root/'full-flutter-artifact-14118412926'
head='0b7bacadd3cdc45d22a8e038c5df50ba8b739d62'
idx=json.loads((p/'archive-index.json').read_text());members={x['path']:x for x in idx['members']}
metadata=json.loads((root/'artifacts-20261114T1442Z/artifacts.original.json').read_text())
art=next(x for x in metadata['artifacts'] if x['id']==14118412926)
assert art['workflow_run']['id']==43604903064 and art['workflow_run']['head_sha']==head
assert art['size_in_bytes']==idx['bytes'] and art['digest']=='sha256:'+idx['sha256']
jobs=json.loads((root/'snapshots/20261114T1443Z/jobs.original.json').read_text())
job=next(x for x in jobs['jobs'] if x['id']==132478533146)
step=next(x for x in job['steps'] if x['name']=='Full Flutter regression suite including every capture')
assert job['head_sha']==head and job['run_id']==43604903064 and step['conclusion']=='success'
summary=json.loads((p/'originals/acceptance-summary.json').read_text())
for name in ['acceptance-summary.json','flutter-machine.jsonl']:
 raw=(p/'originals'/name).read_bytes();assert len(raw)==members[name]['bytes'] and hashlib.sha256(raw).hexdigest()==members[name]['sha256']
raw=(p/'originals/flutter-machine.jsonl').read_text()
events=[];numbered=[];non_json=[];non_object_json=collections.Counter()
for no,line in enumerate(raw.splitlines(),1):
 try:event=json.loads(line)
 except json.JSONDecodeError:non_json.append({'line':no,'nonempty':bool(line.strip())});continue
 if not isinstance(event,dict):non_object_json[type(event).__name__]+=1;continue
 events.append(event);numbered.append((no,event))
source=(root/'flutter-source-binding/run_full_flutter_acceptance.py').read_bytes()
assert hashlib.sha256(source).hexdigest()=='d51614e941cc3c8cec83da860aa9e6b47a0cc47fd5ec8df25c441b8a023c547d'
tree=ast.parse(source.decode());fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='summarize')
ns={};exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),'bound_original_summarize','exec'),ns)
capture_errors=sorted(x for x in members if x.endswith('.error.txt'))
recomputed=ns['summarize'](events,summary['flutter_exit_code'],capture_errors)
for k,value in recomputed.items():assert summary[k]==value,(k,summary[k],value)
assert recomputed['status']=='PASS' and summary['runner_errors']==[]
starts={e['test']['id']:e['test']['name'] for e in events if e.get('type')=='testStart'}
finishes=[(no,e) for no,e in numbered if e.get('type')=='testDone']
assert len(finishes)==len({e['testID'] for _,e in finishes})
assert all(e['testID'] in starts for _,e in finishes)
assert not any(e.get('type')=='error' for e in events)
final=[(no,e) for no,e in numbered if e.get('type')=='done']
assert len(final)==1 and final[0]==numbered[-1] and final[0][1]['success'] is True
pngs=[n for n in members if n.endswith('.png')]
assert len(pngs)==summary['rendered_png_count']
for record in summary['capture_png_counts'].values():
 assert sum(n.startswith(record['directory']+'/') for n in pngs)==record['pngs']
for record in summary['capture_file_outputs'].values():assert (record['path'] in members)==record['created']
target_names=[
'd1_woerter real registry answer persists its exact subject and topic',
'actual Diktat canvas and duplicate self-ratings persist one correct and one wrong word',
'two complete actual Diktat sessions show twenty words and award each earned bonus without extra Daily']
targets=[]
for name in target_names:
 ids=[i for i,n in starts.items() if n==name];assert len(ids)==1
 done=[(no,e) for no,e in finishes if e['testID']==ids[0]];assert len(done)==1
 no,event=done[0];assert event['result']=='success' and event['skipped'] is False and event['hidden'] is False
 targets.append({'test_id':ids[0],'name':name,'original_line':no,'original_event':event})
report={'schema':1,'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'host_source':head,'native_source':'baf148b03a7a32c6ad9f737d731f900eb9113ea1','run_id':43604903064,'run_attempt':1,'job_id':job['id'],'original_step':step,'artifact_id':art['id'],'archive_bytes':idx['bytes'],'archive_sha256':idx['sha256'],'all_member_crc_sha_verified':len(members),'rendered_png_members':len(pngs),'png_decoding_or_visual_review_performed':False,'original_runner_sha256':hashlib.sha256(source).hexdigest(),'summary_recomputed_with_original_summarize_function':recomputed,'runner_errors_from_original_summary':summary['runner_errors'],'machine':{'line_count':len(raw.splitlines()),'object_events':len(events),'non_object_json_values':dict(non_object_json),'non_json_lines':len(non_json),'nonempty_non_json_lines':sum(x['nonempty'] for x in non_json),'all_test_done_events':len(finishes),'hidden_test_done_events':sum(bool(e.get('hidden')) for _,e in finishes),'unique_finished_ids':len({e['testID'] for _,e in finishes}),'error_events':0,'final_done_original_line':final[0][0],'final_done_original_event':final[0][1]},'previously_failed_diktat_cases_current_originals':targets,'capture_counts_checked_against_full_archive_index':True,'scope':'Current complete Flutter suite on 0b7 only; no whole-run, APK, Android, FPS or publication claim. Test event times are original relative milliseconds, not invented UTC timestamps.'}
out=root/'full-flutter-original-review.json';b=(json.dumps(report,indent=2,ensure_ascii=False)+'\n').encode();out.open('xb').write(b)
print(json.dumps({'path':str(out),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'visible_passed':recomputed['passed'],'failed':recomputed['failed'],'skipped':recomputed['skipped'],'machine_events':len(events),'original_done':final[0][1]},ensure_ascii=False))
