from pathlib import Path
import datetime,hashlib,importlib.util,json,os,signal,subprocess,sys,time,tarfile,traceback
B=Path(__file__).resolve().parent
R=Path('/workspace/scratch/b3485b7bb989/native-ce909c4-import-validation-20261114/checkout')
G='/opt/godot/4.6.3/Godot_v4.6.3-stable_linux.x86_64'
for n in ('tmp','xdg-data','xdg-cache','xdg-config'):(B/n).mkdir()
env={**os.environ,'GIT_OPTIONAL_LOCKS':'0','GIT_NO_LAZY_FETCH':'1','PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(B/'tmp'),'XDG_DATA_HOME':str(B/'xdg-data'),'XDG_CACHE_HOME':str(B/'xdg-cache'),'XDG_CONFIG_HOME':str(B/'xdg-config')}
os.environ.update({k:env[k] for k in ('GIT_OPTIONAL_LOCKS','GIT_NO_LAZY_FETCH')})
def ident(d):return {'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()}
def save(n,v):
 p=B/n;p.write_text(json.dumps(v,indent=2)+'\n');assert json.loads(p.read_bytes())==v

def git(*a):return subprocess.check_output(['git','-C',str(R),*a],env=env)
def cache():
 return [{'path':str(p.relative_to(R)),**ident(p.read_bytes())} for p in sorted((R/'.godot').rglob('*')) if p.is_file()]
h=R/'tools/verify_dream_rasters.py';assert ident(h.read_bytes())['sha256']=='f7296a802d15c382dbcc77640373a0f53e30306fcaab3de869549ff1656de89d'
(B/'snapshot-helper-original.py').write_bytes(h.read_bytes());s=importlib.util.spec_from_file_location('snapshot_attempt2',h);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
before=m.snapshot_source(R,B,'before');assert before['head']=='ce909c4d3bab3a5514b653bf945a0ef46adfa539' and before['tree']=='e2a374b2154f7ecb080f693c4bc90def53a20a00'
(B/'git-index-before.bin').write_bytes((R/'.git/index').read_bytes());(B/'git-status-before.bin').write_bytes(git('status','--porcelain=v1','--untracked-files=all'))
oldcache=cache();save('import-cache-before.json',oldcache)
(B/'meminfo-before.txt').write_bytes(Path('/proc/meminfo').read_bytes());mem=dict((line.split(':',1)[0],line.split(':',1)[1].strip()) for line in (B/'meminfo-before.txt').read_text().splitlines());print('MEMORY_BEFORE',mem.get('MemAvailable'),flush=True)
argv=[G,'--headless','--path',str(R),'--editor','--import','--quit'];start=datetime.datetime.now(datetime.timezone.utc).isoformat();timer=time.monotonic();timeout=False
with (B/'import.stdout').open('xb') as stdout,(B/'import.stderr').open('xb') as stderr:
 p=subprocess.Popen(argv,cwd=R,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 print('IMPORT_STARTED',p.pid,start,flush=True)
 try:rc=p.wait(timeout=300)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(p.pid,signal.SIGTERM)
  try:rc=p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);rc=p.wait(timeout=10)
(B/'meminfo-after.txt').write_bytes(Path('/proc/meminfo').read_bytes())
row={'attempt':2,'original_attempt_pack':'/workspace/scratch/b3485b7bb989/native-ce909c4-import-validation-20261114','argv':argv,'cwd':str(R),'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'duration_seconds':time.monotonic()-timer,'timeout_seconds':300,'timed_out':timeout,'returncode':rc,'stdout':ident((B/'import.stdout').read_bytes()),'stderr':ident((B/'import.stderr').read_bytes()),'engine':ident(Path(G).read_bytes()),'environment_overrides':{k:env[k] for k in ('GIT_OPTIONAL_LOCKS','GIT_NO_LAZY_FETCH','PYTHONDONTWRITEBYTECODE','TMPDIR','XDG_DATA_HOME','XDG_CACHE_HOME','XDG_CONFIG_HOME')},'note':'Explicitly authorized single follow-up import after resource relocation; no attribution of first SIGKILL to OOM'};save('invocation.json',row)
error=None
try:
 after=m.snapshot_source(R,B,'after');same={k:before[k]==after[k] for k in ('head','tree','index_sha256','tracked')};assert all(same.values()),same
 generated=after['untracked_import_inventory'];save('generated-uid-import-inventory.json',generated)
 with tarfile.open(B/'generated-uid-import-originals.tar.gz','w:gz') as tf:
  for v in generated:tf.add(R/v['path'],arcname=v['path'],recursive=False)
 with tarfile.open(B/'generated-uid-import-originals.tar.gz','r:gz') as tf:
  for member in tf.getmembers():
   if member.isfile():assert tf.extractfile(member).read()==(R/member.name).read_bytes()
 save('source-invariance.json',{'checks':same,'tracked_count':len(after['tracked']),'materialized_count':sum(x['materialized'] for x in after['tracked']),'generated_entries':len(generated),'no_cleanup_performed':True})
except Exception:
 error=traceback.format_exc();(B/'source-invariance-error.txt').write_text(error)
(B/'git-index-after.bin').write_bytes((R/'.git/index').read_bytes());(B/'git-status-after.bin').write_bytes(git('status','--porcelain=v1','--untracked-files=all'));(B/'git-tracked-diff.patch').write_bytes(git('diff','HEAD','--'))
newcache=cache();save('import-cache-after.json',newcache)
import re
streams=(B/'import.stdout').read_bytes()+b'\n'+(B/'import.stderr').read_bytes();markers=[line.decode('utf-8','replace') for line in streams.splitlines() if re.search(rb'SCRIPT ERROR|Parse Error|ERROR:|Assertion failed|ObjectDB instances leaked|resources still in use at exit',line)]
result={'status':'PASS_IMPORT' if rc==0 and not timeout and not markers and not error else 'FAIL_IMPORT','head':before['head'],'tree':before['tree'],'attempt':2,'returncode':rc,'timed_out':timeout,'error_markers':markers,'source_invariance_error':error,'generated_cache_before':len(oldcache),'generated_cache_after':len(newcache),'old_small_cache_retained_before_start':True,'scope':'One explicitly authorized follow-up editor import only. No test, game, renderer or authority process pair.'};save('result.json',result);print(json.dumps(result),flush=True)
raise SystemExit(0 if result['status']=='PASS_IMPORT' else 1)
