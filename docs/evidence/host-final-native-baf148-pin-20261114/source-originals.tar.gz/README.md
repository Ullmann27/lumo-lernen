# Exact final Native pin on Host a9e03188

This source-only follow-up changes exactly three SHA literals from bd0712259bb64908a5649ee1999638826c9eb597 to baf148b03a7a32c6ad9f737d731f900eb9113ea1. The final Native commit, tree and parent were independently read through the official repository API; its new CI outcome is not asserted.

Only config/godot-source.json revision, APPROVED[2020] and CONNECT_FOUR_2020_REVISION change. All 50 historical pins, version, engine, workflows, budgets and functional gates remain unchanged. Existing source bytes outside these literals must roundtrip exactly.

No repository checkout, Git index, ref, CI or test has been changed or executed. Root publishes the source checkpoint first. The subsequent authorized local gate is exactly one invocation of the existing 24 Candidate plus 40 Legacy test methods, with complete before/after source and Git identity evidence. PR485 activation remains a later Root operation.
