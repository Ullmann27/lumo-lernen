# Native PR182: read-only source review at 9f2e8656

**Status: source comparison frozen; no integration or combined acceptance.**

Compared published Native `9f2e865614262c7176f9fdd987766ff5e45f2551` / tree `8e29d5a15a424b42f27184a763adce8b2aa71b13` against active `baf148b03a7a32c6ad9f737d731f900eb9113ea1` / tree `0c18a0ca5200ade267cfedb4c12d5c4b0a761a00`, using producer base `34421df83566dd4773420cc2a225887956459435`.

## Concrete connection decision

There are 30 relevant paths: 13 new Native asset paths reusing exact current Host image blobs, 13 new text paths, two changed files whose base equals baf, and two true overlapping files. The separate producer workflow and narrative document are references only. All 32 producer delta blobs, modes and sizes are verified against the authentic complete producer tree.

* `host_bridge.gd`: preserve the existing explicit Village opt-in and games fallback. Extend its ordinary scene allowlist with Memory/Quiz and its subject allowlist with Englisch. A whole-file replacement would lose the Village guard.
* `learning_world.gd`: preserve the existing Wisp initialization, four celebration hooks and pause/resume. Merge the English additions into `_build_stage` and `_notification`. Whole-file replacement would lose those target behaviors. Existing PCM narration and durable-return functions are byte-identical across all three versions.

The exact 28 protected target path identities and all 15 unchanged function blocks are in `source-contract-binding.json`. No merged source has been created.

## Actual original CI boundary

Native run `43603969762`, attempt1, is FAILURE and pairs Host `c0ca5265eb4159e6848317da5f49edabaa75bfa0` with Native9f2. Memory succeeded (7020 presenter checks,8 captures; actual pair244 checks/57 inputs). English succeeded (8 Dart cases/1060 checks;3299 renderer checks/10 captures/98 input events). Quiz failed at its question1 persisted-reveal assertion, ending with62 checks/3 captures and QuizNativePair FAIL. The error label is a failed assertion, not proof of successful reveal.

The source rejects null explanations for revealed questions. Producer narrative later identifies an original null explanation and a separate50:50 display issue, but the log does not itself expose the complete question payload. No repair or new success is invented here. Later47ca sources are outside this frozen review.

## Evidence and limits

Stored original API/complete job logs remain in the sibling selective-review pack and are referenced with exact hashes. Local source copies are reconstructed from complete original compare hunks and exact original base bytes, then verified against published Git blobs. Two missing local base blobs were read once from their exact immutable GitHub blob identities. The initial missing-local entries remain unchanged, resolved separately in `additional-source-reads/index.json`.

A generic literal resource scan initially encountered the intentionally invalid `res://secret.glb` negative fixture; its exact classification is documented. All actual literal resource dependencies resolve in the selected target namespace. This is static availability, not an engine result.

No product edits, imports, tests, engine runs, new CI queries, image downloads, visual approval, Git/ref/pin mutation or Android/FPS claim occurred. Existing52/17, Dream, Discovery, Village, Mobile, Wisp and C4Return requirements remain mandatory for any later combined source.
