import importlib.util
from pathlib import Path
import tempfile
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('embedded', ROOT / 'scripts/prepare_embedded_games.py')
embedded = importlib.util.module_from_spec(spec)
spec.loader.exec_module(embedded)


class EmbeddedAndroidTest(unittest.TestCase):
    def test_same_package_private_engine_repeatable_preparation(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            main = root / 'android/app/src/main'
            main.mkdir(parents=True)
            manifest = main / 'AndroidManifest.xml'
            manifest.write_text('<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application><activity android:name=".MainActivity" android:exported="true" /></application><queries><package android:name="dev.ullmann.lumo3d" /></queries></manifest>')
            gradle = root / 'android/app/build.gradle.kts'
            gradle.write_text('android { namespace = "dev.ullmann.lumo.lumo_lernen"\n defaultConfig { applicationId = "dev.ullmann.lumo.lumo_lernen.coachpreview" } }')
            templates = root / 'tools/auto_install'
            templates.mkdir(parents=True)
            for filename in ('GameEventStore.kt', 'LumoGameActivity.kt', 'CardsTableBridge.kt', 'CardsAuthorityService.kt', 'CardsAuthorityRegistry.java', 'ConnectFourBridge.kt', 'ConnectFourAuthorityService.kt', 'ConnectFourGameActivity.kt'):
                (templates / filename).write_text((ROOT / 'tools/auto_install' / filename).read_text())
            # Upgrade a host already prepared by the old script. Existing app
            # rules and its reflected plugin rule must survive the JNI fix.
            rules = root / 'android/app/proguard-rules.pro'
            original_rules = ('# Existing application rules\n'
                              '-keep class example.CustomBridge { *; }\n'
                              '-keep class dev.ullmann.lumo.lumo_lernen.LumoHostPlugin { *; }\n')
            rules.write_text(original_rules)
            embedded.prepare(root)
            first_manifest, first_gradle, first_rules = manifest.read_bytes(), gradle.read_bytes(), rules.read_bytes()
            embedded.prepare(root)
            self.assertEqual(first_manifest, manifest.read_bytes())
            self.assertEqual(first_gradle, gradle.read_bytes())
            self.assertEqual(first_rules, rules.read_bytes())
            self.assertTrue(rules.read_text().startswith(original_rules))
            self.assertEqual(rules.read_text().count('-keep class org.godotengine.godot.** { *; }'), 1)
            self.assertEqual(rules.read_text().count('-keep class dev.ullmann.lumo.lumo_lernen.LumoHostPlugin { *; }'), 1)
            self.assertEqual(rules.read_text().count(
                '-keep class * implements com.google.firebase.components.ComponentRegistrar { *; }'), 1)
            doc = ET.parse(manifest).getroot()
            attr = lambda name: '{http://schemas.android.com/apk/res/android}' + name
            activities = doc.findall('application/activity')
            self.assertEqual(len(activities), 3)
            engine = activities[1]
            self.assertEqual(engine.get(attr('exported')), 'false')
            self.assertEqual(engine.get(attr('process')), ':lumo_game')
            self.assertEqual(engine.get(attr('resizeableActivity')), 'true')
            services = doc.findall('application/service')
            self.assertEqual(len(services), 2)
            self.assertEqual(services[0].get(attr('name')), 'dev.ullmann.lumo.lumo_lernen.CardsAuthorityService')
            self.assertEqual(services[0].get(attr('exported')), 'false')
            self.assertIsNone(services[0].get(attr('process')), 'Authority must share the Dart main process')
            c4 = activities[2]
            self.assertEqual(c4.get(attr('name')), 'dev.ullmann.lumo.lumo_lernen.ConnectFourGameActivity')
            self.assertEqual(c4.get(attr('exported')), 'false')
            self.assertEqual(c4.get(attr('process')), ':lumo_game')
            self.assertEqual(c4.get(attr('screenOrientation')), 'sensor')
            self.assertEqual(services[1].get(attr('name')), 'dev.ullmann.lumo.lumo_lernen.ConnectFourAuthorityService')
            self.assertEqual(services[1].get(attr('exported')), 'false')
            self.assertIsNone(services[1].get(attr('process')))
            self.assertIn('-keep class dev.ullmann.lumo.lumo_lernen.ConnectFourHostPlugin { *; }', rules.read_text())
            self.assertFalse(doc.findall('uses-permission'), 'No new background/wake/network permissions')
            service_file = main / 'kotlin/dev/ullmann/lumo/lumo_lernen/CardsAuthorityService.kt'
            self.assertTrue(service_file.is_file())
            self.assertIn('package dev.ullmann.lumo.lumo_lernen', service_file.read_text())
            registry_file = main / 'java/dev/ullmann/lumo/lumo_lernen/CardsAuthorityRegistry.java'
            self.assertTrue(registry_file.is_file())
            self.assertTrue(registry_file.read_text().startswith('package dev.ullmann.lumo.lumo_lernen;\n'))
            self.assertFalse(doc.findall('queries/package'))
            renderer = [entry for entry in doc.findall('application/meta-data')
                        if entry.get(attr('name')) == 'io.flutter.embedding.android.EnableImpeller']
            self.assertEqual(len(renderer), 1)
            self.assertEqual(renderer[0].get(attr('value')), 'false')
            self.assertIn('org.godotengine:godot:4.6.3.stable', gradle.read_text())
            self.assertIn('.coachpreview', gradle.read_text())
            self.assertIn('noCompress += "pck"', gradle.read_text())
            self.assertIn('if (project.findProperty("split-per-abi") != "true") {', gradle.read_text())
            self.assertIn('abiFilters.addAll(listOf("arm64-v8a", "x86_64"))', gradle.read_text())
            self.assertNotIn('ndk { abiFilters.clear(); abiFilters.addAll', gradle.read_text())
            self.assertIn('android.applicationVariants.configureEach {', gradle.read_text())
            self.assertIn('apkOutput.versionCodeOverride = flutter.versionCode', gradle.read_text())
            self.assertEqual(gradle.read_text().count('apkOutput.versionCodeOverride = flutter.versionCode'), 1)
            self.assertNotIn('afterEvaluate {', gradle.read_text())
            self.assertNotIn('androidComponents {', gradle.read_text())
            self.assertIn('tasks.register("verifyLumoSplitVersionCodes")', gradle.read_text())
            self.assertIn('apkOutput.versionCodeOverride == expected', gradle.read_text())


if __name__ == '__main__':
    unittest.main()
