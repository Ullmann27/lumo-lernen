from pathlib import Path
import subprocess, json, hashlib, datetime, time, os, shutil
BASE=Path(__file__).resolve().parent
REPO=BASE/'checkout'
OLD=Path('/workspace/scratch/b3485b7bb989/native2281-packaging-export-20261114/checkout-after')
HEAD='ce909c4d3bab3a5514b653bf945a0ef46adfa539'
TREE='e2a374b2154f7ecb080f693c4bc90def53a20a00'
BASE.joinpath('setup').mkdir()
ENV={**os.environ,'GIT_OPTIONAL_LOCKS':'0','PYTHONDONTWRITEBYTECODE':'1'}
def identity(data):return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
seq=0
rows=[]
def run(argv,cwd):
 global seq
 seq+=1;stem=f'{seq:02d}'
 start=now();t=time.monotonic()
 with (BASE/'setup'/f'{stem}.stdout').open('xb') as out,(BASE/'setup'/f'{stem}.stderr').open('xb') as err:
  p=subprocess.run(argv,cwd=cwd,env=ENV,stdout=out,stderr=err)
 row={'argv':argv,'cwd':str(cwd),'started_at':start,'finished_at':now(),'duration_seconds':time.monotonic()-t,'returncode':p.returncode,'stdout':identity((BASE/'setup'/f'{stem}.stdout').read_bytes()),'stderr':identity((BASE/'setup'/f'{stem}.stderr').read_bytes())}
 rows.append(row);(BASE/'setup'/'invocations.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(stem,argv[0:5],p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 return (BASE/'setup'/f'{stem}.stdout').read_bytes()
old_index=OLD/'.git/index'
old={'head':subprocess.check_output(['git','-C',str(OLD),'rev-parse','HEAD'],env=ENV).decode().strip(),'index':identity(old_index.read_bytes()),'objects':str((OLD/'.git/objects').resolve())}
(BASE/'setup'/'original-object-store-before.json').write_text(json.dumps(old,indent=2)+'\n')
run(['git','init',str(REPO)],BASE)
alt=REPO/'.git/objects/info/alternates'
alt.write_text(str((OLD/'.git/objects').resolve())+'\n')
run(['git','remote','add','origin','https://github.com/Ullmann27/lumo-godot.git'],REPO)
run(['git','-c','http.version=HTTP/1.1','-c','protocol.version=2','fetch','--depth=1','--filter=blob:none','--no-tags','origin',HEAD],REPO)
run(['git','checkout','--detach',HEAD],REPO)
actual=run(['git','rev-parse','HEAD','HEAD^{tree}'],REPO).decode().splitlines()
assert actual==[HEAD,TREE],actual
status=run(['git','status','--porcelain=v1','--untracked-files=all'],REPO)
assert not status,status
raw=run(['git','cat-file','commit',HEAD],REPO)
assert hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==HEAD
assert ('parent 2281d990fb584db6f2cf786da8fec3badc2d9585\n').encode() in raw
old_after={'head':subprocess.check_output(['git','-C',str(OLD),'rev-parse','HEAD'],env=ENV).decode().strip(),'index':identity(old_index.read_bytes()),'objects':str((OLD/'.git/objects').resolve())}
assert old_after==old
(BASE/'setup'/'original-object-store-after.json').write_text(json.dumps(old_after,indent=2)+'\n')
summary={'status':'EXACT_CLEAN_CHECKOUT','head':HEAD,'tree':TREE,'checkout':str(REPO),'parent_object_store_unchanged':True,'workspace_free_bytes':shutil.disk_usage(BASE).free,'commands':len(rows)}
(BASE/'setup'/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
