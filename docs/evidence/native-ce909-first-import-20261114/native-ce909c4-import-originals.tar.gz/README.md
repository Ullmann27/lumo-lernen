# Native ce909c4: actual import failure and focused contract result

This immutable evidence records one real Godot 4.6.3 editor import on the exact published Native commit ce909c4d3bab3a5514b653bf945a0ef46adfa539. The import was killed by SIGKILL after 7.974 seconds, before completion. Its independent 300-second local watcher did not expire. The last original progress message is “Creating autoload scripts...”; stderr is empty. The available original streams contain no script/parser/leak error. The cause is unresolved. Post-failure memory observations cannot establish causality and the expected cgroup counters are unavailable. No engine retry has been performed.

The first and only separate run of tools.tests.test_memory_native_pair_evidence passed all six synthetic evidence-counterexample methods, with zero skips. It does not execute a game or establish an authority pair or device result.

The full index and all 3,742 materialized tracked bytes and modes, HEAD and tree match before and after both stages. All 34 new sources and 35 protected paths match the frozen source identities. The shared parent object store's HEAD/index remained unchanged. Two generated .godot cache files (5,651 bytes) are inventoried and archived; no external UID/import files were generated and no cleanup was performed.

The technical archive includes all original command streams, invocation/exit records, source inventories, source bindings, snapshot-reader source and the exact small cache originals. The complete private checkout remains outside the archive; its existing tracked sources are bound to the published Git object. Actual Host/Native pairs await successful import and explicit environment coordination.
