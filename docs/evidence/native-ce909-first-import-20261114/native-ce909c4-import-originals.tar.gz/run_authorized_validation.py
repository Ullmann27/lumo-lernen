from pathlib import Path
import ast,hashlib,importlib.util,json,os,re,subprocess,sys,time,datetime,tarfile,traceback,shutil
BASE=Path(__file__).resolve().parent
REPO=BASE/'checkout'
PACK=Path('/workspace/scratch/b3485b7bb989/native182-29080-integration-2281-20261114')
HEAD='ce909c4d3bab3a5514b653bf945a0ef46adfa539'; TREE='e2a374b2154f7ecb080f693c4bc90def53a20a00'
GODOT=Path('/opt/godot/4.6.3/Godot_v4.6.3-stable_linux.x86_64')
OUT=BASE/'validation';OUT.mkdir(exist_ok=False)
for n in ('tmp','xdg-data','xdg-cache','xdg-config'): (OUT/n).mkdir()
ENV={**os.environ,'GIT_OPTIONAL_LOCKS':'0','GIT_NO_LAZY_FETCH':'1','PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(OUT/'tmp'),'XDG_DATA_HOME':str(OUT/'xdg-data'),'XDG_CACHE_HOME':str(OUT/'xdg-cache'),'XDG_CONFIG_HOME':str(OUT/'xdg-config')}
os.environ.update({k:v for k,v in ENV.items() if k in ('GIT_OPTIONAL_LOCKS','GIT_NO_LAZY_FETCH','PYTHONDONTWRITEBYTECODE')})
def ident(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def save(name,v):
 p=OUT/name;p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n');assert json.loads(p.read_bytes())==v
 return p

def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args],env=ENV)
assert git('rev-parse','HEAD','HEAD^{tree}').decode().splitlines()==[HEAD,TREE]
assert not git('status','--porcelain=v1','--untracked-files=all')
for f in ('source-freeze.json','protected-target-paths.json'):
 data=(PACK/f).read_bytes();(OUT/f).write_bytes(data)
records=[]
for item in json.loads((PACK/'source-freeze.json').read_bytes())['sources']+json.loads((PACK/'protected-target-paths.json').read_bytes())['paths']:
 p=REPO/item['path'];actual=ident(p.read_bytes());mode='100755' if p.stat().st_mode&0o111 else '100644'
 assert all(actual[k]==item[k] for k in ('bytes','sha256','git_blob')) and mode==item['mode'],item['path']
 records.append({'path':item['path'],'mode':mode,**actual})
save('source-freeze-binding.json',{'head':HEAD,'tree':TREE,'new_sources':34,'protected_paths':35,'verified':records})
engine=ident(GODOT.read_bytes());assert engine['sha256']=='f64d4ed19fc9df9440321653fcc80df8c6e365ba7b6de0a29e2cfa9fa71bfeb3'
helper=REPO/'tools/verify_dream_rasters.py';h=ident(helper.read_bytes());assert h['sha256']=='f7296a802d15c382dbcc77640373a0f53e30306fcaab3de869549ff1656de89d'
(OUT/'snapshot-helper-original.py').write_bytes(helper.read_bytes())
save('tool-binding.json',{'engine':{'path':str(GODOT),**engine},'snapshot_helper':{'path':'tools/verify_dream_rasters.py',**h},'python':sys.version,'environment_overrides':{k:ENV[k] for k in ('GIT_OPTIONAL_LOCKS','GIT_NO_LAZY_FETCH','PYTHONDONTWRITEBYTECODE','TMPDIR','XDG_DATA_HOME','XDG_CACHE_HOME','XDG_CONFIG_HOME')}})
spec=importlib.util.spec_from_file_location('bound_dream_snapshot',helper);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
before=mod.snapshot_source(REPO,OUT,'before')
for name,args in [('git-index-before.bin',('ls-files','--stage','-z')),('git-tree-before.bin',('ls-tree','-rz','HEAD')),('git-status-before.bin',('status','--porcelain=v1','--untracked-files=all'))]: (OUT/name).write_bytes(git(*args))
(OUT/'git-index-file-before.bin').write_bytes((REPO/'.git/index').read_bytes())
stages=[]
def run(name,argv,timeout):
 stem=OUT/name;started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
 with stem.with_suffix('.stdout').open('xb') as out,stem.with_suffix('.stderr').open('xb') as err:
  p=subprocess.Popen(argv,cwd=REPO,env=ENV,stdout=out,stderr=err,start_new_session=True)
  timed_out=False
  try:rc=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   import signal
   timed_out=True;os.killpg(p.pid,signal.SIGTERM)
   try:rc=p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);rc=p.wait(timeout=10)
 data=stem.with_suffix('.stdout').read_bytes()+b'\n'+stem.with_suffix('.stderr').read_bytes()
 errors=[line.decode('utf-8','replace') for line in data.splitlines() if re.search(rb'SCRIPT ERROR|Parse Error|ERROR:|Assertion failed|ObjectDB instances leaked|resources still in use at exit',line)]
 row={'name':name,'argv':argv,'cwd':str(REPO),'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'duration_seconds':time.monotonic()-t,'timeout_seconds':timeout,'timed_out':timed_out,'returncode':rc,'stdout':ident(stem.with_suffix('.stdout').read_bytes()),'stderr':ident(stem.with_suffix('.stderr').read_bytes()),'error_markers':errors}
 stages.append(row);save('invocations.json',stages);print(json.dumps({'stage':name,'returncode':rc,'seconds':row['duration_seconds'],'errors':errors,'timed_out':timed_out}),flush=True)
 if rc or timed_out or errors:raise RuntimeError('Actual stage failed: '+name)
 return row
error=None
try:
 print('BEFORE_BOUND',len(before['tracked']),flush=True)
 run('godot-import',[str(GODOT),'--headless','--path',str(REPO),'--editor','--import','--quit'],300)
 test=REPO/'tools/tests/test_memory_native_pair_evidence.py'
 methods=[n.name for n in ast.walk(ast.parse(test.read_text())) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
 assert len(methods)==6
 save('focused-test-binding.json',{'path':str(test.relative_to(REPO)),**ident(test.read_bytes()),'method_count':len(methods),'methods':methods,'scope':'Synthetic evidence counterexamples only; no game or host/native process pair'})
 run('memory-evidence-contracts',[sys.executable,'-B','-m','unittest','-v','tools.tests.test_memory_native_pair_evidence'],60)
except Exception as exc:
 error=repr(exc);(OUT/'failure.txt').write_text(traceback.format_exc())
finally:
 try:
  after=mod.snapshot_source(REPO,OUT,'after')
  invariance={k:before[k]==after[k] for k in ('head','tree','index_sha256','tracked')}
  assert all(invariance.values()),invariance
  generated=after['untracked_import_inventory'];save('generated-uid-import-inventory.json',generated)
  with tarfile.open(OUT/'generated-uid-import-originals.tar.gz','w:gz') as tf:
   for item in generated:tf.add(REPO/item['path'],arcname=item['path'],recursive=False)
  with tarfile.open(OUT/'generated-uid-import-originals.tar.gz','r:gz') as tf:
   members=tf.getmembers();assert len(members)==len(generated)
   for member in members:
    if member.isfile():assert tf.extractfile(member).read()==(REPO/member.name).read_bytes()
  save('source-invariance.json',{'checks':invariance,'tracked_count':len(after['tracked']),'materialized_count':sum(e['materialized'] for e in after['tracked']),'generated_entries':len(generated),'generated_archive':ident((OUT/'generated-uid-import-originals.tar.gz').read_bytes()),'no_cleanup_performed':True})
 except Exception:
  (OUT/'source-invariance-error.txt').write_text(traceback.format_exc());error=error or 'source-invariance failure'
 for name,args in [('git-index-after.bin',('ls-files','--stage','-z')),('git-tree-after.bin',('ls-tree','-rz','HEAD')),('git-status-after.bin',('status','--porcelain=v1','--untracked-files=all')),('git-tracked-diff-after.patch',('diff','HEAD','--'))]: (OUT/name).write_bytes(git(*args))
 (OUT/'git-index-file-after.bin').write_bytes((REPO/'.git/index').read_bytes())
 summary={'status':'FAIL' if error else 'PASS_IMPORT_AND_6_PYTHON_CONTRACTS','head':HEAD,'tree':TREE,'error':error,'stages':len(stages),'scope':'One editor import and six focused Python evidence contracts. No game/renderer/authority-pair/Android run.'}
 save('result.json',summary);print(json.dumps(summary),flush=True)
if error:raise SystemExit(1)
