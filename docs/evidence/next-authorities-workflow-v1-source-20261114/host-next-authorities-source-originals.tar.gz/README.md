# Separate next-authority qualification: frozen source proposal

The sole proposed repository file is `.github/workflows/lumo-next-table-authorities.yml`. It runs only on an actual push to `integration/lumo-next-table-authorities-20261114` with read-only repository permissions. Its Host is the actual pushed `github.sha`; its Native source is immutable ce909c4d3bab3a5514b653bf945a0ef46adfa539 / e2a374b2154f7ecb080f693c4bc90def53a20a00. The read-only source review used Host3fac, but that old literal is not an executed workflow result or pin.

## Five independent groups

- Memory: the original geometry renderer and real Dart/Godot authority, preserving the 900-second view and 330-second pair limits; eight view PNGs, eight authority captures and twelve actual motion frames.
- Quiz: the original real Dart/Godot authority with its 330-second limit, six captures and the actual durable QA ledger/return checks.
- English: fresh actual Dart vocabulary payload, its original SHA bound in the actual 900-second Native renderer, seventeen PNGs.
- Android Host compile: unchanged current `compile_android_host.sh`, genuine Kotlin/Java compilation, actual Table and retained C4 class bytes copied and hashed. No APK/device result is inferred.
- Focused Flutter: precisely the original seven requested files, one process with concurrency one, complete raw machine stdout/stderr, the unchanged strict summarize function, all seven suites, completion, nonzero tests and zero skips required. A new explicit 1,200-second process bound prevents an unending compiler failure; it is not a retry.

All groups have the existing 35-minute narrow job budget. The three renderer groups import once with a 300-second bound and the proven Godot4.6.3 ZIP/binary hashes. No local engine attempt was made for this pack.

## Source and original-evidence boundary

Both repositories are fully checked out. The verified unchanged Dream reader snapshots every tracked byte/mode and Git index before and after. Native HEAD/tree are exact; the pushed Host commit object and tree are bound directly. Generated UID/import files are inventoried and preserved separately. Every declared pubspec asset/font, including the documented cards WebP, must exist with its committed bytes. No sparse exclusion or substitute asset is allowed.

Current renderer report PNGs are fully decoded with the bound original Pillow reader and checked against actual report dimensions/hashes. Original sidecars are retained. Report counts are tied to unique original engine markers. Actual source pairs, child exit codes, errors, timeouts and leak markers are checked. Complete fresh artifacts are uploaded even on failure; no token or signed URL is requested or saved.

The actual local import SIGKILLs and Flutter setup/compiler failures remain separate evidence. Producer29080/Host50503 is only the original template's provenance and cannot become a current pair result. The four existing Dart contracts and 99/45 local Python/JVM results are not separately re-counted as new qualification; English's real producer is necessarily run to supply fresh current renderer input. The unchanged Android compiler keeps its mandatory tests.

## Deliberately unchanged

The active C4 workflow, candidate verifier, delivery verifier, source pins, product sources and existing 52/17, Dream, Discovery, Wisp/Return and release gates are untouched. This five-group desktop/compile/Flutter qualification grants no Android Binder, SharedPreferences, APK, FPS or publication approval. APK pin and future device/delivery hookup remain Root decisions after actual results.

`review-only-inline-code/` contains verbatim excerpts to ease source review; these are not extra proposed repository files. No generated inline code was imported or executed locally. Actionlint and actual qualification wait for Root's published source checkpoint.
