from pathlib import Path
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
HOST = BASE / 'host-3fac2cfa-focused-validation-20261114/checkout'
NATIVE = BASE / 'native-ce909c4-import-validation-20261114/checkout'
ENV = {**os.environ, 'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1'}
TARGET = '.github/workflows/lumo-next-table-authorities.yml'


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args], env=ENV)


def source_state(root):
    index = Path(os.fsdecode(git(root, 'rev-parse', '--git-path', 'index')).strip())
    if not index.is_absolute():
        index = root / index
    return {'head': git(root, 'rev-parse', 'HEAD').decode().strip(),
            'tree': git(root, 'rev-parse', 'HEAD^{tree}').decode().strip(),
            'index_sha256': hashlib.sha256(index.read_bytes()).hexdigest(),
            'tracked_diff': git(root, 'diff', '--name-only', 'HEAD', '--').decode()}


def write_json(path, value):
    data = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        raise ValueError('Refusing to replace a frozen proof: ' + path)
    target.write_bytes(data)
    assert target.read_bytes() == data
    return identity(data)


before = {'host': source_state(HOST), 'native': source_state(NATIVE)}
assert before['host']['head'] == '3fac2cfaf23b80a127e711130fc6d7692776d316'
assert before['host']['tree'] == 'e76ef3862a0b2c73706d425a2b92a484fda5f9f3'
assert before['native']['head'] == 'ce909c4d3bab3a5514b653bf945a0ef46adfa539'
assert before['native']['tree'] == 'e2a374b2154f7ecb080f693c4bc90def53a20a00'
assert all(not value['tracked_diff'] for value in before.values())
assert git(HOST, 'ls-tree', 'HEAD', TARGET) == b''
references = []
native_references = [
    'tools/verify_dream_rasters.py', 'tools/run_godot_probe.py', 'tools/validate_project.py',
    'tools/run_memory_native_authority.py', 'tools/run_quiz_native_authority.py',
    'scripts/tests/learning_english_regression.gd', 'scripts/tests/memory_table_regression.gd',
    'scripts/tests/memory_table_runtime.gd', 'scripts/tests/quiz_studio_runtime.gd',
]
host_references = [
    '.github/workflows/lumo-connect-four-2020.yml', 'scripts/verify_connect_four_delivery.py',
    'scripts/verify_connect_four_candidate.py', 'scripts/compile_android_host.sh',
    'scripts/run_full_flutter_acceptance.py', 'pubspec.yaml', 'pubspec.lock',
    'tool/check_native_english_activity.dart', 'tools/android_qa/memory_native_authority.dart',
    'tools/android_qa/quiz_native_authority.dart',
    'test/games/memory_native_entry_test.dart', 'test/games/memory_result_frame_test.dart',
    'test/quiz_native_roundtrip_lifecycle_test.dart', 'test/reward_wallet_queue_zone_test.dart',
    'test/table_games_launcher_binding_test.dart', 'test/table_games_wallet_profile_test.dart',
    'test/tutoring/native_english_activity_test.dart',
]
for kind, checkout, paths in [('native-ce909', NATIVE, native_references), ('host3fac', HOST, host_references)]:
    for relative in paths:
        raw = (checkout / relative).read_bytes()
        info = identity(raw)
        assert git(checkout, 'rev-parse', 'HEAD:' + relative).decode().strip() == info['git_blob']
        destination = ROOT / 'originals' / kind / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            assert destination.read_bytes() == raw
        else:
            destination.write_bytes(raw)
        assert destination.read_bytes() == raw
        references.append({'repository': kind, 'path': relative, 'commit': before['native' if kind.startswith('native') else 'host']['head'],
                           'original_copy': str(destination.relative_to(ROOT)), **info})

workflow = (ROOT / 'final-source' / TARGET).read_bytes()
text = workflow.decode()
assert b'\0' not in workflow
assert '50503fef8e93700d9a889e33c3d2c37fccb46e42' not in text
assert '3fac2cfaf23b80a127e711130fc6d7692776d316' not in text
assert 'EXPECTED_HOST: ${{ github.sha }}' in text
assert 'group: [memory, quiz, english, android-host-compile, flutter-contracts]' in text
assert 'd0bc2113065e481c9c2c2b2c37daa4e8be3fe9e27f0ab9ab0b6096e9a37907f3' in text
final = {'path': TARGET, 'source_path': 'final-source/' + TARGET, 'mode': '100644', 'before': None, 'after': identity(workflow)}
patch = ('diff --git a/' + TARGET + ' b/' + TARGET + '\nnew file mode 100644\n'
         + 'index 0000000000000000000000000000000000000000..' + final['after']['git_blob'] + '\n'
         + ''.join(difflib.unified_diff([], text.splitlines(keepends=True), fromfile='/dev/null', tofile='b/' + TARGET)))
(ROOT / 'integration.patch').write_text(patch)

contract = {
    'schema': 1, 'scope': 'Separate exact-source qualification, not a C4 release or APK approval',
    'workflow': TARGET, 'trigger': {'event': 'push', 'repository': 'Ullmann27/lumo-lernen',
                                  'branch': 'integration/lumo-next-table-authorities-20261114'},
    'host': 'Actual github.sha of the newly checkpointed workflow, including any intervening approved QA-only correction',
    'native': before['native']['head'], 'native_tree': before['native']['tree'],
    'permissions': {'contents': 'read'}, 'source_count': 1,
    'groups': [
        {'name': 'memory', 'job_timeout_minutes': 35,
         'commands': ['run_godot_probe.py --timeout 900 --required MEMORY_VIEW_PASS -- xvfb-run ... memory_table_regression.gd -- --capture',
                      'xvfb-run ... run_memory_native_authority.py --expected-native ce909c4d3bab3a5514b653bf945a0ef46adfa539 --expected-host "$EXPECTED_HOST" --capture'],
         'pair_timeout_seconds': 330, 'required_original_pngs': 28,
         'png_scope': '8 geometry fixtures + 8 actual production-authority gameplay frames + 12 actual motion frames',
         'original_reports': ['memory-view/memory-view-result.json', 'memory-pair/pair-result.json', 'memory-pair/native/memory-runtime-report.json']},
        {'name': 'quiz', 'job_timeout_minutes': 35, 'pair_timeout_seconds': 330,
         'required_original_pngs': 6,
         'original_reports': ['quiz-pair/pair-result.json', 'quiz-pair/native/quiz-runtime-report.json']},
        {'name': 'english', 'job_timeout_minutes': 35, 'renderer_timeout_seconds': 900,
         'required_original_pngs': 17, 'fixture_producer': 'dart run tool/check_native_english_activity.dart --out .../english-activity.json',
         'original_reports': ['english-activity.json', 'english-native/learning-english-report.json'],
         'fixture_binding': 'Actual current Dart examples and their original SHA are required by the Native report'},
        {'name': 'android-host-compile', 'job_timeout_minutes': 35,
         'command': 'bash scripts/compile_android_host.sh',
         'unchanged_script_sha256': 'fb7c338e9c551fdbb5711ed30bb19c7b799ecf75f87176757eede9cac7e7bb03',
         'required_table_classes': ['TableGameActivity', 'TableGamesHostPlugin', 'TableGamesBridge', 'TableAuthorityService', 'TableGameIntent'],
         'retained_c4_classes': ['ConnectFourGameActivity', 'ConnectFourAuthorityService', 'ConnectFourBridge'],
         'originals': 'Full compile stdout and helper reports plus byte-identical compiled classes; no APK assembly or device acceptance'},
        {'name': 'flutter-contracts', 'job_timeout_minutes': 35, 'single_process_wall_seconds': 1200,
         'argv': ['flutter', 'test', '--no-pub', '--machine', '--concurrency=1', *host_references[-7:]],
         'no_skip_parser': 'Unmodified scripts/run_full_flutter_acceptance.py:summarize, SHA d51614e941cc3c8cec83da860aa9e6b47a0cc47fd5ec8df25c441b8a023c547d',
         'requirements': ['Exactly seven actual suite paths', 'Every started test finishes', 'One successful done event', 'Positive real visible passed count', 'No failed or skipped test', 'No machine error event', 'Exit zero and no timeout'],
         'originals': 'Exact binary stdout/stderr retained; non-JSON/non-object stdout lines are indexed separately and never rewritten'},
    ],
    'all_groups': ['Full Host and Native checkouts, no sparse exclusion', 'All pubspec-declared assets/fonts are current committed bytes, including cards docs WebP',
                   'Exact Godot snapshot helper SHA plus Git blob verified before import',
                   'Actual Host/Native commit objects, trees, all tracked bytes/modes and raw index bound before/after',
                   'Generated UID/import outputs inventoried/archived separately, no git clean',
                   'Pillow 12.3.0; Flutter 3.44.9; actual Host lockfile enforced',
                   'Complete fresh original evidence uploaded on every outcome for 30 days'],
    'renderer_toolchain': {'godot': '4.6.3.stable.official.7d41c59c4',
                          'zip_sha256': 'd0bc2113065e481c9c2c2b2c37daa4e8be3fe9e27f0ab9ab0b6096e9a37907f3',
                          'binary_sha256': 'f64d4ed19fc9df9440321653fcc80df8c6e365ba7b6de0a29e2cfa9fa71bfeb3',
                          'import_wall_seconds': 300, 'display': 'Actual Xvfb screen 2560x2560x24',
                          'backend': 'gl_compatibility with LIBGL_ALWAYS_SOFTWARE=1'},
    'retained_old_validation': 'Local four Dart contracts, 99 Android probe contracts, 45 JVM methods and six Native Python counterexamples remain their original separate evidence. The new workflow does not relabel or redundantly count those as fresh renderer/device results. The existing compile helper retains its own mandatory tests.',
    'new_fixture_generation': 'English repeats the Dart producer only because its fresh output bytes are an input to the exact paired Native renderer.',
    'not_executed_for_this_pack': ['actionlint', 'Python tests', 'Dart or Flutter', 'Godot imports', 'renderer', 'Android compilation', 'CI'],
}
write_json('qualification-contract.json', contract)
write_json('original-source-map.json', {'schema': 1, 'source_before': before, 'references': references,
    'producer_template': {'url': 'https://api.github.com/repos/Ullmann27/lumo-godot/contents/.github/workflows/lumo-nextgen-authority-check.yml?ref=29080ef8cd1a5b385eeeec97976fbefd31280427',
                         **identity((ROOT / 'originals/native290-authority-workflow.original.yml').read_bytes())},
    'protected_existing_workflow_and_verifiers': host_references[:3]})
freeze = {'schema': 1, 'status': 'FROZEN_UNTESTED_EXTERNAL_SOURCE_BEFORE_ROOT_CHECKPOINT',
          'created_utc': datetime.now(timezone.utc).isoformat(),
          'reviewed_host_base': before['host'], 'immutable_native': before['native'],
          'future_host_execution': 'github.sha, never the reviewed baseline literal',
          'source_count': 1, 'files': [final], 'git_mutations': False, 'remote_mutations': False,
          'imports_or_tests_or_lint': 0}
write_json('source-freeze.json', freeze)

readme = '''# Separate next-authority qualification: frozen source proposal

The sole proposed repository file is `.github/workflows/lumo-next-table-authorities.yml`. It runs only on an actual push to `integration/lumo-next-table-authorities-20261114` with read-only repository permissions. Its Host is the actual pushed `github.sha`; its Native source is immutable ce909c4d3bab3a5514b653bf945a0ef46adfa539 / e2a374b2154f7ecb080f693c4bc90def53a20a00. The read-only source review used Host3fac, but that old literal is not an executed workflow result or pin.

## Five independent groups

- Memory: the original geometry renderer and real Dart/Godot authority, preserving the 900-second view and 330-second pair limits; eight view PNGs, eight authority captures and twelve actual motion frames.
- Quiz: the original real Dart/Godot authority with its 330-second limit, six captures and the actual durable QA ledger/return checks.
- English: fresh actual Dart vocabulary payload, its original SHA bound in the actual 900-second Native renderer, seventeen PNGs.
- Android Host compile: unchanged current `compile_android_host.sh`, genuine Kotlin/Java compilation, actual Table and retained C4 class bytes copied and hashed. No APK/device result is inferred.
- Focused Flutter: precisely the original seven requested files, one process with concurrency one, complete raw machine stdout/stderr, the unchanged strict summarize function, all seven suites, completion, nonzero tests and zero skips required. A new explicit 1,200-second process bound prevents an unending compiler failure; it is not a retry.

All groups have the existing 35-minute narrow job budget. The three renderer groups import once with a 300-second bound and the proven Godot4.6.3 ZIP/binary hashes. No local engine attempt was made for this pack.

## Source and original-evidence boundary

Both repositories are fully checked out. The verified unchanged Dream reader snapshots every tracked byte/mode and Git index before and after. Native HEAD/tree are exact; the pushed Host commit object and tree are bound directly. Generated UID/import files are inventoried and preserved separately. Every declared pubspec asset/font, including the documented cards WebP, must exist with its committed bytes. No sparse exclusion or substitute asset is allowed.

Current renderer report PNGs are fully decoded with the bound original Pillow reader and checked against actual report dimensions/hashes. Original sidecars are retained. Report counts are tied to unique original engine markers. Actual source pairs, child exit codes, errors, timeouts and leak markers are checked. Complete fresh artifacts are uploaded even on failure; no token or signed URL is requested or saved.

The actual local import SIGKILLs and Flutter setup/compiler failures remain separate evidence. Producer29080/Host50503 is only the original template's provenance and cannot become a current pair result. The four existing Dart contracts and 99/45 local Python/JVM results are not separately re-counted as new qualification; English's real producer is necessarily run to supply fresh current renderer input. The unchanged Android compiler keeps its mandatory tests.

## Deliberately unchanged

The active C4 workflow, candidate verifier, delivery verifier, source pins, product sources and existing 52/17, Dream, Discovery, Wisp/Return and release gates are untouched. This five-group desktop/compile/Flutter qualification grants no Android Binder, SharedPreferences, APK, FPS or publication approval. APK pin and future device/delivery hookup remain Root decisions after actual results.

`review-only-inline-code/` contains verbatim excerpts to ease source review; these are not extra proposed repository files. No generated inline code was imported or executed locally. Actionlint and actual qualification wait for Root's published source checkpoint.
'''
(ROOT / 'README.md').write_text(readme, encoding='utf-8')

after = {'host': source_state(HOST), 'native': source_state(NATIVE)}
assert before == after
for row in references:
    checkout = HOST if row['repository'] == 'host3fac' else NATIVE
    assert identity((checkout / row['path']).read_bytes()) == {k: row[k] for k in ('bytes', 'sha256', 'git_blob')}
write_json('static-self-review.json', {
    'schema': 1, 'kind': 'SOURCE_READING_AND_BYTE_BINDING_ONLY',
    'source_before': before, 'source_after': after,
    'protected_sources_unchanged': True, 'source_count': 1,
    'findings': ['Host is dynamic actual github.sha including the approved intervening QA fix; Native stays exact ce909/tree e2a374b2',
                 'Original pair helpers and renderer probes are used unchanged; 900/330-second original limits are preserved',
                 'All five groups fail independently with fail-fast false; no continue-on-error, rerun, source fallback or substitute renderer',
                 'Source snapshot and PNG reader byte identities checked before dynamic imports',
                 'Original seven Flutter tests and unmodified summarize function used with concurrency one and no-skip completion checks',
                 'Actual compile script and genuine produced Table/C4 class bytes are required',
                 'The published template and root compile contract were read; original image dimensions/report/marker fields were compared with the actual Native probe sources'],
    'initial_source_draft_corrections_before_freeze': ['Corrected a typed Godot ZIP hash to the exact existing original before any execution or freeze'],
    'test_or_lint_or_generated_code_execution': False,
    'independent_review_pending': True,
})

manifest = {'schema': 1, 'status': 'FROZEN', 'files': []}
for path in sorted(ROOT.rglob('*')):
    if path.is_file():
        manifest['files'].append({'path': str(path.relative_to(ROOT)), **identity(path.read_bytes())})
write_json('manifest.json', manifest)
sums = ''.join(row['sha256'] + '  ' + row['path'] + '\n' for row in manifest['files'])
sums += identity((ROOT / 'manifest.json').read_bytes())['sha256'] + '  manifest.json\n'
(ROOT / 'SHA256SUMS').write_text(sums)
archive = ROOT / 'host-next-authorities-source-originals.tar.gz'
members = [row['path'] for row in manifest['files']] + ['manifest.json', 'SHA256SUMS']
with tarfile.open(archive, 'x:gz') as tar:
    for name in members:
        tar.add(ROOT / name, arcname=name, recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    assert [member.name for member in tar.getmembers()] == members
    for member in tar.getmembers():
        assert tar.extractfile(member).read() == (ROOT / member.name).read_bytes()
write_json('roundtrip.json', {'schema': 1, 'archive': identity(archive.read_bytes()),
                             'member_count': len(members), 'all_members_byte_equal': True})
handoff = {'schema': 1, 'status': 'FROZEN_SOURCE_ONLY_READY_FOR_ROOT_CHECKPOINT_AND_PEERREVIEW',
           'root': str(ROOT), 'source': final,
           'freeze': identity((ROOT / 'source-freeze.json').read_bytes()),
           'manifest': identity((ROOT / 'manifest.json').read_bytes()),
           'contract': identity((ROOT / 'qualification-contract.json').read_bytes()),
           'archive': {'path': archive.name, 'members': len(members), **identity(archive.read_bytes())},
           'next': 'Root checkpoint then actionlint/activation; no local engine, compiler or product test retry',
           'active_workflows_or_delivery_or_pins_changed': False}
write_json('handoff.json', handoff)
print(json.dumps(handoff, ensure_ascii=False, indent=2))
