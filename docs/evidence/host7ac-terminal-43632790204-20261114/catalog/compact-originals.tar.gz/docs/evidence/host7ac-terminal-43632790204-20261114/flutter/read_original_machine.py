#!/usr/bin/env python3
"""Read original Flutter machine output; never execute or modify product sources."""
from pathlib import Path
from collections import Counter
import hashlib, json, sys
from datetime import datetime, timezone

ROOT = Path(sys.argv[1]).resolve()
def identity(p):
    data=p.read_bytes()
    return {"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),
            "git_blob":hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()}
machine=ROOT/"originals/flutter-machine.jsonl"
summary_path=ROOT/"originals/acceptance-summary.json"
before={str(p.relative_to(ROOT)):identity(p) for p in (machine,summary_path)}
assert before["originals/flutter-machine.jsonl"]["sha256"]=="02a34eb91fa9da319ffa11b0b1a8dd8b80e7e6c362823d86228ba8f3b7f7b307"
assert before["originals/acceptance-summary.json"]["sha256"]=="d4df84959a4a46e4cea36f45a88fe45834359aa3ec2e8d0b59180046ee1b1951"
summary=json.loads(summary_path.read_bytes())
events=[]; non_protocol=[]; starts={}; ends={}; suites={}; type_counts=Counter()
for number,line in enumerate(machine.read_text().splitlines(),1):
    if not line.strip():
        non_protocol.append({"line":number,"kind":"blank"});continue
    try: item=json.loads(line)
    except json.JSONDecodeError:
        non_protocol.append({"line":number,"kind":"non_json","text":line});continue
    if not isinstance(item,dict) or not isinstance(item.get("type"),str):
        non_protocol.append({"line":number,"kind":"non_protocol_json","value":item});continue
    type_counts[item["type"]]+=1
    events.append((number,item))
    if item["type"]=="suite":
        suite=item["suite"];assert suite["id"] not in suites;suites[suite["id"]]=suite
    elif item["type"]=="testStart":
        test=item["test"];assert test["id"] not in starts;starts[test["id"]]=test
    elif item["type"]=="testDone":
        assert item["testID"] not in ends;ends[item["testID"]]=item
assert set(starts)==set(ends)
assert all(t["suiteID"] in suites for t in starts.values())
failures=[{"test":starts[i],"end":e} for i,e in ends.items() if e["result"]!="success"]
skips=[{"test":starts[i],"end":e} for i,e in ends.items() if e.get("skipped") is not False]
errors=[{"line":n,"event":e} for n,e in events if e["type"]=="error"]
visible=[i for i,e in ends.items() if e.get("hidden") is False and e["result"]=="success" and not e["skipped"]]
hidden=[i for i,e in ends.items() if e.get("hidden") is True and e["result"]=="success" and not e["skipped"]]
done=[{"line":n,"event":e} for n,e in events if e["type"]=="done"]
assert len(done)==1 and done[0]["event"]["success"] is True and events[-1][1]["type"]=="done"
assert not failures and not skips and not errors
assert len(visible)+len(hidden)==len(ends)
assert summary["status"]=="PASS" and summary["passed"]==len(visible)
assert summary["failed"]==[] and summary["skipped"]==[] and summary["runner_errors"]==[]
assert summary["flutter_exit_code"]==0 and summary["runner_completed_successfully"] is True
per_suite=[]
for sid,suite in suites.items():
    ids=[i for i in visible if starts[i]["suiteID"]==sid]
    per_suite.append({"id":sid,"path":suite["path"],"visible_successes":len(ids),
                      "tests":[{"id":i,"name":starts[i]["name"],"time_ms":ends[i]["time"]} for i in ids]})
after={str(p.relative_to(ROOT)):identity(p) for p in (machine,summary_path)}
assert after==before
result={"schema":1,"kind":"original_machine_read_only_recount","checked_at":datetime.now(timezone.utc).isoformat(),
        "run_id":43632790204,"run_attempt":1,"host_sha":"7ac736fdbd042769592e88de0f9849632242316d",
        "native_sha":"f9d9772bb932d7ee8702eeb5bca6d98c286f3b98","artifact_id":14128439571,
        "source_originals_before":before,"source_originals_after":after,"unchanged":True,
        "counts":{"visible_success":len(visible),"hidden_success":len(hidden),"paired_test_ids":len(ends),
                  "failures":len(failures),"skips":len(skips),"error_events":len(errors),"suites":len(suites)},
        "types":dict(type_counts),"done":done[0],"original_summary_matches":True,
        "non_protocol_counts":dict(Counter(x["kind"] for x in non_protocol)),
        "non_protocol_policy":"Retained separately, not counted as protocol tests or discarded from the original.",
        "claims":"Only the original Flutter stage; no Android, APK, visual, or overall-run acceptance."}
out=ROOT/"machine-inspection";out.mkdir(exist_ok=False)
for name,obj in [("recount.json",result),("suite-results.json",per_suite),("non-protocol-lines.json",non_protocol)]:
    (out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+"\n")
print(json.dumps(result,ensure_ascii=False,indent=2))
