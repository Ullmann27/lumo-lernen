# Final qualification-inventory binding repair

Exactly one tuple in the final file-inventory Python block changes. It compares the already captured stage and flag hashes instead of requiring binary Git-index metadata equality. HEAD, tree and tracked count remain required; the complete source snapshot program and every other workflow byte remain unchanged. The original binary hashes and full binary/stage/flag originals remain in the evidence and complete original-file inventory.

The preserved Quiz artifact is the actual failed Run 43627104987 / attempt 1 on Host abb531 and Native 2e023. Its source-after guard succeeded. All semantic source and stage/flag bindings are equal, while the Native binary-index hash differs. The historical final inventory step still failed on that binary hash and remains a FAIL original.

The six local process calls execute only the complete extracted final-inventory Python block on separate byte-identical copies of all 197 original artifact files. They are not product, renderer, Android or CI executions. The original old block reproduces rejection; the new block succeeds once; four changed/missing Stage/Flag cases remain rejected. Locally produced qualification-result.json files retain original CI identifiers solely as fixture provenance and are explicitly stored under controlled-replays-not-ci.

The V1 harness was never executed. Static review before the first call corrected only its ZIP-roster sort key from string sorting to Path sorting, matching the unchanged workflow. Both frozen versions, the exact preparation-only diff and all actual V2 process receipts are retained. There was no unrecorded preflight, product run or retry.

The compact archive retains the complete original ZIP, all source/preimage/program bytes, API and job originals, every process stream/exit, all case inventories and each deliberately mutated file. Unchanged case-input copies are omitted from the archive because their complete bytes are already present in the original ZIP; those copies remain locally and are fully indexed in manifest.json.
