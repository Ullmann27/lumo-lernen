#!/usr/bin/env python3
"""Run only the exact final inventory programs on separate original-byte copies.

These are local evidence-reader replays, never new product or CI results. The
copied CI identifiers retain the provenance of the input originals only.
"""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time


PACK = Path(__file__).resolve().parents[1]
ORIGINALS = Path('/workspace/scratch/b3485b7bb989/host-next-authorities-abb531-native-evidence-20261114/artifacts/14127190566/inspection/originals')


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def inventory(root):
    result = []
    for path in sorted(root.rglob('*')):
        require(not path.is_symlink(), 'Unexpected input symlink')
        if path.is_file():
            result.append({'path': path.relative_to(root).as_posix(), **identity(path.read_bytes())})
    return result


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main():
    output = PACK / 'controlled-replays-not-ci'
    output.mkdir(exist_ok=False)
    sources = {
        'old': PACK / 'validation/original-inventory.py',
        'patched': PACK / 'validation/patched-inventory.py',
    }
    expected = {
        'old': '29d1a3a1ed91365dfc492b1fb5100eb05df911f40266f8ceebf78bd27ab9e0dd',
        'patched': '2ef7180f1d210e8627260624b6ab0c85fb159b9ba7f071069b184a3b86c67b7a',
    }
    for kind, source in sources.items():
        require(identity(source.read_bytes())['sha256'] == expected[kind], 'Unexpected exact inventory program')
    original_rows = inventory(ORIGINALS)
    binding = json.loads((PACK / 'original-binding.json').read_bytes())
    bound_rows = [{key: row[key] for key in ('path', 'bytes', 'sha256', 'git_blob')}
                  for row in binding['all_original_archive_members_verified']]
    require(original_rows == sorted(bound_rows, key=lambda row: row['path']), 'Fixture differs from complete original ZIP')
    require(len(original_rows) == 197, 'Unexpected original roster')
    source_before = json.loads((ORIGINALS / 'source-before.json').read_bytes())
    source_after = json.loads((ORIGINALS / 'source-after.json').read_bytes())
    require(source_before['sources']['native']['index_sha256'] != source_after['sources']['native']['index_sha256'],
            'Original binary index difference missing')
    save(output / 'original-input-inventory-before.json', original_rows)
    plan = (
        ('old_original_red', 'old', None, 1, 'ValueError: Final source binding differs'),
        ('patched_original_green', 'patched', None, 0, None),
        ('changed_native_stage', 'patched', 'stage', 1, 'ValueError: Final source binding differs'),
        ('changed_native_flags', 'patched', 'flags', 1, 'ValueError: Final source binding differs'),
        ('missing_native_stage', 'patched', 'missing_stage', 1, "KeyError: 'index_stage_sha256'"),
        ('missing_native_flags', 'patched', 'missing_flags', 1, "KeyError: 'index_flags_sha256'"),
    )
    results = []
    for name, program_kind, mutation, expected_exit, expected_error in plan:
        case = output / name
        case.mkdir()
        evidence = case / 'copied-originals'
        shutil.copytree(ORIGINALS, evidence)
        require(inventory(evidence) == original_rows, name + ': initial copy is not byte-identical')
        changed_paths = []
        if mutation:
            after_path = evidence / 'source-after.json'
            summary = json.loads(after_path.read_bytes())
            if mutation in ('stage', 'flags'):
                proof = evidence / ('source/native/source-index-' + mutation + '-after.raw')
                data = proof.read_bytes()
                if mutation == 'stage':
                    prefix = data[:6]
                    require(prefix in (b'100644', b'100755'), 'Missing actual first stage mode')
                    data = (b'100755' if prefix == b'100644' else b'100644') + data[6:]
                else:
                    require(data[:1] == b'H', 'Missing actual first normal index flag')
                    data = b'h' + data[1:]
                proof.write_bytes(data)
                summary['sources']['native']['index_' + mutation + '_sha256'] = identity(data)['sha256']
                changed_paths.append(proof.relative_to(evidence).as_posix())
            else:
                key = 'index_stage_sha256' if mutation == 'missing_stage' else 'index_flags_sha256'
                del summary['sources']['native'][key]
            after_path.write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
            changed_paths.append('source-after.json')
        actual_input_rows = inventory(evidence)
        changed_actual = [row['path'] for row, old in zip(actual_input_rows, original_rows) if row != old]
        require(sorted(changed_actual) == sorted(changed_paths), name + ': mutation scope differs')
        save(case / 'input-inventory.json', actual_input_rows)
        environment = dict(os.environ, LUMO_QUAL_EVIDENCE=str(evidence), QUALIFICATION_GROUP='quiz',
                           EXPECTED_HOST=source_before['sources']['host']['head'],
                           EXPECTED_NATIVE=source_before['sources']['native']['head'],
                           EXPECTED_NATIVE_TREE=source_before['sources']['native']['tree'],
                           GITHUB_RUN_ID=source_before['run_id'], GITHUB_RUN_ATTEMPT=source_before['run_attempt'],
                           PYTHONDONTWRITEBYTECODE='1')
        argv = [sys.executable, '-B', str(sources[program_kind])]
        started = time.monotonic()
        with (case / 'stdout.original').open('xb') as stdout, (case / 'stderr.original').open('xb') as stderr:
            child = subprocess.Popen(argv, stdout=stdout, stderr=stderr, env=environment, cwd=case)
            timed_out = False
            try:
                code = child.wait(timeout=30)
            except subprocess.TimeoutExpired:
                timed_out = True
                child.kill()
                code = child.wait()
        (case / 'exit-code.original.txt').write_text(str(code) + '\n')
        actual = {'name': name, 'kind': 'controlled local original-evidence replay; not CI',
                  'program': identity(sources[program_kind].read_bytes()), 'argv': argv,
                  'environment': {key: environment[key] for key in ('LUMO_QUAL_EVIDENCE', 'QUALIFICATION_GROUP',
                      'EXPECTED_HOST', 'EXPECTED_NATIVE', 'EXPECTED_NATIVE_TREE', 'GITHUB_RUN_ID', 'GITHUB_RUN_ATTEMPT')},
                  'original_ci_identifiers_are_input_provenance_only': True,
                  'synthetic_mutation': mutation, 'changed_paths': changed_paths, 'exit_code': code,
                  'timed_out': timed_out, 'elapsed_seconds': time.monotonic() - started,
                  'expected_exit_code': expected_exit, 'expected_error': expected_error,
                  'stdout': identity((case / 'stdout.original').read_bytes()),
                  'stderr': identity((case / 'stderr.original').read_bytes())}
        save(case / 'execution.json', actual)
        require(not timed_out and code == expected_exit, name + ': actual exit mismatch')
        if expected_error:
            require(expected_error in (case / 'stderr.original').read_text(), name + ': wrong failure cause')
            require(not (evidence / 'original-file-index.json').exists() and not (evidence / 'qualification-result.json').exists(),
                    name + ': rejected evidence wrote a PASS artifact')
            require(inventory(evidence) == actual_input_rows, name + ': rejected input originals changed')
        else:
            require((case / 'stderr.original').read_bytes() == b'', 'Positive local replay has stderr')
            result = json.loads((evidence / 'qualification-result.json').read_bytes())
            require(result['status'] == 'PASS' and result['group'] == 'quiz', 'Positive local result missing')
            index = json.loads((evidence / 'original-file-index.json').read_bytes())['files']
            expected_rows = [{key: row[key] for key in ('path', 'bytes', 'sha256')} for row in original_rows]
            require(index == expected_rows, 'Complete original inventory differs')
            require([row for row in inventory(evidence) if row['path'] not in ('original-file-index.json', 'qualification-result.json')]
                    == original_rows, 'Positive replay changed original bytes')
            for filename in ('original-file-index.json', 'qualification-result.json'):
                shutil.copyfile(evidence / filename, case / ('local-replay-' + filename))
        results.append(actual)
    final_rows = inventory(ORIGINALS)
    save(output / 'original-input-inventory-after.json', final_rows)
    require(final_rows == original_rows, 'Shared original inputs changed')
    for kind, source in sources.items():
        require(identity(source.read_bytes())['sha256'] == expected[kind], 'Inventory program changed')
    report = {'schema': 1, 'scope': 'Six local file-inventory process calls only; no product, renderer, Dart, Android or CI rerun.',
              'status': 'ALL_EXPECTED_OUTCOMES_MATCHED', 'process_calls': len(results),
              'original_red_reproduced': True, 'patched_full_original_replay_succeeded': True,
              'negative_stage_flag_cases_rejected': 4, 'shared_originals_unchanged': True,
              'full_original_file_count': len(original_rows), 'results': results}
    save(PACK / 'validation-result.json', report)
    print(json.dumps({'status': report['status'], 'process_calls': len(results),
                      'outcomes': [{'case': row['name'], 'exit_code': row['exit_code']} for row in results],
                      'shared_originals_unchanged': True}, indent=2))


if __name__ == '__main__':
    main()
