import hashlib, json, os
from pathlib import Path
root = Path(os.environ['LUMO_QUAL_EVIDENCE'])
before = json.loads((root / 'source-before.json').read_bytes())
after = json.loads((root / 'source-after.json').read_bytes())
for name in ('host', 'native'):
    for key in ('head', 'tree', 'index_sha256', 'tracked_count'):
        if before['sources'][name][key] != after['sources'][name][key]:
            raise ValueError('Final source binding differs')
files = []
for path in sorted(root.rglob('*')):
    if path.is_symlink():
        raise ValueError('Symlink original in qualification evidence')
    if path.is_file():
        data = path.read_bytes()
        files.append({'path': str(path.relative_to(root)), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
(root / 'original-file-index.json').write_text(json.dumps({'schema': 1, 'files': files}, indent=2) + '\n')
(root / 'qualification-result.json').write_text(json.dumps({'schema': 1, 'status': 'PASS',
    'group': os.environ['QUALIFICATION_GROUP'], 'host': os.environ['EXPECTED_HOST'],
    'native': os.environ['EXPECTED_NATIVE'], 'native_tree': os.environ['EXPECTED_NATIVE_TREE'],
    'run_id': os.environ['GITHUB_RUN_ID'], 'run_attempt': os.environ['GITHUB_RUN_ATTEMPT'],
    'scope': 'This separate group only. Existing C4, full Native, Android device and release gates are not replaced.'}, indent=2) + '\n')
print('NEXT_AUTHORITY_QUALIFICATION_PASS group=' + os.environ['QUALIFICATION_GROUP'])
