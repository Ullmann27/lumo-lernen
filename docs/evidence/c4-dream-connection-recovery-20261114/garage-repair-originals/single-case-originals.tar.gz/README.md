# Exact Continue-caption mock expectation repair

The production Continue path already requires `standalone_caption=True`. The selected existing test still expected only `tap=True, exact=True` and failed on current Host32e7. This one-line test-only patch adds the required explicit option to the same strict tuple/dictionary equality; it does not accept arbitrary extra options.

Exactly the original selected case ran once on unchanged32e7 and failed with one assertion failure. Exactly the same case ran once against the proposed test and unchanged production modules and passed. Full original combined stdout/stderr is retained. No full suite or device run occurred.

The same starting test bytes exist in QA1cc5, and its actual `_continue_actual_race` function has the same AST. Therefore the identical final test file is supplied for that later QA connection, without claiming a test run on QA1cc5. Both source checkouts, indices and refs remain unchanged.

The complete file AST is identical after removing only the single added expected dictionary key. All touch/drive ordering, original evidence, save and failure assertions remain. The independently collected CI log belongs to Root; this pack records its supplied identity separately from the local Red/Green.

The disposable test-view uses symlinks to unchanged32e7 dependencies and contains only one proposed regular test source. test-view and runtime-tmp are excluded from the compact archive; their binding inventory and all original sources/results are included.
