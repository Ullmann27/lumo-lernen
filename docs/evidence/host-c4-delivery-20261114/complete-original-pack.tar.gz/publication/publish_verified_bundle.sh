#!/usr/bin/env bash
# INACTIVE REFERENCE PROCEDURE. No workflow calls this file.
# Requires a separately supplied, repository-authorized credential; it is not
# usable with the Actions GITHUB_TOKEN for this workflow-changing source.
set -euo pipefail
if [ "$#" -ne 6 ]; then
  echo 'Usage: publish_verified_bundle.sh SOURCE_CHECKOUT DELIVERY_DIRECTORY ORIGINAL_BUNDLE_ZIP BUNDLE_ARTIFACT_ID PULL_NUMBER NEW_AUDIT_DIRECTORY' >&2
  exit 2
fi
if [ "${GITHUB_ACTIONS:-false}" = true ]; then
  echo 'This separately credentialed publication procedure is not an Actions job.' >&2
  exit 2
fi
: "${GH_TOKEN:?Supply an authorized external Contents-write and Workflows-write credential explicitly. No stored secret is assumed.}"
export GH_HOST=github.com
source_checkout=$(realpath "$1")
delivery=$(realpath "$2")
bundle=$(realpath "$3")
artifact_id=$4
pull_number=$5
audit=$(realpath -m "$6")
case "$artifact_id:$pull_number" in *[!0-9:]*|:*|*:) exit 2 ;; esac
python_bin=${LUMO_DELIVERY_PYTHON:-python3}
"$python_bin" - "$delivery" "$audit" <<'PY'
from pathlib import Path
import sys
bundle, audit = map(Path, sys.argv[1:])
if audit.resolve().is_relative_to(bundle.resolve()):
    raise SystemExit('Publication audit must not modify the original delivery bundle')
PY
test ! -e "$audit"
mkdir -p "$audit"
verifier="$source_checkout/scripts/verify_connect_four_delivery.py"
repository=Ullmann27/lumo-lernen
cd "$source_checkout"
mapfile -t identity < <("$python_bin" - "$delivery" <<'PY'
import sys
from pathlib import Path
sys.path.insert(0, 'scripts')
from verify_connect_four_delivery import checked_plan, read
root = Path(sys.argv[1]); plan = checked_plan(root)
facts = read(root/'assets/C4-DELIVERY-FACTS.json')
print(facts['binding']['run_id'])
print(plan['tag'])
print(plan['download_url'])
PY
)
test "${#identity[@]}" -eq 3
run_id=${identity[0]}
tag=${identity[1]}
download_url=${identity[2]}

read_acceptance() {
  local destination=$1
  mkdir "$destination"
  gh api "repos/$repository/actions/runs/$run_id" > "$destination/run.json"
  gh api "repos/$repository/actions/runs/$run_id/jobs?per_page=100" > "$destination/jobs.json"
  gh api "repos/$repository/actions/runs/$run_id/artifacts?per_page=100" > "$destination/artifacts.json"
  gh api "repos/$repository/pulls/$pull_number" > "$destination/pull.json"
  "$python_bin" "$verifier" check-current --delivery "$delivery" --metadata "$destination" \
    --bundle-archive "$bundle" --bundle-artifact-id "$artifact_id" --pull-request "$pull_number"
}

read_acceptance "$audit/before-create"
gh api --paginate --slurp "repos/$repository/releases?per_page=100" > "$audit/before-create/releases.json"
gh api "repos/$repository/git/matching-refs/tags/$tag" > "$audit/before-create/tags.json"
"$python_bin" "$verifier" check-vacant --delivery "$delivery" --metadata "$audit/before-create"

# Atomic creation only. A conflict or any API error stops the procedure. There
# is deliberately no force, delete, overwrite, resume or fallback credential.
gh api --method POST "repos/$repository/git/refs" --input "$delivery/audit/create-tag.json" > "$audit/created-tag.json"
gh api "repos/$repository/git/ref/tags/$tag" > "$audit/tag-before-draft.json"
"$python_bin" "$verifier" check-tag --delivery "$delivery" --tag "$audit/tag-before-draft.json"
gh api --method POST "repos/$repository/releases" --input "$delivery/audit/create-release.json" > "$audit/created-release.json"
"$python_bin" "$verifier" check-release --delivery "$delivery" --tag "$audit/tag-before-draft.json" \
  --created "$audit/created-release.json" --release "$audit/created-release.json" --stage empty-draft
mapfile -t created < <("$python_bin" - "$audit/created-release.json" <<'PY'
import json, sys
value = json.load(open(sys.argv[1]))
print(value['id'])
print(value['upload_url'].split('{', 1)[0])
PY
)
test "${#created[@]}" -eq 2
release_id=${created[0]}
upload_base=${created[1]}
while IFS= read -r asset_name; do
  gh api --method POST "$upload_base?name=$asset_name" \
    --input "$delivery/assets/$asset_name" -H 'Content-Type: application/octet-stream' \
    > "$audit/upload-$asset_name.json"
done < "$delivery/audit/asset-names.txt"
gh api "repos/$repository/releases/$release_id" > "$audit/uploaded-release.json"
gh api "repos/$repository/git/ref/tags/$tag" > "$audit/tag-before-publish.json"
"$python_bin" "$verifier" check-release --delivery "$delivery" --tag "$audit/tag-before-publish.json" \
  --created "$audit/created-release.json" --release "$audit/uploaded-release.json" --stage uploaded-draft

# Re-read the current PR, successful complete workflow, original artifacts and
# complete bundle immediately before publication. No preparation is a release.
read_acceptance "$audit/before-publish"
gh api --method PATCH "repos/$repository/releases/$release_id" --input "$delivery/audit/publish-release.json" > "$audit/publish-response.json"
gh api "repos/$repository/releases/$release_id" > "$audit/published-release.json"
gh api "repos/$repository/git/ref/tags/$tag" > "$audit/published-tag.json"
"$python_bin" "$verifier" check-release --delivery "$delivery" --tag "$audit/published-tag.json" \
  --created "$audit/created-release.json" --release "$audit/published-release.json" --stage published
curl --fail --location --proto '=https' --proto-redir '=https' \
  --output "$audit/actual-public-download.apk" "$download_url"
"$python_bin" "$verifier" verify-public --delivery "$delivery" --tag "$audit/published-tag.json" \
  --created "$audit/created-release.json" --release "$audit/published-release.json" \
  --apk "$audit/actual-public-download.apk" --receipt "$audit/PUBLIC-DELIVERY-RECEIPT.json"
