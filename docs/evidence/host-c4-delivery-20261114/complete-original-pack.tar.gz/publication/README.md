# Getrennter Publikationsschritt – aktuell nicht aktiviert

Der vorgeschlagene C4-Workflow hat ausschließlich Leserechte. Sein siebter Job `prepare-c4-delivery` erstellt das überprüfte Artefakt `lumo-connect-four-2020-delivery-bundle`. Er veröffentlicht weder eine APK noch einen Tag oder Release. Das beigefügte `publish_verified_bundle.sh` ist eine getrennte, derzeit nicht ausgeführte Referenzprozedur und wird von keinem Workflow aufgerufen.

## Tatsächliche Berechtigungsgrenze

Die offizielle GitHub-Releases-Dokumentation verlangt für einen Zielcommit, der gegenüber dem Defaultbranch Workflowdateien hinzufügt oder verändert, zusätzlich Workflows-Schreibberechtigung. Der Actions-`GITHUB_TOKEN` kann diese Berechtigung nicht erhalten. Für den hier betrachteten C4-Commit gibt es aktuell weder einen nachgewiesenen geeigneten externen Token noch einen exponierten Release-Schreibaufruf im Connector. Ein aktivierter Publisher würde diese konkrete Grenze nicht lösen.

Ein bereits vorhandener Tag ist keine belegte Ausnahme: `target_commitish` wird dann für die Erstellung des Tags nicht benutzt. Daraus ergibt sich keine dokumentierte Ausnahme von der Berechtigungsprüfung des Release-Zielcommits. Dieses Verfahren verlangt ohnehin einen neuen, noch nicht vorhandenen Versionstag und ersetzt keinen vorhandenen Stand.

Primärquellen:

- <https://docs.github.com/en/rest/releases/releases#create-a-release>
- <https://docs.github.com/en/rest/releases/releases#update-a-release>
- <https://docs.github.com/en/rest/git/refs#create-a-reference>
- <https://docs.github.com/en/rest/releases/assets#upload-a-release-asset>
- <https://docs.github.com/en/code-security/concepts/supply-chain-security/immutable-releases>

## Voraussetzungen für eine spätere tatsächliche Ausführung

Ein autorisierter Betreiber muss separat einen für `Ullmann27/lumo-lernen` geeigneten externen Zugang bereitstellen: mindestens Contents write, Workflows write, Actions read und die nötigen Pull-request-Leserechte; bei klassischen OAuth/PAT-Zugängen die jeweils entsprechenden Repository-/Workflow-Scopes. `GH_TOKEN` ist hier ausschließlich die explizite Eingabe des aufrufenden Prozesses, kein behaupteter vorhandener Secretname. Die Prozedur lehnt ihre Ausführung innerhalb von GitHub Actions ausdrücklich ab. Ein fehlender oder unzureichender Zugang wird nicht durch einen anderen Account, ein vorhandenes Tag oder eine alternative Quelle ersetzt.

Benötigt werden die unveränderte ausgecheckte und saubere, tatsächlich gebaute Hostrevision, das vollständige originale Bundle-ZIP aus dem erfolgreich abgeschlossenen C4-Lauf, dessen Artifact-ID, die exakte entpackte Bundle-Dateiliste und die weiterhin auf denselben Host-HEAD zeigende C4-PR. Die Originalgröße und der vollständige ZIP-SHA aus der frischen Actions-API werden vor Nutzung erneut geprüft; jeder ZIP-Eintrag wird auf regulären Pfad, CRC, Größe und SHA geprüft und bytegleich mit dem entpackten Bundle verglichen. Die sieben tatsächlichen Jobs müssen erfolgreich abgeschlossen sein. Die sechs fachlichen Jobs allein erteilen keine Veröffentlichungserlaubnis.

Aufruf nach Erfüllung dieser Voraussetzungen:

```bash
bash publication/publish_verified_bundle.sh \
  "$SOURCE_CHECKOUT" "$DELIVERY_DIRECTORY" "$ORIGINAL_BUNDLE_ZIP" \
  "$BUNDLE_ARTIFACT_ID" "$C4_PULL_NUMBER" "$NEW_PUBLICATION_AUDIT_DIRECTORY"
```

Die sechs Variablen sind explizite Eingaben dieses späteren Aufrufs. Es werden keine heutigen SHA-, Run-, Artefakt- oder Zugangswerte erfunden. Python und `gh`, `curl`, `realpath` müssen lokal vorhanden sein; die Prozedur installiert nichts. Die Quellprüfung verwendet den Verifier aus der tatsächlich gebauten Hostrevision.

## Ablauf und verbleibende Grenzen

Die Prozedur liest zunächst neue Originalmetadaten und prüft vollständigen Lauf, PR, Artifact-Identität und Bundle. Sie prüft danach den vollständigen Releasekatalog sowie die exakte Tag-Abwesenheit. Erst dann erstellt sie genau einen neuen Commit-Tag und einen leeren Prerelease-Draft, lädt die zehn geprüften Dateien hoch und vergleicht alle tatsächlich von GitHub gemeldeten Assetgrößen, SHA256-Digests und Direktpfade. Unmittelbar vor der Veröffentlichung werden Quellstand und vollständige erfolgreiche Workflowannahme nochmals gelesen. Ein nachträglicher Fehler führt zum Abbruch; bereits erzeugte Tags, Drafts oder Assets werden weder gelöscht noch ersetzt oder bei einem zweiten Aufruf wiederverwendet.

Erst nach einem erfolgreichen Publish wird die einzelne APK ohne Authorization-Header über den öffentlichen HTTPS-Direktlink heruntergeladen. Nur bei vollständiger Bytegleichheit entsteht außerhalb des originalen Bundles `PUBLIC-DELIVERY-RECEIPT.json`. Der geplante Downloadpfad in `publication-plan.json` ist vorher kein bestätigter, erreichbarer Link.

Die eigene Nichtüberschreibungsregel ist nicht mit serverseitiger GitHub-Release-Immutability gleichzusetzen. Der Receipt übernimmt das tatsächliche API-Feld `immutable`; Repositoryeinstellungen werden nicht geändert. Ein `false` oder fehlendes Feld darf nicht als GitHub-Sperre ausgegeben werden.

Diese Referenzprozedur wurde lokal nur syntaktisch geprüft. Kein Tag-, Release-, Upload- oder öffentlicher APK-Downloadaufruf wurde ausgeführt. Die tatsächliche Veröffentlichung und deren Zugangsvoraussetzung bleiben offen.
