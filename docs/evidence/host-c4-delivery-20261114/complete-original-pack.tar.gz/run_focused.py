#!/usr/bin/env python3
from pathlib import Path
import argparse,datetime,hashlib,json,os,shutil,subprocess,sys,time
PACK=Path(__file__).resolve().parent
BASE=Path('/workspace/scratch/b3485b7bb989')
PYTHON=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3')
p=argparse.ArgumentParser();p.add_argument('--label',required=True);args=p.parse_args()
out=PACK/'evidence'/args.label;out.mkdir(exist_ok=False)
view=out/'validation-view';view.mkdir()
for root in (BASE/'host-c4-pipeline-20261114/proposed',PACK/'proposed'):
 for src in sorted(root.rglob('*')):
  if src.is_file():
   dest=view/src.relative_to(root);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
host=BASE/'lumo-host-connect-four-integration'
def fingerprint():
 rows=[]
 for root in (PACK/'proposed',BASE/'host-c4-pipeline-20261114/proposed',host/'scripts',host/'tools/android_qa'):
  for path in sorted(root.rglob('*')):
   if path.is_file() and path.suffix in ('.py','.yml','.yaml','.kt','.json') and '__pycache__' not in path.parts:
    raw=path.read_bytes();rows.append({'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 return {'host_head':subprocess.check_output(['git','-C',str(host),'rev-parse','HEAD'],text=True).strip(),'files':rows}
before=fingerprint();(out/'sources-before.json').write_text(json.dumps(before,indent=2)+'\n')
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','LUMO_C4_REFERENCE_HOST':str(host),
 'PYTHONPATH':os.pathsep.join(map(str,[view/'scripts',view/'tools/android_qa',host/'scripts',host/'tools/android_qa']))}
commands=[
 [str(PYTHON),'-m','unittest','discover','-s','scripts/tests','-p','test_connect_four_delivery.py','-v'],
 [str(PYTHON),'-m','unittest','discover','-s','scripts/tests','-p','test_connect_four_pipeline.py','-v'],
]
results=[]
for i,command in enumerate(commands,1):
 start=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/f'suite-{i}.log').open('wb') as log:
  completed=subprocess.run(command,cwd=view,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 raw=(out/f'suite-{i}.log').read_bytes()
 results.append({'command':command,'cwd':str(view),'started_at':started,'elapsed_seconds':time.monotonic()-start,'exit_code':completed.returncode,'log':f'suite-{i}.log','log_bytes':len(raw),'log_sha256':hashlib.sha256(raw).hexdigest()})
 print(json.dumps(results[-1]),flush=True)
after=fingerprint();(out/'sources-after.json').write_text(json.dumps(after,indent=2)+'\n')
report={'schema':1,'scope':'Focused offline contract tests only; synthetic transport/metadata fixtures, no actual APK/engine/device/release operation','python':str(PYTHON),'environment':{k:env[k] for k in ('PYTHONDONTWRITEBYTECODE','LUMO_C4_REFERENCE_HOST','PYTHONPATH')},'results':results,'source_stable':before==after,'host_head':before['host_head']}
(out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print('source_stable',before==after,flush=True)
sys.exit(0 if before==after and all(r['exit_code']==0 for r in results) else 1)
