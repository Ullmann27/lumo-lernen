"""Offline delivery counterexamples; never an APK, device or release claim."""
from __future__ import annotations

import copy
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'scripts'))
import verify_connect_four_delivery as delivery


def job_block(text, name):
    match = re.search(r'^  '+re.escape(name)+r':\n(.*?)(?=^  [a-z][\w-]*:\n|\Z)', text, re.M|re.S)
    if match is None:
        raise AssertionError('Missing actual job: '+name)
    return match[1]


def fixture():
    binding = {'host_source': 'a'*40, 'native_source': 'b'*40, 'versionCode': 2020,
               'versionName': '0.13.8', 'workflow': delivery.WORKFLOW,
               'run_id': 12345, 'run_attempt': 1, 'candidate_artifact_id': 100,
               'candidate_artifact_digest': 'sha256:'+'c'*64}
    run = {'id': 12345, 'run_attempt': 1, 'head_sha': 'a'*40,
           'head_branch': delivery.BRANCH, 'path': delivery.WORKFLOW, 'event': 'pull_request',
           'repository': {'full_name': delivery.REPOSITORY}, 'status': 'in_progress', 'conclusion': None}
    pull = {'number': 999, 'state': 'open',
            'head': {'sha': 'a'*40, 'ref': delivery.BRANCH, 'repo': {'full_name': delivery.REPOSITORY}},
            'base': {'repo': {'full_name': delivery.REPOSITORY}}}
    rows = []
    for index, (name, steps) in enumerate(delivery.REQUIRED_STEPS.items()):
        rows.append({'id': index+20, 'name': name, 'run_id': 12345, 'run_attempt': 1,
                     'head_sha': 'a'*40, 'status': 'completed', 'conclusion': 'success',
                     'completed_at': 'synthetic-original-time', 'steps': [
                         {'name': step, 'status': 'completed', 'conclusion': 'success'} for step in steps]})
    rows.append({'id': 50, 'name': delivery.PUBLISH_JOB, 'run_id': 12345, 'run_attempt': 1,
                 'head_sha': 'a'*40, 'status': 'in_progress', 'conclusion': None, 'steps': []})
    jobs = {'total_count': len(rows), 'jobs': rows}
    artifacts = {'total_count': len(delivery.ARTIFACT_NAMES), 'artifacts': [
        {'id': 100+index, 'name': name, 'size_in_bytes': 42, 'digest': 'sha256:'+'c'*64,
         'expired': False, 'workflow_run': {'id': 12345, 'head_sha': 'a'*40}}
        for index, name in enumerate(delivery.ARTIFACT_NAMES)]}
    return binding, run, pull, jobs, artifacts


class OriginalAcceptanceTests(unittest.TestCase):
    def setUp(self):
        self.binding, self.run, self.pull, self.jobs, self.artifacts = fixture()

    def check(self):
        return delivery.checked_jobs(self.run, self.jobs, self.pull, self.binding, 999)

    def test_exact_current_six_completed_jobs_and_running_publisher_are_required(self):
        self.assertEqual(set(self.check()), set(delivery.REQUIRED_STEPS))
        self.assertEqual(set(delivery.checked_artifacts(self.artifacts, self.binding)), set(delivery.ARTIFACT_NAMES))

    def test_each_failure_skip_cancel_and_foreign_attempt_blocks_delivery(self):
        for row in self.jobs['jobs'][:-1]:
            for field, value in [('conclusion', 'failure'), ('conclusion', 'skipped'),
                                 ('conclusion', 'cancelled'), ('run_attempt', 2),
                                 ('head_sha', 'd'*40), ('run_id', 99999), ('status', 'in_progress')]:
                original = row[field]; row[field] = value
                with self.subTest(job=row['name'], field=field, value=value), self.assertRaises(ValueError):
                    self.check()
                row[field] = original

    def test_reported_job_success_cannot_hide_a_skipped_or_failed_real_gate(self):
        for row in self.jobs['jobs'][:-1]:
            for step in row['steps']:
                for value in ('skipped', 'failure'):
                    step['conclusion'] = value
                    with self.subTest(step=step['name'], value=value), self.assertRaises(ValueError):
                        self.check()
                step['conclusion'] = 'success'

    def test_stale_or_foreign_branch_event_or_pull_request_is_rejected(self):
        for obj, key, value in [(self.run, 'event', 'workflow_dispatch'),
                                (self.run, 'path', '.github/workflows/lumo-kart-graphics-2019.yml'),
                                (self.run, 'status', 'completed'), (self.pull, 'state', 'closed'),
                                (self.pull['head'], 'sha', 'd'*40),
                                (self.pull['head'], 'ref', 'main'),
                                (self.pull['head']['repo'], 'full_name', 'outside/fork')]:
            previous = obj[key]; obj[key] = value
            with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                self.check()
            obj[key] = previous

    def test_incomplete_duplicate_or_extra_jobs_cannot_hide_an_unchecked_gate(self):
        original = copy.deepcopy(self.jobs)
        for changed in ({'total_count': 8, 'jobs': self.jobs['jobs']},
                        {'total_count': 8, 'jobs': self.jobs['jobs']+[self.jobs['jobs'][0]]},
                        {'total_count': 8, 'jobs': self.jobs['jobs']+[{'name': 'unreviewed-extra-gate'}]}):
            self.jobs = changed
            with self.assertRaises(ValueError): self.check()
        self.jobs = original

    def test_every_original_artifact_requires_exact_source_run_digest_and_availability(self):
        for row in self.artifacts['artifacts']:
            for key, value in [('expired', True), ('digest', None), ('size_in_bytes', 0)]:
                previous = row[key]; row[key] = value
                with self.subTest(artifact=row['name'], key=key), self.assertRaises(ValueError):
                    delivery.checked_artifacts(self.artifacts, self.binding)
                row[key] = previous
            row['workflow_run']['head_sha'] = 'f'*40
            with self.assertRaises(ValueError): delivery.checked_artifacts(self.artifacts, self.binding)
            row['workflow_run']['head_sha'] = 'a'*40
        self.artifacts['artifacts'][0]['id'] = 10101
        with self.assertRaises(ValueError): delivery.checked_artifacts(self.artifacts, self.binding)


class PcmOriginalLogTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name)/'build-contracts.log'
        self.valid = '\n'.join(
            [method+' (test_speech_envelope_contract.SpeechEnvelopeContractTest.'+method+') ... ok'
             for method in delivery.PCM_CONTRACTS]
            +['Ran 600 tests in 120.005s', '', 'OK', *delivery.PCM_CONTRACTS.values(), ''])
        self.path.write_text(self.valid)

    def test_complete_actual_stdout_contract_is_preserved_with_70_scoped_assertions(self):
        result = delivery.checked_pcm_log(self.path)
        self.assertEqual((result['tests'], result['pcm_assertions'], result['skips']), (600, 70, 0))
        self.assertIn('no Android audio claim', result['scope'])
        self.assertEqual(result['original_log']['sha256'], hashlib.sha256(self.valid.encode()).hexdigest())

    def test_missing_marker_unexecuted_method_skip_failure_or_duplicate_completion_fails(self):
        method, marker = next(iter(delivery.PCM_CONTRACTS.items()))
        variants = [self.valid.replace(marker, ''), self.valid.replace(method+' (', 'different_method ('),
                    self.valid.replace('\nOK\n', '\nOK (skipped=1)\n'),
                    self.valid.replace(' ... ok', ' ... skipped no compiler', 1),
                    self.valid+'FAILED (errors=1)\n', self.valid+'OK\n',
                    self.valid+'Ran 600 tests in 120.005s\n']
        for text in variants:
            self.path.write_text(text)
            with self.subTest(text=text[-100:]), self.assertRaises(ValueError):
                delivery.checked_pcm_log(self.path)


class NewReleaseOnlyTests(unittest.TestCase):
    def setUp(self):
        self.facts = {'versionName': '0.13.8', 'versionCode': 2020}
        self.plan = {'host_source': 'a'*40, 'tag': 'coachpreview-build-2020',
                     'download_url': 'https://github.com/Ullmann27/lumo-lernen/releases/download/coachpreview-build-2020/Lumo-Lernen-Neu.apk',
                     'assets': {'Lumo-Lernen-Neu.apk': {'bytes': 10, 'sha256': 'c'*64}}}
        self.tag = {'ref': 'refs/tags/coachpreview-build-2020', 'object': {'type': 'commit', 'sha': 'a'*40}}
        self.created = {'id': 20, 'tag_name': self.plan['tag'], 'target_commitish': 'a'*40,
                        'draft': True, 'prerelease': True, 'assets': [],
                        'upload_url': 'https://uploads.github.com/repos/Ullmann27/lumo-lernen/releases/20/assets{?name,label}'}

    def release(self, published=False):
        return {**self.created, 'draft': not published,
                'published_at': 'synthetic-publication-time' if published else None,
                'assets': [{'id': 30, 'name': 'Lumo-Lernen-Neu.apk', 'state': 'uploaded',
                            'size': 10, 'digest': 'sha256:'+'c'*64,
                            'browser_download_url': self.plan['download_url']}], 'immutable': False}

    def test_new_version_requires_complete_catalog_and_rejects_any_existing_tag_or_release(self):
        self.assertEqual(delivery.checked_release_catalog([[]], [], self.facts)['tag'], self.plan['tag'])
        for pages, refs in [([[{'tag_name': self.plan['tag'], 'draft': True}]], []),
                            ([[{'tag_name': self.plan['tag'], 'draft': False}]], []),
                            ([[]], [self.tag]),
                            ([[]], [{**self.tag, 'object': {'type': 'commit', 'sha': 'f'*40}}]),
                            ([], {}), ([], []), ({'items': []}, [])]:
            with self.subTest(pages=pages, refs=refs), self.assertRaises(ValueError):
                delivery.checked_release_catalog(pages, refs, self.facts)

    def test_newer_published_family_version_cannot_be_downgraded(self):
        current = {'tag_name': 'coachpreview-build-2021', 'draft': False, 'prerelease': True,
                   'assets': [{'name': 'Lumo-Lernen-Neu.apk'}]}
        with self.assertRaises(ValueError): delivery.checked_release_catalog([[current]], [], self.facts)
        with self.assertRaises(ValueError):
            delivery.checked_release_catalog([[]], [], {'versionName': '0.13.7', 'versionCode': 2019})

    def test_new_draft_then_exact_uploaded_assets_then_publication_are_distinct(self):
        delivery.checked_release(self.created, self.tag, self.created, self.plan, 'empty-draft')
        delivery.checked_release(self.release(), self.tag, self.created, self.plan, 'uploaded-draft')
        receipt = delivery.checked_release(self.release(True), self.tag, self.created, self.plan, 'published')
        self.assertIs(receipt['github_immutable'], False)
        self.assertIs(receipt['no_replacement_policy'], True)
        with self.assertRaises(ValueError):
            delivery.checked_release(self.release(), self.tag, self.created, self.plan, 'published')

    def test_asset_metadata_must_prove_actual_hash_size_uploaded_state_and_direct_url(self):
        for key, value in [('digest', 'sha256:'+'d'*64), ('digest', None), ('size', 11),
                            ('state', 'starter'), ('browser_download_url', 'https://example.test/fake.apk')]:
            release = self.release(); release['assets'][0][key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                delivery.checked_release(release, self.tag, self.created, self.plan, 'uploaded-draft')
        for assets in ([], self.release()['assets']*2):
            with self.assertRaises(ValueError):
                delivery.checked_release({**self.release(), 'assets': assets}, self.tag, self.created, self.plan, 'uploaded-draft')

    def test_wrong_source_tag_release_identity_or_reused_nonempty_draft_fails(self):
        for key, value in [('id', 21), ('target_commitish', 'd'*40), ('prerelease', False),
                            ('tag_name', 'coachpreview-build-2019'), ('upload_url', 'https://outside.test/assets')]:
            with self.subTest(key=key), self.assertRaises(ValueError):
                delivery.checked_release({**self.release(), key: value}, self.tag, self.created, self.plan, 'uploaded-draft')
        with self.assertRaises(ValueError):
            delivery.checked_release(self.release(), {**self.tag, 'object': {'type': 'tag', 'sha': 'a'*40}},
                                     self.created, self.plan, 'uploaded-draft')
        with self.assertRaises(ValueError):
            delivery.checked_release(self.release(), self.tag, self.release(), self.plan, 'uploaded-draft')


class NativeOriginalLogTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        # Explicitly synthetic mode names, never engine observations.
        self.modes = [('synthetic_'+str(i), 'headless') for i in range(48)] + sorted(delivery.NEW_NATIVE)
        self.runner = '\n'.join('check_probe '+name+" '["+name+"] PASS' "+mode
                                 for name, mode in self.modes)
        self.lines = ['probe\tmode\tresult']+[name+'\t'+mode+'\tPASS' for name, mode in self.modes]
        (self.root/'results.tsv').write_text('\n'.join(self.lines)+'\n')
        for name, mode in self.modes:
            (self.root/(name+'-'+mode+'.log')).write_text('['+name+'] PASS\n')

    def test_exact_52_order_and_four_additive_modes_are_required(self):
        self.assertEqual(len(delivery.checked_native_results(self.root, self.runner)), 52)
        with self.assertRaises(ValueError):
            delivery.checked_native_results(self.root, '\n'.join(self.runner.splitlines()[:-1]))
        with self.assertRaises(ValueError):
            delivery.checked_native_results(self.root, self.runner.replace('lumo_facial_capture', 'another_probe'))
        (self.root/'results.tsv').write_text('\n'.join(self.lines[:-1])+'\n')
        with self.assertRaises(ValueError): delivery.checked_native_results(self.root, self.runner)

    def test_reported_pass_never_overrides_post_pass_engine_error_or_missing_original(self):
        path = self.root/(self.modes[-1][0]+'-'+self.modes[-1][1]+'.log')
        original = path.read_bytes()
        for error in ('ERROR: 4 resources still in use at exit', 'SCRIPT ERROR: broken',
                      'Parse Error: invalid script', 'ObjectDB instances leaked'):
            path.write_bytes(original+error.encode()+b'\n')
            with self.subTest(error=error), self.assertRaises(ValueError):
                delivery.checked_native_results(self.root, self.runner)
        path.unlink()
        with self.assertRaises(ValueError): delivery.checked_native_results(self.root, self.runner)

    def test_actual_facial_runner_multiline_command_keeps_one_mode(self):
        original = "check_probe lumo_facial_capture '[lumo_facial_capture] PASS' rendered"
        replacement = original+' \\\n  --resolution 640x640 --fixed-fps 24 \\\n  --write-movie "$LOG_DIR/captures/lumo_facial_capture/facial-runtime.avi"'
        self.assertEqual(self.runner.count(original), 1)
        multiline = self.runner.replace(original, replacement)
        self.assertEqual(len(delivery.checked_native_results(self.root, multiline)), 52)


class RealFilesAndCommandsTests(unittest.TestCase):
    def preparation_fixture(self, root):
        binding, run, pull, jobs, artifacts = fixture()
        source = root/'source'; (source/'config').mkdir(parents=True)
        pin = {'revision': binding['native_source'], 'repository': 'https://github.com/Ullmann27/lumo-godot.git'}
        delivery.write_new(source/'config/godot-source.json', pin)
        for name in ('candidate', 'runtime', 'host_compile', 'android', 'update', 'metadata',
                     'build_contracts', 'native_evidence', 'native_source'):
            (root/name).mkdir()
        (root/'android/c4').mkdir()
        payload = b'explicitly-synthetic-byte-transport-fixture-not-a-real-signed-APK'
        (root/'candidate/Lumo-Lernen-Neu.apk').write_bytes(payload)
        apk = {'package': 'dev.ullmann.lumo.lumo_lernen.coachpreview', 'versionCode': 2020,
               'versionName': '0.13.8', 'abis': ['arm64-v8a'], 'bytes': len(payload),
               'sha256': hashlib.sha256(payload).hexdigest(),
               'signingCertificateSha256': 'a6b1ef61bf59db4e0794c742aeb3b5506d130f4d21175c9975140e6acdb80702',
               'godot': {'revision': 'b'*40, 'pck_sha256': 'd'*64}}
        facts = {'schema': 1, 'status': 'PASS', 'versionCode': 2020, 'versionName': '0.13.8',
                 'binding': binding, 'apks': {'arm64-v8a': apk, 'x86_64': {**apk, 'abis': ['x86_64']}}}
        delivery.write_new(root/'facts.json', facts)
        for name, value in [('run', run), ('jobs', jobs), ('artifacts', artifacts), ('pull', pull),
                            ('releases', [[]]), ('tags', [])]:
            delivery.write_new(root/'metadata'/(name+'.json'), value)
        for path, value in [('candidate/BUILD-PROVENANCE.json', {'synthetic_fixture': True}),
                            ('candidate/GODOT-SOURCE.json', pin),
                            ('android/c4/c4-result.json', {'synthetic_fixture': True}),
                            ('runtime/runtime-gate.json', {'synthetic_fixture': True}),
                            ('update/update-result.json', {'synthetic_fixture': True})]:
            delivery.write_new(root/path, value)
        log = '\n'.join([method+' (test_speech_envelope_contract.SpeechEnvelopeContractTest.'+method+') ... ok'
                         for method in delivery.PCM_CONTRACTS]
                        +['Ran 600 tests in 120.005s', 'OK', *delivery.PCM_CONTRACTS.values(), ''])
        (root/'build_contracts/build-contracts.log').write_text(log)
        args = SimpleNamespace(**{name: root/name for name in ('candidate', 'runtime', 'host_compile', 'android',
                               'update', 'metadata', 'build_contracts', 'native_evidence', 'native_source')},
                               source='a'*40, build_run=12345, run_attempt=1, artifact_id=100,
                               artifact_digest='c'*64, pull_request=999, facts=root/'facts.json', out=root/'delivery')
        return source, args, facts

    def test_prepare_reexecutes_existing_candidate_validator_and_requires_native_before_writes(self):
        with tempfile.TemporaryDirectory() as temporary:
            source, args, facts = self.preparation_fixture(Path(temporary))
            # Only the expensive real APK/runtime/device verifier is stubbed at
            # its explicit boundary. This is not an APK/device acceptance run.
            with mock.patch('verify_connect_four_candidate.verify', return_value=facts) as candidate, \
                 mock.patch.object(delivery, 'committed_pcm_sources', return_value={'fixture': {}}), \
                 mock.patch.object(delivery, 'checked_native', side_effect=ValueError('actual native evidence missing')):
                with self.assertRaisesRegex(ValueError, 'actual native evidence missing'):
                    delivery.prepare(args)
                candidate.assert_called_once_with(args)
                self.assertFalse(args.out.exists())
            with mock.patch('verify_connect_four_candidate.verify', return_value={**facts, 'versionCode': 2019}):
                with self.assertRaisesRegex(ValueError, 'Fresh complete candidate replay differs'):
                    delivery.prepare(args)
                self.assertFalse(args.out.exists())

    def test_preparation_preserves_originals_and_writes_only_new_atomic_release_inputs(self):
        with tempfile.TemporaryDirectory() as temporary:
            source, args, facts = self.preparation_fixture(Path(temporary))
            with mock.patch('verify_connect_four_candidate.verify', return_value=facts), \
                 mock.patch.object(delivery, 'committed_pcm_sources', return_value={'fixture': {}}), \
                 mock.patch.object(delivery, 'checked_native', return_value={'fixture': True, 'core_modes': 52}) as native, \
                 mock.patch.object(delivery, 'ROOT', source), \
                 mock.patch.object(delivery.subprocess, 'check_output', return_value='e'*40+'\n'), \
                 contextlib.redirect_stdout(io.StringIO()):
                plan = delivery.prepare(args)
            native.assert_called_once_with(args.native_evidence, args.native_source, 'b'*40)
            self.assertEqual(delivery.read(args.out/'audit/create-tag.json'),
                             {'ref': 'refs/tags/coachpreview-build-2020', 'sha': 'a'*40})
            self.assertEqual(delivery.read(args.out/'audit/create-release.json')['draft'], True)
            self.assertEqual(delivery.read(args.out/'audit/publish-release.json'), {'draft': False, 'make_latest': 'false'})
            self.assertEqual(delivery.checked_plan(args.out), plan)
            self.assertEqual((args.out/'assets/C4-CANDIDATE-FACTS.json').read_bytes(), args.facts.read_bytes())
            self.assertEqual((args.out/'assets/Lumo-Lernen-Neu.apk').read_bytes(), (args.candidate/'Lumo-Lernen-Neu.apk').read_bytes())
            self.assertEqual((args.out/'audit/original-run.json').read_bytes(), (args.metadata/'run.json').read_bytes())
            self.assertFalse((args.out/'PUBLIC-DELIVERY-RECEIPT.json').exists())

    def test_staged_bytes_cannot_change_or_hide_extra_or_symlinked_files(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); (root/'assets').mkdir()
            apk = root/'assets/Lumo-Lernen-Neu.apk'; apk.write_bytes(b'synthetic-transport-fixture-only')
            plan = {'schema': 1, 'versionCode': 2020, 'versionName': '0.13.8',
                    'tag': 'coachpreview-build-2020', 'host_source': 'a'*40,
                    'download_url': 'https://github.com/Ullmann27/lumo-lernen/releases/download/coachpreview-build-2020/Lumo-Lernen-Neu.apk',
                    'assets': {apk.name: delivery.record(apk)}}
            delivery.write_new(root/'publication-plan.json', plan)
            self.assertEqual(delivery.checked_plan(root), plan)
            apk.write_bytes(b'changed')
            with self.assertRaises(ValueError): delivery.checked_plan(root)
            apk.unlink(); apk.symlink_to(root/'publication-plan.json')
            with self.assertRaises(ValueError): delivery.checked_plan(root)

    def test_duplicate_json_keys_and_overwriting_prior_delivery_metadata_are_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary)/'original.json'; path.write_text('{"status":"FAIL","status":"PASS"}')
            with self.assertRaises(ValueError): delivery.read(path)
            with self.assertRaises(FileExistsError): delivery.write_new(path, {'status': 'PASS'})

    def test_only_one_permissioned_job_and_every_explicit_success_input_are_required(self):
        text = (ROOT/'.github/workflows/lumo-connect-four-2020.yml').read_text()
        block = job_block(text, delivery.PUBLISH_JOB)
        self.assertEqual(text.count('contents: write'), 1)
        self.assertIn('contents: write', block)
        head = block.split('    steps:', 1)[0]
        expression = head.split('    if: >-\n', 1)[1].split('    runs-on:', 1)[0].replace('\n', ' ')
        values = {'github.repository': delivery.REPOSITORY, 'github.event_name': 'pull_request',
                  'github.event.pull_request.head.repo.full_name': delivery.REPOSITORY,
                  'github.head_ref': delivery.BRANCH,
                  **{'needs.'+name+'.result': 'success' for name in delivery.REQUIRED_STEPS}}
        def allowed(conditions):
            code = expression.replace('&&', 'and')
            for key in sorted(conditions, key=len, reverse=True): code = code.replace(key, repr(conditions[key]))
            return eval(code.strip(), {'__builtins__': {}}, {})
        self.assertTrue(allowed(values))
        for key in values:
            with self.subTest(key=key): self.assertFalse(allowed({**values, key: 'different'}))
        self.assertNotIn('if: always()', head)
        for name in delivery.ARTIFACT_NAMES[1:]: self.assertIn('name: '+name, block)

    def test_actual_mutation_commands_never_replace_an_existing_tag_asset_or_release(self):
        text = (ROOT/'.github/workflows/lumo-connect-four-2020.yml').read_text()
        block = job_block(text, delivery.PUBLISH_JOB)
        for forbidden in ('--force', '--clobber', '--method DELETE', 'git push', 'verify-existing',
                          'publish-reviewed-2019', 'release_approved: true'):
            self.assertNotIn(forbidden, block)
        positions = [block.index(needle) for needle in (
            'verify_connect_four_delivery.py prepare',
            'verify_connect_four_delivery.py check-current',
            'gh api --method POST "repos/$GITHUB_REPOSITORY/git/refs"',
            'gh api --method POST "repos/$GITHUB_REPOSITORY/releases"',
            '--stage empty-draft', 'gh api --method POST "$upload_base?name=$asset_name"', '--stage uploaded-draft',
            'gh api --method PATCH "repos/$GITHUB_REPOSITORY/releases/$release_id"',
            '--stage published', 'curl --fail --location', 'verify_connect_four_delivery.py verify-public')]
        self.assertEqual(positions, sorted(positions))
        curl = next(line for line in block.splitlines() if 'curl --fail --location' in line)
        self.assertNotIn('Authorization', curl)
        self.assertNotIn('GH_TOKEN', curl)
        self.assertIn("--proto '=https' --proto-redir '=https'", curl)

    def test_cli_receipt_requires_actual_public_file_hash_after_release_and_tag_checks(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); (root/'assets').mkdir()
            payload = b'synthetic-transport-fixture-not-an-APK'
            original = root/'assets/Lumo-Lernen-Neu.apk'; original.write_bytes(payload)
            plan = {'schema': 1, 'versionCode': 2020, 'versionName': '0.13.8', 'host_source': 'a'*40,
                    'tag': 'coachpreview-build-2020',
                    'download_url': 'https://github.com/Ullmann27/lumo-lernen/releases/download/coachpreview-build-2020/Lumo-Lernen-Neu.apk',
                    'assets': {original.name: delivery.record(original)}}
            delivery.write_new(root/'publication-plan.json', plan)
            tag = {'ref': 'refs/tags/'+plan['tag'], 'object': {'type': 'commit', 'sha': 'a'*40}}
            created = {'id': 200, 'tag_name': plan['tag'], 'target_commitish': 'a'*40,
                       'draft': True, 'prerelease': True, 'assets': [],
                       'upload_url': 'https://uploads.github.com/repos/Ullmann27/lumo-lernen/releases/200/assets{?name,label}'}
            release = {**created, 'draft': False, 'published_at': 'synthetic-time', 'immutable': False,
                       'assets': [{'id': 300, 'name': original.name, 'state': 'uploaded',
                                   'size': len(payload), 'digest': 'sha256:'+hashlib.sha256(payload).hexdigest(),
                                   'browser_download_url': plan['download_url']}]}
            for name, data in [('tag', tag), ('created', created), ('release', release)]:
                delivery.write_new(root/(name+'.json'), data)
            public = root/'actual-public-download'; public.write_bytes(b'wrong')
            command = ['verify_connect_four_delivery.py', 'verify-public', '--delivery', str(root),
                       '--tag', str(root/'tag.json'), '--created', str(root/'created.json'),
                       '--release', str(root/'release.json'), '--apk', str(public)]
            with mock.patch.object(sys, 'argv', command), self.assertRaises(ValueError): delivery.main()
            self.assertFalse((root/'PUBLIC-DELIVERY-RECEIPT.json').exists())
            public.write_bytes(payload)
            with mock.patch.object(sys, 'argv', command), contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(delivery.main(), 0)
            receipt = delivery.read(root/'PUBLIC-DELIVERY-RECEIPT.json')
            self.assertEqual(receipt['public_apk'], delivery.record(original))
            self.assertIs(receipt['github_immutable'], False)


if __name__ == '__main__':
    unittest.main()
