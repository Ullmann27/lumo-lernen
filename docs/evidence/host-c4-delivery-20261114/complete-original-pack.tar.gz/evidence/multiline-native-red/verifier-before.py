#!/usr/bin/env python3
"""Recheck current C4 originals and a new, non-replacing 2020 APK release.

This program performs no GitHub writes. The separately permissioned publisher
uses its checked inputs, creates a new tag/draft, then checks every uploaded
asset before publishing. Historical 2019 receipts never authorize this path.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
REPOSITORY = 'Ullmann27/lumo-lernen'
WORKFLOW = '.github/workflows/lumo-connect-four-2020.yml'
BRANCH = 'integration/lumo-c4-connections-20261114'
PUBLISH_JOB = 'publish-c4-2020'
REQUIRED_STEPS = {
    'connect-four-runtime': (
        'Import the exact configured native source in its own directory',
        'Require the actual production Dart and rendered Godot two-process gate',
    ),
    'android-host-compile': (
        'Compile actual current Android host before native release pin approval',
        'Bind actual compiled C4 Activity bridge and Binder bytecode',
    ),
    'verify-and-build': (
        'Full Flutter regression suite including every capture',
        'Verify all build and preservation contracts',
        'Code-level Android probe regression with verified image dependencies',
        'Require actual gameplay gates on the exact pinned native source',
        'Build unified real Android APK',
        'Verify APK archive and collect reproducible source hashes',
        'Upload exact candidate (no release or synthetic screenshots)',
    ),
    'android-c4': ('Install and tour the exact APK',),
    'update-2020-from-2017': (
        'Preserve actual 2017 learning through an in-place 2020 upgrade',
    ),
    'verify-c4-candidate': (
        'Reverify both signed APKs and every mandatory current C4 and update proof',
    ),
}
ARTIFACT_NAMES = (
    'lumo-connect-four-2020-candidate',
    'lumo-connect-four-2020-desktop-runtime',
    'lumo-connect-four-2020-android-host-compile',
    'lumo-connect-four-2020-android-c4',
    'lumo-connect-four-2020-in-place-update-proof',
    'lumo-connect-four-2020-candidate-verification',
    'lumo-connect-four-2020-build-contracts',
    'lumo-candidate-pinned-native-gameplay',
)
PCM_CONTRACTS = {
    'test_original_pcm_envelope_contract':
        'LUMO_SPEECH_ENVELOPE_PASS checks=23 original_apfel_duration_ms=929 bins=47',
    'test_original_learning_lifecycle_contract':
        'LUMO_SPEECH_LIFECYCLE_PASS checks=17 platform=synthetic_JVM_boundary no_Android_playback_claim=true',
    'test_build_consent_rate_and_activity_contract':
        'LUMO_BUILD_SPEECH_PASS checks=30 platform=synthetic_JVM_boundary no_Android_playback_claim=true',
}
NEW_NATIVE = {
    ('lumo_facial_regression', 'headless'),
    ('lumo_facial_capture', 'rendered'),
    ('connect_four_visual_capture', 'rendered'),
    ('treasure_title_contrast_regression', 'rendered'),
}
ERROR_LINE = re.compile(r'SCRIPT ERROR|Parse Error|ERROR:|Assertion failed|'
                        r'ObjectDB instances leaked|resources still in use at exit')


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def regular(path: Path) -> Path:
    require(path.is_file() and not path.is_symlink(), 'Original regular file required: ' + str(path))
    return path


def digest(path: Path) -> str:
    with regular(path).open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def record(path: Path) -> dict:
    return {'bytes': regular(path).stat().st_size, 'sha256': digest(path)}


def read(path: Path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, 'Duplicate original JSON key: ' + key)
            result[key] = value
        return result
    return json.loads(regular(path).read_bytes(), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def write_new(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as handle:
        handle.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


def checked_jobs(run: dict, jobs: dict, pull: dict, binding: dict, pr_number: int) -> dict:
    source, run_id, attempt = (binding['host_source'], binding['run_id'], binding['run_attempt'])
    require(run.get('id') == run_id and run.get('run_attempt') == attempt
            and run.get('head_sha') == source and run.get('head_branch') == BRANCH
            and run.get('path') == WORKFLOW and run.get('event') == 'pull_request'
            and run.get('repository', {}).get('full_name') == REPOSITORY
            and run.get('status') == 'in_progress' and run.get('conclusion') is None,
            'Publication requires this still-current exact C4 workflow attempt')
    require(pull.get('number') == pr_number and pull.get('state') == 'open'
            and pull.get('head', {}).get('sha') == source
            and pull.get('head', {}).get('ref') == BRANCH
            and pull.get('head', {}).get('repo', {}).get('full_name') == REPOSITORY
            and pull.get('base', {}).get('repo', {}).get('full_name') == REPOSITORY,
            'The current same-repository C4 pull request moved or closed')
    rows = jobs.get('jobs', [])
    require(isinstance(rows, list) and jobs.get('total_count') == len(rows),
            'Incomplete original workflow job list')
    result = {}
    for name, required_steps in REQUIRED_STEPS.items():
        found = [row for row in rows if row.get('name') == name]
        require(len(found) == 1, 'Missing or duplicate mandatory job: ' + name)
        job = found[0]
        require(job.get('run_id') == run_id and job.get('head_sha') == source
                and job.get('run_attempt') == attempt and job.get('status') == 'completed'
                and job.get('conclusion') == 'success', 'Mandatory current job failed: ' + name)
        steps = job.get('steps', [])
        require(isinstance(steps, list) and steps
                and all(step.get('conclusion') in ('success', 'skipped') for step in steps),
                'A mandatory job contains an unsuccessful original step: ' + name)
        for label in required_steps:
            selected = [step for step in steps if step.get('name') == label]
            require(len(selected) == 1 and selected[0].get('status') == 'completed'
                    and selected[0].get('conclusion') == 'success',
                    'Actual required step missing or skipped: ' + label)
        result[name] = {'id': job['id'], 'completed_at': job.get('completed_at'),
                        'required_steps': list(required_steps)}
    publishers = [row for row in rows if row.get('name') == PUBLISH_JOB]
    require(len(publishers) == 1 and publishers[0].get('run_id') == run_id
            and publishers[0].get('head_sha') == source
            and publishers[0].get('run_attempt') == attempt
            and publishers[0].get('status') == 'in_progress'
            and publishers[0].get('conclusion') is None,
            'The separate current publisher job is not running')
    require({row.get('name') for row in rows} == {*REQUIRED_STEPS, PUBLISH_JOB},
            'Unexpected C4 job set requires an explicit delivery-contract update')
    return result


def checked_artifacts(metadata: dict, binding: dict) -> dict:
    rows = metadata.get('artifacts', [])
    require(isinstance(rows, list) and metadata.get('total_count') == len(rows),
            'Incomplete original artifact list')
    result = {}
    for name in ARTIFACT_NAMES:
        matches = [row for row in rows if row.get('name') == name]
        require(len(matches) == 1, 'Missing or duplicate required original artifact: ' + name)
        row = matches[0]
        require(type(row.get('id')) is int and row['id'] > 0
                and type(row.get('size_in_bytes')) is int and row['size_in_bytes'] > 0
                and row.get('expired') is False
                and re.fullmatch(r'sha256:[a-f0-9]{64}', str(row.get('digest')))
                and row.get('workflow_run', {}).get('id') == binding['run_id']
                and row.get('workflow_run', {}).get('head_sha') == binding['host_source'],
                'Required original artifact has wrong source/run/digest: ' + name)
        result[name] = {key: row[key] for key in ('id', 'name', 'size_in_bytes', 'digest')}
    candidate = result[ARTIFACT_NAMES[0]]
    require(candidate['id'] == binding['candidate_artifact_id']
            and candidate['digest'] == binding['candidate_artifact_digest'],
            'Publisher candidate differs from tested upload')
    return result


def checked_pcm_log(path: Path) -> dict:
    text = regular(path).read_text(encoding='utf-8')
    totals = re.findall(r'^Ran (\d+) tests? in [0-9.]+s$', text, re.M)
    require(len(totals) == 1 and int(totals[0]) > 0
            and len(re.findall(r'^OK$', text, re.M)) == 1
            and not re.search(r'^(?:FAILED|ERROR: |FAIL: |OK \(skipped=)', text, re.M)
            and not re.search(r'\.\.\. skipped\b', text),
            'The original full scripts contract suite is incomplete, failed or skipped')
    for method, marker in PCM_CONTRACTS.items():
        line = method + ' (test_speech_envelope_contract.SpeechEnvelopeContractTest.' + method + ') ... ok'
        require(text.splitlines().count(line) == 1 and text.splitlines().count(marker) == 1,
                'The exact actual current PCM/JVM contract is missing: ' + method)
    return {'tests': int(totals[0]), 'skips': 0, 'pcm_assertions': 70,
            'scope': 'Synthetic JVM boundary compiled from current production Kotlin; no Android audio claim',
            'original_log': record(path), 'required_markers': list(PCM_CONTRACTS.values())}


def checked_release_catalog(pages, refs, facts: dict) -> dict:
    from release_pipeline_gates import (evaluate_source, newest_published_family_build)
    require(isinstance(pages, list) and pages and all(isinstance(page, list) for page in pages),
            'The complete paginated original release catalog is required')
    require(isinstance(refs, list), 'Original matching tag refs must be an array')
    releases = [item for page in pages for item in page]
    require(all(isinstance(item, dict) for item in releases), 'Invalid original release object')
    tag = 'coachpreview-build-' + str(facts['versionCode'])
    require(not any(item.get('tag_name') == tag for item in releases),
            'Version release already exists; never reuse, overwrite or repair it in place')
    require(not any(item.get('ref') == 'refs/tags/' + tag for item in refs),
            'Version tag already exists; no replacement or verify-existing publication')
    result = evaluate_source(pubspec_text='version: '+facts['versionName']+'+'+str(facts['versionCode'])+'\n',
                             last_published=newest_published_family_build(releases))
    require(result['versionCode'] == 2020, 'This separate publisher accepts only the actual 2020 version')
    return result


def checked_tag(tag: dict, plan: dict) -> None:
    require(tag.get('ref') == 'refs/tags/' + plan['tag']
            and tag.get('object', {}).get('type') == 'commit'
            and tag.get('object', {}).get('sha') == plan['host_source'],
            'New version tag does not identify the exact verified Host commit')


def checked_release(release: dict, tag: dict, created: dict, plan: dict, stage: str) -> dict:
    require(stage in ('empty-draft', 'uploaded-draft', 'published'), 'Unknown publication stage')
    checked_tag(tag, plan)
    expected_id = created.get('id')
    require(type(expected_id) is int and expected_id > 0 and release.get('id') == expected_id
            and created.get('tag_name') == release.get('tag_name') == plan['tag']
            and created.get('target_commitish') == release.get('target_commitish') == plan['host_source']
            and created.get('draft') is True and created.get('prerelease') is True
            and release.get('prerelease') is True
            and release.get('draft') is (stage != 'published'),
            'The newly created release identity/state/source differs')
    require(created.get('assets') == [], 'The creation response was not a fresh empty draft')
    rows = release.get('assets')
    require(isinstance(rows, list), 'Original uploaded asset objects are missing')
    expected = {} if stage == 'empty-draft' else plan['assets']
    require(len(rows) == len(expected)
            and {row.get('name') for row in rows} == set(expected)
            and len({row.get('id') for row in rows}) == len(rows),
            'New release asset set differs from the exact verified input set')
    for asset in rows:
        name = asset['name']
        require(asset.get('state') == 'uploaded' and type(asset.get('id')) is int
                and asset['id'] > 0 and asset.get('size') == expected[name]['bytes']
                and asset.get('digest') == 'sha256:' + expected[name]['sha256']
                and asset.get('browser_download_url') ==
                'https://github.com/'+REPOSITORY+'/releases/download/'+plan['tag']+'/'+name,
                'Actual uploaded asset digest/size/direct URL differs: ' + name)
    if stage == 'published':
        require(isinstance(release.get('published_at'), str) and release['published_at'],
                'Published release timestamp is missing')
    immutable = release.get('immutable')
    require(immutable is None or type(immutable) is bool, 'Malformed GitHub immutable flag')
    return {'release_id': expected_id, 'tag': plan['tag'], 'stage': stage,
            'github_immutable': immutable,
            'no_replacement_policy': True,
            'direct_apk_url': plan['download_url']}


def native_module(root: Path, name: str):
    sys.path.insert(0, str(root/'tools'))
    path = regular(root/'tools'/name)
    spec = importlib.util.spec_from_file_location('_c4_delivery_'+path.stem, path)
    loaded = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = loaded
    spec.loader.exec_module(loaded)
    return loaded


def checked_native_results(root: Path, runner: str) -> list[dict]:
    roster = [shlex.split(line)[1:4] for line in runner.splitlines() if line.startswith('check_probe ')]
    require(len(roster) == 52 and all(len(row) == 3 for row in roster)
            and len({(row[0], row[2]) for row in roster}) == 52
            and NEW_NATIVE <= {(row[0], row[2]) for row in roster},
            'Approved source must contain all 52 current native modes, including the four new modes')
    results = regular(root/'results.tsv').read_text().splitlines()
    expected = ['probe\tmode\tresult', *[name+'\t'+mode+'\tPASS' for name, marker, mode in roster]]
    require(results == expected, 'The exact original 52-mode result order is incomplete or failed')
    proofs = []
    for name, marker, mode in roster:
        path = root/(name+'-'+mode+'.log')
        text = regular(path).read_text()
        require(marker in text and not ERROR_LINE.search(text),
                'Original native log is missing PASS or contains a real engine error: '+path.name)
        proofs.append({'path': path.name, 'marker': marker, **record(path)})
    return proofs


def checked_native(logs: Path, source: Path, revision: str) -> dict:
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()
    tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=source, text=True).strip()
    require(head == revision, 'Native verifier checkout differs from approved candidate pin')
    subprocess.run(['git', 'diff', '--exit-code', 'HEAD', '--'], cwd=source, check=True)
    root = logs/'nextgen'
    require(regular(logs/'source-sha.txt').read_text().strip() == revision
            and regular(root/'source-sha.txt').read_text().strip() == revision
            and regular(root/'source-tree.txt').read_text().strip() == tree
            and not regular(root/'source-dirty.txt').read_text().strip()
            and regular(root/'engine.txt').read_text().strip().startswith('4.6.3.stable.'),
            'Original native source/tree/clean/engine stamps differ')
    runner = regular(source/'tools/validate_nextgen.sh').read_text()
    proofs = checked_native_results(root, runner)
    runner_log = regular(logs/'nextgen-runner.log').read_text()
    for marker in (
        '[Studio2020RasterRoster] PASS 16 actual PNG files, 3 original sidecars and 1 verified facial movie',
        '[LumoNextgen52] PASS: all 48 previous modes plus four Studio2020 modes and 16 bound rasters/movie/sidecars',
        '[LumoNextgen] PASS',
    ):
        require(marker in runner_log, 'Original complete 52-mode runner lacks its required ending: '+marker)
    require(not ERROR_LINE.search(runner_log), 'Original complete native runner contains a real failure')
    # Existing roster helpers write their indices. Replay in a disposable mirror:
    # only immutable PNG/movie payloads are hardlinked; JSON originals are copied.
    # The downloaded original metadata remains untouched.
    def payload_copy(src, dest):
        path = regular(Path(src))
        if path.suffix in ('.png', '.avi', '.mp4'):
            try:
                os.link(src, dest)
            except OSError:
                shutil.copyfile(src, dest)
        else:
            shutil.copyfile(src, dest)
        return dest
    rosters = {}
    with tempfile.TemporaryDirectory(prefix='c4-native-replay-') as temporary:
        replay = Path(temporary)
        for path in (root/'captures').rglob('*'):
            require(not path.is_symlink(), 'Native capture symlink is not accepted')
        shutil.copytree(root/'captures', replay/'captures', copy_function=payload_copy)
        helpers = (
            ('verify_studio_rasters.py', 'renderer-images.json', 24),
            ('verify_village_rasters.py', 'village-images.json', 4),
            ('verify_puzzle_menu_rasters.py', 'puzzle-menu-images.json', 6),
            ('verify_safe_area_rasters.py', 'safe-area-images.json', 7),
        )
        for helper, manifest, count in helpers:
            original = read(root/manifest)
            native_module(source, helper).verify(replay)
            checked = read(replay/manifest)
            require(checked == original and len(checked.get('images', [])) == count,
                    'Current native original roster replay differs: '+manifest)
            from PIL import Image
            for row in checked['images']:
                path = regular(root/row['path'])
                require(path.resolve().is_relative_to(root.resolve()), 'Native raster escapes original evidence')
                with Image.open(path) as image:
                    image.verify()
                with Image.open(path) as image:
                    image.load()
                    require(image.format == 'PNG' and image.size == (row['width'], row['height']),
                            'Original raster did not decode to its reported physical dimensions')
            rosters[manifest] = record(root/manifest)
    # This is the actual additive helper from the configured Native commit.
    # Its write=False contract rechecks all 16 new PNGs, original sidecars and
    # movie bytes/decoding without rewriting the original canonical report.
    original = read(root/'studio-2020-images.json')
    before = record(root/'studio-2020-images.json')
    fresh = native_module(source, 'verify_studio_2020_rasters.py').verify(root, write=False)
    require(fresh == original and record(root/'studio-2020-images.json') == before
            and fresh.get('schema') == 1 and fresh.get('kind') == 'studio_2020_extension'
            and fresh.get('source', {}).get('commit') == revision
            and fresh.get('source', {}).get('tree') == tree
            and len(fresh.get('images', [])) == 16 and len(fresh.get('reports', [])) == 3
            and len(fresh.get('movies', [])) == 1,
            'The original new 2020 face/C4/treasure raster/movie evidence differs')
    rosters['studio-2020-images.json'] = before
    return {'source': revision, 'tree': tree, 'core_modes': 52, 'mode_logs': proofs,
            'complete_runner_log': record(logs/'nextgen-runner.log'),
            'original_rosters': rosters,
            'scope': 'Actual pinned-source desktop engine and raster/movie proofs; no device FPS/audio claim'}


def committed_pcm_sources() -> dict:
    paths = [ROOT/'tools/auto_install/LumoLearningSpeech.kt',
             ROOT/'tools/auto_install/LumoSpeechEnvelope.kt', ROOT/'scripts/prepare_android.py',
             ROOT/'scripts/tests/test_speech_envelope_contract.py', ROOT/'scripts/tests/test_prepare_android.py',
             *sorted((ROOT/'scripts/tests/fixtures/speech_envelope_contract').rglob('*'))]
    result = {}
    for path in paths:
        if path.is_dir():
            continue
        relative = path.relative_to(ROOT).as_posix()
        data = regular(path).read_bytes()
        committed = subprocess.check_output(['git', 'show', 'HEAD:'+relative], cwd=ROOT)
        require(data == committed, 'PCM evidence source is not the committed candidate: '+relative)
        result[relative] = record(path)
    require(len(result) >= 17, 'Complete actual PCM fixtures and installer sources are required')
    return result


def prepare(args) -> dict:
    from verify_connect_four_candidate import verify as verify_candidate
    from release_pipeline_gates import evaluate_verification
    require(not args.out.exists(), 'Refusing to overwrite a delivery snapshot')
    original_facts = read(args.facts)
    # Re-execute the existing verifier against actual APKs and original C4,
    # runtime, compile and update evidence; no reported PASS substitutes for it.
    fresh = verify_candidate(args)
    require(fresh == original_facts, 'Fresh complete candidate replay differs from original final facts')
    binding = fresh['binding']
    jobs = checked_jobs(read(args.metadata/'run.json'), read(args.metadata/'jobs.json'),
                        read(args.metadata/'pull.json'), binding, args.pull_request)
    artifacts = checked_artifacts(read(args.metadata/'artifacts.json'), binding)
    pcm = checked_pcm_log(args.build_contracts/'build-contracts.log')
    pcm['sources'] = committed_pcm_sources()
    native = checked_native(args.native_evidence, args.native_source, binding['native_source'])
    selected = checked_release_catalog(read(args.metadata/'releases.json'),
                                       read(args.metadata/'tags.json'), fresh)
    arm64 = fresh['apks']['arm64-v8a']
    evaluate_verification(arm64, version_name=fresh['versionName'], version_code=fresh['versionCode'])
    require(read(args.candidate/'GODOT-SOURCE.json') == read(ROOT/'config/godot-source.json'),
            'Original candidate native config differs from current approved source')
    host_tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip()
    facts = {
        'schema': 1, 'status': 'ALL_CURRENT_GATES_REVERIFIED_BEFORE_NEW_RELEASE',
        'host_source': binding['host_source'], 'host_tree': host_tree,
        'native_source': binding['native_source'], 'versionName': fresh['versionName'],
        'versionCode': fresh['versionCode'], 'binding': binding, 'jobs': jobs,
        'original_artifacts': artifacts, 'pcm': pcm, 'native': native,
        'original_candidate_facts': record(args.facts), 'apks': fresh['apks'],
        'api37_approved': False, 'physical_arm64_tested': False,
        'measured_device_fps': None, 'audible_android_pcm_approved': False,
        'separate_human_visual_receipt': False,
        'scope': 'Signed ARM64 test delivery; real API35 C4/update and desktop gates only',
        'publication_policy': 'Only a newly created version tag and release; never replace or resume existing assets',
    }
    assets, audit = args.out/'assets', args.out/'audit'
    assets.mkdir(parents=True); audit.mkdir()
    originals = {
        'Lumo-Lernen-Neu.apk': args.candidate/'Lumo-Lernen-Neu.apk',
        'BUILD-PROVENANCE.json': args.candidate/'BUILD-PROVENANCE.json',
        'GODOT-SOURCE.json': args.candidate/'GODOT-SOURCE.json',
        'C4-CANDIDATE-FACTS.json': args.facts,
        'C4-ANDROID-RESULT.json': args.android/'c4/c4-result.json',
        'C4-DESKTOP-RUNTIME.json': args.runtime/'runtime-gate.json',
        'UPDATE-2020-RESULT.json': args.update/'update-result.json',
    }
    for name, source in originals.items():
        regular(source)
        if name.endswith('.apk'):
            os.link(source, assets/name)
        else:
            shutil.copyfile(source, assets/name)
        require(record(assets/name) == record(source), 'Release staging changed original bytes: '+name)
    with (assets/'Lumo-Lernen-Neu.apk.sha256').open('x') as handle:
        handle.write(arm64['sha256']+'  Lumo-Lernen-Neu.apk\n')
    write_new(assets/'C4-DELIVERY-FACTS.json', facts)
    write_new(assets/'PUBLISH-VERIFICATION.json', arm64)
    asset_index = {path.name: record(path) for path in sorted(assets.iterdir())}
    plan = {'schema': 1, 'host_source': binding['host_source'], 'tag': selected['tag'],
            'versionName': fresh['versionName'], 'versionCode': fresh['versionCode'],
            'download_url': selected['downloadUrl'], 'assets': asset_index}
    write_new(args.out/'publication-plan.json', plan)
    for name in ('run', 'jobs', 'artifacts', 'pull', 'releases', 'tags'):
        shutil.copyfile(args.metadata/(name+'.json'), audit/('original-'+name+'.json'))
    write_new(audit/'create-tag.json', {'ref': 'refs/tags/'+plan['tag'], 'sha': args.source})
    body = (
        'Lumo Lernen C4 '+fresh['versionName']+'+'+str(fresh['versionCode'])+' — signed ARM64 TEST APK.\n\n'
        'Exact Host: '+args.source+'\nExact Godot: '+binding['native_source']+'\n'
        'APK SHA-256: '+arm64['sha256']+'\nPCK SHA-256: '+arm64['godot']['pck_sha256']+'\n'
        'Signing certificate SHA-256: '+arm64['signingCertificateSha256']+'\n'
        'Original acceptance run: https://github.com/'+REPOSITORY+'/actions/runs/'+str(args.build_run)+'\n\n'
        'All current Flutter/build contracts, 52 native modes with face/C4/treasure rasters and movie, '
        'the real Dart/Godot C4 pair, actual API35 C4 touches/IPC/return and 2017→2020 preservation '
        'passed and their originals were rechecked before this new version was published.\n'
        'PCM contracts use a synthetic JVM boundary. No API37, physical ARM64, audible device PCM, '
        'human visual receipt or device FPS claim is made.\n'
        'Update the existing family app without uninstalling. This uses the unchanged Lumo TEST '
        'certificate, not Google Play production signing. Previous tags/releases/assets are never replaced.\n'
    )
    write_new(audit/'create-release.json', {'tag_name': plan['tag'], 'target_commitish': args.source,
              'name': 'Lumo '+str(fresh['versionCode'])+' ARM64 Test-APK', 'body': body,
              'draft': True, 'prerelease': True, 'make_latest': 'false', 'generate_release_notes': False})
    write_new(audit/'publish-release.json', {'draft': False, 'make_latest': 'false'})
    with (audit/'asset-names.txt').open('x') as handle:
        handle.write(''.join(name+'\n' for name in asset_index))
    print('[C4Delivery] PREPARED: all current originals reverified; no release mutation performed')
    return plan


def checked_plan(root: Path) -> dict:
    plan = read(root/'publication-plan.json')
    require(plan.get('schema') == 1 and plan.get('versionCode') == 2020
            and plan.get('tag') == 'coachpreview-build-2020'
            and re.fullmatch('[a-f0-9]{40}', str(plan.get('host_source'))), 'Invalid current delivery plan')
    require(isinstance(plan.get('assets'), dict) and plan['assets'], 'Release input set missing')
    actual = {p.name: record(p) for p in (root/'assets').iterdir()}
    require(actual == plan['assets'], 'Staged release files changed after acceptance')
    from release_pipeline_gates import family_apk_download_url
    require(plan.get('download_url') == family_apk_download_url(plan['tag']), 'Direct APK URL differs')
    return plan


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    prepare_parser = commands.add_parser('prepare')
    for name in ('candidate', 'runtime', 'host-compile', 'android', 'update', 'metadata', 'out',
                 'facts', 'build-contracts', 'native-evidence', 'native-source'):
        prepare_parser.add_argument('--'+name, type=Path, required=True)
    for name in ('source', 'artifact-digest'):
        prepare_parser.add_argument('--'+name, required=True)
    for name in ('build-run', 'run-attempt', 'artifact-id', 'pull-request'):
        prepare_parser.add_argument('--'+name, type=int, required=True)
    current = commands.add_parser('check-current')
    current.add_argument('--delivery', type=Path, required=True)
    current.add_argument('--metadata', type=Path, required=True)
    current.add_argument('--pull-request', type=int, required=True)
    for name in ('check-tag', 'check-release', 'verify-public'):
        command = commands.add_parser(name)
        command.add_argument('--delivery', type=Path, required=True)
        command.add_argument('--tag', type=Path, required=True)
        if name != 'check-tag':
            command.add_argument('--created', type=Path, required=True)
            command.add_argument('--release', type=Path, required=True)
        if name == 'check-release':
            command.add_argument('--stage', choices=('empty-draft', 'uploaded-draft', 'published'), required=True)
        if name == 'verify-public':
            command.add_argument('--apk', type=Path, required=True)
    args = parser.parse_args()
    if args.command == 'prepare':
        prepare(args)
        return 0
    plan = checked_plan(args.delivery)
    if args.command == 'check-current':
        facts = read(args.delivery/'assets/C4-DELIVERY-FACTS.json')
        checked_jobs(read(args.metadata/'run.json'), read(args.metadata/'jobs.json'),
                     read(args.metadata/'pull.json'), facts['binding'], args.pull_request)
        require(checked_artifacts(read(args.metadata/'artifacts.json'), facts['binding'])
                == facts['original_artifacts'], 'Required immutable upload identity changed before publication')
        checked_release_catalog(read(args.metadata/'releases.json'), read(args.metadata/'tags.json'), facts)
        return 0
    if args.command == 'check-tag':
        checked_tag(read(args.tag), plan)
    else:
        stage = args.stage if args.command == 'check-release' else 'published'
        receipt = checked_release(read(args.release), read(args.tag), read(args.created), plan, stage)
        if args.command == 'verify-public':
            require(record(args.apk) == plan['assets']['Lumo-Lernen-Neu.apk'],
                    'Unauthenticated direct Chrome download bytes differ from the actual signed APK')
            receipt.update({'status': 'PUBLIC_TEST_APK_BYTES_VERIFIED', 'host_source': plan['host_source'],
                            'versionName': plan['versionName'], 'versionCode': plan['versionCode'],
                            'public_apk': record(args.apk), 'plan_sha256': digest(args.delivery/'publication-plan.json')})
            write_new(args.delivery/'PUBLIC-DELIVERY-RECEIPT.json', receipt)
            print('[C4Delivery] verified direct Chrome APK:', plan['download_url'])
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
