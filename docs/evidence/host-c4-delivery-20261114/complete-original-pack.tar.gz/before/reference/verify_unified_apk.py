"""Verify signing, embedded source, package, ABIs and resource packaging."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import zipfile

from verify_android_apk import verify_apk, find_apksigner

ROOT = Path(__file__).resolve().parents[1]
SUPPORTED_ABIS = {'arm64-v8a', 'x86_64'}
EXPECTED_SIGNING_CERT_SHA256 = (
    'a6b1ef61bf59db4e0794c742aeb3b5506d130f4d21175c9975140e6acdb80702'
)
EXPECTATION_PATHS = (
    'pubspec.yaml', 'config/godot-source.json', 'config/lumo-offline-voice.json',
    'assets/audio/voice/lumo_free/catalog.json',
)


def load_expectations(repository: Path | None, revision: str | None) -> tuple[dict, dict | None]:
    """Keep current verification code while binding historical inputs to Git bytes."""
    if repository is None and revision is None:
        return {name: (ROOT / name).read_bytes() for name in EXPECTATION_PATHS}, None
    if repository is None or revision is None:
        raise RuntimeError('Expectation repository and revision must be supplied together')
    if not re.fullmatch(r'[0-9a-f]{40}', revision):
        raise RuntimeError('Expected a full immutable expectation commit SHA')
    git = ['git', '--no-replace-objects', '-C', str(repository)]
    commit = subprocess.check_output(git + ['rev-parse', revision + '^{commit}'], text=True).strip()
    if commit != revision:
        raise RuntimeError('Expectation revision does not identify the exact commit')
    files = {name: subprocess.check_output(git + ['show', f'{revision}:{name}'])
             for name in EXPECTATION_PATHS}
    return files, {'revision': revision, 'files': {
        name: hashlib.sha256(content).hexdigest() for name, content in files.items()}}


def validate_abis(actual: set[str], expected: set[str] | None = None) -> None:
    wanted = SUPPORTED_ABIS if expected is None else expected
    if not wanted or not wanted <= SUPPORTED_ABIS:
        raise RuntimeError(f'Unsupported expected native architectures: {wanted}')
    if actual != wanted:
        raise RuntimeError(f'Unexpected native architectures: {actual}, expected {wanted}')


def validate_offline_voice(archive: zipfile.ZipFile, abis: set[str],
                           config: dict, catalog: dict) -> dict:
    """Check the actual packaged weights, license, clips and native libraries."""
    names = archive.namelist()
    model_prefix = 'assets/lumo_offline_voice/'
    flutter_prefix = 'assets/flutter_assets/assets/audio/voice/lumo_free/'

    def payload(name: str) -> bytes:
        if names.count(name) != 1:
            raise RuntimeError(f'Missing or duplicated local voice asset: {name}')
        return archive.read(name)

    manifest = json.loads(payload(model_prefix + 'model-manifest.json'))
    if manifest != config:
        raise RuntimeError('Packaged local voice identity or model pin differs from source')
    for name, expected in config['file_sha256'].items():
        if hashlib.sha256(payload(model_prefix + name)).hexdigest() != expected:
            raise RuntimeError(f'Packaged local voice weight digest mismatch: {name}')
    for prefix in (model_prefix, flutter_prefix):
        if hashlib.sha256(payload(prefix + 'LICENSE-MODEL.txt')).hexdigest() != config['model_license_sha256']:
            raise RuntimeError('Original local voice model license missing or changed')
        payload(prefix + 'LICENSE-CODE.txt')
    packaged_catalog = json.loads(payload(flutter_prefix + 'catalog.json'))
    if packaged_catalog != catalog:
        raise RuntimeError('Packaged local voice clip catalog differs from source')
    if (catalog.get('variant') != config['profile']
            or catalog.get('preset') != config['preset']
            or catalog.get('speaker_id') != config['speaker_id']
            or catalog.get('machine_generated') is not True
            or catalog.get('aliases')):
        raise RuntimeError('Invalid free local voice clip identity or aliases')
    clips = catalog['clips']
    if len(clips) < 150:
        raise RuntimeError('Free local voice public clip inventory is incomplete')
    for clip in clips.values():
        if not re.fullmatch(r'free_[0-9a-f]{16}', clip['id']):
            raise RuntimeError('Invalid packaged local voice clip path')
        if hashlib.sha256(payload(flutter_prefix + clip['id'] + '.m4a')).hexdigest() != clip['asset_sha256']:
            raise RuntimeError(f'Packaged free voice clip digest mismatch: {clip["id"]}')
    for abi in abis:
        for library in ('libonnxruntime.so', 'libonnxruntime4j_jni.so'):
            payload(f'lib/{abi}/{library}')
    return {
        'profile': config['profile'], 'preset': config['preset'],
        'speakerId': config['speaker_id'], 'sampleRate': config['sample_rate'],
        'onnxruntimeVersion': config['onnxruntime_version'],
        'clipCount': len(clips), 'modelSha256': config['file_sha256'],
        'modelLicenseSha256': config['model_license_sha256'],
        'scope': 'Actual APK package validation, not audible playback acceptance',
    }


def verify(path: Path, expected_abis: set[str] | None = None, *,
           expectations_repository: Path | None = None,
           expectations_revision: str | None = None):
    certificate = verify_apk(path)
    if certificate.lower() != EXPECTED_SIGNING_CERT_SHA256:
        raise RuntimeError(
            'Signing certificate SHA-256 does not match the installed family app '
            f'({EXPECTED_SIGNING_CERT_SHA256})'
        )
    tools = Path(find_apksigner()).parent
    badging = subprocess.check_output([str(tools / 'aapt'), 'dump', 'badging', str(path)], text=True)
    package = re.search(r"package: name='([^']+)' versionCode='([^']+)' versionName='([^']+)'", badging)
    if package is None or package.group(1) != 'dev.ullmann.lumo.lumo_lernen.coachpreview':
        raise RuntimeError('Wrong package: this delivery must safely update the Build 274 parallel app')
    expectations, expectations_source = load_expectations(expectations_repository, expectations_revision)
    version = re.search(r'^version:\s*([^\s+]+)\+(\d+)\s*$',
                        expectations['pubspec.yaml'].decode('utf-8'), re.MULTILINE)
    if version is None:
        raise RuntimeError('Expected a version name and build number in pubspec.yaml')
    expected_code = os.environ.get('LUMO_BUILD_NUMBER', version.group(2))
    expected_name = os.environ.get('LUMO_VERSION_NAME', version.group(1))
    if expectations_source is not None and (expected_code != version.group(2)
                                            or expected_name != version.group(1)):
        raise RuntimeError('Version overrides cannot change source-bound expectations')
    if package.group(2) != expected_code or package.group(3) != expected_name:
        raise RuntimeError(
            f'Wrong Android version: {package.group(3)}+{package.group(2)}, '
            f'expected {expected_name}+{expected_code}')
    if "sdkVersion:'24'" not in badging:
        raise RuntimeError('Unexpected minimum Android version')
    if "targetSdkVersion:'36'" not in badging:
        raise RuntimeError('Unexpected target Android version')
    source = json.loads(expectations['config/godot-source.json'])
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('APK ZIP integrity failed')
        names = archive.namelist()
        abis = {name.split('/')[1] for name in names if name.startswith('lib/') and name.endswith('.so')}
        validate_abis(abis, expected_abis)
        for abi in abis:
            for library in ('libflutter.so', 'libapp.so', 'libgodot_android.so'):
                if f'lib/{abi}/{library}' not in names:
                    raise RuntimeError(f'Missing {abi}/{library}')
        offline_voice = validate_offline_voice(
            archive, abis,
            json.loads(expectations['config/lumo-offline-voice.json']),
            json.loads(expectations['assets/audio/voice/lumo_free/catalog.json']),
        )
        info = archive.getinfo('resources.arsc')
        if info.compress_type != zipfile.ZIP_STORED:
            raise RuntimeError('Android 11 requires uncompressed resources.arsc')
        with path.open('rb') as apk_file:
            apk_file.seek(info.header_offset)
            local_header = apk_file.read(30)
        name_length, extra_length = struct.unpack_from('<HH', local_header, 26)
        resource_offset = info.header_offset + 30 + name_length + extra_length
        if resource_offset % 4:
            raise RuntimeError('Android 11 requires aligned resources.arsc')
        # Compressed JNI libraries are extracted on install. Their ELF load
        # segments must still support Android devices with 16-KiB pages.
        for name in names:
            if not (name.startswith('lib/') and name.endswith('.so')):
                continue
            elf = archive.read(name)
            if elf[:6] != b'\x7fELF\x02\x01':
                raise RuntimeError(f'Expected a little-endian ELF64 library: {name}')
            phoff = struct.unpack_from('<Q', elf, 32)[0]
            phentsize, phnum = struct.unpack_from('<HH', elf, 54)
            for index in range(phnum):
                offset = phoff + index * phentsize
                kind = struct.unpack_from('<I', elf, offset)[0]
                if kind == 1 and struct.unpack_from('<Q', elf, offset + 48)[0] < 16384:
                    raise RuntimeError(f'Native library lacks 16-KiB load alignment: {name}')
        pack = archive.read('assets/lumo_game.pck')
        provenance = json.loads(archive.read('assets/lumo_game_source.json'))
        if provenance['revision'] != source['revision']:
            raise RuntimeError('Wrong Godot source revision')
        if hashlib.sha256(pack).hexdigest() != provenance['pck_sha256']:
            raise RuntimeError('Embedded PCK digest mismatch')
        if struct.unpack('<4s4I', pack[:20])[0] != b'GDPC':
            raise RuntimeError('Invalid Godot PCK')
    xml = subprocess.check_output([str(tools / 'aapt'), 'dump', 'xmltree', str(path), 'AndroidManifest.xml'], text=True)
    if 'LumoGameActivity' not in xml or ':lumo_game' not in xml:
        raise RuntimeError('Private embedded game activity missing')
    if re.search(r'android:debuggable[^\n]*0xffffffff', xml):
        raise RuntimeError('Release APK is debuggable')
    result = {'package': package.group(1), 'versionCode': int(package.group(2)), 'versionName': package.group(3),
              'minSdk': 24, 'targetSdk': 36, 'abis': sorted(abis),
              'elf16KiBAligned': True, 'resourcesArscAligned': True, 'bytes': path.stat().st_size,
              'sha256': hashlib.file_digest(path.open('rb'), 'sha256').hexdigest(),
              'signingCertificateSha256': certificate, 'godot': provenance,
              'offlineVoice': offline_voice}
    if expectations_source is not None:
        result['expectationsSource'] = expectations_source
    print(json.dumps(result, indent=2))
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('apk', type=Path)
    parser.add_argument('--abi', action='append', choices=sorted(SUPPORTED_ABIS),
                        help='Exact expected ABI; repeat for multiple. Default checks both.')
    parser.add_argument('--expectations-repository', type=Path,
                        help='Git checkout containing an explicitly pinned historical expectation commit.')
    parser.add_argument('--expectations-revision',
                        help='Full commit SHA supplying version, Godot pin and voice metadata; current guards remain.')
    args = parser.parse_args()
    if (args.expectations_repository is None) != (args.expectations_revision is None):
        parser.error('--expectations-repository and --expectations-revision must be supplied together')
    verify(args.apk, set(args.abi) if args.abi else None,
           expectations_repository=args.expectations_repository,
           expectations_revision=args.expectations_revision)
