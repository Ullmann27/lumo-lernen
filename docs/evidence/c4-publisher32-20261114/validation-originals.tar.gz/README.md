# Publisher9799 — einmaliger isolierter Vertragslauf

Auf dem tatsächlichen veröffentlichten Commit9799d1d637eb870dbb366d95d6593ed7ca876849, Tree0760912044f5beefcf24a734e49a956259116e8b, wurde genau einmal der freigegebene Befehl ausgeführt:

    python3 -m unittest -v scripts.tests.test_publish_connect_four_delivery

Ergebnis:32 PASS,0 Fehler,0 Skips; Originalausgabe Ran32 tests in0.593s, tatsächlicher Prozess0.819 Sekunden, Exit0. Die vollständige unveränderte unittest-Ausgabe liegt in publisher32.stderr; publisher32.stdout ist tatsächlich leer. Eingaben, argv, Zeitpunkte, Exitcode und Hashes sind separat erhalten.

Der eigene Checkout wurde ohne Änderungen an fremden Arbeitsverzeichnissen exakt und flach aus der veröffentlichten SHA geholt. Der zuvor angeforderte einzelne Autosave-Aufruf meldete Nothing new to save; er änderte weder Quelle, Branch noch Index und führte keinen Push aus.

Alle4474 getrackten Index-/Tree-Einträge sind vor/nach gebunden:9 tatsächlich materialisierte Dateien byte- und modegleich;4465 nicht benötigte Pfade ausdrücklich als fehlende skip-worktree-Einträge. Keine fehlende Datei war unmittelbarer Import oder Fixturebedarf dieser32 selbstständigen Tests. Vollständige Rohindizes, Stages, Flags und Inventare sind erhalten. Getrackte und ungetrackte Änderungen sowie neue ignorierte Dateien sind nicht entstanden.

Die Tests verwenden synthetische Bundle-/APK-Bytes und kontrollierte API-/Git-Grenzen, führen dabei die vorhandenen echten Verifierfunktionen aus und verbieten socket.create_connection. Es wurde kein Live-Publisher, kein Gerät, keine Engine, kein neuer CI-Lauf und keine Release-/Tag-/Refmutation ausgeführt. Das Ergebnis ersetzt keine tatsächliche Veröffentlichung und keine erfolgreiche Host-CI. Der vorherige reine Quellenreview bleibt getrennt und unverändert.

manifest.json und SHA256SUMS binden den vollständigen Pack. Das daneben bereitgestellte deterministische Archiv enthält sämtliche Packdateien; sein Inhalt wurde vollständig bytegleich zurückgelesen.
