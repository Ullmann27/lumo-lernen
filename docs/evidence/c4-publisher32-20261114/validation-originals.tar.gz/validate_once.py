#!/usr/bin/env python3
import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import time

REPO = Path('/tmp/lumo-publisher-9799d1d-validation-20261114/host')
OUT = Path(__file__).resolve().parent
SHA = '9799d1d637eb870dbb366d95d6593ed7ca876849'
TREE = '0760912044f5beefcf24a734e49a956259116e8b'
ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_NO_LAZY_FETCH='1',
           GIT_TERMINAL_PROMPT='0', PYTHONDONTWRITEBYTECODE='1')


def digest(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, env=ENV)


def save(path, data):
    with path.open('xb') as handle:
        handle.write(data)
    assert path.read_bytes() == data


def jsave(path, value):
    save(path, (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode())


def snapshot(name):
    directory = OUT / name
    directory.mkdir(exist_ok=False)
    head = git('rev-parse', 'HEAD').decode().strip()
    tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
    assert head == SHA and tree == TREE
    originals = {
        'status.bin': git('status', '--porcelain=v1', '-z', '--untracked-files=all'),
        'stage.bin': git('ls-files', '--stage', '-z'),
        'flags.bin': git('ls-files', '-v', '-z'),
        'tree.bin': git('ls-tree', '-r', '-z', '--full-tree', 'HEAD'),
        'untracked.bin': git('ls-files', '--others', '--exclude-standard', '-z'),
        'ignored.bin': git('ls-files', '--others', '--ignored', '--exclude-standard', '-z'),
    }
    index = Path(git('rev-parse', '--git-path', 'index').decode().strip())
    if not index.is_absolute():
        index = REPO / index
    originals['index.bin'] = index.read_bytes()
    assert originals['status.bin'] == originals['untracked.bin'] == originals['ignored.bin'] == b''
    for path, data in originals.items():
        save(directory / path, data)
    flags = {part[2:].decode(): part[:1].decode() for part in originals['flags.bin'].split(b'\0') if part}
    tracked = []
    for part in originals['stage.bin'].split(b'\0'):
        if not part:
            continue
        metadata, raw_path = part.split(b'\t', 1)
        mode, blob, stage = metadata.decode().split()
        path = raw_path.decode()
        assert stage == '0'
        physical = REPO / path
        row = {'path': path, 'mode': mode, 'git_blob': blob, 'flag': flags[path],
               'materialized': physical.exists() or physical.is_symlink()}
        if row['materialized']:
            assert not physical.is_symlink() and physical.is_file()
            data = physical.read_bytes()
            actual_blob = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
            actual_mode = '100755' if physical.stat().st_mode & stat.S_IXUSR else '100644'
            assert actual_blob == blob and actual_mode == mode, path
            row.update(digest(data), actual_blob=actual_blob, actual_mode=actual_mode)
        else:
            assert flags[path] == 'S', path
        tracked.append(row)
    report = {'head': head, 'tree': tree, 'branch': git('branch', '--show-current').decode().strip(),
              'raw': {path: digest(data) for path, data in originals.items()}, 'tracked': tracked,
              'materialized_count': sum(row['materialized'] for row in tracked),
              'sparse_missing_count': sum(not row['materialized'] for row in tracked)}
    jsave(directory / 'inventory.json', report)
    return report


def command(name, argv, timeout):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    monotonic = time.monotonic()
    with (OUT / (name + '.stdout')).open('xb') as stdout, (OUT / (name + '.stderr')).open('xb') as stderr:
        try:
            process = subprocess.run(argv, cwd=REPO, env=ENV, stdin=subprocess.DEVNULL,
                                     stdout=stdout, stderr=stderr, timeout=timeout, check=False)
            code, expired = process.returncode, False
        except subprocess.TimeoutExpired:
            code, expired = None, True
    result = {'argv': argv, 'cwd': str(REPO), 'started_at': started,
              'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'elapsed_seconds': time.monotonic() - monotonic, 'exit_code': code,
              'timed_out': expired, 'timeout_seconds': timeout,
              'stdout': digest((OUT / (name + '.stdout')).read_bytes()),
              'stderr': digest((OUT / (name + '.stderr')).read_bytes())}
    jsave(OUT / (name + '.json'), result)
    print(json.dumps(result), flush=True)
    return result


def main():
    before_autosave = snapshot('before-autosave')
    autosave = command('autosave-once', ['python3', 'tools/lumo_autosave.py', 'once'], 60)
    assert autosave['exit_code'] == 0 and not autosave['timed_out']
    assert b'Nothing new to save' in (OUT / 'autosave-once.stdout').read_bytes()
    before = snapshot('before-tests')
    assert before == before_autosave
    inputs = OUT / 'input-source'
    inputs.mkdir()
    for row in before['tracked']:
        if row['materialized']:
            path = inputs / row['path']
            path.parent.mkdir(parents=True, exist_ok=True)
            save(path, (REPO / row['path']).read_bytes())
    test_path = REPO / 'scripts/tests/test_publish_connect_four_delivery.py'
    methods = [node.name for node in ast.walk(ast.parse(test_path.read_text()))
               if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')]
    assert len(methods) == 32
    jsave(OUT / 'test-input-binding.json', {'head': SHA, 'tree': TREE, 'methods': sorted(methods),
                                           'runtime': subprocess.check_output(['python3', '--version'], env=ENV).decode().strip(),
                                           'test_source': digest(test_path.read_bytes()),
                                           'network': 'Written test classes replace socket.create_connection with failure; synthetic API and Git boundaries, no live publisher invocation'})
    result = command('publisher32', ['python3', '-m', 'unittest', '-v',
                                     'scripts.tests.test_publish_connect_four_delivery'], 180)
    after = snapshot('after-tests')
    comparison = {'head_tree_index_stage_materialized_bytes_modes_unchanged': before == after,
                  'all_tracked_entries': len(before['tracked']),
                  'materialized_count': before['materialized_count'],
                  'explicit_missing_skip_worktree_count': before['sparse_missing_count'],
                  'autosave_did_not_change_source_or_index': before_autosave == before}
    jsave(OUT / 'source-comparison.json', comparison)
    assert before == after
    print(json.dumps(comparison), flush=True)
    raise SystemExit(result['exit_code'] if result['exit_code'] is not None else 124)


if __name__ == '__main__':
    main()
