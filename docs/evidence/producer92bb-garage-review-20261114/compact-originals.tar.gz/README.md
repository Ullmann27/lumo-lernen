# PR502 92bb Garagevergleich

**Kein zusätzlicher Garagepatch ist durch diesen Quellen- und Bildvergleich begründet.** Der bestehende Observer auf Host3fac bindet seine Scrollbewegung bereits an den tatsächlichen kurzen Listenbereich, kann rückwärts zu Gecko korrigieren und behält den ursprünglichen Ganzwort-Boru-Leser.

Die beiden neuen veröffentlichten Original-PNGs wurden jeweils direkt angesehen: Main zeigt Boru unter dem abgeschnittenen Gecko-Bereich, Update den vollständigen Gecko-Titel. Die Update-OCR endet nach dem ersten Contrast-Treffer; unsere aktuelle Erfassung liest ausdrücklich alle Caption-Regionen. Eine direkte Gleichsetzung dieser Erfassungen wäre falsch.

Die vier nativen Garage-/Katalogdateien auf3213 und ce909 sind bytegleich. **Beide besitzen dieselbe 14er-Flotte.** Die sechs Werte des Producerhelfers sind nur eine OCR-Hilfsliste. Der vorhandene2281-Beleg bindet die drei maßgeblichen Garageblobs ebenfalls exakt.

Der Bericht erhält die strikten Bild-, Eindeutigkeits-, Frist-, Fünf-Gesten-, Volltitel-, Race-Save- und Continue-Caption-Grenzen. Der separate Workflow-/Release-Lint-Nachtrag wurde nur eingeordnet und wird nicht übernommen.

Keine Tests, Imports, OCR-/Geräteversuche oder CI-Abfragen. Kein neuer PASS für diese Frames. Die PNGs sind gegen veröffentlichte Gitblobs und die veröffentlichte Provenienz geprüft; die vollständigen ursprünglichen Actions-ZIPs wurden in diesem Review nicht erneut geladen. review.json enthält die genaue Kontrollflussbewertung und Grenzen; current-and-native-source-binding.json hält vollständige Quellbytes über deduplizierte Blobs und unveränderte HEAD-/Tree-/Indexbindungen fest.
