import json, os
from pathlib import Path
data = json.loads((Path(os.environ['LUMO_QUAL_EVIDENCE']) / 'flutter-version.json').read_bytes())
if data.get('frameworkVersion') != '3.44.9':
    raise ValueError('Actual Flutter version differs')
