import hashlib, json, os, re
from pathlib import Path, PurePosixPath
proof = Path(os.environ['LUMO_QUAL_EVIDENCE'])
host = Path(os.environ['GITHUB_WORKSPACE']) / 'host-source'
inventory = json.loads((proof / 'source/host/source-inventory-before.json').read_bytes())
tracked = {row['path']: row for row in inventory['tracked']}
text = (host / 'pubspec.yaml').read_text()
lines = text.splitlines()
inside, section, declarations = False, None, []
for line in lines:
    if line == 'flutter:':
        inside = True
        continue
    if inside and line and not line.startswith((' ', '#')):
        inside = False
    if not inside:
        continue
    if re.fullmatch(r'  assets:\s*', line):
        section = 'assets'
        continue
    if re.fullmatch(r'  fonts:\s*', line):
        section = 'fonts'
        continue
    if re.match(r'^  [^ ]', line):
        section = None
    if section == 'assets' and line.strip() and not line.lstrip().startswith('#'):
        match = re.fullmatch(r'    - ((?:assets|docs)/[^#\s]+)\s*', line)
        if not match:
            raise ValueError('Unsupported asset declaration; refusing an incomplete preflight: ' + line)
        declarations.append(match.group(1))
    elif section == 'fonts' and re.search(r'\basset\s*:', line):
        match = re.fullmatch(r'        - asset: ((?:assets|docs)/[^#\s]+)\s*', line)
        if not match:
            raise ValueError('Unsupported font asset declaration: ' + line)
        declarations.append(match.group(1))
if not declarations or 'docs/lumo_game_specs/2026-10-05/03_cards/lumo_cards_key_art.webp' not in declarations:
    raise ValueError('Required complete pubspec asset declarations are absent')
records = []
for declaration in declarations:
    relative = PurePosixPath(declaration)
    if relative.is_absolute() or '..' in relative.parts:
        raise ValueError('Unsafe declared asset')
    names = sorted(name for name in tracked if name.startswith(declaration)) if declaration.endswith('/') else [declaration]
    if not names:
        raise ValueError('No committed files in declared asset directory: ' + declaration)
    entries = []
    for name in names:
        source = host / name
        if name not in tracked or not source.is_file() or source.is_symlink():
            raise ValueError('Missing actual committed asset: ' + name)
        data = source.read_bytes()
        if hashlib.sha256(data).hexdigest() != tracked[name]['sha256']:
            raise ValueError('Declared asset differs from the source snapshot: ' + name)
        entries.append({'path': name, 'bytes': len(data), 'sha256': tracked[name]['sha256'], 'git_blob': tracked[name]['git_blob']})
    records.append({'declaration': declaration, 'files': entries})
(proof / 'pubspec-assets.json').write_text(json.dumps({'schema': 1, 'status': 'PASS',
    'source': inventory['head'], 'declarations': records,
    'unique_file_count': len({row['path'] for item in records for row in item['files']})}, indent=2) + '\n')
print('PUBSPEC_ASSETS_BOUND declarations=' + str(len(declarations)))
