import hashlib, json, os
from pathlib import Path
host = Path(os.environ['GITHUB_WORKSPACE']) / 'host-source'
proof = Path(os.environ['LUMO_QUAL_EVIDENCE']) / 'android-host-compile'
report = json.loads((proof / 'result.json').read_bytes())
if report.get('status') != 'PASS' or report.get('flutter_source_commit') != os.environ['EXPECTED_HOST']:
    raise ValueError('Actual Host compile result/source differs')
classes = {}
required = ('TableGameActivity', 'TableGamesHostPlugin', 'TableGamesBridge', 'TableAuthorityService', 'TableGameIntent',
            'ConnectFourGameActivity', 'ConnectFourAuthorityService', 'ConnectFourBridge')
for name in required:
    paths = sorted((host / 'build/app').rglob(name + '.class'))
    if not paths:
        raise ValueError('Actual Android bytecode missing: ' + name)
    classes[name] = []
    for number, path in enumerate(paths):
        data = path.read_bytes()
        if not data.startswith(bytes.fromhex('cafebabe')):
            raise ValueError('Invalid actual Android class')
        target = proof / 'classes' / (name + '-' + str(number) + '.class')
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        if target.read_bytes() != data:
            raise ValueError('Original compiled class copy differs')
        row = {'source_path': str(path.relative_to(host)), 'original': str(target.relative_to(proof)),
               'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        if name.startswith('Table') and not any(entry['path'] == row['source_path'] and entry['sha256'] == row['sha256'] and entry['bytes'] == row['bytes']
                                                for entry in report['classes'].get(name, [])):
            raise ValueError('Table class differs from the actual compiler report')
        classes[name].append(row)
(proof / 'table-and-c4-classes.json').write_text(json.dumps({'status': 'PASS', 'source': os.environ['EXPECTED_HOST'],
    'classes': classes, 'scope': 'Actual Android Kotlin/Java compilation only; no APK, R8 or device approval'}, indent=2) + '\n')
print('TABLE_ANDROID_COMPILE_PASS table_classes=5 retained_c4_classes=3')
