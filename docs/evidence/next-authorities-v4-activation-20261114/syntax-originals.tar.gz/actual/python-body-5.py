import hashlib, importlib.util, json, math, os, re, sys
from pathlib import Path
sys.dont_write_bytecode = True
root = Path(os.environ['LUMO_QUAL_EVIDENCE'])
native = Path(os.environ['GITHUB_WORKSPACE']) / 'native-source'
group = os.environ['QUALIFICATION_GROUP']
helper = root / 'tools/verify_dream_rasters.py'
raw = helper.read_bytes()
if hashlib.sha256(raw).hexdigest() != 'f7296a802d15c382dbcc77640373a0f53e30306fcaab3de869549ff1656de89d':
    raise ValueError('Original PNG reader changed')
if hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() != 'da8eed7d6383fcbc82a03596518a5fcc3b9a00c5':
    raise ValueError('Original PNG reader blob differs')
spec = importlib.util.spec_from_file_location('bound_renderer_reader', helper)
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)
decoded = []
sidecars = []
def log_marker(relative, expression, *, engine=False):
    text, record = reader.original_text(root, relative)
    reader.require(not reader.ERRORS.search(text), 'Engine error, timeout or leak in ' + relative)
    reader.require(sum(bool(re.fullmatch(expression, line)) for line in text.splitlines()) == 1,
                   'Required unique original marker missing: ' + relative)
    if engine:
        reader.require(text.splitlines().count('Godot Engine v' + reader.ENGINE + ' - https://godotengine.org') == 1,
                       'Exactly one actual approved engine invocation is required: ' + relative)
    return record
def positive_count(value):
    reader.require(type(value) in (int, float) and math.isfinite(value) and value == int(value) and 0 < value <= 1000000000,
                   'Positive integral original count required')
    return int(value)
def png(folder, entry, *, name_key='file', dimensions_key=None):
    name = entry.get(name_key)
    reader.require(isinstance(name, str) and Path(name).name == name, 'Nonlocal capture path')
    relative = folder + '/' + name
    dimensions = entry.get(dimensions_key) if dimensions_key else [entry.get('width'), entry.get('height')]
    reader.require(isinstance(dimensions, list) and len(dimensions) == 2, 'Missing actual framebuffer dimensions')
    normalized = []
    for value in dimensions:
        reader.require(type(value) in (int, float) and value == int(value), 'Nonintegral original framebuffer dimension')
        normalized.append(int(value))
    record, pixels = reader.png(root, relative, normalized)
    reader.require(record['sha256'] == entry.get('sha256'), 'PNG/report byte identity differs')
    decoded.append({**record, 'decoded_rgb_sha256': hashlib.sha256(pixels.tobytes()).hexdigest()})
def pair_sources(pair):
    reader.require(pair.get('success') is True and pair.get('capture_requested') is True, 'Actual captured authority pair did not pass')
    for phase in ('source_before', 'source_after'):
        identity = pair.get(phase, {})
        for name, expected in [('host', os.environ['EXPECTED_HOST']), ('native', os.environ['EXPECTED_NATIVE'])]:
            reader.require(identity.get(name, {}).get('commit') == expected, 'Pair uses foreign ' + name + ' source')
        reader.require(identity['native']['tree'] == os.environ['EXPECTED_NATIVE_TREE'], 'Pair uses foreign Native tree')
        source_before = json.loads((root / 'source-before.json').read_bytes())
        reader.require(identity['host']['tree'] == source_before['sources']['host']['tree'], 'Pair uses foreign Host tree')
    reader.require(pair['source_before'] == pair['source_after'], 'Pair source identity changed')
    exits = pair.get('process_exit_codes', {})
    reader.require(len(exits) == 2 and all(type(value) is int and value == 0 for value in exits.values()),
                   'Both real authority children must exit successfully')
if group == 'english':
    report, _ = reader.original_json(root, 'english-native/learning-english-report.json')
    fixtures, fixture_record = reader.original_json(root, 'english-activity.json')
    reader.require(fixtures.get('failures') == 0 and len(fixtures.get('examples', {})) == 14,
                   'Current Dart English task producer did not supply the complete catalogue')
    reader.require(report.get('fixture_kind') == 'actual_dart_producer_report' and
                   report.get('task_fixture_sha256') == fixture_record['sha256'], 'Actual Dart/Native fixture binding differs')
    reader.require(report.get('failures') == [] and report.get('renderer') not in (None, '', 'headless'), 'English renderer failed or absent')
    reader.require(type(report.get('checks')) in (int, float) and report['checks'] > 0, 'English checks absent')
    captures = report.get('captures', [])
    reader.require(len(captures) == 17, 'Seventeen actual English captures required')
    for entry in captures:
        png('english-native', entry, name_key='png', dimensions_key='window_px')
        stem = Path(entry['png']).stem
        for suffix in ('.json', '.layout.json'):
            _, record = reader.original_json(root, 'english-native/' + stem + suffix)
            sidecars.append(record)
    reader.require(bool(report.get('source_sha256')) and bool(report.get('input_events')), 'English source/input observations absent')
    for path, sha in report.get('source_sha256', {}).items():
        reader.require(hashlib.sha256((native / path).read_bytes()).hexdigest() == sha, 'English measured source differs')
    log_marker('english-render.log', r'LEARNING_ENGLISH_PASS checks=' + str(positive_count(report['checks'])) +
               r' captures=17 input_events=' + str(len(report['input_events'])) + r' fixture=actual_dart_producer_report', engine=True)
elif group == 'memory':
    view, _ = reader.original_json(root, 'memory-view/memory-view-result.json')
    reader.require(view.get('status') == 'PASS' and view.get('errors') == [] and view.get('capture') is True,
                   'Actual Memory geometry did not pass')
    reader.require(len(view.get('captures', [])) == 8, 'Eight Memory geometry captures required')
    for entry in view['captures']:
        png('memory-view', entry)
    log_marker('memory-view.log', r'MEMORY_VIEW_PASS checks=' + str(positive_count(view['checks'])) + r' captures=8', engine=True)
    pair, _ = reader.original_json(root, 'memory-pair/pair-result.json')
    pair_sources(pair)
    runtime, _ = reader.original_json(root, 'memory-pair/native/memory-runtime-report.json')
    reader.require(runtime.get('success') is True and runtime.get('failures') == [] and
                   runtime.get('mode') == 'production_dart_disk_authority' and runtime.get('display_driver') not in (None, '', 'headless'),
                   'Actual Memory authority renderer did not pass')
    reader.require(len(runtime.get('captures', [])) == 8 and len(runtime.get('motion_frames', [])) == 12,
                   'Memory gameplay captures or twelve real flip frames missing')
    for entry in runtime['captures'] + runtime['motion_frames']:
        png('memory-pair/native', entry)
    for entry in runtime['captures']:
        layout, record = reader.original_json(root, 'memory-pair/native/' + Path(entry['file']).stem + '.layout.json')
        reader.require(layout.get('settled') is True and all(layout.get(key) == entry.get(key) for key in ('token', 'roundId', 'revision')),
                       'Memory current layout identity differs')
        sidecars.append(record)
    reader.require(pair.get('checks') == runtime.get('checks') and pair.get('inputs') == len(runtime.get('inputs', [])),
                   'Memory actual pair/result counts differ')
    log_marker('memory-pair/godot-runtime.log', r'\[MemoryTableRuntime\] PASS checks=' + str(positive_count(runtime['checks'])) +
               r' inputs=' + str(positive_count(len(runtime['inputs']))), engine=True)
    log_marker('memory-pair/runner.log', r'\[MemoryNativePair\] PASS')
elif group == 'quiz':
    pair, _ = reader.original_json(root, 'quiz-pair/pair-result.json')
    pair_sources(pair)
    runtime, _ = reader.original_json(root, 'quiz-pair/native/quiz-runtime-report.json')
    reader.require(runtime.get('mode') == 'production_dart_disk_authority' and runtime.get('failures') == [] and
                   runtime.get('display_driver') not in (None, '', 'headless'), 'Actual Quiz authority renderer did not pass')
    reader.require(len(runtime.get('captures', [])) == 6, 'Six actual Quiz captures required')
    for entry in runtime['captures']:
        png('quiz-pair/native', entry, dimensions_key='size_px')
        reader.require(entry.get('layout') == Path(entry['file']).stem + '.layout.json', 'Quiz original layout path differs')
        layout, record = reader.original_json(root, 'quiz-pair/native/' + entry['layout'])
        reader.require(layout.get('settled') is True and layout.get('pending') == 0 and layout.get('revision') == entry.get('revision'),
                       'Quiz current layout identity differs')
        sidecars.append(record)
    reader.require(pair.get('checks') == runtime.get('checks') and pair.get('inputs') == len(runtime.get('inputs', [])),
                   'Quiz actual pair/result counts differ')
    log_marker('quiz-pair/godot-runtime.log', r'\[QuizStudioRuntime\] PASS checks=' + str(positive_count(runtime['checks'])) + r' captures=6', engine=True)
    log_marker('quiz-pair/runner.log', r'\[QuizNativePair\] PASS')
else:
    raise ValueError('Unknown renderer group')
names = [row['path'] for row in decoded]
reader.require(len(names) == len(set(names)), 'Repeated original PNG entry')
actual_pngs = sorted(str(path.relative_to(root)) for path in root.rglob('*.png') if 'user' not in path.relative_to(root).parts)
reader.require(sorted(names) == actual_pngs, 'Original PNG roster differs from reports')
for path in root.rglob('*.log'):
    if path.name in ('godot-import.log', 'godot-runtime.log', 'runner.log') or path.name.endswith('-render.log') or path.name == 'memory-view.log':
        reader.require(not reader.ERRORS.search(path.read_text()), 'Engine error, timeout or leak in original ' + str(path.relative_to(root)))
(root / 'renderer-originals.json').write_text(json.dumps({'schema': 1, 'status': 'PASS', 'group': group,
    'host': os.environ['EXPECTED_HOST'], 'native': os.environ['EXPECTED_NATIVE'], 'pngs': decoded, 'sidecars': sidecars,
    'scope': 'Actual desktop renderer/authority and declared QA transport only; no Android, physical-device, audio or FPS acceptance'}, indent=2) + '\n')
print('RENDERER_ORIGINALS_PASS group=' + group + ' decoded_pngs=' + str(len(decoded)))
