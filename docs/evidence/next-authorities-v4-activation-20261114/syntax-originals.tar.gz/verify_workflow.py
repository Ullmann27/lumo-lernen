#!/usr/bin/env python3
"""Verify the exact committed V4 workflow without importing product code."""
import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import textwrap


ROOT = Path('/tmp/lumo-root-recovery-1750/host')
PROOF = Path('/workspace/scratch/b3485b7bb989/host-authorities-v4-syntax-20261114/actual')
RELATIVE = '.github/workflows/lumo-next-table-authorities.yml'
EXPECTED_HEAD = '528a265a7cc9e28f26523249b07fba0fdc1bf801'
EXPECTED_TREE = 'd209a72bf2fefe9890e570d0c5739b760f3bec0d'
EXPECTED_BLOB = 'fbd470a24012b238de1e347c0021e40951aa7c23'
EXPECTED_SHA = 'fa59d9fa5b2fbc333300c57b821561132aab0f043bf1ba4e9f7f07840b1d17eb'


def require(value, message):
    if not value:
        raise ValueError(message)


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args],
                                   env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'})


def main():
    PROOF.mkdir(exist_ok=False)
    require(git('rev-parse', 'HEAD').decode().strip() == EXPECTED_HEAD, 'Wrong actual checkout')
    require(git('rev-parse', 'HEAD^{tree}').decode().strip() == EXPECTED_TREE, 'Wrong actual tree')
    require(not git('status', '--porcelain=v1'), 'Actual checkout is not clean')
    raw = (ROOT / RELATIVE).read_bytes()
    require(len(raw) == 65909 and hashlib.sha256(raw).hexdigest() == EXPECTED_SHA, 'Wrong workflow bytes')
    require(hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == EXPECTED_BLOB,
            'Wrong workflow Git blob')
    require(git('show', 'HEAD:' + RELATIVE) == raw, 'Workflow is not the actual committed source')
    (PROOF / 'workflow.original.yml').write_bytes(raw)
    (PROOF / 'source-commit.raw').write_bytes(git('cat-file', 'commit', 'HEAD'))
    (PROOF / 'source-tree.raw').write_bytes(git('ls-tree', '-rz', '--full-tree', 'HEAD'))
    stage = git('ls-files', '--stage', '-z')
    (PROOF / 'source-index-stage.raw').write_bytes(stage)
    lines = raw.decode().splitlines()
    blocks = []
    position = 0
    while position < len(lines):
        _, marker, suffix = lines[position].partition("<<'PY'")
        if not marker:
            position += 1
            continue
        redirects = shlex.split(suffix, posix=True)
        require(not len(redirects) % 2 and all(
            redirects[i] in ('>', '1>', '2>', '>>', '1>>', '2>>') and redirects[i + 1]
            for i in range(0, len(redirects), 2)), 'Unsupported original heredoc suffix')
        start = position + 1
        position = start
        while position < len(lines) and lines[position].strip() != 'PY':
            position += 1
        require(position < len(lines), 'Unclosed original Python body')
        code = textwrap.dedent('\n'.join(lines[start:position])) + '\n'
        ast.parse(code, filename=RELATIVE + ':' + str(start + 1))
        body = code.encode()
        (PROOF / ('python-body-' + str(len(blocks) + 1) + '.py')).write_bytes(body)
        blocks.append({'first_line': start + 1, 'last_line': position,
                       'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()})
        position += 1
    require(len(blocks) == 9, 'The complete nine-block source roster is required')
    require(sum(b['sha256'] == '1ed0e3cd4c7839d9d3e3427767fb5eaadf0550a782885fb373bd694e2cc65760'
                for b in blocks) == 1, 'The six-case-tested snapshot program is not retained exactly')
    original_binary = Path('/workspace/scratch/b3485b7bb989/authority-lint-43622916726-verified-20261114/originals/actionlint')
    binary_bytes = original_binary.read_bytes()
    binary_sha = hashlib.sha256(binary_bytes).hexdigest()
    require(binary_sha == 'c872d6db8c6bf83a8eaa704fc93999f027d55dffbc63b8a6abdccb47df5f4cd4', 'Wrong original Actionlint binary')
    binary = PROOF / 'actionlint'
    binary.write_bytes(binary_bytes)
    binary.chmod(0o755)
    version = subprocess.run([str(binary), '--version'], capture_output=True, timeout=30)
    (PROOF / 'actionlint-version.stdout').write_bytes(version.stdout)
    (PROOF / 'actionlint-version.stderr').write_bytes(version.stderr)
    require(version.returncode == 0 and version.stdout.startswith(b'1.7.12\n'), 'Unexpected actual Actionlint version')
    result = subprocess.run([str(binary), '-no-color', str(ROOT / RELATIVE)], cwd=ROOT,
                            capture_output=True, timeout=30)
    (PROOF / 'actionlint.stdout').write_bytes(result.stdout)
    (PROOF / 'actionlint.stderr').write_bytes(result.stderr)
    (PROOF / 'actionlint.exit-code.txt').write_text(str(result.returncode) + '\n')
    require(result.returncode == 0, 'Actual Actionlint failed; original diagnostics retained')
    require((ROOT / RELATIVE).read_bytes() == raw, 'Workflow bytes changed')
    require(git('ls-files', '--stage', '-z') == stage and not git('status', '--porcelain=v1'),
            'Actual source index or worktree changed')
    report = {'schema': 1, 'status': 'PASS', 'created_utc': datetime.now(timezone.utc).isoformat(),
              'host': EXPECTED_HEAD, 'tree': EXPECTED_TREE, 'workflow_git_blob': EXPECTED_BLOB,
              'workflow_sha256': EXPECTED_SHA, 'workflow_bytes': len(raw),
              'actual_python_blocks': blocks, 'actual_python_block_count': len(blocks),
              'actual_actionlint_exit': result.returncode, 'actual_actionlint_invocations': 1,
              'actionlint_sha256': binary_sha, 'shellcheck_available': shutil.which('shellcheck'),
              'source_and_index_unchanged': True,
              'scope': 'Actual exact committed workflow syntax and nine Python bodies; no product imports, renderer, JVM, Android or APK result.'}
    (PROOF / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
