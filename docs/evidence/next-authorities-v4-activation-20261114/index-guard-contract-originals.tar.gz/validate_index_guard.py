#!/usr/bin/env python3
"""Exercise the exact workflow snapshot with explicitly synthetic Git repositories."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import textwrap
from datetime import datetime, timezone


def identity(data):
    return {
        'bytes': len(data),
        'sha256': hashlib.sha256(data).hexdigest(),
        'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(),
    }


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def git(root, *args):
    return subprocess.check_output(
        ['git', '-C', str(root), *args], stderr=subprocess.PIPE,
        env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'},
    )


def snapshot_program(workflow):
    lines = workflow.decode().splitlines()
    marker = 'cat > "$LUMO_QUAL_ROOT/source_snapshot.py" <<\'PY\''
    starts = [number + 1 for number, line in enumerate(lines) if line.strip() == marker]
    require(len(starts) == 1, 'The exact snapshot heredoc must occur once')
    start = starts[0]
    end = start
    while end < len(lines) and lines[end].strip() != 'PY':
        end += 1
    require(end < len(lines), 'Unclosed snapshot source')
    return (textwrap.dedent('\n'.join(lines[start:end])) + '\n').encode()


def make_repository(path, reader=None):
    path.mkdir(parents=True)
    git(path, 'init', '--quiet', '--initial-branch=fixture')
    git(path, 'config', 'user.name', 'Lumo isolated Git contract')
    git(path, 'config', 'user.email', 'git-contract@invalid.example')
    git(path, 'config', 'commit.gpgsign', 'false')
    git(path, 'config', 'core.filemode', 'true')
    (path / 'product.txt').write_bytes(b'unchanged fixture content\n')
    if reader is not None:
        (path / 'tools').mkdir()
        (path / 'tools/verify_dream_rasters.py').write_bytes(reader)
    git(path, 'add', '--all')
    git(path, 'commit', '--quiet', '-m', 'Synthetic local source fixture; never a product result')
    return git(path, 'rev-parse', 'HEAD').decode().strip()


def run_phase(program, phase, environment, record_dir, label):
    result = subprocess.run(
        [sys.executable, '-B', str(program), phase], env=environment,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30,
    )
    (record_dir / (label + '.stdout')).write_bytes(result.stdout)
    (record_dir / (label + '.stderr')).write_bytes(result.stderr)
    (record_dir / (label + '.exit-code.txt')).write_text(str(result.returncode) + '\n')
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--workflow', type=Path, required=True)
    parser.add_argument('--original-workflow', type=Path, required=True)
    parser.add_argument('--reader', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root = args.output.resolve()
    root.mkdir(parents=True, exist_ok=False)
    patched = args.workflow.read_bytes()
    original = args.original_workflow.read_bytes()
    reader = args.reader.read_bytes()
    require(identity(patched)['git_blob'] == '3e9c5cab10d05c47204f87003e439e4a2d884709', 'Wrong patched workflow')
    require(identity(original)['git_blob'] == '6a08dfb852cbec128db96aaa84add2bc69a7194b', 'Wrong original workflow')
    require(identity(reader)['git_blob'] == 'da8eed7d6383fcbc82a03596518a5fcc3b9a00c5', 'Wrong unchanged source reader')
    source_dir = root / 'original-source'
    source_dir.mkdir()
    programs = {}
    for name, data in (('patched', patched), ('original', original)):
        (source_dir / (name + '-workflow.yml')).write_bytes(data)
        program = source_dir / (name + '-snapshot.py')
        program.write_bytes(snapshot_program(data))
        programs[name] = program
    (source_dir / 'verify_dream_rasters.py').write_bytes(reader)
    cases = []
    names = ('unchanged', 'refreshed_index_metadata', 'changed_bytes',
             'changed_executable_bit', 'staged_only_change', 'assume_unchanged_flag')
    for name in names:
        case = root / 'cases' / name
        case.mkdir(parents=True)
        workspace = case / 'workspace'
        host, native = workspace / 'host-source', workspace / 'native-source'
        host_head = make_repository(host)
        native_head = make_repository(native, reader)
        proof = case / 'patched-proof'
        proof.mkdir()
        environment = {
            **os.environ, 'GIT_OPTIONAL_LOCKS': '0', 'PYTHONDONTWRITEBYTECODE': '1',
            'GITHUB_WORKSPACE': str(workspace), 'LUMO_QUAL_EVIDENCE': str(proof),
            'GITHUB_SHA': host_head, 'EXPECTED_HOST': host_head,
            'EXPECTED_NATIVE': native_head,
            'EXPECTED_NATIVE_TREE': git(native, 'rev-parse', 'HEAD^{tree}').decode().strip(),
            'GITHUB_EVENT_NAME': 'push', 'GITHUB_REPOSITORY': 'Ullmann27/lumo-lernen',
            'GITHUB_REF': 'refs/heads/integration/lumo-next-table-authorities-20261114',
            'QUALIFICATION_GROUP': 'synthetic-git-index-contract',
            'GITHUB_RUN_ID': 'synthetic-local-fixture', 'GITHUB_RUN_ATTEMPT': '1',
        }
        before = run_phase(programs['patched'], 'before', environment, case, 'patched-before')
        require(before.returncode == 0, name + ': actual before process failed')
        index_before = (native / '.git/index').read_bytes()
        stage_before = git(native, 'ls-files', '--stage', '-z')
        product = native / 'product.txt'
        original_product = product.read_bytes()
        legacy_environment = None
        if name == 'refreshed_index_metadata':
            legacy_proof = case / 'original-proof'
            legacy_proof.mkdir()
            legacy_environment = {**environment, 'LUMO_QUAL_EVIDENCE': str(legacy_proof)}
            old_before = run_phase(programs['original'], 'before', legacy_environment, case, 'original-before')
            require(old_before.returncode == 0, 'Original before process failed')
            info = product.stat()
            os.utime(product, ns=(info.st_atime_ns, info.st_mtime_ns + 2_000_000_000))
            git(native, 'update-index', '--refresh', '--', 'product.txt')
            require((native / '.git/index').read_bytes() != index_before, 'The real binary index must change')
            require(git(native, 'ls-files', '--stage', '-z') == stage_before, 'Refresh must retain staged entries')
            old_after = run_phase(programs['original'], 'after', legacy_environment, case, 'original-after')
            require(old_after.returncode != 0 and b'native: source invariant changed: index_sha256' in old_after.stderr,
                    'The exact original guard did not reproduce its raw-index failure')
        elif name == 'changed_bytes':
            product.write_bytes(b'different fixture content\n')
        elif name == 'changed_executable_bit':
            product.chmod(0o755)
        elif name == 'staged_only_change':
            product.write_bytes(b'staged different fixture content\n')
            git(native, 'add', '--', 'product.txt')
            product.write_bytes(original_product)
        elif name == 'assume_unchanged_flag':
            git(native, 'update-index', '--assume-unchanged', '--', 'product.txt')
        after = run_phase(programs['patched'], 'after', environment, case, 'patched-after')
        expected_success = name in ('unchanged', 'refreshed_index_metadata')
        require((after.returncode == 0) == expected_success, name + ': unexpected actual after result')
        if not expected_success:
            require(b'ValueError:' in after.stderr, name + ': expected a source rejection, not an unrelated failure')
            require(not (proof / 'source-after.json').exists(), name + ': rejected mutation wrote a success summary')
        else:
            summary = json.loads((proof / 'source-after.json').read_bytes())
            require(summary['sources']['native']['binary_index_changed'] == (name == 'refreshed_index_metadata'),
                    name + ': observed binary-index change flag differs')
            native_proof = proof / 'source/native'
            require((native_proof / 'source-index-binary-before.raw').read_bytes() == index_before,
                    name + ': before binary original differs')
            require((native_proof / 'source-index-binary-after.raw').read_bytes() == (native / '.git/index').read_bytes(),
                    name + ': after binary original differs')
            require((native_proof / 'source-index-stage-before.raw').read_bytes() ==
                    (native_proof / 'source-index-stage-after.raw').read_bytes(), name + ': stage originals differ')
        cases.append({'case': name, 'status': 'PASS', 'before_exit': before.returncode,
                      'after_exit': after.returncode, 'expected_success': expected_success,
                      'original_guard_failure_reproduced': legacy_environment is not None,
                      'host_fixture_head': host_head, 'native_fixture_head': native_head})
    require(args.workflow.read_bytes() == patched and args.original_workflow.read_bytes() == original,
            'Workflow inputs changed during the contracts')
    report = {'schema': 1, 'status': 'PASS', 'created_utc': datetime.now(timezone.utc).isoformat(),
              'cases': cases, 'cases_run': len(cases), 'patched_workflow': identity(patched),
              'original_workflow': identity(original), 'unchanged_reader': identity(reader),
              'patched_snapshot_program': identity(programs['patched'].read_bytes()),
              'scope': 'Six actual local Git fixture contracts, not application, engine, Android or CI qualification.',
              'historical_limit': 'The original CI binary index bytes were absent. This controlled refresh demonstrates a valid metadata-only change; it does not identify which binary fields changed in those historical runs.'}
    (root / 'validation.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
