import hashlib, importlib.util, json, os, subprocess, sys, tarfile
from pathlib import Path
sys.dont_write_bytecode = True
phase = sys.argv[1]
if phase not in ('before', 'after'):
    raise ValueError('Source phase must be before or after')
proof = Path(os.environ['LUMO_QUAL_EVIDENCE'])
workspace = Path(os.environ['GITHUB_WORKSPACE'])
host, native = workspace / 'host-source', workspace / 'native-source'
expected = {'host': os.environ['EXPECTED_HOST'], 'native': os.environ['EXPECTED_NATIVE']}
if os.environ['GITHUB_SHA'] != expected['host'] or os.environ['GITHUB_EVENT_NAME'] != 'push':
    raise ValueError('This qualification requires the actual pushed Host commit')
if os.environ['GITHUB_REPOSITORY'] != 'Ullmann27/lumo-lernen' or os.environ['GITHUB_REF'] != 'refs/heads/integration/lumo-next-table-authorities-20261114':
    raise ValueError('Unapproved repository or qualification branch')
def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args],
                                   env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'})
def digest(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}
for name, project in (('host', host), ('native', native)):
    if git(project, 'rev-parse', 'HEAD').decode().strip() != expected[name]:
        raise ValueError(name + ': actual HEAD differs')
    if git(project, 'diff', '--name-only', 'HEAD', '--'):
        raise ValueError(name + ': tracked source differs from HEAD')
    if git(project, 'diff', '--cached', '--name-only', 'HEAD', '--'):
        raise ValueError(name + ': Git index differs from HEAD')
if git(native, 'rev-parse', 'HEAD^{tree}').decode().strip() != os.environ['EXPECTED_NATIVE_TREE']:
    raise ValueError('Native tree differs from the approved immutable source')
helper = native / 'tools/verify_dream_rasters.py'
raw = helper.read_bytes()
identity = digest(raw)
if identity['sha256'] != 'f7296a802d15c382dbcc77640373a0f53e30306fcaab3de869549ff1656de89d' or identity['git_blob'] != 'da8eed7d6383fcbc82a03596518a5fcc3b9a00c5':
    raise ValueError('Unapproved source snapshot/PNG reader bytes')
if git(native, 'show', expected['native'] + ':tools/verify_dream_rasters.py') != raw:
    raise ValueError('Snapshot helper is not the actual committed Native blob')
original = proof / 'tools/verify_dream_rasters.py'
original.parent.mkdir(parents=True, exist_ok=True)
if phase == 'before':
    if original.exists():
        raise ValueError('Source proof must be fresh')
    original.write_bytes(raw)
elif original.read_bytes() != raw:
    raise ValueError('Original snapshot helper changed')
spec = importlib.util.spec_from_file_location('bound_source_reader', original)
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)
states = {}
for name, project in (('host', host), ('native', native)):
    folder = proof / 'source' / name
    folder.mkdir(parents=True, exist_ok=True)
    destination = folder / ('source-inventory-' + phase + '.json')
    if destination.exists():
        raise ValueError('Refusing to replace a source inventory')
    state = reader.snapshot_source(project, folder, phase)
    if not all(row['materialized'] and not row['skip_worktree'] for row in state['tracked']):
        raise ValueError('Qualification requires every tracked source and asset, without sparse exclusions')
    index_stage = git(project, 'ls-files', '--stage', '-z')
    index_flags = git(project, 'ls-files', '-v', '-z')
    index_path = Path(os.fsdecode(git(project, 'rev-parse', '--git-path', 'index')).strip())
    if not index_path.is_absolute():
        index_path = project / index_path
    index_raw = index_path.read_bytes()
    if hashlib.sha256(index_raw).hexdigest() != state['index_sha256']:
        raise ValueError(name + ': binary Git index changed while recording its original')
    for label, data in (('binary', index_raw), ('stage', index_stage), ('flags', index_flags)):
        with (folder / ('source-index-' + label + '-' + phase + '.raw')).open('xb') as stream:
            stream.write(data)
    if phase == 'before':
        commit = git(project, 'cat-file', 'commit', 'HEAD')
        if hashlib.sha1(b'commit ' + str(len(commit)).encode() + b'\0' + commit).hexdigest() != expected[name]:
            raise ValueError('Original Git commit object does not match ' + name)
        (folder / 'source-commit.raw').write_bytes(commit)
        (folder / 'source-tree.raw').write_bytes(git(project, 'ls-tree', '-rz', '--full-tree', 'HEAD'))
        (folder / 'source-index-stage.raw').write_bytes(index_stage)
    else:
        before = json.loads((folder / 'source-inventory-before.json').read_bytes())
        for key in ('head', 'tree', 'tracked'):
            if state[key] != before[key]:
                raise ValueError(name + ': source invariant changed: ' + key)
        if index_stage != (folder / 'source-index-stage-before.raw').read_bytes():
            raise ValueError(name + ': staged paths, modes, blobs or merge stages changed')
        if index_flags != (folder / 'source-index-flags-before.raw').read_bytes():
            raise ValueError(name + ': Git index flags changed')
        generated = [row for row in state['untracked_import_inventory']
                     if row['category'] in ('generated_uid', 'generated_import_metadata')]
        if generated:
            archive = folder / 'generated-import-originals.tar.gz'
            with tarfile.open(archive, 'x:gz') as tar:
                for row in generated:
                    source = project / row['path']
                    if source.is_symlink() or digest(source.read_bytes())['sha256'] != row['sha256']:
                        raise ValueError('Generated import original changed')
                    tar.add(source, arcname=row['path'], recursive=False)
            with tarfile.open(archive, 'r:gz') as tar:
                if len(tar.getmembers()) != len(generated):
                    raise ValueError('Generated import archive member count differs')
                for member, row in zip(tar.getmembers(), generated):
                    if member.name != row['path'] or tar.extractfile(member).read() != (project / row['path']).read_bytes():
                        raise ValueError('Generated import archive bytes differ')
    states[name] = {'head': state['head'], 'tree': state['tree'], 'index_sha256': state['index_sha256'],
                    'index_stage_sha256': hashlib.sha256(index_stage).hexdigest(),
                    'index_flags_sha256': hashlib.sha256(index_flags).hexdigest(),
                    'binary_index_changed': phase == 'after' and state['index_sha256'] != before['index_sha256'],
                    'tracked_count': len(state['tracked']), 'untracked_import_count': len(state['untracked_import_inventory'])}
summary = {'schema': 1, 'phase': phase, 'group': os.environ['QUALIFICATION_GROUP'],
           'run_id': os.environ['GITHUB_RUN_ID'], 'run_attempt': os.environ['GITHUB_RUN_ATTEMPT'],
           'sources': states, 'snapshot_helper': identity,
           'scope': 'Tracked bytes, modes, commit/tree, staged entries and index flags are strict; binary index originals and generated/import outputs are retained separately without cleanup'}
(proof / ('source-' + phase + '.json')).write_text(json.dumps(summary, indent=2) + '\n')
print('SOURCE_' + phase.upper() + '_BOUND host=' + expected['host'] + ' native=' + expected['native'])
