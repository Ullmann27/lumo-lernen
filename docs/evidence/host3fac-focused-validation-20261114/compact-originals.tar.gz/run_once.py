"""External one-shot runner; preserves separate raw streams and actual child exit."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys
import time

PACK = Path(__file__).resolve().parent
ROOT = PACK / "checkout"
SDK = PACK.parent / "toolchains/flutter-3.44.9/flutter"
CACHE = SDK.parent / "pub-cache"


def utc():
    return datetime.now(timezone.utc).isoformat()


def file_identity(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def main():
    label, *argv = sys.argv[1:]
    if not argv or not label.replace("-", "").isalnum():
        raise ValueError("A unique label and explicit argv are required")
    output = PACK / "runs" / label
    output.mkdir(parents=True, exist_ok=False)
    selected = {"GIT_OPTIONAL_LOCKS": "0", "GIT_TERMINAL_PROMPT": "0",
                "TMPDIR": str(PACK / "tmp"), "PUB_CACHE": str(CACHE),
                "FLUTTER_SUPPRESS_ANALYTICS": "true", "DART_SUPPRESS_ANALYTICS": "true",
                "PYTHONDONTWRITEBYTECODE": "1", "REQUIRE_ALL_TESTS": "true",
                "PYTHONPATH": str(ROOT / "scripts/tests") + os.pathsep + str(ROOT),
                "PATH": str(SDK / "bin") + os.pathsep + os.environ.get("PATH", "")}
    for name in ("JAVA_HOME", "LUMO_KOTLIN_LIB_DIR", "LUMO_TEST_JSON_JAR", "JAVA_TOOL_OPTIONS"):
        if name in os.environ:
            selected[name] = os.environ[name]
    env = dict(os.environ, **selected)
    start = {"schema": 1, "started": utc(), "argv": argv, "cwd": str(ROOT),
             "environment": selected, "host": "3fac2cfaf23b80a127e711130fc6d7692776d316",
             "attempt": 1, "original_streams": ["stdout.original.log", "stderr.original.log"]}
    (output / "invocation.json").write_text(json.dumps(start, indent=2) + "\n")
    tick = time.monotonic()
    with (output / "stdout.original.log").open("xb") as stdout, (output / "stderr.original.log").open("xb") as stderr:
        proc = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
        (output / "pid.json").write_text(json.dumps({"pid": proc.pid}) + "\n")
        code = proc.wait()
    result = {"schema": 1, "ended": utc(), "child_exit_code": code,
              "seconds": time.monotonic() - tick,
              "stdout": file_identity(output / "stdout.original.log"),
              "stderr": file_identity(output / "stderr.original.log")}
    (output / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"label": label, **result}, indent=2))
    raise SystemExit(code if code >= 0 else 128 - code)


if __name__ == "__main__":
    main()
