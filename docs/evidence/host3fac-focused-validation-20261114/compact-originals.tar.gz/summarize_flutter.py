"""Summarize original focused Flutter streams using the unchanged repo contract."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

PACK = Path(__file__).resolve().parent
ROOT = PACK / "checkout"
RUN = PACK / "runs" / (sys.argv[1] if len(sys.argv) > 1 else "flutter-new-table-english")


def main():
    result = json.loads((RUN / "result.json").read_text())
    events, other = [], []
    raw = (RUN / "stdout.original.log").read_bytes()
    for number, line in enumerate(raw.decode().splitlines(), 1):
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            other.append({"line": number, "text": line, "kind": "non-JSON original stdout"})
            continue
        if isinstance(event, dict):
            events.append(event)
        else:
            other.append({"line": number, "value": event, "kind": "non-object original JSON"})
    path = ROOT / "scripts/run_full_flutter_acceptance.py"
    spec = importlib.util.spec_from_file_location("unchanged_flutter_summary_contract", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    summary = module.summarize(events, result["child_exit_code"], [])
    starts = {event["test"]["id"]: event["test"] for event in events if event.get("type") == "testStart"}
    suites = {event["suite"]["id"]: event["suite"] for event in events if event.get("type") == "suite"}
    cases = []
    hidden = []
    for event in events:
        if event.get("type") != "testDone":
            continue
        start = starts.get(event["testID"])
        item = {"test_id": event["testID"], "start": start, "finish": event,
                "suite": suites.get(start.get("suiteID")) if start else None}
        (hidden if event.get("hidden") else cases).append(item)
    report = {"schema": 1, "host": "3fac2cfaf23b80a127e711130fc6d7692776d316",
              "scope": json.loads((PACK / "validation-plan.json").read_text())["flutter"],
              "summary": summary, "actual_cases": cases, "hidden_loader_finishes": hidden,
              "suite_events": list(suites.values()), "non_event_stdout_lines": other,
              "error_events": [event for event in events if event.get("type") == "error"],
              "done_events": [event for event in events if event.get("type") == "done"],
              "unchanged_summarizer": {"path": "scripts/run_full_flutter_acceptance.py",
                                      "sha256": hashlib.sha256(path.read_bytes()).hexdigest()},
              "stdout_sha256": hashlib.sha256(raw).hexdigest(),
              "stderr_sha256": hashlib.sha256((RUN / "stderr.original.log").read_bytes()).hexdigest(),
              "result_origin": "Derived from complete original local streams and actual child exit; no CI or Android claim."}
    output = RUN / "derived-results.json"
    with output.open("x") as handle:
        handle.write(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"summary": summary, "actual_case_finishes": len(cases),
                      "suites": len(suites), "hidden_loaders": len(hidden)}, indent=2))


if __name__ == "__main__":
    main()
