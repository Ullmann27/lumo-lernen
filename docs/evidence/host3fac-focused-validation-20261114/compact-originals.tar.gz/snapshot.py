"""Read-only source/index inventory for this exact local validation checkout."""
from pathlib import Path
import hashlib
import json
import os
import stat
import subprocess
import sys

PACK = Path(__file__).resolve().parent
ROOT = PACK / "checkout"
EXPECTED = "3fac2cfaf23b80a127e711130fc6d7692776d316"
TREE = "e76ef3862a0b2c73706d425a2b92a484fda5f9f3"
ENV = dict(os.environ, GIT_OPTIONAL_LOCKS="0", GIT_TERMINAL_PROMPT="0")


def identity(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, env=ENV)


def main():
    label = sys.argv[1]
    if not label.replace("-", "").isalnum():
        raise ValueError("Invalid snapshot label")
    out = PACK / "inventories" / label
    out.mkdir(parents=True, exist_ok=False)
    head, tree = git("rev-parse", "HEAD").decode().strip(), git("rev-parse", "HEAD^{tree}").decode().strip()
    assert (head, tree) == (EXPECTED, TREE), (head, tree)
    index_path = Path(git("rev-parse", "--git-path", "index").decode().strip())
    if not index_path.is_absolute():
        index_path = ROOT / index_path
    index_before = index_path.read_bytes()
    raw = {"head.original": (head + "\n").encode(), "tree.original": (tree + "\n").encode(),
           "ls-files-stage.original": git("ls-files", "--stage", "-z"),
           "ls-tree.original": git("ls-tree", "-r", "-z", "HEAD"),
           "status.original": git("status", "--porcelain=v1", "--untracked-files=all"),
           "index.original": index_before}
    for name, data in raw.items():
        (out / name).write_bytes(data)
    assert not raw["status.original"], raw["status.original"]
    tree_items = {}
    for entry in raw["ls-tree.original"].split(b"\0"):
        if entry:
            metadata, path = entry.split(b"\t", 1)
            mode, kind, blob = metadata.decode().split()
            tree_items[path.decode()] = (mode, kind, blob)
    files, sparse = [], []
    for entry in raw["ls-files-stage.original"].split(b"\0"):
        if not entry:
            continue
        metadata, path = entry.split(b"\t", 1)
        mode, blob, stage = metadata.decode().split()
        rel = path.decode()
        assert stage == "0" and tree_items[rel] == (mode, "blob", blob), rel
        p = ROOT / rel
        if not p.exists() and not p.is_symlink():
            assert rel.startswith("docs/"), rel
            sparse.append({"path": rel, "mode": mode, "git_blob": blob})
            continue
        info = p.lstat()
        if stat.S_ISLNK(info.st_mode):
            assert mode == "120000", rel
            data = os.readlink(p).encode()
        else:
            assert stat.S_ISREG(info.st_mode), rel
            data = p.read_bytes()
            assert (mode == "100755") == bool(info.st_mode & stat.S_IXUSR), rel
        bound = identity(data)
        assert bound["git_blob"] == blob, rel
        files.append({"path": rel, "mode": mode, **bound})
    assert len(files) + len(sparse) == len(tree_items)
    source_map = PACK.parent / "host-pr503-2e20-selective-integration-9f2f-20261114/combined-source-map.json"
    combined = json.loads(source_map.read_text())
    actual = {x["path"]: x for x in files}
    for row in combined["files"]:
        assert all(actual[row["path"]][key] == row["after"][key] for key in ("bytes", "sha256", "git_blob")), row["path"]
    assert len(combined["files"]) == 68
    assert index_path.read_bytes() == index_before, "Read-only inventory changed index"
    assert git("status", "--porcelain=v1", "--untracked-files=all") == raw["status.original"]
    report = {"schema": 1, "host": head, "tree": tree, "checkout": str(ROOT),
              "index_paths": len(tree_items), "materialized_paths": len(files),
              "sparse_docs_paths": len(sparse), "combined_sources": 68,
              "combined_source_map": identity(source_map.read_bytes()),
              "originals": {name: identity(data) for name, data in raw.items()},
              "files": files, "sparse_docs": sparse}
    (out / "source-inventory.json").write_text(json.dumps(report, indent=2) + "\n")
    summary = {k: report[k] for k in ("host", "tree", "index_paths", "materialized_paths", "sparse_docs_paths", "combined_sources")}
    summary["inventory"] = identity((out / "source-inventory.json").read_bytes())
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
