# Host Discovery connection on the published 7136 source

This is an additive **source-only** pack for Host **7136fd69d7343d6be1ff2171c26fa9d496665fda**, tree **e30bf5e130b41e8ca5588163d1e86de57b5ce6e3**. The three immutable GitHub file responses were checked against their Git-blob identities, SHA256 values and the available local d826 copies. Original bytes are retained under `before/`; the original commit response and file-response identities are under `originals/`.

Only these three target files change:

- `.github/workflows/lumo-connect-four-2020.yml`
- `scripts/verify_connect_four_delivery.py`
- `scripts/tests/test_connect_four_delivery.py`

The final files and exact pre/post identities are in `source-freeze.json`. `integration.patch` is the complete three-file patch.

## Required collection in the real Host build

The new mandatory step is **Require actual Discovery gates on the exact pinned native source**. It follows both the existing full Native52/17 gate and the existing Dream5 gate, before the native-artifact upload and APK build. The existing **90-minute Host job budget remains unchanged**.

The step reads the actual Native pin from `config/godot-source.json`, uses the already checked-out pinned Native source and resolves that exact commit's tree. It rejects an incorrect HEAD/tree, dirty tracked source/index or reused Discovery directory. Before importing a new Native helper, it verifies the committed Git blob, actual file Git blob and SHA256 of all five sources:

| Native source | Exact Git blob |
| --- | --- |
| `verify_discovery_connections.py` | `c00ca9873106c974d66282cddfdcfaf5eb3bbebc` |
| `collect_discovery_connections.py` | `1ebdec66300dfb87bf9287d194525d3c374c8aee` |
| Original `verify_discovery_rasters.py` | `219e691fc8aa119cc80221b3db6c77e63caf8bfe` |
| Unchanged `verify_dream_rasters.py` | `da8eed7d6383fcbc82a03596518a5fcc3b9a00c5` |
| Unchanged `run_godot_probe.py` | `c23859ece2d62101d000d7a89556fda5d3fe4105` |

The absolute existing Pillow-venv PATH remains valid after changing into the Native checkout. The new collector receives explicit project, fresh output, actual expected SHA/tree and actual Godot binary arguments. Neither the Native pin nor any individual engine deadline is changed.

Original output is `acceptance-native/discovery/`, with complete collection stdout/stderr at `acceptance-native/discovery-collector.log`. The existing always-uploaded `lumo-candidate-pinned-native-gameplay` artifact includes the ten original logs and wrapper transcripts, 38 PNGs, two reports, source/index inventories, original commit/tree/index files, the original final manifest, and all five bound helper copies. No old Producer screenshot or report is accepted as this future run.

## Independent Delivery replay

The new `checked_native_discovery` verifies the actual pinned Native checkout and original Git index before any dynamic Native import. It binds every helper to both the approved bytes and the actual committed blob. It requires exactly **10 probe records, 38 PNG records and two report records**, the correct `discovery-originals-10-38-2` schema, current Native SHA/tree, and explicit limits on device/FPS/full52 claims.

Every flat original index entry is checked for safe unique paths, regular non-symlink files, exact byte count, SHA256 and Git-blob identity. All categorized PNG/report/probe/helper references and wrapper transcripts must be in that complete index. The collection log must contain the unique exact final marker and no errors, resource leaks, timeouts or failures.

The exact checkout verifier is then called with:

```python
verify(root, expected_native_sha=revision, expected_native_tree=tree, write=False)
```

That immutable Native verifier performs the complete tree/source/order/deadline/log/PNG/report recomputation. Delivery requires its result to equal the original manifest. It rechecks the original manifest, collector log, all indexed input bytes, all source/preserved helper bytes, tracked Git status and original index after replay. The result is stored at **`native.discovery`** in the delivery facts. Collection/replay failure remains a delivery failure.

The existing 52 modes, 17 Studio images, three sidecars, facial movie, Dream5/7/2, Return21, Wisp14, six completed specialist jobs, learning audit, candidate APK/source checks and release/version protections remain required. The release-description draft gains only an accurate additional Discovery clause. Preparation still does not publish a release.

## Counterexamples and preserved tests

All **56 existing Delivery test methods**, including all their 78 previous methods/helpers, are AST-identical. The pack adds **13 focused test methods**, for a future total of **69**. Their synthetic records test only Host transport/source boundaries; they do not simulate a renderer or establish native acceptance.

New cases cover missing/duplicate/skipped/failed mandatory steps, workflow order and unchanged budget, exact real helper constants, foreign/dirty source, modified or missing collector/reader copies, wrong original counts and overclaimed scope, unsafe/duplicate original paths and hash records, missing/symlinked payloads, uncatalogued proof references, errors after PASS, actual decoder failure/difference and even same-value rewrites or index changes during replay.

The production diff preserves 27 existing functions exactly. The only changed existing functions are `checked_native` (one additional mandatory call/result field) and `prepare` (one additional release-description clause); `checked_native_discovery` is added separately.

## Status and open acceptance boundary

Only source authoring, static AST parsing and byte/provenance checks occurred here. **No Host test, Actionlint, engine, renderer, CI action, pin change, budget change or Git mutation was performed.** The exact three-source freeze has been handed to Pipeline for independent read-only review. Actual tests are reserved for Root's subsequent published checkpoint.

The separate Native Discovery renderer CI and Root's subsequent Native-pin decision remain prerequisites for activating this Host connection on a candidate. This pack does not treat the Native source checkpoint or its local counterexamples as a successful 38-image renderer result. It carries no new Android, APK, physical-device, FPS or human visual approval.

The separate Host497 Village QA/route proposal is outside this three-file Discovery pack and has not been applied here.
