from pathlib import Path
import datetime, hashlib, json, os, platform, subprocess, sys, time
import PIL

root = Path('/tmp/host5ad-village-return-observation-repair-20261114')
out = root/'validation'
out.mkdir()
def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def inventory():
    result=[]
    for directory in ('before-source','reference-source','final-source','test-view'):
        for path in sorted((root/directory).rglob('*')):
            if path.is_file():
                raw=path.read_bytes()
                result.append({'path':path.relative_to(root).as_posix(),'bytes':len(raw),
                    'sha256':hashlib.sha256(raw).hexdigest(),
                    'git_blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),
                    'mode':oct(path.stat().st_mode & 0o777)})
    return result
def write(name,value):
    with (out/name).open('x') as f:
        f.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
before=inventory()
write('sources-before.json',before)
write('environment.json',{'python':sys.version,'executable':sys.executable,'platform':platform.platform(),
    'pillow':PIL.__version__,'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
    'scope':'One authorized 12+34 controlled contract run on exact frozen 5ad source overlay; no Git checkout/index, ADB, OCR or engine execution'})
command=[sys.executable,'-B','-m','unittest','test_village_flutter_return_observation','test_village_android_evidence','-v']
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0',
    LUMO_VILLAGE_SOURCE_ROOT=str(root/'final-source'),
    PYTHONPATH=os.pathsep.join(str(root/p) for p in (
       'final-source/tools/android_qa/tests','final-source/.github/probes',
       'test-view/tools/android_qa/tests','test-view/tools/android_qa','test-view/.github/probes')))
start=utc();t=time.monotonic()
with (out/'stdout.original.log').open('xb') as stdout,(out/'stderr.original.log').open('xb') as stderr:
    process=subprocess.run(command,cwd=root/'test-view',env=env,stdout=stdout,stderr=stderr,timeout=180,check=False)
end=utc()
write('process.json',{'command':command,'cwd':str(root/'test-view'),'started_at':start,'ended_at':end,
    'elapsed_seconds':time.monotonic()-t,'exit_code':process.returncode,
    'authorized_once':True,'expected_methods':46,'product_or_device_claim':False})
after=inventory();write('sources-after.json',after)
write('source-comparison.json',{'same':before==after,'file_count':len(before),
    'changed':[b['path'] for b,a in zip(before,after) if b!=a] if len(before)==len(after) else ['inventory length']})
for stream in ('stdout','stderr'):
    raw=(out/(stream+'.original.log')).read_bytes()
    print(json.dumps({'stream':stream,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}))
print(json.dumps({'exit_code':process.returncode,'sources_unchanged':before==after,'elapsed_seconds':time.monotonic()-t}))
