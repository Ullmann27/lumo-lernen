from pathlib import Path
from urllib.parse import urlparse,unquote
import subprocess,os,json,hashlib,stat,time,datetime
ROOT=Path('/workspace/scratch/b3485b7bb989')
REPO=ROOT/'math491-bb97-validation-checkout'
OUT=ROOT/'host-cfa4725-diktat-progress-validation-20261114'
SDK=ROOT/'toolchains/flutter-3.44.9/flutter'
TEMP=Path('/tmp/host-cfa4725-diktat-runtime-20261114');TEMP.mkdir(exist_ok=False)
EXPECTED_SHA='cfa4725263f15e9cc3f75d8f6dfae0949fbb86ab'
EXPECTED_TREE='d0fedc2ceeb02e7eefea61b2667195a43f14bdf6'
TEST_PATH='test/learning_modules/deutsch_sach_module_progress_test.dart'
ENV={**os.environ,'GIT_OPTIONAL_LOCKS':'0','GIT_NO_LAZY_FETCH':'1','PYTHONDONTWRITEBYTECODE':'1'}
def identity(data):return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}
def put_json(name,data):
 with (OUT/name).open('x',encoding='utf-8') as f:json.dump(data,f,ensure_ascii=False,indent=2);f.write('\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO,env=ENV)
def snapshot(label):
 head=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip()
 status=git('status','--porcelain=v1','--untracked-files=all')
 assert head==EXPECTED_SHA and tree==EXPECTED_TREE
 index=Path(git('rev-parse','--git-path','index').decode().strip());index=index if index.is_absolute() else REPO/index
 index_bytes=index.read_bytes();(OUT/f'git-status-{label}.original.txt').write_bytes(status)
 stages=git('ls-files','--stage','-z');(OUT/f'git-index-{label}.original.bin').write_bytes(stages)
 skip={entry[2:].decode() for entry in git('ls-files','-t','-z').split(b'\0') if entry[:1]==b'S'}
 files=[];missing=[];changed=[]
 for entry in stages.split(b'\0'):
  if not entry:continue
  meta,rawpath=entry.split(b'\t',1);mode,blob,stage=meta.decode().split();path=rawpath.decode();p=REPO/path
  assert stage=='0'
  if not p.exists() and not p.is_symlink():missing.append({'path':path,'skip_worktree':path in skip,'blob':blob});continue
  st=p.lstat();data=os.fsencode(os.readlink(p)) if stat.S_ISLNK(st.st_mode) else p.read_bytes()
  record={'path':path,'mode':mode,'indexed_blob':blob,**identity(data)}
  files.append(record)
  if record['git_blob']!=blob:changed.append(path)
 packages={path:identity((REPO/path).read_bytes()) for path in ['pubspec.yaml','pubspec.lock','.dart_tool/package_config.json','.dart_tool/package_graph.json']}
 result={'schema':1,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'tree':tree,'branch':git('branch','--show-current').decode().strip(),'status_bytes':identity(status),'actual_index_bytes':identity(index_bytes),'index_stage_stream':identity(stages),'indexed_count':len(files)+len(missing),'materialized_count':len(files),'materialized_files':files,'missing_sparse_paths':missing,'changed_source_paths':changed,'package_inputs':packages}
 put_json(f'source-{label}.json',result)
 assert not status and not changed and all(x['skip_worktree'] for x in missing)
 return result
config_path=REPO/'.dart_tool/package_config.json';config=json.loads(config_path.read_bytes())
missing=[];cache_roots=set()
for package in config['packages']:
 uri=package['rootUri'];p=Path(unquote(urlparse(uri).path)) if uri.startswith('file:') else (config_path.parent/uri).resolve()
 if not p.is_dir():missing.append({'name':package['name'],'path':str(p)})
 if '/hosted/' in str(p):cache_roots.add(str(p).split('/hosted/',1)[0])
assert not missing and len(cache_roots)==1
ENV.update({'PATH':str(SDK/'bin')+os.pathsep+os.environ['PATH'],'PUB_CACHE':next(iter(cache_roots)),'TMPDIR':str(TEMP),'CI':'true','FLUTTER_SUPPRESS_ANALYTICS':'true','DART_SUPPRESS_ANALYTICS':'true'})
assert identity((REPO/TEST_PATH).read_bytes())['sha256']=='e0eced5d27a8e2606816a4cc83d39edc2047f906b035f2d3e9e50c8c8fd45849'
before=snapshot('before')
argv=[str(SDK/'bin/flutter'),'test','--no-pub','--reporter=json',TEST_PATH]
started=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic()
put_json('execution-binding.json',{'schema':1,'head':EXPECTED_SHA,'tree':EXPECTED_TREE,'cwd':str(REPO),'argv':argv,'started_at':started,'environment':{key:ENV[key] for key in ['PUB_CACHE','TMPDIR','CI','FLUTTER_SUPPRESS_ANALYTICS','DART_SUPPRESS_ANALYTICS','GIT_OPTIONAL_LOCKS','GIT_NO_LAZY_FETCH','PYTHONDONTWRITEBYTECODE']},'sdk_metadata':json.loads((SDK/'bin/cache/flutter.version.json').read_bytes()),'resolved_package_count':len(config['packages']),'expected_test_count':17,'retry':False,'pub_resolution_requested':False})
print(json.dumps({'phase':'test_started','head':EXPECTED_SHA,'argv':argv,'package_count':len(config['packages']),'materialized_sources':before['materialized_count']}),flush=True)
with (OUT/'flutter-machine.stdout.jsonl').open('xb') as stdout,(OUT/'flutter.stderr.log').open('xb') as stderr:
 child=subprocess.Popen(argv,cwd=REPO,env=ENV,stdout=stdout,stderr=stderr)
 code=child.wait()
finish={'schema':1,'argv':argv,'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'duration_seconds':time.monotonic()-clock,'child_exit_code':code,'child_exit_known':True,'retry':False}
put_json('process-result.json',finish)
after=snapshot('after')
unchanged=all(before[key]==after[key] for key in ['head','tree','branch','status_bytes','actual_index_bytes','index_stage_stream','materialized_files','missing_sparse_paths','changed_source_paths','package_inputs'])
raw=(OUT/'flutter-machine.stdout.jsonl').read_bytes();events=[];other=[]
for line_no,line in enumerate(raw.splitlines(),1):
 try:event=json.loads(line)
 except (ValueError,UnicodeDecodeError):other.append({'line':line_no,'raw_utf8':line.decode(errors='replace')});continue
 if isinstance(event,dict):events.append((line_no,event))
 else:other.append({'line':line_no,'json_value':event})
tests={event['test']['id']:{'start_line':line,**event['test']} for line,event in events if event.get('type')=='testStart'}
results=[{'line':line,'test':tests.get(event.get('testID')),**event} for line,event in events if event.get('type')=='testDone' and not event.get('hidden',False)]
expected=json.loads((ROOT/'host-79c7-diktat-progress-fixture-repair-20261114/test-inventory.json').read_bytes())['visible_original_tests']
counts={'pass':sum(r.get('result')=='success' and not r.get('skipped',False) for r in results),'errors_or_failures':sum(r.get('result')!='success' for r in results),'skips':sum(r.get('skipped',False) for r in results),'total':len(results)}
done=[{'line':line,**event} for line,event in events if event.get('type')=='done']
error_events=[{'line':line,**event} for line,event in events if event.get('type')=='error']
valid=(code==0 and unchanged and len(results)==17 and counts=={'pass':17,'errors_or_failures':0,'skips':0,'total':17} and [r['test']['name'] for r in results]==expected and len(done)==1 and done[0].get('success') is True and not error_events)
summary={'schema':1,'status':'PASS' if valid else 'FAIL','head':EXPECTED_SHA,'tree':EXPECTED_TREE,'source_unchanged':unchanged,'process':finish,'counts':counts,'all_original_case_names_preserved':sorted(r['test']['name'] for r in results if r['test'])==sorted(expected),'test_results':results,'done':done,'error_events':error_events,'non_machine_lines':other,'stdout':identity(raw),'stderr':identity((OUT/'flutter.stderr.log').read_bytes()),'limits':['One local existing17-case Flutter test file, not the full suite.','No new Android/APK/native or overall candidate acceptance.','Original failed37ec CI evidence remains unchanged.']}
put_json('test-result.json',summary)
print(json.dumps({'phase':'test_finished','status':summary['status'],'counts':counts,'child_exit_code':code,'source_unchanged':unchanged,'duration_seconds':finish['duration_seconds']}),flush=True)
raise SystemExit(0 if valid else 1)
