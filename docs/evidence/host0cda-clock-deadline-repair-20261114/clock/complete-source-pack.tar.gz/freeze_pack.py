from pathlib import Path
import datetime,difflib,gzip,hashlib,io,json,re,tarfile
P=Path('/tmp/host0cda-c4-reward-clock-fixture-repair-20261114')
REL='test/games/connect_four_bot_save_retry_test.dart'
HOST='0cda410b9e5dceba3ffaf04f9c0fc45880dac6a9'
TREE='a97942c991cbb38d22c8b97f06a3e5bb162ab942'
EVIDENCE=Path('/tmp/host0cda-c4-flutter-compile-evidence-20261114')
ROOT_ORIGINALS=Path('/tmp/root-8e64-clock-followup-originals-20261114')
def ident(b):
 return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def write(rel,b):
 p=P/rel;p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():assert p.read_bytes()==b,str(p)
 else:
  with p.open('xb') as f:f.write(b)
 assert p.read_bytes()==b
 return ident(b)
def js(rel,obj):return write(rel,(json.dumps(obj,indent=2,ensure_ascii=False)+'\n').encode())
old=Path('/tmp/host-pr507-0d7e-integration-7ac-20261114/final-source')/REL
before=old.read_bytes();after=(P/'original-source'/REL).read_bytes()
assert ident(before)['git_blob']=='c4b90bc73b76a2df23acdb253fa4213b798fed21'
assert ident(after)['git_blob']=='830b3f661c2a289f5ae76ed545cfed60fe27b36a'
leaves=json.loads((EVIDENCE/'activation-originals/tree-leaves.json').read_bytes());tree={r['path']:r for r in leaves}
assert tree[REL]['sha']==ident(before)['git_blob'] and tree[REL]['mode']=='100644'
write('before/'+REL,before);write('final-source/'+REL,after)
references=[]
for rel,p in [('lib/features/games/connect_four/lumo_connect_four_game.dart',Path('/tmp/host-pr508-c4-optin-followup-v2-20261114/final-source/lib/features/games/connect_four/lumo_connect_four_game.dart')),('lib/features/games/shared/lumo_game_pause_scope.dart',Path('/workspace/scratch/b3485b7bb989/host-3fac2cfa-focused-validation-20261114/checkout/lib/features/games/shared/lumo_game_pause_scope.dart'))]:
 b=p.read_bytes();assert ident(b)['git_blob']==tree[rel]['sha'];write('reference-source/'+rel,b);references.append({'path':rel,'actual_0cda_tree_entry':tree[rel],**ident(b)})
sdk=Path('/workspace/scratch/b3485b7bb989/toolchains/flutter-3.44.9/flutter/packages/flutter_test/lib/src/binding.dart').read_bytes()
assert ident(sdk)['git_blob']=='44b74b7d6be7726228605cce77c04231c6070bd6'
write('reference-source/flutter-3.44.9/packages/flutter_test/lib/src/binding.dart',sdk)
write('originals/current-flutter-version.txt',(EVIDENCE/'host-compile/artifact-originals/flutter-version.txt').read_bytes())
write('originals/current-activation-binding.json',(EVIDENCE/'activation-binding.json').read_bytes())
original_manifest=json.loads((ROOT_ORIGINALS/'manifest.json').read_bytes())
for r in original_manifest:
 p=Path(r['local_path']);b=p.read_bytes();i=ident(b)
 assert i['bytes']==r['bytes'] and i['sha256']==r['sha256'] and i['git_blob']==r['blob']
 write('originals/producer-8e64/'+p.name,b)
write('originals/producer-8e64/manifest.json',(ROOT_ORIGINALS/'manifest.json').read_bytes())
original_patch=(ROOT_ORIGINALS/'2-implementation-against-exact-8e64.patch').read_text()
patch=original_patch.split('--- a/.github/workflows/')[0]
write('integration.patch',patch.encode())
lines=before.decode().splitlines(keepends=True);out=[];cursor=0;hunks=0
plines=patch.splitlines(keepends=True);i=0
while i<len(plines):
 line=plines[i]
 if not line.startswith('@@ '):i+=1;continue
 m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',line);assert m
 start=int(m.group(1))-1;assert start>=cursor;out.extend(lines[cursor:start]);cursor=start;i+=1;old_count=new_count=0;hunks+=1
 while i<len(plines) and not plines[i].startswith('@@ '):
  line=plines[i];assert line[0] in ' +-'
  if line[0] in ' -':assert lines[cursor]==line[1:];cursor+=1;old_count+=1
  if line[0] in ' +':out.append(line[1:]);new_count+=1
  i+=1
 assert old_count==int(m.group(2) or 1) and new_count==int(m.group(4) or 1)
out.extend(lines[cursor:]);assert ''.join(out).encode()==after and hunks==1
oldtext=before.decode();newtext=after.decode();marker="  testWidgets('Lifecycle pause during reward retry defers the settled result',"
assert oldtext.count(marker)==newtext.count(marker)==1
oldprefix,oldcase=oldtext.split(marker);newprefix,newcase=newtext.split(marker);assert oldprefix==newprefix
names=lambda s:re.findall(r"^  testWidgets\('([^']+)'",s,re.M)
assert names(oldtext)==names(newtext) and len(names(oldtext))==6
def calls(s):
 result=[]
 for m in re.finditer(r'\bexpect\s*\(',s):
  start=m.start();i=m.end();depth=1;quote=None
  while depth:
   c=s[i]
   if quote:
    if c=='\\':i+=2;continue
    if c==quote:quote=None
   elif c in "'\"":quote=c
   elif c=='(':depth+=1
   elif c==')':depth-=1
   i+=1
  result.append(''.join(line.strip() for line in s[start:i].splitlines()))
 return result
oc=calls(oldcase);nc=calls(newcase);assert len(oc)==11 and len(nc)==14
at=0;preserved=[]
for c in oc:
 while at<len(nc) and nc[at]!=c:at+=1
 assert at<len(nc),c
 preserved.append(at);at+=1
additions=[c for i,c in enumerate(nc) if i not in preserved]
assert additions==['expect(held.release.isCompleted, isFalse)','expect(fixture.app.state.stars, 0)','expect(find.byType(AlertDialog), findsNothing)']
assert oldtext.splitlines()[260].strip()=='expect(held.entered.isCompleted, isTrue);'
inspection=EVIDENCE/'full-flutter/inspection';machine=(inspection/'originals/flutter-machine.jsonl').read_bytes();events=[]
for lineno,line in enumerate(machine.decode().splitlines(),1):
 try:r=json.loads(line)
 except json.JSONDecodeError:continue
 if isinstance(r,dict) and ((r.get('test') or {}).get('id')==56 or r.get('testID')==56 or (r.get('suite') or {}).get('id')==27):events.append({'line':lineno,'event':r})
assert len(events)==5 and any('connect_four_bot_save_retry_test.dart:261:5' in e['event'].get('message','') for e in events)
current={'host':HOST,'tree':TREE,'run_id':43637785992,'attempt':1,'job_id':132579589188,'artifact_id':14131068776,'original_machine':ident(machine),'events':events,'summary':json.loads((inspection/'originals/acceptance-summary.json').read_bytes()),'scope':'Actual current 0cda failure, distinct from producer8e64; selected original events only here. Complete machine/ZIP remain in the separate current CI evidence pack.'}
js('originals/current-0cda-failure-events.json',current)
freeze={'schema':1,'status':'SOURCE_FROZEN_NOT_RUN','base_host':HOST,'base_tree':TREE,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_count':1,'sources':[{'path':REL,'mode':'100644','before':ident(before),'after':ident(after),'provenance':'Exact Root-supplied producer-prepared immutable GitHub blob 830b3f661c2a289f5ae76ed545cfed60fe27b36a; fetched once and fully UTF-8/Gitblob checked. No new producer commit identity is assumed.'}],'excluded_producer_hunks':['.github/workflows/lumo-nextgen-feature-contracts.yml'],'tests_executed':False,'product_changes':False,'git_or_ci_mutation':False}
js('source-freeze.json',freeze)
review={'schema':1,'status':'NO_CONCRETE_STATIC_BLOCKER_TEST_SCHEDULING_REPAIR','base_host':HOST,'base_tree':TREE,'source':freeze['sources'][0],'current_failure':{'run_id':43637785992,'job_id':132579589188,'test_id':56,'suite_id':27,'start_line':113,'framework_line':123,'error_line':124,'done_line':125,'assertion':'held.entered.isCompleted: expected true, actual false at261:5','before_inactive_and_ack_release':True},'historical_producer_failure':{'host':'8e64f27c86e1704fa65dfe9ef9c8b2217f9f0a11','run_id':43634307306,'job_id':132567623144,'scope':'Root-provided selected original events and published reports; no independent full producer ZIP or machine download in this review.'},'mechanism':['Current C4 6c9ee29c catches failed terminal reward, pauses, then schedules Duration.zero retry; the live generation, owner and native-opening guards are unchanged.','LumoGameTurnClock 9ffc5f25 stores the paused action; explicit Fortsetzen resumes and arms Timer(_remaining).','Exact Flutter3.44.9 binding44b74b7d calls FakeAsync.elapse only when pump duration is non-null. Bare pump flushes microtasks and frames but does not advance the queued zero-delay timer.','The one-millisecond pump reaches the held real platform write before the unchanged entered assertion and before inactive. No fixed success value or mock result replaces this assertion.'],'preservation':{'one_original_test_hunk_applies_without_fuzz':True,'first_five_tests_and_all_helpers_prefix_byte_equal':True,'prefix':ident(oldprefix.encode()),'six_names_unchanged':names(oldtext),'old_sixth_assertions':oc,'new_sixth_assertions':nc,'old_11_preserved_in_order':True,'additional_three_pre_ack_assertions':additions,'unchanged_product_references':references},'cleanup':'Finally conditionally releases the held ACK once, restores resumed, drains idle callbacks, calls unchanged _close to unmount/dispose/reset, and drains again. The finally has no return/catch or result substitution that could convert a failed assertion to success.','sdk':{'official_url':'https://github.com/flutter/flutter/blob/3.44.9/packages/flutter_test/lib/src/binding.dart','source':ident(sdk),'pump_body_lines':[2248,2263],'version_evidence':'originals/current-flutter-version.txt'},'classification':'Test navigation/scheduling precondition repair. Current failing test never reached inactive/result-deferral assertions. This static review does not prove a new runtime pass or rule out other defects beyond the observed failure.','unchanged_scope':['All production, workflow, pin, writer, ink, journal and wallet source bytes remain outside the one-file proposed delta.','All six test names, eleven original assertions in the sixth case, the first five complete cases and all helpers remain.','Frozen 82-case catalog and current 0cda evidence remain unchanged; a later activated source binding must identify the new testblob.'],'execution':{'tests':False,'dart_or_flutter':False,'packages':False,'ci_start':False,'git_write':False}}
js('review.json',review)
js('handoff.json',{'schema':1,'status':'READY_FOR_ROOT_SOURCE_CHECKPOINT_NOT_RUN','base_host':HOST,'source_freeze':ident((P/'source-freeze.json').read_bytes()),'review':ident((P/'review.json').read_bytes()),'patch':ident((P/'integration.patch').read_bytes()),'sources':freeze['sources'],'current_actual_result':'0cda full Flutter2732PASS/1FAIL/0SKIP;82roster81/1. The failed source remains unchanged until Root checkpoints this separate test repair.','next_validation':'One subsequent actual CI must execute the corrected case and unchanged suite; no local rerun or active source change was performed.'})
files=sorted(p for p in P.rglob('*') if p.is_file() and p.name not in ('manifest.json','complete-source-pack.tar.gz','archive-binding.json'))
js('manifest.json',{'schema':1,'entries':[{'path':p.relative_to(P).as_posix(),**ident(p.read_bytes())} for p in files]});files.append(P/'manifest.json')
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tar:
 for p in sorted(files):
  b=p.read_bytes();t=tarfile.TarInfo(p.relative_to(P).as_posix());t.mode=0o644;t.mtime=0;t.size=len(b);tar.addfile(t,io.BytesIO(b))
archive=gzip.compress(buf.getvalue(),mtime=0);write('complete-source-pack.tar.gz',archive)
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
 assert len(tar.getmembers())==len(files)
 for m in tar.getmembers():assert tar.extractfile(m).read()==(P/m.name).read_bytes()
js('archive-binding.json',{'path':'complete-source-pack.tar.gz',**ident(archive),'members':len(files),'roundtrip':True})
print(json.dumps({n:ident((P/n).read_bytes()) for n in ('source-freeze.json','review.json','handoff.json','manifest.json','complete-source-pack.tar.gz')},indent=2))
