# Dorfanschluss auf Host a118 und Native afc0df9

Dieser Pack friert ausschließlich einen Quellenvorschlag ein. Für diese neue Kombination wurden weder Fluttertests noch Python-, Engine-, Android- oder Audioprüfungen ausgeführt.

## Feste Quellen

Host-Basis: a118409930ecdf605743382051e88f7e0898b8e9, Tree 68573f0c40ce641a6443a5648fd664bc44ca6c95.
Veröffentlichter Producer: Host-PR497, 07cac7225e2f7b6451665dfda9c38841f51c758b, Tree 17b4d10565001b61fe1fa5012004cce4ec7642d9.
Erforderliche native Paarung: afc0df9a2b1794f39051add9dfce0cf947bb177b, Tree 3e621dc8230e155e1089deb1a40c22f177e546b3.

source-freeze.json enthält alle 16 Vorher-/Producer-/Endidentitäten mit Bytezahl, SHA256 und Git-Blob. Die vollständige ursprüngliche Host-Tree-Antwort und ihre 675 neu berechneten Teilbaumidentitäten binden sämtliche 4.976 Einträge. source-readback.json dokumentiert die Byteprüfung; kein Gitobjekt oder Checkout wurde geändert.

## Enthaltener Produktumfang

Acht Produktpfade verbinden das sichtbare Portal Dorfwirtschaft mit settlement, livingVillage=true und settlementMode=settlement. Sie erhalten die aktuellen Owner-/Lease-/Session-/Rückkehrgrenzen und die bestehenden Spiele. Die sieben passenden Producer-Testdateien sind exakt veröffentlicht übernommen. 14 der 16 Enddateien sind bytegleich zum Producer.

MainActivity.kt enthält ausschließlich die Dorfhunks. Die zwei fremden Änderungen an Distribution und Installerkanal sind ausgeschlossen; alle übrigen Bereiche vor dem Szenenblock und ab der bestehenden Cards-Prüfung bleiben bytegleich zu a118. Der Producerstand des C4-Flowtests ist ebenfalls ausgeschlossen: unsere jüngeren Async-, Owner-, Fallback-, Scroll- und Bot-Gegenfälle bleiben erhalten.

Die 52 in source-freeze.json gebundenen Schutzpfade umfassen bestehende C4-Dateien, Writer/Journal, die jüngste Kamera-/Diktat-/Stiftarbeit, gemeinsame Helfer und Assets. Sie sind kein Teil der vorgeschlagenen Änderungen. Es gibt keinen Versions-, Pin-, Workflow- oder Receiptwechsel.

## Sechs verpflichtende Capturefälle

scripts/run_full_flutter_acceptance.py erhält genau einen CAPTURE_DIRECTORIES-Eintrag:
LUMO_VILLAGE_CAPTURES -> village.

Die beiden vorhandenen Runnerfunktionen summarize und main sind AST-identisch. Entfernen ausschließlich der hinzugefügten Zeile stellt die ursprünglichen Bytes wieder her. Fehler-, Timeout- und Skipprüfung bleiben unverändert.

Der spätere vollständige Lauf muss alle sechs Fälle aus test/design/dorfwirtschaft_spielewelt_capture_test.dart tatsächlich ausführen:

| Fall | Viewport | Textfaktor | Ausgabedatei |
|---|---|---|---|
| fold-cover | 344 × 882 | 1 | village-fold-cover.png |
| phone | 412 × 915 | 1 | village-phone.png |
| fold-open | 690 × 829 | 1 | village-fold-open.png |
| fold-landscape | 1200 × 900 | 1 | village-fold-landscape.png |
| fold-wide-min | 640 × 829 | 1 | village-fold-wide-min.png |
| fold-open-large-text | 690 × 829 | 1,2 | village-fold-open-large-text.png |

Die Testquelle prüft die Produktionsoberfläche, vollständige Wortgeometrie, mindestens 48 × 48 große bedienbare Ziele und genau einen beobachteten Bridge-Aufruf mit den drei Dorfparametern. Die native Antwort im Widgettest ist ausdrücklich simuliert. Es liegen in diesem Pack noch keine neuen Aufnahmebilder vor.

## Sprach- und Beleggrenze

Der bytegleich erhaltene LumoLearningSpeech-Helfer erlaubt weiterhin nur learning/build und verlangt die vorhandenen Consent-/Lizenzbedingungen. Die neue Dorfroute reicht vorhandene Optionen weiter, erweitert diese Erlaubnis aber nicht. In der exakt gebundenen Settlement-Datei gibt es keinen direkten Sprachaufruf. Daraus folgt keine hörbare Dorf- oder PCM-Freigabe.

references/native-afc0df9 enthält die bereits vorhandenen Originale der separaten nativen Prüfung. Der dortige Village-Headlesslauf ist an afc0df9 gebunden. Er ist keine Ausführung dieses neuen Flutter-/Android-Kombinats.

## Getrennter Android-Vorschlag

Der Nachbarpack host-pr497-village-qa-proposal-a118-20261114 enthält ausschließlich drei neue Probe-/Verifier-/Testpfade. Seine V2 ergänzt eine nachgelagerte lokale Fristprüfung im neuen Probehelfer. Candidate-, Delivery- und Workflowanschlüsse liegen dort lediglich als veröffentlichte Referenzhunks. Root führt diese mit dem separat bearbeiteten Discovery-Gate zusammen.

## Nächste Abnahme

Erst den festen kombinierten Quellencheckpoint herstellen und den passenden Native-Pin durch Root verbinden. Danach die sieben betroffenen Flutterdateien sowie bestehende Launcher-/Embedding-Verträge prüfen; der spätere vollständige Flutterlauf muss die sechs Aufnahmen ohne Skip erzeugen. Die getrennten 34 Android-QA-Verträge sind synthetische Prüfungen. Ein tatsächlicher neuer APK-/API35-Dorfrundweg bleibt danach eigenständig erforderlich.

Kein Test- oder Geräteergebnis aus einer älteren Quelle wird auf diese Kombination übertragen.
