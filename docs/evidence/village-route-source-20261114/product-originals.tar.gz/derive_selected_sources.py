from pathlib import Path
import ast
import difflib
import hashlib
import json

ROOT = Path('/workspace/scratch/b3485b7bb989/host-pr497-village-route-integration-a118-20261114')
PRODUCTS = (
    'lib/features/games/games_content.dart',
    'lib/features/games/spielwelt/spielwelt_game_icon.dart',
    'lib/features/games/spielwelt/spielwelt_hub.dart',
    'lib/features/games/spielwelt/spielwelt_routes.dart',
    'lib/features/lumo3d/lumo3d_launcher.dart',
    'lib/features/lumo3d/lumo_game_entry_overlay.dart',
    'tools/auto_install/MainActivity.kt',
    'tools/auto_install/LumoGameActivity.kt',
)
TESTS = (
    'test/games/dorfwirtschaft_portal_test.dart',
    'test/games/games_world_layout_test.dart',
    'test/games/spielwelt_hub_capture_test.dart',
    'test/games/spielwelt_routing_test.dart',
    'test/games/spielwelt_semantics_action_test.dart',
    'test/lumo_game_entry_overlay_test.dart',
    'test/design/dorfwirtschaft_spielewelt_capture_test.dart',
)
RUNNER = 'scripts/run_full_flutter_acceptance.py'

def identity(data):
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
            'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}

def put(relative, data):
    target=ROOT/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as stream:stream.write(data)

def remove_once(data, old, new):
    assert data.count(old)==1, old[:80]
    return data.replace(old,new,1)

preservation={'schema':1,'source_execution':False,'tests_executed':0,'notes':[]}
for path in PRODUCTS+TESTS:
    original=(ROOT/'originals/producer497'/path).read_bytes()
    selected=original
    if path=='tools/auto_install/MainActivity.kt':
        distribution=b'''    private val distributionChannel: String by lazy {
        try {
            @Suppress("DEPRECATION")
            val info = packageManager.getApplicationInfo(packageName, PackageManager.GET_META_DATA)
            info.metaData?.getString("dev.ullmann.lumo.DISTRIBUTION") ?: "unavailable"
        } catch (_: Exception) { "unavailable" }
    }
'''
        installer=b'''            if (call.method == "distribution") {
                result.success(distributionChannel)
                return@setMethodCallHandler
            }
            // The manifest is authoritative even if a caller bypasses the Dart UI.
            if (distributionChannel != "family") {
                result.success(false)
                return@setMethodCallHandler
            }
'''
        selected=remove_once(remove_once(selected,distribution,b''),installer,b'')
        base=(ROOT/'originals/a118'/path).read_bytes()
        start=b'                        val requested = call.argument<String>("scene")'
        end=b'                        if (game == "cards") {'
        assert base.count(start)==selected.count(start)==1
        assert base.count(end)==selected.count(end)==1
        b0,b1=base.index(start),base.index(end)
        s0,s1=selected.index(start),selected.index(end)
        assert base[:b0]==selected[:s0]
        assert base[b1:]==selected[s1:]
        assert b'distributionChannel' not in selected
        assert base.split(b'        ).setMethodCallHandler { call, result ->',1)[0] == selected.split(b'        ).setMethodCallHandler { call, result ->',1)[0]
        preservation['main_activity']={
            'excluded_exact_producer_hunks':[identity(distribution),identity(installer)],
            'outside_requested_scene_through_voice_options_byte_equal':True,
            'before':identity(base),'producer':identity(original),'after':identity(selected),
            'preserved_suffix_starts_at':'if (game == "cards") {',
            'preserved_guards':['existing installer channel','Cards token','C4 authority token',
                                'reduceAnimations','caller-session handling','Activity result','engine process check'],
        }
    put('final-source/'+path,selected)

runner=(ROOT/'originals/a118'/RUNNER).read_bytes()
needle=b"    'LUMO_NATIVE_PROFILE_CAPTURE_DIR': 'native-profiles',\n"
assert runner.count(needle)==1
after=runner.replace(needle,needle+b"    'LUMO_VILLAGE_CAPTURES': 'village',\n",1)
put('final-source/'+RUNNER,after)
before_tree=ast.parse(runner)
after_tree=ast.parse(after)
functions=lambda tree:{n.name:ast.dump(n,include_attributes=False) for n in tree.body
                      if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
assert functions(before_tree)==functions(after_tree)
removed=after.replace(b"    'LUMO_VILLAGE_CAPTURES': 'village',\n",b'',1)
assert removed==runner
preservation['capture_runner']={
    'before':identity(runner),'after':identity(after),
    'only_added_line':"'LUMO_VILLAGE_CAPTURES': 'village',",
    'all_existing_functions_ast_equal':True,'function_names':list(functions(before_tree)),
    'restoring_exact_added_line_yields_original_bytes':True,
    'six_new_capture_cases_require_actual_execution_no_skip_allowance':True,
}
preservation['games_screen_flow_test']={
    'path':'test/games/games_screen_flow_test.dart',
    'identity':identity((ROOT/'originals/a118/test/games/games_screen_flow_test.dart').read_bytes()),
    'excluded_producer_file':True,'reason':'Current owner/async fallback/scroll/old-bot assertions are newer; no village hunk exists in this producer delta.'
}
preservation['speech_scope']={
    'path':'tools/auto_install/LumoLearningSpeech.kt',
    'identity':identity((ROOT/'dependencies/a118/tools/auto_install/LumoLearningSpeech.kt').read_bytes()),
    'unchanged':True,
    'allowed_games':['learning','build'],
    'new_route_forwards_existing_consent_voice_options_but_does_not_add_speech_allowance':True,
    'native_settlement_world_has_no_direct_speech_call_in_bound_source':True,
    'audible_village_acceptance':False,
}
patch=[]
for path in PRODUCTS+TESTS+(RUNNER,):
    p=ROOT/'originals/a118'/path
    before=p.read_text().splitlines(True) if p.exists() else []
    after=(ROOT/'final-source'/path).read_text().splitlines(True)
    patch.extend(difflib.unified_diff(before,after,fromfile='a/'+path if p.exists() else '/dev/null',tofile='b/'+path))
put('integration.patch',''.join(patch).encode())
put('preservation.json',(json.dumps(preservation,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'paths':list(PRODUCTS+TESTS+(RUNNER,)),
                  'source_count':len(PRODUCTS)+len(TESTS)+1,
                  'main_activity':preservation['main_activity']['after'],
                  'runner':preservation['capture_runner']['after'],
                  'patch':identity((ROOT/'integration.patch').read_bytes()),
                  'no_product_tests':True},ensure_ascii=False))
