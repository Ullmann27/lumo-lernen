from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

os.environ.update(PYTHONDONTWRITEBYTECODE='1', GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0', GIT_TERMINAL_PROMPT='0')
sys.dont_write_bytecode = True
repo = Path('/tmp/lumo-root-recovery-1105/host-discovery')
output = Path('/tmp/host-4f5d66f-discovery-targeted-validation-20261114')
output.mkdir(exist_ok=False)
(output / 'runner.py').write_bytes(Path(__file__).read_bytes())
source_helper = Path('/tmp/lumo-root-recovery-1105/native-discovery/tools/verify_dream_rasters.py')
assert hashlib.sha256(source_helper.read_bytes()).hexdigest() == 'f7296a802d15c382dbcc77640373a0f53e30306fcaab3de869549ff1656de89d'
spec = importlib.util.spec_from_file_location('original_source_inventory', source_helper)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
before = helper.snapshot_source(repo, output, 'before')
assert before['head'] == '4f5d66f96c5ad84939e4cd09bc66fb4744ae2a6b'
assert before['tree'] == '0e89490ea5d877c8249c8d461270b8e364d2c986'
results = []
commands = [
    ('delivery-and-pipeline', [sys.executable, '-m', 'unittest',
                              'scripts.tests.test_connect_four_delivery',
                              'scripts.tests.test_connect_four_pipeline', '-v'], 240),
    ('actionlint', ['/workspace/scratch/e0abce7d2838/toolchain/actionlint/actionlint',
                   '.github/workflows/lumo-connect-four-2020.yml'], 60),
]
for name, command, timeout in commands:
    started = datetime.now(timezone.utc).isoformat()
    tick = time.monotonic()
    argv = ['timeout', '--signal=TERM', '--kill-after=5s', f'{timeout}s', *command]
    completed = subprocess.run(argv, cwd=repo, capture_output=True)
    (output / (name + '.stdout.log')).write_bytes(completed.stdout)
    (output / (name + '.stderr.log')).write_bytes(completed.stderr)
    success = completed.returncode == 0
    if name == 'delivery-and-pipeline':
        text = (completed.stdout + b'\n' + completed.stderr).decode('utf-8')
        success = success and re.search(r'Ran 80 tests in [0-9.]+s\s+OK\s*$', text) is not None
        success = success and not re.search(r'\b(?:skipped|FAILED|ERROR)\b', text)
    record = {'name': name, 'argv': argv, 'started_at_utc': started,
              'finished_at_utc': datetime.now(timezone.utc).isoformat(),
              'elapsed_seconds': time.monotonic() - tick, 'returncode': completed.returncode,
              'pass': bool(success)}
    results.append(record)
    (output / (name + '.result.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
after = helper.snapshot_source(repo, output, 'after')
unchanged = all(before[key] == after[key] for key in ('head', 'tree', 'index_sha256', 'tracked', 'untracked_import_inventory'))
summary = {'schema': 1, 'head': before['head'], 'tree': before['tree'],
           'status': 'PASS' if unchanged and all(result['pass'] for result in results) else 'FAIL',
           'results': results, 'delivery_cases': 69, 'pipeline_cases': 11,
           'total_cases': 80, 'skips': 0,
           'tracked_source_entries': len(before['tracked']),
           'materialized_source_entries': sum(entry['materialized'] for entry in before['tracked']),
           'explicit_sparse_entries': sum(entry['skip_worktree'] for entry in before['tracked']),
           'source_index_and_untracked_inventory_unchanged': unchanged,
           'actual_engine_runs': 0, 'actual_widget_runs': 0, 'actual_device_runs': 0,
           'native_pin_changed': False,
           'scope': '69 delivery boundary cases and11 existing pipeline contracts on exact4f5d66f, plus one Actionlint; no combined product or device acceptance.'}
(output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary), flush=True)
raise SystemExit(0 if summary['status'] == 'PASS' else 1)
