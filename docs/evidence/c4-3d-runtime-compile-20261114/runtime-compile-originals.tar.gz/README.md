# Host 3d91bd83: current Runtime and Android Host Compile originals

Run 43589206933, attempt 1, Host 3d91bd8355a539c3c2413760959684cd3fee985a, Native bd0712259bb64908a5649ee1999638826c9eb597.

Both reviewed jobs are successful. The actual desktop two-process report records 170 checks, 250 frames and 259 decoded PNGs, plus independent Return21 and Wisp14 logs. The compile job records 10 registry tests, 107 Gradle tasks and 9 host plus 3 C4 class identities. These are new originals for this run. No previous run has been reused.

The before/after source inventory is byte-identical: 447 Host and 1,256 Native selected tracked files. Every recorded path/blob/mode/size has been independently matched against complete immutable Git tree API originals. The source-bound runner itself checks working bytes against HEAD before and after execution.

Complete original job logs, raw API snapshots, all 31 JSON/text artifact members, complete ZIP/PNG indexes, source inventories, and the exact relevant runner/workflow/pin/installer are included. Files of at least 16 KiB use deterministic gzip with verified original-byte roundtrips. original-byte-mapping.json identifies every preserved source file and both hashes. Original ZIPs, PNG payloads and runtime caches remain at the recorded external original-archive paths; no PNG is recompressed.

This checkpoint is limited to the two completed jobs. Desktop capture rate is not measured Android FPS. The test SharedPreferences/local-file bridge is not Android IPC or physical-device preservation. There is no visual review or overall C4/APK/release approval.
