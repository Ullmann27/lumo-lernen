#!/usr/bin/env python3
"""Collect only explicitly assigned original Runtime/Compile artifacts."""
from __future__ import annotations
import base64
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import shutil
import stat
import sys
import urllib.request
import zipfile
import zlib

from PIL import Image

ROOT = Path('/tmp/host-pr485-3d91bd83-pipeline-evidence-20261114')
HOST = '3d91bd8355a539c3c2413760959684cd3fee985a'
RUN = 43589206933
ALLOWED = {14112126601, 14111162845}


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save_json(path, value):
    raw = (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()
    with path.open('xb') as f:
        f.write(raw)
    return identity(raw)


def collect(request):
    ident = int(request['artifact_id'])
    if ident not in ALLOWED:
        raise RuntimeError('Artifact outside assigned scope')
    metadata = request['metadata']
    if metadata['id'] != ident or metadata['expired'] or metadata['workflow_run']['id'] != RUN or metadata['workflow_run']['head_sha'] != HOST:
        raise RuntimeError('Original artifact metadata binding mismatch')
    size = int(metadata['size_in_bytes'])
    expected = metadata['digest'].removeprefix('sha256:')
    if not 0 < size <= 32 * 1024 * 1024:
        raise RuntimeError('Archive outside assigned size budget')
    if shutil.disk_usage('/tmp').free < size * 2 + 64 * 1024 * 1024:
        raise RuntimeError('Insufficient temporary disk reserve')
    out = ROOT / 'artifacts' / str(ident)
    out.mkdir(parents=True, exist_ok=False)
    temporary = out / 'download.part'
    sha = hashlib.sha256()
    total = 0
    try:
        with urllib.request.urlopen(request['download_url'], timeout=90) as response, temporary.open('xb') as destination:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > size:
                    raise RuntimeError('Archive exceeds exact API size')
                sha.update(chunk)
                destination.write(chunk)
    except Exception as exc:
        save_json(out / 'download-error.json', {'error_type': type(exc).__name__, 'http_status': getattr(exc, 'code', None), 'bytes_received': total, 'signed_url_omitted': True})
        raise RuntimeError('Original download failed; private endpoint omitted') from None
    if total != size or sha.hexdigest() != expected:
        save_json(out / 'download-integrity-failure.json', {'expected_size': size, 'actual_size': total, 'expected_sha256': expected, 'actual_sha256': sha.hexdigest()})
        raise RuntimeError('Archive digest/size mismatch')
    archive = out / 'original.zip'
    temporary.rename(archive)
    members = []
    images = []
    selected = []
    materialized = 0
    with zipfile.ZipFile(archive) as z:
        names = set()
        expanded = 0
        for info in z.infolist():
            name = info.filename
            path = PurePosixPath(name)
            if name in names or path.is_absolute() or '..' in path.parts or '\\' in name or (str(path) != name.rstrip('/')):
                raise RuntimeError('Unsafe or duplicate original archive path')
            names.add(name)
            mode = (info.external_attr >> 16) & 0xffff
            if stat.S_ISLNK(mode) or (stat.S_IFMT(mode) not in (0, stat.S_IFREG, stat.S_IFDIR)):
                raise RuntimeError('Nonregular original archive member')
            if info.flag_bits & 1:
                raise RuntimeError('Encrypted member cannot be verified')
            if info.is_dir():
                members.append({'path': name, 'directory': True, 'bytes': 0})
                continue
            expanded += info.file_size
            if info.file_size > 64 * 1024 * 1024 or expanded > 512 * 1024 * 1024:
                raise RuntimeError('Archive member budget exceeded')
            raw = z.read(info)
            crc = zlib.crc32(raw) & 0xffffffff
            if len(raw) != info.file_size or crc != info.CRC:
                raise RuntimeError('Original member CRC/size mismatch')
            row = {'path': name, **identity(raw), 'crc32': f'{crc:08x}', 'compressed_bytes': info.compress_size, 'zip_mode': mode}
            members.append(row)
            if path.suffix.lower() == '.png':
                with Image.open(io.BytesIO(raw)) as image:
                    if image.format != 'PNG':
                        raise RuntimeError('PNG member has a foreign format')
                    image.load()
                    images.append({**row, 'width': image.width, 'height': image.height, 'mode': image.mode, 'decoded': True})
            elif path.suffix.lower() in {'.json', '.jsonl', '.log', '.txt', '.tsv', '.csv', '.sha256', '.md', '.dart', '.gd', '.py', '.sh'}:
                if materialized + len(raw) > 32 * 1024 * 1024:
                    raise RuntimeError('Small original materialization budget exceeded')
                destination = out / 'originals' / Path(*path.parts)
                destination.parent.mkdir(parents=True, exist_ok=True)
                with destination.open('xb') as f:
                    f.write(raw)
                if destination.read_bytes() != raw:
                    raise RuntimeError('Materialized original bytes differ')
                materialized += len(raw)
                selected.append(row)
    save_json(out / 'member-index.json', members)
    save_json(out / 'png-index.json', images)
    save_json(out / 'selected-originals.json', selected)
    report = {'schema': 1, 'artifact_id': ident, 'name': metadata['name'], 'host_source': HOST, 'run_id': RUN,
              'archive': str(archive), 'archive_bytes': total, 'archive_sha256': sha.hexdigest(),
              'all_member_crc_sha_verified': True, 'members': len(members), 'decoded_original_pngs': len(images),
              'expanded_bytes': expanded, 'selected_originals': len(selected), 'selected_original_bytes': materialized,
              'pngs_materialized': 0, 'visual_review': False, 'engine_device_or_tests_executed': False}
    save_json(out / 'verification.json', report)
    return report


if __name__ == '__main__':
    try:
        requests = json.loads(base64.b64decode(sys.argv[1], validate=True))
        for request in requests:
            print(json.dumps(collect(request)), flush=True)
    except Exception as exc:
        print(json.dumps({'status': 'FAIL', 'type': type(exc).__name__, 'message': str(exc) if isinstance(exc, RuntimeError) else 'Unexpected collector failure; original details retained locally without private URLs'}), flush=True)
        raise SystemExit(1)
