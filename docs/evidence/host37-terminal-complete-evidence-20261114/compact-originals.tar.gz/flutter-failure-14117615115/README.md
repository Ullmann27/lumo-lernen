# Original 37ec Flutter failure before supersession

This pack binds the complete final job log, run/job/artifact API originals, complete original ZIP and complete machine stream to host 37ec6c6a, run 43601673844 attempt 1, build job 132468566278. The final API conclusion is cancelled after activation of a successor, while the full Flutter stream already ended with a genuine failure at 14:05:25.5581454Z.

All three errors are StateError: Bad state: No element in the existing _revealWrittenWord helper at line 195. Machine event offsets are preserved; no absolute timestamp is invented for individual machine events. 2,605 visible tests succeeded, three failed, none were skipped; the original stream contains its final success:false done event.

All 554 archive members were read to EOF and CRC/SHA verified. Only the two machine/summary members were materialized. The 552 image originals remain in the full original ZIP without extraction or image alteration.

The complete original ZIP remains alongside this manifest and in its original GitHub Actions artifact. compact-originals.tar.gz deliberately includes all other evidence and the complete manifest, but excludes the 336 MB ZIP to avoid duplicating that immutable large file. This exclusion is explicit and does not represent a complete archive-byte roundtrip claim. The selected compact members are separately byte-verified.

No test rerun, device execution, source modification, retry, cancellation, or Git operation was performed. The local read parser first encountered an auxiliary list-form protocol event; its corrected read retained all original lines and separately inventoried non-test-event lines. No CI result was changed.
