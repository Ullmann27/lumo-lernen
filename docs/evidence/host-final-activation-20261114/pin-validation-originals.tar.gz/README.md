# Final source-bound pin validation

The single authorized test invocation executed the actual published Host 68f86b7dafa2dcd1e42ee019c4be46b9e9bdc697 / tree ecd5df0797c2b4102f2c7bbc30146f3061d713ce, pinned to Native baf148b03a7a32c6ad9f737d731f900eb9113ea1.

Exactly 24 Candidate and 40 Legacy unittest methods passed, exit 0, with no errors, failures or skips. Complete original stdout/stderr, real child timing and exit, the executed external runner, published source originals and before/after snapshots are retained. All 4,440 tracked index entries match the published commit tree; all seven materialized files match their Git blobs and modes. The other 4,433 tracked entries are explicitly absent under sparse checkout. Source, HEAD/tree, full index bytes and status are identical before and after.

The first checkout materialization found that the local shared object cache contained the commit/tree but lacked the three new pin blobs. No test had executed. The three exact published remote sources were independently SHA256/Git-blob checked and materialized only in the new private checkout and its own object store. The initial preparation failure and its inspection remain in checkout-preparation.json; it is not presented as a test result.

No 88-method suite, Actionlint, engine, renderer, device, CI or release action was run. No existing checkout, index or ref was changed. The result is a source identity contract, not a new Android or release acceptance. Root performs the later documented PR485 activation separately.

The checkout directory is intentionally excluded from the compact archive; all seven actual input source files and the complete before/after index/tree/status bindings are included independently.
