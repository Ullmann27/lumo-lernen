import ast,datetime,hashlib,json,os,pathlib,platform,re,stat,subprocess,sys,time
PACK=pathlib.Path(__file__).resolve().parent
ROOT=PACK/"checkout"
HEAD="68f86b7dafa2dcd1e42ee019c4be46b9e9bdc697"
TREE="ecd5df0797c2b4102f2c7bbc30146f3061d713ce"
ENV=dict(os.environ,PYTHONDONTWRITEBYTECODE="1",GIT_OPTIONAL_LOCKS="0")
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
def git(*args):
 p=subprocess.run(["git","-C",str(ROOT),*args],env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if p.returncode:raise RuntimeError("git read failed: "+repr(args)+" "+p.stderr.decode())
 return p.stdout
def snapshot(label):
 head=git("rev-parse","HEAD").decode().strip(); tree=git("rev-parse","HEAD^{tree}").decode().strip()
 assert (head,tree)==(HEAD,TREE)
 status=git("status","--porcelain=v1","-z","--untracked-files=all")
 assert status==b"",repr(status)
 index=git("ls-files","--stage","-z"); flags=git("ls-files","-v","-z"); rawtree=git("ls-tree","-r","-z","HEAD")
 flagmap={x[2:].decode():x[:1].decode() for x in flags.split(b"\0") if x}
 treemap={}
 for row in rawtree.split(b"\0"):
  if not row:continue
  meta,path=row.split(b"\t",1); mode,kind,oid=meta.decode().split()
  assert kind=="blob"
  treemap[path.decode()]=(mode,oid)
 indexed={}; present=[]; absent=[]
 for row in index.split(b"\0"):
  if not row:continue
  meta,path=row.split(b"\t",1); mode,oid,stage=meta.decode().split(); name=path.decode()
  assert stage=="0"
  indexed[name]=(mode,oid)
  p=ROOT/name
  if p.is_symlink():
   raw=os.readlink(p).encode(); actual_mode="120000"
  elif p.is_file():
   raw=p.read_bytes(); actual_mode="100755" if p.stat().st_mode&0o111 else "100644"
  elif not p.exists():
   assert flagmap[name]=="S",(name,flagmap.get(name))
   absent.append(name); continue
  else:raise AssertionError("Unexpected tracked file type: "+name)
  assert blob(raw)==oid,(name,blob(raw),oid)
  assert actual_mode==mode,(name,actual_mode,mode)
  present.append({"path":name,"mode":mode,"bytes":len(raw),"sha256":sha(raw),"git_blob":oid,"index_flag":flagmap[name]})
 assert indexed==treemap
 ip=pathlib.Path(git("rev-parse","--git-path","index").decode().strip())
 if not ip.is_absolute():ip=ROOT/ip
 ib=ip.read_bytes()
 raw={"index-stage.nul":index,"index-flags.nul":flags,"tree.nul":rawtree,"status.nul":status,"index.bin":ib,"commit.txt":git("cat-file","commit","HEAD")}
 for name,b in raw.items():(PACK/(label+"."+name)).write_bytes(b)
 out={"head":head,"tree":tree,"parent":git("rev-parse","HEAD^").decode().strip(),"index_sha256":sha(ib),"raw_bindings":{name:{"bytes":len(b),"sha256":sha(b)} for name,b in raw.items()},"indexed_count":len(indexed),"materialized_count":len(present),"sparse_absent_count":len(absent),"indexed":[{"path":name,"mode":mode,"git_blob":oid,"flag":flagmap[name]} for name,(mode,oid) in indexed.items()],"materialized":present,"sparse_absent":absent,"status_empty":True}
 (PACK/(label+"-source.json")).write_text(json.dumps(out,indent=2)+"\n")
 return out
before=snapshot("before")
counts={}
for file in ("test_candidate_2011_pin.py","test_legacy_release_pin.py"):
 tree=ast.parse((ROOT/"scripts/tests"/file).read_bytes())
 counts[file]=len([n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name.startswith("test_")])
assert counts=={"test_candidate_2011_pin.py":24,"test_legacy_release_pin.py":40}
cfg=json.loads((ROOT/"config/godot-source.json").read_text())
assert cfg=={"repository":"https://github.com/Ullmann27/lumo-godot.git","revision":"baf148b03a7a32c6ad9f737d731f900eb9113ea1","engine":"4.6.3"}
argv=[sys.executable,"-m","unittest","scripts.tests.test_candidate_2011_pin","scripts.tests.test_legacy_release_pin","-v"]
env_record={"python_executable":sys.executable,"python_version":sys.version,"platform":platform.platform(),"boot_id":pathlib.Path("/proc/sys/kernel/random/boot_id").read_text().strip(),"controlled_environment":{k:ENV[k] for k in ("PYTHONDONTWRITEBYTECODE","GIT_OPTIONAL_LOCKS")},"unittest_argv":argv,"cwd":str(ROOT),"expected_methods":counts}
(PACK/"environment.json").write_text(json.dumps(env_record,indent=2)+"\n")
start=utc(); t=time.monotonic()
with (PACK/"unittest.stdout.log").open("xb") as out,(PACK/"unittest.stderr.log").open("xb") as err:
 p=subprocess.run(argv,cwd=ROOT,env=ENV,stdout=out,stderr=err)
elapsed=time.monotonic()-t; end=utc()
process={"argv":argv,"cwd":str(ROOT),"started_at":start,"ended_at":end,"elapsed_seconds":elapsed,"exit_code":p.returncode,"test_invocations":1,"stdout":{"path":"unittest.stdout.log","bytes":(PACK/"unittest.stdout.log").stat().st_size,"sha256":sha((PACK/"unittest.stdout.log").read_bytes())},"stderr":{"path":"unittest.stderr.log","bytes":(PACK/"unittest.stderr.log").stat().st_size,"sha256":sha((PACK/"unittest.stderr.log").read_bytes())}}
(PACK/"process-result.json").write_text(json.dumps(process,indent=2)+"\n")
after=snapshot("after")
assert before==after,"Source/index/status changed during test"
log=(PACK/"unittest.stderr.log").read_text()
match=re.search(r"^Ran (\d+) tests in ([0-9.]+)s$",log,re.M)
ids=re.findall(r"^test_\S+ \([^\n]+\) \.\.\. ok$",log,re.M)
ok=p.returncode==0 and match is not None and int(match[1])==64 and len(ids)==64 and re.search(r"^OK$",log,re.M) is not None
result={"schema":1,"status":"PASS" if ok else "FAIL","host_commit":HEAD,"host_tree":TREE,"native_commit":cfg["revision"],"methods":int(match[1]) if match else None,"method_counts":counts,"passed_method_lines":len(ids),"errors":len(re.findall(r"^ERROR:",log,re.M)),"failures":len(re.findall(r"^FAIL:",log,re.M)),"skipped_method_lines":len(re.findall(r"\.\.\. skipped ",log)),"source_index_status_unchanged":before==after,"indexed_paths":before["indexed_count"],"materialized_paths":before["materialized_count"],"sparse_absent_paths":before["sparse_absent_count"],"index_sha256":before["index_sha256"],"process":process,"scope":"One local 64-method pin/source contract invocation only; no workflow/engine/renderer/Android or release acceptance."}
(PACK/"result.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result))
sys.exit(0 if ok else 1)
