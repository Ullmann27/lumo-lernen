// ════════════════════════════════════════════════════════════════════════
// LEARNING MODULE REGISTRY — Mapping Topic-ID -> echtes Lern-Modul
// ════════════════════════════════════════════════════════════════════════
// Heinz Feedback: 'Alle Optionen in Lernen sind nur Chats - keine aktiven
// Lern-Module ausser Buchstaben schreiben.'
//
// Loesung: Registry mit Topic-IDs die echte interaktive Module haben.
// Beim Tap auf ein Topic in der Akademie:
//   1) Pruefe ob Topic-ID hier registriert ist
//   2) Wenn ja -> oeffne echtes Modul
//   3) Wenn nein -> oeffne ChatGPT-Chat (Fallback)
//
// 20 registrierte Themen; beide Einmaleinsvarianten teilen einen Screen.
// Bei aktivem Wortmodus öffnet die Akademie d1_woerter bereits vor dieser
// Registry im Wort-Schreibcoach. Die übrigen Themen öffnen diese Module.
// ════════════════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';

import '../../app/app_state.dart';
import 'artikel_lernen/artikel_lernen_screen.dart';
import 'bruchrechnen/bruchrechnen_screen.dart';
import 'einmaleins/einmaleins_screen.dart';
import 'farben/farben_screen.dart';
import 'formen/formen_screen.dart';
import 'geld/geld_screen.dart';
import 'jahreszeiten/jahreszeiten_screen.dart';
import 'mehrzahl/mehrzahl_screen.dart';
import 'minus_bis_10/minus_bis_10_screen.dart';
import 'plus_bis_10/plus_bis_10_screen.dart';
import 'tiere/tiere_screen.dart';
import 'uhr_lernen/uhr_lernen_screen.dart';
import 'verkehr/verkehr_screen.dart';
import 'wetter/wetter_screen.dart';
import 'wort_diktat/wort_diktat_screen.dart';
import 'wortarten/wortarten_screen.dart';
import 'zahlen_bis_10/zahlen_bis_10_screen.dart';
import 'zahlen_bis_100/zahlen_bis_100_screen.dart';
import 'zeitformen/zeitformen_screen.dart';

class LearningModuleRegistry {
  LearningModuleRegistry._();

  /// Liefert einen Builder fuer ein echtes Lern-Modul wenn Topic-ID
  /// registriert ist. Sonst null (-> Fallback auf ChatGPT-Chat).
  static Widget? builderFor(String topicId, LumoAppState appState) {
    switch (topicId) {
      case 'm1_plus10':
        return PlusBis10Screen(appState: appState);
      case 'm1_minus10':
        return MinusBis10Screen(appState: appState);
      case 'm1_zahlen10':
        return ZahlenBis10Screen(appState: appState);
      case 'm1_formen':
        return FormenScreen(appState: appState);
      case 's1_tiere':
        return TiereScreen(appState: appState);
      case 's1_farben':
        return FarbenScreen(appState: appState);
      case 'm2_uhr':
        return UhrLernenScreen(appState: appState);
      case 'm2_geld':
        return GeldScreen(appState: appState);
      case 'm2_zahlen100':
        return ZahlenBis100Screen(appState: appState);
      case 'd2_artikel':
        return ArtikelLernenScreen(appState: appState);
      case 'd2_mehrzahl':
        return MehrzahlScreen(appState: appState);
      case 's2_jahreszeiten':
        return JahreszeitenScreen(appState: appState);
      case 's2_wetter':
        return WetterScreen(appState: appState);
      case 's2_verkehr':
        return VerkehrScreen(appState: appState);
      case 'd3_wortarten':
        return WortartenScreen(appState: appState);
      case 'd3_zeitformen':
        return ZeitformenScreen(appState: appState);
      case 'd1_woerter':
        return WortDiktatScreen(appState: appState);
      case 'm2_einmaleins':
        return EinmaleinsScreen(appState: appState, fullRange: false);
      case 'm3_einmaleins_voll':
        return EinmaleinsScreen(appState: appState, fullRange: true);
      case 'm4_bruch':
        return BruchrechnenScreen(appState: appState);
      default:
        return null;
    }
  }

  static const Set<String> registeredTopicIds = {
    'm1_plus10',
    'm1_minus10',
    'm1_zahlen10',
    'm1_formen',
    's1_tiere',
    's1_farben',
    'm2_uhr',
    'm2_geld',
    'm2_zahlen100',
    'm2_einmaleins',
    'm3_einmaleins_voll',
    'm4_bruch',
    'd1_woerter',
    'd2_artikel',
    'd2_mehrzahl',
    's2_jahreszeiten',
    's2_wetter',
    's2_verkehr',
    'd3_wortarten',
    'd3_zeitformen',
  };

  static bool hasModule(String topicId) =>
      registeredTopicIds.contains(topicId);
}
