from pathlib import Path
import ast, hashlib, json, difflib
B=Path('/workspace/scratch/b3485b7bb989'); S=Path(__file__).parent
P=B/'host-pr503-table-probe-adapter-9f2f-20261114';P.mkdir(exist_ok=True)
original=B/'producer-pr503-pr182-followup-50503f-47ca64-20261114/original-source/host-505/.github/probes/lumo_connect_four_android_probe.py'
raw=original.read_bytes();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()=='ffa5c6d9a0c8e4403847fd07e8436234f7af979e'
text=raw.decode();tree=ast.parse(text);functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
names=('require','flutter_hub_navigation_target','sha','verified_pck','write','parse_json','number','integer','vector','rectangle','same_numbers','inside','project','to_decor','button_target')
def write(rel,data):
 q=P/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data if isinstance(data,bytes) else data.encode());assert q.read_bytes()==(data if isinstance(data,bytes) else data.encode())
write('originals/producer-505-c4-shared.py',raw)
header='''#!/usr/bin/env python3
"""Shared observation contracts for the Memory and Quiz Android probes.

This module does not run the C4 probe or install, root, seed, or repair an app.
The game-specific subclasses retain their actual frames, controls, authority
ACKs, read-only saves, physical inputs, return observations and fixed budgets.
The fifteen pure geometry/JSON/APK/navigation functions are extracted exactly
from the published50503 C4 source; its C4 session logic is deliberately absent.
"""
from __future__ import annotations

import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import zipfile

PACKAGE = 'dev.ullmann.lumo.lumo_lernen.coachpreview'
FILES = '/data/user/0/' + PACKAGE + '/files'
SELF = '.github/probes/lumo_table_authority_android_shared.py'
PCK_PATH = 'assets/lumo_game.pck'
MODULE_PATHS = {
    'modernization_android_tour': '.github/probes/modernization_android_tour.py',
    'creative_android_probe': '.github/probes/creative_android_probe.py',
    'lumo_studio_surfaces_android_probe': '.github/probes/lumo_studio_surfaces_android_probe.py',
    'studio_creative_android_probe': '.github/probes/studio_creative_android_probe.py',
    'pr207_android_smoke': 'scripts/probes/pr207_android_smoke.py',
    'pr207_android_ui_probe': 'scripts/probes/pr207_android_ui_probe.py',
}
SOURCE_FILES = (SELF, *MODULE_PATHS.values(),
    '.github/probes/flutter_surface_readiness.py',
    'tools/android_qa/native_surface_readiness.py',
    'tools/android_qa/native_ocr_tiles.py',
    'tools/android_qa/kart_tour_evidence.py',
    'tools/android_qa/kart_garage_evidence.py',
    'tools/android_qa/kart_android_race.py')


'''
body='\n\n\n'.join(ast.get_source_segment(text,functions[n]) for n in names)+'\n\n\n'
new='''def before_deadline(deadline, limit=30):
    require(type(deadline) in (int, float) and math.isfinite(deadline),
            'A finite existing probe deadline is required')
    remaining = deadline - time.monotonic()
    require(remaining > 0, 'Authority probe deadline exhausted')
    return min(limit, remaining)


def checked_source_binding(root, expected, paths, deadline, *, executing_file=None):
    """Read exact committed bytes; never trust only a matching HEAD string."""
    root = Path(root).resolve()
    require(type(expected) is str and re.fullmatch('[a-f0-9]{40}', expected),
            'Full expected Host SHA required for shared authority helpers')
    if executing_file is not None:
        require(Path(executing_file).resolve() == root / SELF,
                'Shared authority helper was imported from another checkout')

    def git(*arguments):
        result = subprocess.run(['git', '-C', str(root), *arguments],
                                capture_output=True, timeout=before_deadline(deadline))
        before_deadline(deadline)
        require(result.returncode == 0 and not result.stderr,
                'Source binding Git read failed: ' + arguments[0])
        return result.stdout

    require(git('rev-parse', 'HEAD').decode().strip() == expected,
            'Shared authority Host HEAD differs')
    commit_tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
    require(re.fullmatch('[a-f0-9]{40}', commit_tree), 'Actual Host tree is missing')
    require(not git('status', '--porcelain', '--untracked-files=no').strip(),
            'Tracked shared authority checkout is dirty')
    hashes = {}
    require(len(set(paths)) == len(paths), 'Duplicate shared source path')
    for relative in paths:
        require(type(relative) is str and relative and not Path(relative).is_absolute()
                and '..' not in Path(relative).parts, 'Unsafe shared source path')
        file = root / relative
        require(file.is_file() and not file.is_symlink() and file.resolve().is_relative_to(root),
                'Shared source is absent or outside the candidate')
        original = git('show', 'HEAD:' + relative)
        actual = file.read_bytes()
        require(actual == original, 'Working shared source differs: ' + relative)
        hashes[relative] = hashlib.sha256(actual).hexdigest()
    before_deadline(deadline)
    return {'host': expected, 'tree': commit_tree, 'source_sha256': hashes}


def bound_module(module, root, relative):
    require(getattr(module, '__file__', None) is not None and
            Path(module.__file__).resolve() == Path(root).resolve() / relative,
            'Runtime module came from another checkout: ' + relative)
    return module


class AndroidProbe:
    """Only the inherited API used by the two game-specific probes."""
    def __init__(self, args):
        before_deadline(self.deadline)
        self.args, self.out = args, args.out
        self.count, self.events = 0, []
        require(Path.cwd().resolve() == args.candidate_source.resolve(),
                'Shared authority probe requires its candidate source CWD')
        require(not self.out.exists() or not any(self.out.iterdir()),
                'Refusing to overwrite previous authority evidence')
        self.out.mkdir(parents=True, exist_ok=True)
        self.initial_shared_binding = self.bind_shared_sources()
        write(self.out / 'shared-source-binding-initial.json', self.initial_shared_binding)
        os.environ['ANDROID_SERIAL'] = args.serial
        for relative in ('.github/probes', 'scripts/probes', 'tools/android_qa'):
            sys.path.insert(0, str(args.candidate_source / relative))
        loaded = {name: bound_module(importlib.import_module(name), args.candidate_source, relative)
                  for name, relative in MODULE_PATHS.items()}
        self.tour = loaded['modernization_android_tour']
        self.probe = bound_module(self.tour.probe, args.candidate_source,
                                  MODULE_PATHS['creative_android_probe'])
        self.base = bound_module(self.tour.base, args.candidate_source,
                                 MODULE_PATHS['pr207_android_smoke'])
        self.live = bound_module(self.tour.live, args.candidate_source,
                                 MODULE_PATHS['pr207_android_ui_probe'])
        self.surfaces = loaded['lumo_studio_surfaces_android_probe']
        self.creative = loaded['studio_creative_android_probe']
        require(self.bind_shared_sources() == self.initial_shared_binding,
                'Shared source changed while importing observed helpers')
        self.old_adb = self.base.adb
        self.base.adb = self.adb

    def bind_shared_sources(self):
        return checked_source_binding(self.args.candidate_source, self.args.expected_source,
                                      SOURCE_FILES, self.deadline, executing_file=__file__)

    def tag(self, name):
        self.count += 1
        return f'{self.count:04d}-{name}'

    def pid(self):
        value = self.adb('shell', 'pidof', PACKAGE + ':lumo_game', check=False).strip()
        require(re.fullmatch(r'[1-9]\\d*', value) is not None,
                'Actual isolated table process absent or ambiguous')
        return int(value)

    def wait(self, name, observe, accept, timeout=45):
        deadline = time.monotonic() + min(timeout, before_deadline(self.deadline, timeout))
        errors = []
        while time.monotonic() < deadline:
            try:
                value = observe()
                if accept(value):
                    before_deadline(min(deadline, self.deadline))
                    return value
            except (RuntimeError, json.JSONDecodeError, KeyError, TypeError) as error:
                errors.append(str(error))
            time.sleep(min(.4, max(0, deadline - time.monotonic())))
        write(self.out / (self.tag(name) + '-failure.json'),
              {'last_errors': errors[-12:], 'budget_seconds': timeout})
        raise RuntimeError(name + ' not observed before deadline')
'''
write('final-source/.github/probes/lumo_table_authority_android_shared.py',header+body+new)
for name in ('lumo_memory_android_probe.py','lumo_quiz_android_probe.py'):
 rel='.github/probes/'+name;original=(S/'producer-final'/rel).read_text();s=original
 if name.startswith('lumo_memory'):
  s=s.replace("Path(__file__).with_name('lumo_connect_four_android_probe.py')","Path(__file__).with_name('lumo_table_authority_android_shared.py')")
  s=s.replace("'memory_android_shared_geometry'","'memory_table_authority_shared'")
  s=s.replace("SELF, '.github/probes/lumo_connect_four_android_probe.py',","SELF, '.github/probes/lumo_table_authority_android_shared.py',")
  s=s.replace('        super().__init__(args)\n        self.deadline = time.monotonic() + 600','        self.deadline = time.monotonic() + 600\n        super().__init__(args)')
  s=s.replace("'actual_installed_apk_sha256': actual, 'source_hashes': hashes}","'actual_installed_apk_sha256': actual, 'source_hashes': hashes,\n                'shared_source_binding': self.bind_shared_sources()}")
 else:
  s=s.replace('import lumo_connect_four_android_probe as shared','import lumo_table_authority_android_shared as shared')
  s=s.replace("'actual_installed_apk_sha256': installed_sha, 'source_hashes': hashes}","'actual_installed_apk_sha256': installed_sha, 'source_hashes': hashes,\n                'shared_source_binding': self.bind_shared_sources()}")
 oldguard="    if (args.out / 'result.json').exists():" if name.startswith('lumo_memory') else "    if (args.out/'result.json').exists():"
 if name.startswith('lumo_memory'):
  assert oldguard in s;s=s.replace(oldguard,"    if args.out.exists() and any(args.out.iterdir()):")
 write('before/'+rel,original);write('final-source/'+rel,s)
rel='tools/android_qa/tests/test_quiz_android_probe.py';original=(S/'producer-final'/rel).read_text();s=original
s=s.replace("SHARED_PATH = Path(os.environ.get('LUMO_QUIZ_SHARED_SOURCE',\n    str(ROOT/'.github/probes/lumo_connect_four_android_probe.py'))).resolve()","SHARED_PATH = (ROOT/'.github/probes/lumo_table_authority_android_shared.py').resolve()")
s=s.replace("'lumo_connect_four_android_probe'","'lumo_table_authority_android_shared'");write('before/'+rel,original);write('final-source/'+rel,s)
for p in (P/'final-source').rglob('*.py'):ast.parse(p.read_text())
print('Adapter written, static syntax parsed only; no module imported or test executed.',P)
