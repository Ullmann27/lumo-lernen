from pathlib import Path
import json,hashlib,subprocess,re,difflib
B=Path('/workspace/scratch/b3485b7bb989'); P=Path(__file__).parent
O=B/'producer-pr503-pr182-selective-review-20261114'; F=B/'producer-pr503-pr182-followup-50503f-47ca64-20261114'; R=B/'producer-nextgen2e-290-root-originals-20261114'; repo='/tmp/lumo-root-recovery-1242/host'; target='9f2f3690caacadbe7ced363f0e810f0cc0b5eb9b'
def ident(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def save(path,b):
 q=P/path;q.parent.mkdir(parents=True,exist_ok=True)
 if q.exists():assert q.read_bytes()==b, str(q)
 else:q.write_bytes(b)
 assert q.read_bytes()==b;return ident(b)
def j(path,obj):return save(path,(json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode())
old=json.loads((O/'selective-integration-manifest.json').read_text());follow=json.loads((F/'selective-followup-review.json').read_text());compare=json.loads((R/'host505-to-2e.compare.original.json').read_text()); source={}; provenance={}
for x in old['host_files']:
 if x['disposition']=='excluded':continue
 data=(O/x['source']).read_bytes();assert ident(data)['git_blob']==x['producer_blob'];source[x['path']]=data;provenance[x['path']]={'first_source':str(O/x['source']),'last_changed_at':'8b09c48ba8e4b41e8b25521b022d4d64ba4bb2bc','producer_base_blob':x['producer_base_blob']}
 base=O/'original-source/host-base'/x['path']
 if base.is_file():
  data0=base.read_bytes();assert ident(data0)['git_blob']==x['producer_base_blob'];save('producer-base/'+x['path'],data0)
for x in follow['host_paths']:
 if x['group'] not in ('memory_result','english_objects'):continue
 data=(F/x['source']['file']).read_bytes();assert ident(data)['git_blob']==x['producer_blob'];source[x['path']]=data;provenance.setdefault(x['path'],{'producer_base_blob':None})['last_changed_at']='50503fef8e93700d9a889e33c3d2c37fccb46e42';provenance[x['path']]['last_source']=str(F/x['source']['file'])
def apply_patch(before,patch):
 lines=before.decode('utf-8').splitlines(keepends=True);parts=patch.splitlines();out=[];cursor=0;i=0
 while i<len(parts):
  m=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*',parts[i]);assert m,parts[i]
  start=int(m[1]);count=int(m[2] or 1);newcount=int(m[4] or 1);at=start-1 if count else start
  assert at>=cursor;out.extend(lines[cursor:at]);cursor=at;i+=1;oldseen=newseen=0
  while i<len(parts) and not parts[i].startswith('@@ '):
   part=parts[i];assert part and part[0] in ' +-';text=part[1:]+'\n';no_nl=i+1<len(parts) and parts[i+1]=='\\ No newline at end of file'
   if no_nl:text=text[:-1]
   if part[0] in ' -':assert cursor<len(lines) and lines[cursor]==text,(cursor,lines[cursor:cursor+1],text);cursor+=1;oldseen+=1
   if part[0] in ' +':out.append(text);newseen+=1
   i+=2 if no_nl else 1
  assert (oldseen,newseen)==(count,newcount),(oldseen,newseen,count,newcount)
 out.extend(lines[cursor:]);return ''.join(out).encode('utf-8')
newdelta=[]
for x in compare['files']:
 rel=x['filename'];chosen=rel.startswith('.github/probes/lumo_memory_') or rel.startswith('.github/probes/lumo_quiz_') or rel.startswith('tools/android_qa/tests/') or rel=='test/games/memory_result_frame_test.dart'
 rec={'path':rel,'status':x['status'],'published_blob':x['sha'],'selected':chosen};save('delta-patches/'+rel.replace('/','__')+'.patch',(x.get('patch','')+'\n').encode())
 if chosen:
  before=source.get(rel,b'');data=apply_patch(before,x['patch']);assert ident(data)['git_blob']==x['sha'],rel
  if before:save('producer-505-before/'+rel,before)
  source[rel]=data;provenance.setdefault(rel,{'producer_base_blob':None})['last_changed_at']='2e20f5f24cee7a696296e6bea5618cc130a40ce2';provenance[rel]['last_source']='originals/root-2e/host505-to-2e.compare.original.json';rec['identity']=ident(data)
 else:rec['reason']='Producer workflow/document reference only; preserve Root candidate workflow and verification contracts.'
 newdelta.append(rec)
rawtree=subprocess.check_output(['git','-C',repo,'ls-tree','-r','-z','--full-tree',target]);save('originals/target-9f2f.ls-tree.z',rawtree);tree={}
for item in rawtree.split(b'\0'):
 if not item:continue
 a,p=item.split(b'\t',1);mode,typ,blob=a.decode().split();tree[p.decode()]={'mode':mode,'type':typ,'git_blob':blob}
save('originals/target-9f2f.commit.raw',subprocess.check_output(['git','-C',repo,'cat-file','commit',target]));j('originals/target-9f2f.tree.json',tree)
rows=[]
for rel,data in sorted(source.items()):
 data.decode('utf-8');pid=save('producer-final/'+rel,data);current=tree.get(rel);row={'path':rel,'producer':pid,'producer_head':'2e20f5f24cee7a696296e6bea5618cc130a40ce2','provenance':provenance[rel],'target':current}
 if current:
  cur=subprocess.check_output(['git','-C',repo,'show',target+':'+rel]);assert ident(cur)['git_blob']==current['git_blob'];save('before/'+rel,cur);row['target_identity']=ident(cur)
  if cur==data:row['disposition']='already_identical'
  elif current['git_blob']==provenance[rel].get('producer_base_blob'):row['disposition']='exact_producer_replacement_base_identical';save('proposed/'+rel,data)
  else:row['disposition']='three_way_required';save('comparison/'+rel.replace('/','__')+'.current-to-producer.patch',''.join(difflib.unified_diff(cur.decode().splitlines(True),data.decode().splitlines(True),fromfile='current/'+rel,tofile='producer/'+rel)).encode())
 else:row['disposition']='new_exact_producer_file';save('proposed/'+rel,data)
 rows.append(row)
j('source-materialization.json',{'schema':1,'kind':'UNTESTED_EXTERNAL_MATERIALIZATION','target':target,'target_tree':'4159e7ab2212aca6e3347aa5f08544bdfdb30c26','producer':'2e20f5f24cee7a696296e6bea5618cc130a40ce2','producer_tree':'f53e255d2edcf59977a1e23f6638b219a136ebe2','rows':rows})
j('new-delta-classification.json',{'schema':1,'from':'50503fef8e93700d9a889e33c3d2c37fccb46e42','to':'2e20f5f24cee7a696296e6bea5618cc130a40ce2','commits':[x['sha'] for x in compare['commits']],'files':newdelta})
print('PACK',P,'selected',len(rows),'new_delta_selected',sum(x['selected'] for x in newdelta));print('COLLISIONS',[(x['path'],x['disposition']) for x in rows if x['disposition']=='three_way_required'])
