# Host 3d91 terminal Android evidence

Run 43589206933, attempt 1, pull_request, Host 3d91bd8355a539c3c2413760959684cd3fee985a and Native bd0712259bb64908a5649ee1999638826c9eb597. Actual final conclusion: FAILURE. Runtime, Compile and Build succeeded; both Android jobs failed at observed vehicle-card discovery. Final verification and delivery preparation were skipped.

The original complete Build, Android-C4 and Update logs plus final API replies are preserved unchanged. Their SHA256, Git-blob hashes and byte counts were independently recalculated after materialization. Both original commits and actual source copies bind the source tree.

Artifact 14114895060 was downloaded once. Its complete 53,588,701-byte ZIP matches the API SHA256 and all 362 members were fully read for CRC/SHA256. archive-index.json inventories all members. The ZIP remains separate at the recorded path; the compact tar omits it. 91 explicit original members (3,397,934 bytes) include the actual failure pictures, OCR/TSV, readiness and tour-result. No image was recoded.

The two opened original frames show Comet followed by Boru Rally. The actual raw TSV contains the full contiguous words Boru Rally; the OCR line additionally contains decorative tokens. This is an observed exact-line matcher limitation, not a claim that Gecko Velo was visible or selected. All current FAIL results remain intact.

The Update artifact itself has not yet been downloaded. Its original full log reports the same card-discovery error. No final Update preservation PASS, C4 Android success, completed race, audio/FPS or physical-device claim is made. No source was changed and no test, renderer or device rerun was started.

Original Runtime/Compile evidence is separately committed as 1fb106229b522af8e8c63e1e4b8c6d173ec3f587. TreasureTitleContrast's actual banner-to-PASS span is 396.3436123 seconds; the 600-second gate is unchanged.
