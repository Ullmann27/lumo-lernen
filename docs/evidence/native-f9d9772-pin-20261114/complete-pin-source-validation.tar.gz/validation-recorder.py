from pathlib import Path
import datetime, hashlib, json, os, platform, re, subprocess, sys, time
ROOT=Path('/tmp/host-e536-native-f9d9772-pin-integration-20261114')
OUT=ROOT/'validation';OUT.mkdir(exist_ok=False)
def ident(b):
 return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def save(name,v):
 with (OUT/name).open('xb') as f:f.write((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def snapshot():
 rows=[]
 for parent in ['before-source','final-source','reference-source','test-view']:
  for p in sorted((ROOT/parent).rglob('*')):
   if p.is_file():rows.append({'path':p.relative_to(ROOT).as_posix(),'mode':oct(p.stat().st_mode & 0o777),**ident(p.read_bytes())})
 for rel in ['source-freeze.json','source-preservation.json','pin.patch','test-roster.json','originals/host-commit.original.json','originals/tree.original.json','originals/native-commit.original.json']:
  p=ROOT/rel;rows.append({'path':rel,'mode':oct(p.stat().st_mode&0o777),**ident(p.read_bytes())})
 return rows
freeze=json.loads((ROOT/'source-freeze.json').read_text())
assert freeze['base_host']=='e53669a2e06d1832cc6844dbe1077d652551fdb8'
for r in freeze['files']:
 a=(ROOT/'final-source'/r['path']).read_bytes();b=(ROOT/'before-source'/r['path']).read_bytes()
 assert ident(a)==r['after'] and ident(b)==r['before']
 assert (ROOT/'test-view'/r['path']).read_bytes()==a
before=snapshot();save('sources-before.json',before)
argv=[sys.executable,'-B','-m','unittest','scripts.tests.test_candidate_2011_pin','scripts.tests.test_legacy_release_pin','-v']
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0');env.pop('PYTHONPATH',None)
save('environment.json',{'executable':sys.executable,'python':sys.version,'platform':platform.platform(),'cwd':str(ROOT/'test-view'),'kind':'Private plain exact source view; not a new Git checkout or a published modified commit.','overrides':{'PYTHONDONTWRITEBYTECODE':'1','GIT_OPTIONAL_LOCKS':'0','PYTHONPATH':'removed'}})
save('invocation.json',{'argv':argv,'cwd':str(ROOT/'test-view'),'invocations':1,'expected_tests':64,'source_freeze':ident((ROOT/'source-freeze.json').read_bytes())})
start=now();tick=time.monotonic()
with (OUT/'stdout.original.log').open('xb') as out,(OUT/'stderr.original.log').open('xb') as err:
 try:
  p=subprocess.run(argv,cwd=ROOT/'test-view',env=env,stdout=out,stderr=err,check=False,timeout=120);rc=p.returncode;timeout=False
 except subprocess.TimeoutExpired:rc=None;timeout=True
elapsed=time.monotonic()-tick;end=now()
save('process.json',{'argv':argv,'started_at':start,'ended_at':end,'elapsed_seconds':elapsed,'returncode':rc,'timed_out':timeout})
after=snapshot();save('sources-after.json',after)
stderr=(OUT/'stderr.original.log').read_text()
summary=re.findall(r'(?m)^Ran (\d+) tests? in ([0-9.]+)s\s*$',stderr)
count=int(summary[-1][0]) if summary else None
ok=bool(re.search(r'(?m)^OK\s*$',stderr))
passed=rc==0 and not timeout and count==64 and ok and before==after
save('source-comparison.json',{'same':before==after,'bound_file_records':len(before),'executable_view_files':sum(x['path'].startswith('test-view/') for x in before),'no_existing_repository_write':True})
result={'schema':1,'status':'PASS' if passed else 'FAIL','actual_invocations':1,'tests':count,'candidate_methods':24,'legacy_methods':40,'exit_code':rc,'timed_out':timeout,'exact_OK_summary':ok,'unittest_seconds':float(summary[-1][1]) if summary else None,'process_seconds':elapsed,'sources_unchanged':before==after,'stdout':ident((OUT/'stdout.original.log').read_bytes()),'stderr':ident((OUT/'stderr.original.log').read_bytes()),'scope':'Existing source identity contracts on the three frozen proposed pin replacements. No APK, engine, Android, CI, release or active-ref acceptance.'}
save('result.json',result)
print(json.dumps(result,indent=2),flush=True)
sys.exit(0 if passed else 1)
