#!/usr/bin/env python3
"""One authorized 104-method check of the published, unchanged QA checkout."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

REPO = Path("/tmp/lumo-recovery-20261114/host-qa")
OUT = Path(__file__).resolve().parent
PYTHON = Path("/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3")
ACTIONLINT = Path("/workspace/scratch/e0abce7d2838/toolchain/actionlint/actionlint")
HEAD = "0d7ea79cd02b921ed685abc79b27df8a5f6b4ccb"
TREE = "863c4b45bcd6a564070ca128565688bde7e1ed11"


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=REPO,
                                   env={**os.environ, "GIT_OPTIONAL_LOCKS": "0"})


def put(name, value):
    raw = (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()
    with (OUT / name).open("xb") as stream:
        stream.write(raw)


def snapshot(label):
    status = git("status", "--porcelain=v1", "--untracked-files=all")
    (OUT / (label + "-git-status.txt")).write_bytes(status)
    head, tree = git("rev-parse", "HEAD").decode().strip(), git("rev-parse", "HEAD^{tree}").decode().strip()
    rows, absent = [], []
    for name in git("ls-files", "-z").decode().split("\0"):
        if not name:
            continue
        path = REPO / name
        if path.is_file():
            raw = path.read_bytes()
            rows.append({"path": name, "bytes": len(raw), "sha256": sha(raw)})
        else:
            absent.append(name)
    index = Path(git("rev-parse", "--git-path", "index").decode().strip())
    if not index.is_absolute():
        index = REPO / index
    value = {"head": head, "tree": tree, "status_sha256": sha(status),
             "index_sha256": sha(index.read_bytes()), "materialized_tracked_files": rows,
             "tracked_not_materialized": absent}
    raw = (json.dumps(value, indent=2) + "\n").encode()
    compressed = gzip.compress(raw, mtime=0)
    if gzip.decompress(compressed) != raw:
        raise ValueError("Fingerprint gzip roundtrip differs")
    with (OUT / (label + "-sources.json.gz")).open("xb") as stream:
        stream.write(compressed)
    put(label + "-fingerprint.json", {"head": head, "tree": tree,
        "git_status_sha256": sha(status), "index_sha256": value["index_sha256"],
        "source_count": len(rows), "tracked_not_materialized_count": len(absent),
        "original_json_bytes": len(raw), "original_json_sha256": sha(raw),
        "gzip_sha256": sha(compressed), "gzip_roundtrip": True})
    if head != HEAD or tree != TREE or status:
        raise ValueError("Checkout source or clean status differs from the authorized commit")
    return value


def main():
    before = snapshot("before")
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "REQUIRE_ALL_TESTS": "true",
           "GIT_OPTIONAL_LOCKS": "0"}
    version_commands = [[str(PYTHON), "--version"], [str(ACTIONLINT), "-version"]]
    put("environment.json", {"at": utc(), "cwd": str(REPO), "python": str(PYTHON),
        "require_all_tests": True, "versions": [{"command": command,
        "output": subprocess.check_output(command, stderr=subprocess.STDOUT, env=env).decode()}
        for command in version_commands]})
    groups = [
        ("wait-contracts", 9, [str(PYTHON), "-B", "-m", "unittest", "-v", "scripts.tests.test_android_runtime_wait_notification"]),
        ("console-anr-contracts", 86, [str(PYTHON), "-B", "-m", "unittest", "-v",
          "scripts.tests.test_android_console_transport", "scripts.tests.test_android_runtime_device_logger",
          "scripts.tests.test_runtime_logcat_sections", "scripts.tests.test_android_framework_ready",
          "scripts.tests.test_verify_android_runtime_anr"]),
        ("workflow-contracts", 9, [str(PYTHON), "-B", "-m", "unittest", "-v", "scripts.tests.test_console_start_workflow"]),
        ("actionlint", None, [str(ACTIONLINT), ".github/workflows/lumo-console-start-7b16.yml"]),
    ]
    results = []
    for name, expected, command in groups:
        started_at, started = utc(), time.monotonic()
        raw_path = OUT / (name + ".log")
        timed_out = False
        with raw_path.open("xb") as stream:
            try:
                execution = subprocess.run(command, cwd=REPO, env=env, stdout=stream,
                                           stderr=subprocess.STDOUT, timeout=300)
                exit_code = execution.returncode
            except subprocess.TimeoutExpired:
                exit_code, timed_out = 124, True
        raw = raw_path.read_bytes()
        counts = [int(value) for value in re.findall(rb"^Ran (\d+) tests? in [0-9.]+s$", raw, re.M)]
        skipped = bool(re.search(rb"^OK \(skipped=|^FAILED.*skipped=|\.\.\. skipped ", raw, re.M))
        passed = exit_code == 0 and not timed_out and not skipped
        if expected is not None:
            passed = passed and counts == [expected] and b"\nOK\n" in raw
        result = {"name": name, "command": command, "cwd": str(REPO), "started_at": started_at,
                  "finished_at": utc(), "elapsed_seconds": time.monotonic() - started,
                  "exit_code": exit_code, "timed_out": timed_out, "expected_methods": expected,
                  "observed_method_counts": counts, "skip_reported": skipped, "pass": passed,
                  "raw_log": raw_path.name, "raw_log_bytes": len(raw), "raw_log_sha256": sha(raw)}
        results.append(result)
        print(json.dumps(result), flush=True)
    after = snapshot("after")
    result = {"head": HEAD, "tree": TREE, "phases": results, "sources_and_git_unchanged": before == after,
              "status": "PASS" if before == after and all(row["pass"] for row in results) else "FAIL",
              "test_methods": sum(sum(row["observed_method_counts"]) for row in results),
              "scope": "Exactly 9 wait + 86 existing console/ANR + 9 workflow methods and actionlint1. No GPU, Android, engine, APK, source or Git action."}
    put("result.json", result)
    print(json.dumps({"status": result["status"], "methods": result["test_methods"],
                      "sources_unchanged": result["sources_and_git_unchanged"]}), flush=True)
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
