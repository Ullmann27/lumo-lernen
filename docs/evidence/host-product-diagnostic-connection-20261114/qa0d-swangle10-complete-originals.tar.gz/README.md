# SWANGLE-Verträge auf dem veröffentlichten QA-Checkpoint 0d7ea

**Einmaliger tatsächlicher Lauf: 10 Methoden bestanden, 0 Fehler, 0 Failures, 0 Skips.** Gemeldete Testdauer 0,567 Sekunden; gesamte Prozessdauer 0,666 Sekunden.

Geprüft wurde exakt Host/QA-Commit `0d7ea79cd02b921ed685abc79b27df8a5f6b4ccb`, Baum `863c4b45bcd6a564070ca128565688bde7e1ed11`, im sauberen tatsächlichen Checkout `/tmp/lumo-recovery-20261114/host-qa`. Der vollständige Git-Commitinhalt wurde zusätzlich gegen seine echte Objekt-ID gehasht. Die drei Reparaturquellen stimmen mit Freeze `2ea77b280905bb6482ebf93a11fccdcc771fab1fda220e1b12070ab067a5e9fe` überein.

## Ausführung und Erhaltung

Einziger Testaufruf:

```text
PYTHONDONTWRITEBYTECODE=1 python3 -B -m unittest -v scripts.tests.test_runtime_followup_workflow
```

Der vollständige unveränderte Rohlog liegt in `contracts-10.log`. `invocation.json` bindet Verzeichnis, Argumente, Umgebungswerte und Startzeit; `result.json` enthält die tatsächlichen Zählwerte und Hashes. Es gab keinen zweiten Testlauf.

735 materialisierte versionierte Dateien waren vor und nach dem Lauf Gitblob-genau identisch. HEAD, Tree, Branch, Gitindex und leerer Gitstatus blieben gleich. Die 3333 im Sparse-Checkout nicht materialisierten Pfade werden vollständig benannt; sie werden nicht als physisch geprüft ausgegeben. Beide vollständigen Quellmanifeste und Indexaufnahmen liegen verlustfrei deterministisch gzip-komprimiert vor. Die gespeicherten und unkomprimierten Hashes stehen in `storage-provenance.json`.

Die erste Eingabeprüfung fand einen durch Sparse ausgeblendeten Wrapper. Dabei begann noch kein Testlauf. `preflight-missing-inputs.json` erhält diesen Befund; Root materialisierte anschließend ausschließlich die bereits veröffentlichten Bytes. Nach der Abstimmung mit Pipelines getrenntem Quellvergleich wurde für den hier belegten Lauf ein vollständig neuer Vorzustand aufgenommen.

## Belegter Umfang

Die aktuelle Reporterimplementierung nimmt die bytegebundenen Originaldaten des früheren 08e-SWANGLE-Falls an und lehnt widersprüchliche oder fehlende Launch-/Backend-/GLES-Daten weiter ab. Die vorhandenen Host-/SwiftShader-, Hardware- und Workflowverträge sind enthalten. Das ist ein lokaler Programm-/Originaldaten-Replay. Der frühere echte SWANGLE-Job bleibt FAILURE. Ein erfolgreicher zukünftiger Emulator-/App-/ANR-Lauf wird hieraus nicht abgeleitet.

Es wurden keine Quellen, Git-Refs, Pins oder CI-Läufe verändert und keine Geräte- oder Enginetests gestartet. Der andere Pipeline-Testumfang bleibt getrennt; dieser Pack behauptet ausschließlich die zehn hier protokollierten Methoden.
