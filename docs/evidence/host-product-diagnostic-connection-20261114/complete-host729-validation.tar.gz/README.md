# Host729585 — targeted validation

Source: `729585db3f49ecff7f0632439f90edb882f09454`, tree `93301ed1c1e0b18f15163ae6198be0bc6b962762`. Native pin: `0e26153f0e58cc05739e72923b4c563a4cf380b8`.

The assigned 142 Python tests passed (41 delivery, 11 pipeline, 24 candidate pin, 40 legacy pin, 4 real Jump decoding, 7 console-original parsing, 9 failure diagnostics, 6 printf contracts). Neither Python nor Actionlint was rerun. Actionlint passed for exactly the C4 and curriculum workflows.

The first Flutter command failed before any test case: the sparse checkout lacked the committed Cards WebP. Its complete failed log is retained. Root materialized that one 356,822-byte Git blob without a source change. The separate second command passed all seven exact-selection tests.

The actual Dart audit produced 236 families and 7,552 structural samples with zero issues. A separately authorized second command used the exact workflow pipeline and split streams; the unchanged delivery consumer accepted all six original files. The two build-hook notices are exactly the 44-byte stderr. The 372-byte stdout is pure JSON. No CI run, job or source-binding file was fabricated. Both runs' four generated data files are byte-identical.

## Source preservation

Before/after snapshots bind every materialized indexed path (2,429 initially; 2,430 after Root's exact asset materialization). HEAD, tree, branch, tracked blob/mode/stage entries, package inputs and clean status remained unchanged. Raw index bytes are unchanged within each test group. Their different hash across Root's materialization is expressly preserved; the pack does not claim overall raw-index identity.

## Limits

These are local contract results, not Android, audio, rendered-device or semantic approval. The audit itself marks curriculum review pending and official/all-variant approval false. Local FFmpeg is 7.1.5 and Pillow 13.0.0; CI's older FFmpeg/Pillow boundary remains separately documented. No broad suite or emulator was run.

`manifest.json` binds every original pack file. `compact-originals.tar.gz` retains the complete listed bytes, including the original failed Flutter invocation; `archive-binding.json` records the complete roundtrip. No binaries, caches, APKs or redundant source packs are included.
