#!/usr/bin/env python3
"""Run only the explicitly assigned source-bound validation phases."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import os
import subprocess
import sys
import time

PACK = Path(__file__).resolve().parent
REPO = Path('/tmp/lumo-recovery-20261114/host-c4')
HEAD = '729585db3f49ecff7f0632439f90edb882f09454'
TREE = '93301ed1c1e0b18f15163ae6198be0bc6b962762'
FLUTTER = '/workspace/scratch/e0abce7d2838/toolchain/flutter/bin/flutter'
DART = '/workspace/scratch/e0abce7d2838/toolchain/flutter/bin/dart'
ACTIONLINT = '/workspace/scratch/e0abce7d2838/toolchain/actionlint/actionlint'
MODULES = [
    'scripts.tests.test_connect_four_delivery',
    'scripts.tests.test_connect_four_pipeline',
    'scripts.tests.test_candidate_2011_pin',
    'scripts.tests.test_legacy_release_pin',
    'scripts.tests.test_studio_jump_decode',
    'scripts.tests.test_console_launch_originals',
    'scripts.tests.test_console_launch_failure_diagnostics',
    'scripts.tests.test_console_logger_printf',
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=REPO)


def snapshot(label):
    head = git('rev-parse', 'HEAD').decode().strip()
    tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
    assert (head, tree) == (HEAD, TREE)
    status = git('status', '--porcelain=v1', '--untracked-files=all')
    index = Path(git('rev-parse', '--git-path', 'index').decode().strip())
    if not index.is_absolute():
        index = REPO/index
    rows = []
    for record in git('ls-files', '--stage', '-z').split(b'\0'):
        if not record:
            continue
        fields, name = record.split(b'\t', 1)
        mode, blob, stage = fields.decode().split()
        relative = os.fsdecode(name)
        path = REPO/relative
        row = {'path': relative, 'mode': mode, 'git_blob': blob, 'stage': stage,
               'materialized': path.exists() or path.is_symlink()}
        if row['materialized']:
            data = os.fsencode(os.readlink(path)) if path.is_symlink() else path.read_bytes()
            actual = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
            assert actual == blob, relative
            row.update(bytes=len(data), sha256=sha(data), actual_git_blob=actual)
        rows.append(row)
    package_inputs = {}
    for name in ('.dart_tool/package_config.json', '.dart_tool/package_graph.json'):
        data = (REPO/name).read_bytes()
        package_inputs[name] = {'bytes': len(data), 'sha256': sha(data)}
    result = {'head': head, 'tree': tree, 'branch': git('branch', '--show-current').decode().strip(),
              'status_porcelain': status.decode(), 'index_sha256': sha(index.read_bytes()),
              'tracked_index': rows, 'package_inputs': package_inputs}
    raw = (json.dumps(result, indent=2)+'\n').encode()
    path = PACK/(label+'.json.gz')
    with path.open('xb') as handle:
        with gzip.GzipFile(filename='', fileobj=handle, mode='wb', mtime=0) as output:
            output.write(raw)
    (PACK/(label+'-binding.json')).write_text(json.dumps({
        'path': path.name, 'bytes': len(raw), 'sha256': sha(raw),
        'gzip_bytes': path.stat().st_size, 'gzip_sha256': sha(path.read_bytes()),
        'materialized_count': sum(row['materialized'] for row in rows),
        'tracked_count': len(rows), 'source_head': head, 'source_tree': tree,
    }, indent=2)+'\n')
    return result


def run(phase):
    if phase == 'python':
        command = [sys.executable, '-m', 'unittest', '-v', *MODULES]
    elif phase == 'actionlint':
        command = [ACTIONLINT, '.github/workflows/lumo-connect-four-2020.yml',
                   '.github/workflows/lumo-learning-curriculum-audit.yml']
    elif phase in ('flutter', 'flutter-after-asset'):
        command = [FLUTTER, 'test', '--no-pub', 'test/learning/learning_exact_selection_test.dart',
                   '--reporter=expanded']
    elif phase == 'audit':
        command = [DART, 'run', 'tools/audit_learning_tasks_all_grades.dart', str(PACK/'actual-learning-audit')]
    else:
        raise ValueError('Unassigned validation phase')
    environment = dict(os.environ)
    environment.update(TMPDIR='/tmp/lumo-host729-validation-20261114',
                       PYTHONDONTWRITEBYTECODE='1', CI='true',
                       FLUTTER_SUPPRESS_ANALYTICS='true', DART_SUPPRESS_ANALYTICS='true')
    environment['PATH'] = '/workspace/scratch/e0abce7d2838/toolchain/gradle-9.1.0/bin:'+environment['PATH']
    java = Path('/usr/lib/jvm/java-21-openjdk-amd64')
    if java.is_dir():
        environment['JAVA_HOME'] = str(java)
    log = PACK/'logs'/(phase+'.log')
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    before = time.monotonic()
    with log.open('xb') as output:
        result = subprocess.run(command, cwd=REPO, env=environment,
                                stdout=output, stderr=subprocess.STDOUT)
    report = {'phase': phase, 'command': command, 'cwd': str(REPO), 'host_source': HEAD,
              'host_tree': TREE, 'started_at_utc': started,
              'completed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'elapsed_seconds': time.monotonic()-before, 'exit_code': result.returncode,
              'original_log': {'path': str(log), 'bytes': log.stat().st_size,
                               'sha256': sha(log.read_bytes())},
              'scope': 'Local targeted source validation; no Android/audio/semantic approval'}
    (PACK/'results'/(phase+'.json')).write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report), flush=True)
    return result.returncode


if __name__ == '__main__':
    if sys.argv[1] == 'snapshot':
        result = snapshot(sys.argv[2])
        print(json.dumps({'snapshot': sys.argv[2], 'head': result['head'],
                          'materialized': sum(row['materialized'] for row in result['tracked_index']),
                          'status': result['status_porcelain'], 'index_sha256': result['index_sha256']}))
    else:
        raise SystemExit(run(sys.argv[1]))
