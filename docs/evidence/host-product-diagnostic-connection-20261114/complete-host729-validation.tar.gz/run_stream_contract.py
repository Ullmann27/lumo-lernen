#!/usr/bin/env python3
"""Execute the authorized real Dart stream/consumer pairing without CI claims."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time
import traceback

PACK = Path(__file__).resolve().parent
REPO = Path('/tmp/lumo-recovery-20261114/host-c4')
OUT = PACK/'workflow-audit-streams'
HEAD = '729585db3f49ecff7f0632439f90edb882f09454'
TREE = '93301ed1c1e0b18f15163ae6198be0bc6b962762'


def record(path):
    data = path.read_bytes()
    return {'path': str(path.relative_to(PACK)), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def main():
    OUT.mkdir(exist_ok=False)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO).decode().strip() == HEAD
    command = ['bash', '-c', '''set -euo pipefail
audit_dir="$1"
dart run tools/audit_learning_tasks_all_grades.dart "$audit_dir" 2> "$audit_dir/audit.stderr.log" | tee "$audit_dir/audit.stdout.log"
''', 'workflow-dart-stream-check', str(OUT)]
    env = dict(os.environ)
    env.update(TMPDIR='/tmp/lumo-host729-validation-20261114', CI='true',
               PYTHONDONTWRITEBYTECODE='1', FLUTTER_SUPPRESS_ANALYTICS='true',
               DART_SUPPRESS_ANALYTICS='true')
    env['PATH'] = '/workspace/scratch/e0abce7d2838/toolchain/flutter/bin:'+env['PATH']
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.monotonic()
    with (PACK/'logs/workflow-audit-run.stdout.log').open('xb') as stdout, \
         (PACK/'logs/workflow-audit-run.stderr.log').open('xb') as stderr:
        completed = subprocess.run(command, cwd=REPO, env=env, stdout=stdout, stderr=stderr)
    result = {'source': HEAD, 'tree': TREE, 'command': command, 'cwd': str(REPO),
              'started_at_utc': started, 'elapsed_seconds': time.monotonic()-clock,
              'dart_exit_code': completed.returncode,
              'scope': 'Local execution of original workflow Dart invocation and unmodified consumer; no CI run, job, source-binding or artifact is invented'}
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(REPO/'scripts'))
    with (PACK/'logs/workflow-audit-parser.log').open('x') as log:
        if completed.returncode == 0:
            try:
                import verify_connect_four_delivery as verifier
                parsed = verifier.checked_learning_outputs(OUT)
                result['parser'] = {'status': 'PASS', 'result': parsed}
                print(json.dumps(parsed, indent=2), file=log)
            except Exception as error:
                result['parser'] = {'status': 'FAIL', 'type': type(error).__name__, 'message': str(error)}
                traceback.print_exc(file=log)
        else:
            result['parser'] = {'status': 'NOT_RUN', 'reason': 'Original Dart invocation failed'}
            print('Parser not executed after failed Dart invocation.', file=log)
    result['originals'] = [record(path) for path in sorted(OUT.iterdir()) if path.is_file()]
    result['completed_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (PACK/'results/workflow-audit-stream-contract.json').open('x') as output:
        json.dump(result, output, indent=2)
        output.write('\n')
    print(json.dumps(result), flush=True)
    return 0 if completed.returncode == 0 and result['parser']['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
