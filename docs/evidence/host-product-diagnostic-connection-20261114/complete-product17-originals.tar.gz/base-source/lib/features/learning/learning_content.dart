import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../app/app_state.dart';
import '../../app/app_theme.dart';
import '../../app/app_design.dart';
import '../../widgets/fox/lumo_companion_requests.dart';
import '../../core/ai_task_cache.dart';
import '../../core/ai_tutor_service.dart';
import '../../core/test_result_repository.dart';
import '../../core/lumo_ai_proxy_client.dart';
import '../../core/lumo_ai_learning_access.dart';
import '../../core/lumo_ai_learning_policy_bridge.dart';
import '../../core/lumo_tutor_contracts.dart';
import '../../core/lumo_tutor_engine.dart';
import '../../core/tutor_coordination_engine.dart';
import '../../core/math/lumo_rechentricks.dart';
import '../../core/lumo_visual_aid_service.dart';
import '../../core/school_exercise_generator.dart';
import '../../core/task_quality_guard.dart';
import '../../core/writing_target_parser.dart';
import '../../core/task_hint_service.dart';
import '../../core/recent_task_repository.dart';
import '../../core/session_variety_guard.dart';
import '../../core/lumo_voice.dart';
import '../../core/lumo_voice_clips.dart';
import '../../domain/learning/adaptive_learning_engine.dart';
import '../../domain/learning/error_detective.dart';
import '../../domain/tutoring/native_learning_activity.dart';
import '../lumo3d/lumo3d_launcher.dart';
import '../../domain/learning/lumo_learning_domain.dart';
import '../../domain/learning/lumo_learning_feedback_engine.dart';
import '../../domain/learning/reward_engine.dart';
import '../shared/widgets/lumo_premium_effects.dart' hide LumoGlassCard;
import 'adapters/legacy_lumo_task_adapter.dart';
import 'renderers/adaptive_task_renderer.dart';
import 'renderers/shape_trace_task_renderer.dart';
import 'renderers/writing_task_renderer.dart';
import 'widgets/rechentricks_mentor_card.dart';
import 'widgets/lumo_learning_tree_card.dart';
import 'widgets/lumo_tutor_hint_card.dart';
import 'widgets/lumo_tutor_offer_card.dart';
import 'widgets/lumo_place_value_workshop.dart';
import 'widgets/lumo_learning_scene_card.dart';
import '../../domain/learning_intelligence/lesson_scene_engine.dart';
import '../../domain/learning_intelligence/lumo_intelligence_engine.dart';
import '../../domain/learning_intelligence/learning_scene_contract.dart';
import '../lumo_welt/lumo_welt_screen.dart';
import '../../theme/lumo_visual_tokens.dart';
import '../../widgets/design/lumo_design_system.dart';
import '../../widgets/fox/lumo_character.dart';

class LearningContent extends StatefulWidget {
  const LearningContent({
    super.key,
    required this.appState,
    this.aiProxy = const LumoAiProxyClient(),
  });
  final LumoAppState appState;
  final LumoAiProxyClient aiProxy;

  @override
  State<LearningContent> createState() => _LearningContentState();
}

class _LearningContentState extends State<LearningContent> {
  final _factory = ExerciseFactory();
  final _adapter = const LegacyLumoTaskAdapter();
  final _resultHandler = const SkillStateUpdater();
  final _rewardEngine = const RewardEngine();
  var _feedbackEngine = LumoLearningFeedbackEngine();
  final _taskHints = const TaskHintService();
  LumoCompanionTaskContext? _publishedTaskContext;
  String? _activeSessionScope;
  final Map<String, SkillState> _skillStates = <String, SkillState>{};
  final List<String> _recentTaskKeys = <String>[];
  final List<String> _recentUnits = <String>[];
  final Set<String> _sessionTaskKeys = <String>{};
  Set<String> _lastTaskMarkers = <String>{};

  // Nachhilfelehrer: KI-generierte Aufgaben aus Cache, basierend auf Schwaechen
  static const AiTutorService _tutor = AiTutorService();
  static const AiTaskCache _aiCache = AiTaskCache();
  static const TaskQualityGuard _taskQualityGuard = TaskQualityGuard();
  static const RecentTaskRepository _recentRepo = RecentTaskRepository();
  static const LumoTutorEngine _localTutorEngine = LumoTutorEngine();
  TutorCoordinationEngine get _tutorCoordinator =>
      LumoCompanionRequests.instance.tutor;
  // Visuelle Hilfe als 4. Eskalations-Stufe (nach 5+ Fehlversuchen).
  // Nutzt nur den lokalen Pfad (kein Cloud-Aufruf, keine Credit-Kosten),
  // weil das fuer Heinz' Toechter im taeglichen Lernen ausreicht.
  static const LumoVisualAidService _visualAidService = LumoVisualAidService();
  // Vermeidet sichtbare Wiederholungen ueber den exakten Aufgaben-Key
  // hinaus: gleiche Antwort, gleiches Prompt-Muster, gleiche Schluesselwoerter.
  // So sehen Heinz' Toechter nicht 5x in Folge "1+2", "2+1", "1+3" usw.
  final SessionVarietyGuard _varietyGuard = SessionVarietyGuard();
  final List<LumoAiTaskDraft> _aiDraftQueue = <LumoAiTaskDraft>[];
  String? _aiQueueScope;

  String get _currentAiScope =>
      '${widget.appState.profileGeneration}|$_childId|${widget.appState.state.grade}|${_aiSubjectName(widget.appState.state.subject)}';

  String get _sessionScope {
    final state = widget.appState.state;
    return '${widget.appState.profileGeneration}|$_childId|${state.subject}|${state.unit}|${state.sessionKind.name}';
  }

  static const int _recentTaskMemory = RecentTaskRepository.maxTaskKeys;
  static const int _recentUnitMemory = 10;

  late LumoTask _task;
  late TaskInstance _taskInstance;
  DateTime _taskStartedAt = DateTime.now();
  bool _answered = false;
  bool _nativeLearningOpen = false;
  Timer? _autoAdvanceTimer;
  bool? _lastCorrect;
  RewardDelta? _lastRewardDelta;
  SkillState? _lastSkillState;
  LumoFeedbackTurn? _lastFeedback;
  int _questionNum = 1;

  /// Lumo neben dem Fortschritt jubelt oder tröstet nach jeder Antwort.
  final _lumo = LumoCharacterController();
  bool _sessionFinished = false;
  // Test: Fragen, die beim ersten Versuch richtig waren (Tests-Bildschirm).
  int _testFirstTryCorrect = 0;
  bool _questionHadWrong = false;
  int _attemptCount = 0;
  int _totalTaskAttempts = 0;
  String? _lastGivenAnswer;
  String? _tutorHint;
  PlaceValueLessonSession? _placeValueLesson;
  int _sceneRequestSerial = 0;
  ExplanationMethod _sceneMethod = ExplanationMethod.verbal;
  SceneCompletion? _pendingSceneCompletion;
  ExplanationMethod _pendingSceneMethod = ExplanationMethod.verbal;
  String? _sceneCompletionError;

  Future<void> _saveSceneCompletion() async {
    final proof = _pendingSceneCompletion;
    if (proof == null) return;
    final generation = widget.appState.profileGeneration;
    final subject = _task.subject, unit = _task.unit;
    try {
      final saved = await widget.appState.saveLearningSceneCompletion(
          subject: subject,
          unit: unit,
          proof: proof,
          method: _pendingSceneMethod);
      if (!mounted || generation != widget.appState.profileGeneration) return;
      if (saved && identical(_pendingSceneCompletion, proof)) {
        setState(() {
          _pendingSceneCompletion = null;
          _sceneCompletionError = null;
        });
      }
    } catch (_) {
      if (mounted && generation == widget.appState.profileGeneration) {
        setState(() => _sceneCompletionError =
            'Dein Lernschritt wartet noch aufs Speichern.');
      }
    }
  }

  int _requestedHelpLevel = 0;
  // Bildhilfe-Karte als 4. Hilfsstufe nach 5+ Fehlversuchen.
  // Nur lokal generiert, kein Cloud-Aufruf.
  LumoVisualAid? _visualAid;
  // 2026-06-05 Iter 21: Rechentricks-Mentor-Erklärung.
  // Wird bei attempt 2 fuer Math-Aufgaben angezeigt - Mildenberger-Stil.
  RechentricksExplanation? _rechentricks;

  // Konfetti-Trigger: jedes Hochzaehlen loest einen neuen Burst aus.
  // Wird bei richtigen Antworten erhoeht.
  int _confettiTrigger = 0;

  // Phase 2 - Lumo Fehlerdetektiv: zaehlt Fehlerarten in dieser Session.
  // Wird in den ErrorBreakdownRepository persistiert und vom DNA-Engine
  // in Phase 1 gelesen.
  final Map<String, int> _errorBreakdown = <String, int>{};

  // KI-Hilfe vom Cloud-Tutor (optional, nur wenn aiProxyEnabled).
  // Heinz' Wunsch: pro Bereich zugeschnittener KI-Helfer mit echtem Kontext.
  String? _aiHelpReply;
  bool _aiHelpLoading = false;

  int get _totalQuestions {
    switch (widget.appState.state.sessionKind) {
      case LumoSessionKind.quickPractice:
        return 10;
      case LumoSessionKind.exerciseSet:
        return 20;
      case LumoSessionKind.test:
        return kLumoTestQuestions;
      case LumoSessionKind.schoolwork:
        return 30;
      case LumoSessionKind.tutoring:
        return 8;
    }
  }

  bool get _allowHelp =>
      widget.appState.state.sessionKind != LumoSessionKind.schoolwork &&
      widget.appState.state.sessionKind != LumoSessionKind.test;

  @override
  void initState() {
    super.initState();
    LumoCompanionRequests.instance.helpRequested.addListener(_requestTaskHelp);
    _loadNextTask(resetCounter: false);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final settings = widget.appState.state.settings;
      if (!settings.voiceEnabled || !settings.autoReadEnabled) return;
      // Always audible with the bundled warm German recording, even when
      // the optional license for synthesizing arbitrary text is not granted.
      unawaited(LumoVoice.instance.speak(
        'Hallo! Schön, dass du da bist. Ich bin Lumo. '
        'Komm, wir entdecken zusammen etwas Neues!',
        style: VoiceStyle.greeting,
      ));
    });
    // Persistente Wiederholungsvermeidung nachladen, ohne den ersten Frame zu blockieren.
    _hydrateRecent();
    // Nachhilfelehrer-Hook (fire and forget):
    //   1. KI-Aufgaben aus Cache laden (kostenlos, lokal)
    //   2. Wenn Cache niedrig und KI freigegeben: vom Server nachfuellen
    _hydrateAiQueueAndMaybeRefill();
  }

  @override
  void didUpdateWidget(covariant LearningContent oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (_activeSessionScope == _sessionScope) return;
    _skillStates.clear();
    _feedbackEngine = LumoLearningFeedbackEngine();
    _errorBreakdown.clear();
    _recentTaskKeys.clear();
    _recentUnits.clear();
    _sessionTaskKeys.clear();
    _lastTaskMarkers.clear();
    _varietyGuard.reset();
    _aiDraftQueue.clear();
    _aiQueueScope = null;
    _loadNextTask(resetCounter: true);
    unawaited(_hydrateRecent());
    unawaited(_hydrateAiQueueAndMaybeRefill());
  }

  Future<void> _hydrateRecent() async {
    final generation = widget.appState.profileGeneration;
    final st = widget.appState.state;
    final childId = _childId;
    final subject = st.subject;
    final keys = await _recentRepo.loadTaskKeys(
      childId: childId,
      subject: subject,
    );
    final units = await _recentRepo.loadUnits(
      childId: childId,
      subject: subject,
    );
    if (!mounted ||
        generation != widget.appState.profileGeneration ||
        childId != _childId ||
        subject != widget.appState.state.subject) {
      return;
    }
    setState(() {
      final currentKeys = List<String>.from(_recentTaskKeys);
      final currentUnits = List<String>.from(_recentUnits);

      _recentTaskKeys
        ..clear()
        ..addAll(keys);
      for (final key in currentKeys) {
        _recentTaskKeys.remove(key);
        _recentTaskKeys.add(key);
      }
      while (_recentTaskKeys.length > _recentTaskMemory) {
        _recentTaskKeys.removeAt(0);
      }

      _recentUnits
        ..clear()
        ..addAll(units);
      for (final unit in currentUnits) {
        _recentUnits.remove(unit);
        _recentUnits.add(unit);
      }
      while (_recentUnits.length > _recentUnitMemory) {
        _recentUnits.removeAt(0);
      }
    });
  }

  Future<void> _hydrateAiQueueAndMaybeRefill() async {
    final generation = widget.appState.profileGeneration;
    final st = widget.appState.state;
    final subject = _aiSubjectName(st.subject);
    if (subject == null) return;
    final childId = _childId;
    final scope = _currentAiScope;
    bool isCurrent() =>
        mounted &&
        generation == widget.appState.profileGeneration &&
        _childId == childId &&
        widget.appState.state.grade == st.grade &&
        _aiSubjectName(widget.appState.state.subject) == subject;
    final fresh = await _aiCache.loadFresh(
      childId: childId,
      subject: subject,
      grade: st.grade,
    );
    if (isCurrent()) {
      setState(() {
        _aiQueueScope = scope;
        _aiDraftQueue
          ..clear()
          ..addAll(fresh);
      });
    }
    if (!isCurrent()) return;
    // Refill bei Bedarf - laeuft asynchron, kein Block
    final result = await _tutor.refillIfNeeded(
      settings: st.settings,
      profile: widget.appState.learningProfile,
      childId: childId,
      childName: st.childName,
      grade: st.grade,
      subject: subject,
    );
    if (!isCurrent()) return;
    if (!result.skipped && result.generated > 0) {
      // Neue Drafts in die Queue uebernehmen
      final updated = await _aiCache.loadFresh(
        childId: childId,
        subject: subject,
        grade: st.grade,
      );
      if (!isCurrent()) return;
      setState(() {
        _aiQueueScope = scope;
        _aiDraftQueue
          ..clear()
          ..addAll(updated);
      });
    }
  }

  /// Mappt App-Subject-Bezeichnungen auf Cache/Server-Schluessel.
  /// Null bedeutet: kein KI-Vorrat fuer dieses Subject.
  String? _aiSubjectName(String stateSubject) {
    final s = stateSubject.trim();
    if (s == 'Mathematik' || s == 'Mathe') return 'Mathematik';
    if (s == 'Deutsch') return 'Deutsch';
    if (s == 'Englisch') return 'Englisch';
    if (s == 'Sachunterricht') return 'Sachunterricht';
    return null; // Lesen/Schreiben/Mixed -> Standard-Generator
  }

  LumoTutorSubject _tutorSubjectFor(String subject) {
    final normalized = subject.trim().toLowerCase();
    if (normalized.contains('mathe')) return LumoTutorSubject.mathematik;
    if (normalized.contains('deutsch') ||
        normalized.contains('rechtschreibung') ||
        normalized.contains('schreiben')) {
      return LumoTutorSubject.deutsch;
    }
    if (normalized.contains('lesen')) return LumoTutorSubject.lesen;
    if (normalized.contains('englisch')) return LumoTutorSubject.englisch;
    if (normalized == 'logik') return LumoTutorSubject.logik;
    return LumoTutorSubject.sachunterricht;
  }

  String get _childFirstName {
    final name = widget.appState.state.childName.trim();
    if (name.isEmpty) return 'Kind';
    return name.split(RegExp(r'\s+')).first;
  }

  String get _experienceTitle {
    final st = widget.appState.state;
    final subject = st.subject;
    if (st.sessionKind == LumoSessionKind.schoolwork) {
      return subject == 'Alle' ? 'Lumo-Schularbeit' : '$subject-Schularbeit';
    }
    if (st.sessionKind == LumoSessionKind.test) {
      return subject == 'Alle' ? 'Lumo-Test' : '$subject-Test';
    }
    if (subject == 'Mathematik') {
      final visual = _task.visual.toLowerCase();
      final story = visual.contains('story') ||
          _task.unit.toLowerCase().contains('geschichte') ||
          _task.prompt.length > 62;
      return story ? 'Rechen-Geschichte' : 'Mathe-Abenteuer';
    }
    return switch (subject) {
      'Deutsch' || 'Rechtschreibung' || 'Schreiben' => 'Wort-Abenteuer',
      'Lesen' => 'Lese-Abenteuer',
      'Englisch' => 'English Adventure',
      'Sachunterricht' => 'Entdecker-Abenteuer',
      'Logik' => 'Denk-Abenteuer',
      'Alle' => 'Lumo-Lernabenteuer',
      _ => '$subject-Abenteuer',
    };
  }

  String get _experienceSubtitle {
    final st = widget.appState.state;
    if (st.sessionKind == LumoSessionKind.schoolwork) {
      return 'Wie in der Schule: konzentriert arbeiten, am Ende gemeinsam auswerten.';
    }
    if (st.sessionKind == LumoSessionKind.test) {
      return 'Zeig, was du schon kannst. Ruhig lesen und selbst entscheiden.';
    }
    return switch (st.subject) {
      'Mathematik' => 'Entdecke Zahlen, löse Aufgaben, werde ein Mathe-Profi!',
      'Deutsch' ||
      'Rechtschreibung' ||
      'Schreiben' =>
        'Entdecke Wörter, Sätze und Sprache – Schritt für Schritt.',
      'Lesen' =>
        'Lies genau, verstehe Geschichten und finde die richtige Spur.',
      'Englisch' => 'Listen, speak, read and learn – mit Lumo an deiner Seite.',
      'Sachunterricht' => 'Entdecke Natur, Technik, Österreich und deine Welt.',
      'Logik' => 'Muster erkennen, kombinieren und clevere Lösungen finden.',
      _ => 'Lernen, entdecken und jeden Tag ein Stück weiterkommen.',
    };
  }

  String get _welcomeForKind {
    switch (widget.appState.state.sessionKind) {
      case LumoSessionKind.quickPractice:
        return 'Arbeite wie im Heft. Ruhig lesen, dann erst antworten.';
      case LumoSessionKind.exerciseSet:
        return 'Wir machen heute zwanzig Aufgaben. Ich merke mir, was dir gut gelingt.';
      case LumoSessionKind.test:
        return 'Testmodus. Lies ruhig und antworte selbst.';
      case LumoSessionKind.schoolwork:
        return 'Wie eine echte Schularbeit. Ich gebe heute keine Hilfe.';
      case LumoSessionKind.tutoring:
        return 'Nachhilfe. Ich schaue genau, welcher Schritt dir hilft.';
    }
  }

  void _loadNextTask({bool resetCounter = false}) {
    _activeSessionScope = _sessionScope;
    _autoAdvanceTimer?.cancel();
    // Keep prompt, answer, progress and renderer on the same checked task.
    _task = _adapter.qualityCheckedTask(_nextTask());
    _rememberTask(_task);
    _taskInstance = _adapter.toTaskInstance(
      task: _task,
      childId: _childId,
      difficulty: _task.difficulty,
    );
    _taskStartedAt = DateTime.now();
    _answered = false;
    _lastCorrect = null;
    _lastRewardDelta = null;
    _lastSkillState = null;
    _lastFeedback = null;
    _tutorHint = null;
    _placeValueLesson = null;
    _sceneRequestSerial = 0;
    _pendingSceneCompletion = null;
    _sceneCompletionError = null;
    _sceneMethod = ExplanationMethod.verbal;
    _requestedHelpLevel = 0;
    _visualAid = null;
    _aiHelpReply = null;
    _aiHelpLoading = false;
    _rechentricks = null;
    _attemptCount = 0;
    _totalTaskAttempts = 0;
    _lastGivenAnswer = null;
    _questionHadWrong = false;
    if (resetCounter) {
      _sessionFinished = false;
      _testFirstTryCorrect = 0;
      _questionNum = 1;
      _attemptCount = 0;
    }
    _publishTaskContext();
  }

  void _publishTaskContext() {
    final context = LumoCompanionTaskContext(
      subject: _task.subject,
      unit: _task.unit,
      prompt: _task.prompt,
      isExam: !_allowHelp,
      answering: !_answered && !_sessionFinished,
      taskId: _taskInstance.taskInstanceId,
      attempts: _totalTaskAttempts,
      helpLevel: _requestedHelpLevel,
      lastAnswer: _lastGivenAnswer,
      lastCorrect: _lastCorrect,
      previousHelp: _tutorHint,
      localHelp: _allowHelp
          ? _taskHints.explain(_task,
              level: (_requestedHelpLevel + 1).clamp(1, 3))
          : null,
      activity: _task.visual.contains('writ') ? 'writing' : 'learning',
      profileGeneration: widget.appState.profileGeneration,
    );
    _tutorCoordinator.enterTask(context.tutorScope);
    _publishedTaskContext = context;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && identical(_publishedTaskContext, context)) {
        LumoCompanionRequests.instance.publishTask(context);
      }
    });
  }

  void _requestTaskHelp() {
    if (!mounted ||
        _activeSessionScope != _sessionScope ||
        !_allowHelp ||
        _answered ||
        _sessionFinished) {
      return;
    }
    _requestedHelpLevel = (_requestedHelpLevel + 1).clamp(1, 3);
    _sceneRequestSerial++;
    final placeValueNumber =
        LumoPlaceValueWorkshop.numberForPrompt(_task.prompt);
    if (_placeValueLesson == null && placeValueNumber != null) {
      final target = const LumoIntelligenceEngine().transferNumber(
          placeValueNumber, widget.appState.learningProfile.sceneMemory);
      if (target != null) {
        _placeValueLesson = PlaceValueLessonSession(
            sourceNumber: placeValueNumber,
            targetNumber: target,
            sourceProblemId: _publishedTaskContext!.tutorScope.problemId,
            sourceTaskId: _taskInstance.taskInstanceId,
            generation: widget.appState.profileGeneration);
      }
    }
    // Additional hints during the new task remain assisted, including requests
    // after all four scene methods have already been tried. Only a displayed
    // scene may change the method attached to its later completion receipt.
    _placeValueLesson?.markTransferHelp();
    final hint = _requestedHelpLevel == 2
        ? _buildTutorHint(_lastGivenAnswer ?? '', const []) ??
            _taskHints.explain(_task, level: 2)
        : _taskHints.explain(_task, level: _requestedHelpLevel);
    if (_requestedHelpLevel >= 3) {
      if (_task.subject == 'Mathematik') {
        _rechentricks = const LumoRechentricks().explain(
            prompt: _task.prompt,
            correctAnswer: '${_taskInstance.correctAnswer}',
            grade: widget.appState.state.grade);
      }
      if (LumoPlaceValueWorkshop.numberForPrompt(_task.prompt) == null) {
        unawaited(_loadVisualAid());
      }
    }
    _lumo.think();
    setState(() => _tutorHint = hint);
    LumoCompanionRequests.instance
        .recordInteraction(LumoInteractionKind.helpRequested);
    _publishTaskContext();
    LumoCompanionRequests.instance.recordLearningEvent(
        LumoLearningEventKind.hintRequested,
        context: _publishedTaskContext);
    LumoCompanionRequests.instance.recordLearningEvent(
        LumoLearningEventKind.hintAccepted,
        context: _publishedTaskContext);
    if (widget.appState.state.settings.voiceEnabled) {
      unawaited(_speakTutorHint(hint));
    }
    if (_cloudHelpAllowed) {
      unawaited(_askAiTutor());
    }
  }

  Future<void> _openNativeLearning() async {
    if (!mounted ||
        _activeSessionScope != _sessionScope ||
        !_allowHelp ||
        _answered ||
        _sessionFinished ||
        _nativeLearningOpen) {
      return;
    }
    final activity = NativeLearningActivity.fromTask(_taskInstance);
    if (activity == null) return;
    final taskId = _taskInstance.taskInstanceId;
    final generation = widget.appState.profileGeneration;
    setState(() {
      _nativeLearningOpen = true;
      // An explicitly requested 3D solution is assistance. The existing
      // result writer receives helpUsed for the following answer.
      _requestedHelpLevel = math.max(1, _requestedHelpLevel);
    });
    _publishTaskContext();
    LumoCompanionRequests.instance.recordLearningEvent(
        LumoLearningEventKind.hintRequested,
        context: _publishedTaskContext);
    try {
      await LumoVoice.instance.stop();
      if (!mounted ||
          widget.appState.profileGeneration != generation ||
          _taskInstance.taskInstanceId != taskId) {
        return;
      }
      await launchLumo3D(context,
          scene: 'learning',
          appState: widget.appState,
          subject: _task.subject,
          learning: activity);
    } finally {
      if (mounted) {
        setState(() => _nativeLearningOpen = false);
        if (widget.appState.profileGeneration == generation &&
            _taskInstance.taskInstanceId == taskId) {
          _publishTaskContext();
        }
      }
    }
  }

  /// Spoken lessons use the shipped warm German Lumo-Frei voice first.
  /// Arbitrary task hints are only synthesized after the parent accepts
  /// the local model license; never silently switch to a different voice.
  Future<void> _speakTutorHint(String text,
      {bool explainAvailability = false}) async {
    final generation = widget.appState.profileGeneration;
    final taskId = _taskInstance.taskInstanceId;
    bool isCurrent() =>
        mounted &&
        generation == widget.appState.profileGeneration &&
        _activeSessionScope == _sessionScope &&
        taskId == _taskInstance.taskInstanceId;
    if (!isCurrent()) return;
    final settings = widget.appState.state.settings;
    if (!settings.voiceEnabled || !LumoVoice.instance.isEnabled) {
      if (explainAvailability && mounted) {
        _showTutorSpeechNotice(
          'Lumos Stimme ist ausgeschaltet. Bitte im Elternbereich '
          'unter Ton und Stimme aktivieren.',
        );
      }
      return;
    }

    await LumoVoiceClips.ensureFreeLoaded();
    if (!isCurrent()) return;
    final recorded = LumoVoiceClips.freeLookup(text) != null;
    if (!recorded && !settings.localVoiceLicenseAccepted) {
      // This complete German phrase is in the signed local catalog. The
      // explanation stays readable instead of disappearing or using TTS.
      unawaited(LumoVoice.instance
          .speak('Hier ist ein kleiner Tipp:', style: VoiceStyle.explain));
      if (explainAvailability) {
        _showTutorSpeechNotice(
          'Lumo kann die Einleitung sprechen. Für ganze neue Erklärungen '
          'bitte im Elternbereich unter Ton und Stimme '
          '„Neue Sätze offline vorlesen“ freigeben.',
        );
      }
      return;
    }
    if (!recorded && !await LumoVoice.instance.localSpeechAvailable()) {
      if (isCurrent()) {
        _showTutorSpeechNotice(
          'Die lokale Lumo-Sprachausgabe ist auf diesem Gerät '
          'noch nicht verfügbar. Der Tipp bleibt lesbar.',
        );
      }
      return;
    }
    if (!isCurrent()) return;
    unawaited(LumoVoice.instance.speak(text, style: VoiceStyle.explain));
  }

  void _showTutorSpeechNotice(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 7),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  bool get _cloudHelpAllowed =>
      widget.appState.state.settings.lumoAiLearningAccess.allows(
          _task.subject == 'Lesen'
              ? LumoAiLearningArea.readingHelp
              : LumoAiLearningArea.taskHelp);

  /// Holt KI-Hilfe vom Cloud-Tutor fuer die aktuelle Aufgabe.
  /// Heinz' Wunsch: pro Bereich zugeschnittener Helfer.
  /// Wenn aiProxyEnabled = false: lokaler Hinweis wird gezeigt.
  Future<void> _askAiTutor() async {
    if (_aiHelpLoading || !_allowHelp || _answered || !_cloudHelpAllowed) {
      return;
    }
    if (!mounted) return;
    final generation = widget.appState.profileGeneration;
    final taskId = _taskInstance.taskInstanceId;
    setState(() => _aiHelpLoading = true);
    try {
      // Bereich basierend auf Subject und Unit waehlen.
      final subject = _task.subject;
      final context = _aiContextForSubject(subject);
      // Konkrete Frage an Lumo: "Hilf mir bei dieser Aufgabe".
      final question = 'Aufgabe: "${_task.prompt}" '
          'Mein bisheriger Versuch: ${_attemptCount > 0 ? 'noch nicht richtig' : 'noch keiner'}. '
          'Bitte gib mir EINEN kleinen Tipp, ohne die Loesung zu verraten.';
      final response = await widget.aiProxy.ask(
        settings: widget.appState.state.settings,
        state: widget.appState.state,
        message: question,
        context: context,
        extras: <String, Object?>{
          'subject': _task.subject,
          'unit': _task.unit,
          'attempt': _attemptCount,
          'visual': _task.visual,
        },
      );
      if (!mounted ||
          generation != widget.appState.profileGeneration ||
          _taskInstance.taskInstanceId != taskId) {
        return;
      }
      if (_answered || !_allowHelp || !_cloudHelpAllowed) {
        setState(() => _aiHelpLoading = false);
        return;
      }
      setState(() {
        // Network or provider failures keep the actual local task help visible.
        _aiHelpReply = response.isCloudAnswer ? response.reply : null;
        _aiHelpLoading = false;
      });
      // Antwort gleich vorlesen, damit auch nicht-lesende Kinder es hoeren.
      if (response.isCloudAnswer &&
          widget.appState.state.settings.voiceEnabled) {
        unawaited(
          LumoVoice.instance.speak(response.reply, style: VoiceStyle.explain),
        );
      }
    } catch (e) {
      if (!mounted ||
          generation != widget.appState.profileGeneration ||
          _taskInstance.taskInstanceId != taskId) {
        return;
      }
      setState(() {
        // The immediate offline explanation remains usable after network errors.
        _aiHelpReply = null;
        _aiHelpLoading = false;
      });
    }
  }

  LumoAiContext _aiContextForSubject(String subject) {
    switch (subject.toLowerCase()) {
      case 'mathematik':
      case 'mathe':
        return LumoAiContext.mathCoach;
      case 'deutsch':
      case 'rechtschreibung':
        return LumoAiContext.writingHelper;
      case 'lesen':
        return LumoAiContext.readingBuddy;
      case 'sachunterricht':
      case 'natur':
        return LumoAiContext.scienceExplorer;
      default:
        return LumoAiContext.learningTutor;
    }
  }

  String get _childId {
    final st = widget.appState.state;
    final safeName = st.childName.trim().isEmpty
        ? 'kind'
        : st.childName.trim().toLowerCase().replaceAll(
              RegExp(r'[^a-z0-9]+'),
              '_',
            );
    return 'local_${safeName}_${st.grade}';
  }

  /// Klassenstufe der Aufgaben: Im Test wählt das Kind leicht, mittel oder
  /// schwer (eine Klasse darunter, die eigene, eine darüber).
  int get _taskGrade {
    final st = widget.appState.state;
    if (st.sessionKind != LumoSessionKind.test) return st.grade;
    return (st.grade + st.testLevel).clamp(1, 4).toInt();
  }

  LumoTask _nextTask() {
    final st = widget.appState.state;
    final taskGrade = _taskGrade;
    final factorySubject = _factorySubjectFor(st.subject, st.unit);
    final factoryUnit = _factoryUnitFor(st.subject, st.unit);

    // Nachhilfelehrer-Bypass: wenn KI-Vorrat vorhanden ist und das
    // Subject Mathe oder Deutsch ist, bevorzuge eine KI-Aufgabe.
    // Kein Crash bei Validierungs-Problemen - dann faellt es einfach
    // auf den Standard-Generator zurueck.
    final aiSubject = _aiSubjectName(st.subject);
    LumoTask? relaxedFallback;
    if (aiSubject != null &&
        factoryUnit == 'Alle' &&
        _aiQueueScope == _currentAiScope &&
        taskGrade == st.grade &&
        _aiDraftQueue.isNotEmpty) {
      while (_aiDraftQueue.isNotEmpty) {
        final draft = _aiDraftQueue.removeAt(0);
        // Cache-Markierung im Hintergrund
        _aiCache.markConsumed(
          childId: _childId,
          subject: aiSubject,
          grade: st.grade,
          prompt: draft.prompt,
        );
        final aiTask = _draftToLumoTask(
          draft,
          st.grade,
          factorySubject,
          factoryUnit,
        );
        if (aiTask == null) continue;
        if (_canUseTask(aiTask, relaxed: false)) return aiTask;
        relaxedFallback ??= _canUseTask(aiTask, relaxed: true) ? aiTask : null;
      }
      // Wenn der KI-Vorrat nur Wiederholungen enthaelt, ziehen wir lieber
      // lokal weiter, statt dem Kind direkt wieder dieselbe Aufgabe zu zeigen.
    }

    final avoidUnits =
        factoryUnit == 'Alle' ? _recentUnits.toSet() : <String>{};
    LumoTask? fallback;

    for (var attempt = 0; attempt < 80; attempt++) {
      final task = _factory.next(
        grade: taskGrade,
        subject: factorySubject,
        unit: factoryUnit,
        weakSkills: st.weakSkills,
        avoidUnits: attempt < 40 ? avoidUnits : const <String>{},
        childName: st.childName,
      );

      if (!_taskQualityGuard.validate(task)) continue;

      if (!_wasRecentlySeen(task)) fallback ??= task;

      // Direkte und persistierte Wiederholungen verhindern: gleicher Task
      // oder gleiche Aufgaben-Familie -> weiter ziehen.
      if (_wasRecentlySeen(task)) continue;

      // SessionVarietyGuard: prueft auch Antwort-/Muster-/Wort-Wiederholung,
      // nicht nur den exakten Aufgaben-Key. Bei strikter Pruefung erst.
      if (_varietyGuard.allows(task, relaxed: false)) {
        return task;
      }
      // Falls strikt nicht passt, merken wir uns den ersten Treffer der
      // wenigstens beim relaxed-Check durchkommt.
      relaxedFallback ??=
          _varietyGuard.allows(task, relaxed: true) ? task : null;
    }

    // Fallback-Reihenfolge:
    //   1. relaxed-Variante (anderes Muster, evtl. gleiches Wort)
    //   2. allgemeiner Fallback aus dem ersten Versuch
    //   3. komplett neuer Generator-Aufruf ohne Vermeidungs-Set
    return relaxedFallback ??
        fallback ??
        _factory.next(
          grade: taskGrade,
          subject: factorySubject == 'Lesen' ? 'Deutsch' : factorySubject,
          unit: factoryUnit == 'Aktives Lesen' ? 'Satz verstehen' : factoryUnit,
          weakSkills: st.weakSkills,
          avoidUnits: const <String>{},
          childName: st.childName,
        );
  }

  /// Wandelt einen vom Server gelieferten Draft in einen LumoTask um.
  /// Liefert null wenn die Pflichtfelder nicht passen oder der TaskQualityGuard
  /// die Aufgabe als fachlich/strukturell unsicher bewertet.
  LumoTask? _draftToLumoTask(
    LumoAiTaskDraft draft,
    int grade,
    String subject,
    String unit,
  ) {
    if (draft.prompt.trim().isEmpty || draft.answer.trim().isEmpty) return null;
    if (draft.choices.length < 2) return null;
    if (!draft.choices.any(
      (c) => c.trim().toLowerCase() == draft.answer.trim().toLowerCase(),
    )) {
      return null;
    }
    final probe = LumoTask(
      id: 'ai_${DateTime.now().microsecondsSinceEpoch}',
      grade: grade,
      subject: subject == 'Alle' ? 'Mathematik' : subject,
      unit: unit == 'Alle' ? 'KI Nachhilfe' : unit,
      prompt: draft.prompt,
      answer: draft.answer,
      choices: draft.choices,
      explanation: draft.explanation.isEmpty
          ? 'Lumo erklärt dir das gleich Schritt für Schritt.'
          : draft.explanation,
      visual: draft.visual,
      difficulty: grade,
      missionTag: 'ai_cache',
    );
    if (!_taskQualityGuard.validate(probe)) return null;
    return probe;
  }

  String _factorySubjectFor(String subject, String unit) {
    final normalizedUnit = unit.trim().toLowerCase();
    if (normalizedUnit == 'schreiben üben' ||
        normalizedUnit == 'schreiben ueben') {
      return 'Schreiben';
    }
    if (normalizedUnit == 'aktives lesen' || normalizedUnit == 'vorlesen') {
      return 'Lesen';
    }
    return subject == 'Alle Themen' ? 'Alle' : subject;
  }

  String _factoryUnitFor(String subject, String unit) {
    final normalized = unit.trim().toLowerCase();
    if (normalized.isEmpty || normalized == 'alle themen') return 'Alle';

    const aliases = <String, String>{
      'wörter lesen': 'Satz verstehen',
      'woerter lesen': 'Satz verstehen',
      'buchstaben finden': 'Anfangslaute',
      'reime erkennen': 'Reime',
      'satz bilden': 'Satz bauen',
      'schreiben üben': 'Buchstaben nachspuren',
      'schreiben ueben': 'Buchstaben nachspuren',
      'silben klatschen': 'Silben',
      'mengen zählen': 'Plus bis 10',
      'mengen zaehlen': 'Plus bis 10',
      'rechenhaus': 'Rechenhaeuser',
      'zahlenstrahl': 'Zahlenreihe',
      'zwanzigerfeld': 'Zehner und Einer',
    };
    return aliases[normalized] ?? unit;
  }

  void _rememberTask(LumoTask task) {
    final markers = _taskMemoryKeys(task);
    _lastTaskMarkers = markers.toSet();
    _sessionTaskKeys.addAll(markers);
    for (final marker in markers) {
      _recentTaskKeys.remove(marker);
      _recentTaskKeys.add(marker);
    }
    while (_recentTaskKeys.length > _recentTaskMemory) {
      _recentTaskKeys.removeAt(0);
    }

    // Variety-Guard merkt sich die Aufgabe ueber den exakten Key hinaus
    // (Antwort, Prompt-Muster, Schluesselwoerter).
    _varietyGuard.remember(task);

    _recentUnits.remove(task.unit);
    _recentUnits.add(task.unit);
    while (_recentUnits.length > _recentUnitMemory) {
      _recentUnits.removeAt(0);
    }

    _recentRepo
        .saveTaskKeys(
          childId: _childId,
          subject: widget.appState.state.subject,
          keys: List<String>.from(_recentTaskKeys),
        )
        .ignore();
    _recentRepo
        .saveUnits(
          childId: _childId,
          subject: widget.appState.state.subject,
          units: List<String>.from(_recentUnits),
        )
        .ignore();
  }

  bool _canUseTask(LumoTask task, {required bool relaxed}) {
    if (_wasRecentlySeen(task)) return false;
    return _varietyGuard.allows(task, relaxed: relaxed);
  }

  bool _wasRecentlySeen(LumoTask task) {
    final markers = _taskMemoryKeys(task);
    return markers.any(
      (marker) =>
          _lastTaskMarkers.contains(marker) ||
          _sessionTaskKeys.contains(marker) ||
          _recentTaskKeys.contains(marker),
    );
  }

  List<String> _taskMemoryKeys(LumoTask task) =>
      _varietyGuard.taskMemoryKeys(task);

  void _answerAdaptive(AdaptiveTaskAnswer answer) {
    if (_answered ||
        _activeSessionScope != _sessionScope ||
        answer.task.taskInstanceId != _taskInstance.taskInstanceId) {
      return;
    }
    _completeAnswer(
      correct: answer.correct,
      hintUsed: _allowHelp &&
          (answer.hintUsed || _tutorHint != null || _aiHelpReply != null),
      answerGiven: answer.answer,
    );
  }

  void _answerWriting(WritingTaskResult result) {
    if (!mounted ||
        _answered ||
        _activeSessionScope != _sessionScope ||
        result.task.taskInstanceId != _taskInstance.taskInstanceId) {
      return;
    }
    final typedAnswer = result.typedAnswer;
    if (typedAnswer != null) {
      // Keyboard-mode is actual spelling practice, not handwriting.
      // Compare real text directly, without manufacturing an ink score.
      final target = WritingTargetParser.parse(result.task.prompt);
      String normalize(String value) =>
          value.trim().replaceAll(RegExp(r'\s+'), ' ').toLowerCase();
      _completeAnswer(
        correct: normalize(typedAnswer) == normalize(target),
        hintUsed: false,
        answerGiven: typedAnswer,
      );
      return;
    }
    if (result.skipped) {
      // "Andere Aufgabe": a different task at the same position. No XP, no
      // wrong answer and no progress that was not earned.
      if (!mounted) return;
      setState(() => _loadNextTask());
      return;
    }
    // Handwriting is ungraded practice: a real attempt in the trainer always
    // leads on. Low contour scores never block progress or become a grade.
    // The typed-answer branch above remains an assessed spelling task.
    _nextQuestion();
  }

  void _speakWritingPraise(String text) {
    if (!widget.appState.state.settings.voiceEnabled) return;
    LumoVoice.instance.speak(text);
  }

  /// 2026-06-05 Iter 20: Form-Nachzeichnen-Aufgaben.
  /// Der Canvas evaluiert intern (bounding box + Ecken-Zahl) und
  /// liefert correct/feedback. Hier wird das in den Standard-Pfad
  /// eingespeist.
  void _answerShapeTrace(ShapeTraceTaskResult result) {
    if (!mounted ||
        _answered ||
        _activeSessionScope != _sessionScope ||
        result.task.taskInstanceId != _taskInstance.taskInstanceId) {
      return;
    }
    _completeAnswer(
      correct: result.correct,
      hintUsed: false,
      answerGiven: 'shape_trace:${result.shape}',
    );
  }

  String? _buildTutorHint(Object answerGiven, List<ErrorType> errorTypes) {
    if (!_allowHelp || _requestedHelpLevel == 0) return null;
    final helpLevel = _requestedHelpLevel >= 3
        ? LumoTutorHelpLevel.visualExplanation
        : LumoTutorHelpLevel.guidedStep;
    const mode = LumoTutorMode.mistakeExplanation;
    final request = LumoTutorRequest(
      mode: mode,
      subject: _tutorSubjectFor(_task.subject),
      grade: widget.appState.state.grade,
      unit: _task.unit,
      helpLevel: helpLevel,
      childFirstName: _childFirstName,
      currentPrompt: _task.prompt,
      childAnswer: '$answerGiven',
      correctAnswer: '${_taskInstance.correctAnswer}',
      attemptCount: _attemptCount,
      weaknessTags: errorTypes.map((type) => type.name).toList(growable: false),
    );
    final response = _localTutorEngine.buildLocalFallback(request);
    return response.shortHint ?? response.explanation ?? response.speech;
  }

  /// Laedt die lokale Bildhilfe asynchron und setzt sie via setState.
  /// Wird ausgeloest wenn das Kind nach 5+ Versuchen immer noch falsch
  /// liegt - dann zeigt Lumo eine bildliche Erklaerung mit Schritten.
  /// Kein Cloud-Aufruf, keine Credit-Kosten.
  Future<void> _loadVisualAid() async {
    final taskId = _taskInstance.taskInstanceId;
    final generation = widget.appState.profileGeneration;
    try {
      final aid = await _visualAidService.buildAid(
        task: _task,
        grade: widget.appState.state.grade,
        attemptCount: _attemptCount,
        // settings sind nur fuer den Cloud-Pfad relevant. Wir uebergeben
        // bewusst die aktuellen Settings - shouldUsePaidImage prueft
        // intern ob der Cloud-Pfad freigegeben ist. Default: nein.
        settings:
            widget.appState.state.settings.copyWith(aiProxyEnabled: false),
        childId: _childId,
        childName: _childFirstName,
        childRequestedImage: false,
      );
      if (!mounted || _taskInstance.taskInstanceId != taskId) return;
      if (generation != widget.appState.profileGeneration ||
          !_allowHelp ||
          _requestedHelpLevel < 3) {
        return;
      }
      setState(() => _visualAid = aid);
    } catch (_) {
      // Bildhilfe ist optional. Wenn sie nicht laedt, gehts ohne weiter.
    }
  }

  void _completeAnswer({
    required bool correct,
    required bool hintUsed,
    required Object answerGiven,
    double? handwritingScore,
  }) {
    if (!mounted || _activeSessionScope != _sessionScope) return;
    hintUsed = _allowHelp &&
        (hintUsed ||
            _requestedHelpLevel > 0 ||
            _tutorCoordinator.helpLevel > 0);
    _totalTaskAttempts++;
    _lastGivenAnswer = '$answerGiven';
    _publishTaskContext();
    LumoCompanionRequests.instance
        .recordInteraction(LumoInteractionKind.answerChecked);
    if (_totalTaskAttempts > 1) {
      LumoCompanionRequests.instance.recordLearningEvent(
          LumoLearningEventKind.taskRepeated,
          context: _publishedTaskContext);
    }
    LumoCompanionRequests.instance.recordLearningEvent(
        LumoLearningEventKind.answerSubmitted,
        context: _publishedTaskContext);
    final before = _skillStates[_taskInstance.skillId.value] ??
        SkillState(
          childId: _childId,
          skillId: _taskInstance.skillId,
          currentDifficulty: widget.appState.state.grade,
          masteryScore: .20,
          repetitionNeed: .50,
        );

    final responseTimeMs =
        DateTime.now().difference(_taskStartedAt).inMilliseconds;
    final errorTypes = correct || hintUsed
        ? const <ErrorType>[]
        : _legacyErrorTypes(answerGiven);
    final firstAttempt = _attemptCount == 0;
    if (widget.appState.state.sessionKind == LumoSessionKind.test) {
      if (correct && !_questionHadWrong) _testFirstTryCorrect++;
      if (!correct) _questionHadWrong = true;
    }
    if (correct) {
      _attemptCount = 0;
      // Heinz' Wunsch: Konfetti bei Erfolgen. Wird ueber Trigger-Int
      // ausgeloest, damit der CustomPainter neu animiert.
      _confettiTrigger++;
      _lumo.cheer();
      HapticFeedback.mediumImpact();
    } else {
      _lumo.comfort();
      if (_allowHelp) _attemptCount++;
    }

    // Phase 2 - Lumo Fehlerdetektiv. Erkennt beim selbstständigen Fehler
    // die wahrscheinlichste Fehlerart und gibt kindgerechtes Feedback.
    // Begleitete Versuche bleiben im Verlauf, ohne als Schwäche zu gelten.
    final nextTutorHint = _tutorHint;
    if (!correct && !hintUsed) {
      final detection = const ErrorDetective().analyze(
        subject: _task.subject,
        prompt: _task.prompt,
        correctAnswer: '${_taskInstance.correctAnswer}',
        givenAnswer: '$answerGiven',
      );
      if (detection.confidence >= 0.65) {
        // Fehlerart zaehlen + persistieren fuer die DNA-Anzeige in Phase 1.
        final key = detection.pattern.germanShortLabel;
        _errorBreakdown[key] = (_errorBreakdown[key] ?? 0) + 1;
        unawaited(widget.appState.recordLearningErrorType(key));
      }
    }
    final result = TaskResult(
      taskInstanceId: _taskInstance.taskInstanceId,
      childId: _childId,
      skillId: _taskInstance.skillId,
      correct: correct,
      responseTimeMs: responseTimeMs,
      helpUsed: hintUsed,
      detectedErrorTypes: errorTypes,
      handwritingScore: handwritingScore,
      frustrationSignal: !correct && responseTimeMs > 18000,
    );
    final after = _resultHandler.applyResult(before: before, result: result);
    final rewardDelta = _rewardEngine.calculateAnswerReward(
      result: result,
      before: before,
      after: after,
      allowRetry: _allowHelp,
      firstAttempt: firstAttempt,
      mode: _learningModeForSession,
      completedSession: _questionNum >= _totalQuestions,
    );

    final feedback = _feedbackEngine.record(
      LumoInteractionEvent(
        subject: _task.subject,
        unit: _task.unit,
        prompt: _task.prompt,
        correctAnswer: _taskInstance.correctAnswer,
        givenAnswer: answerGiven,
        correct: correct,
        helpUsed: hintUsed,
        responseTimeMs: responseTimeMs,
        errorTypes: errorTypes,
        masteryBefore: before.masteryScore,
        masteryAfter: after.masteryScore,
        taskIndex: _questionNum,
        totalTasks: _totalQuestions,
        sessionKind: widget.appState.state.sessionKind.name,
        handwritingScore: handwritingScore,
      ),
    );

    _skillStates[_taskInstance.skillId.value] = after;

    setState(() {
      _answered = correct || !_allowHelp;
      _lastCorrect = correct;
      _lastRewardDelta = rewardDelta;
      _lastSkillState = after;
      _lastFeedback = feedback;
      _tutorHint = nextTutorHint;
    });
    _publishTaskContext();
    final evidence = LumoCompanionRequests.instance.recordLearningEvent(
        correct
            ? LumoLearningEventKind.answerCorrect
            : LumoLearningEventKind.answerIncorrect,
        context: _publishedTaskContext);
    if (evidence != null) {
      unawaited(widget.appState.recordTutorEvidence(
          subject: _task.subject, unit: _task.unit, evidence: evidence));
    }

    if (correct) {
      widget.appState.correctAnswer(_task.unit,
          stars: rewardDelta.stars, xp: rewardDelta.xp);
      widget.appState.recordLearningAnswer(
        subject: _task.subject,
        unit: _task.unit,
        correct: true,
        hintUsed: hintUsed,
        taskId: _taskInstance.taskInstanceId,
        prompt: _task.prompt,
        given: '$answerGiven',
        expected: '${_taskInstance.correctAnswer}',
        durationMs: responseTimeMs,
      );
      LumoVoice.instance.speak(feedback.spokenText);
      _autoAdvanceTimer = Timer(
        Duration(milliseconds: feedback.autoAdvanceDelayMs),
        _nextQuestion,
      );
    } else {
      widget.appState.wrongAnswer(_task.unit, independentEvidence: !hintUsed);
      if (!_allowHelp) {
        widget.appState.addStars(rewardDelta.stars);
        widget.appState.addXp(rewardDelta.xp);
      }
      widget.appState.recordLearningAnswer(
        subject: _task.subject,
        unit: _task.unit,
        correct: false,
        hintUsed: hintUsed,
        taskId: _taskInstance.taskInstanceId,
        prompt: _task.prompt,
        given: '$answerGiven',
        expected: '${_taskInstance.correctAnswer}',
        durationMs: responseTimeMs,
      );
      LumoVoice.instance.speak(feedback.spokenText);
    }
  }

  LearningMode get _learningModeForSession {
    switch (widget.appState.state.sessionKind) {
      case LumoSessionKind.quickPractice:
      case LumoSessionKind.exerciseSet:
        return LearningMode.practice;
      case LumoSessionKind.test:
        return LearningMode.subjectTest;
      case LumoSessionKind.schoolwork:
        return LearningMode.exam;
      case LumoSessionKind.tutoring:
        return LearningMode.tutoring;
    }
  }

  List<ErrorType> _legacyErrorTypes(Object answerGiven) {
    if (_task.subject == 'Mathematik') {
      final given = int.tryParse(
        '$answerGiven'.replaceAll(RegExp(r'[^0-9-]'), ''),
      );
      final expected = int.tryParse(
        '${_taskInstance.correctAnswer}'.replaceAll(RegExp(r'[^0-9-]'), ''),
      );
      if (given != null && expected != null && (given - expected).abs() == 1) {
        return const <ErrorType>[ErrorType.countingError];
      }
      if (_task.prompt.contains('+') || _task.prompt.contains('-')) {
        return const <ErrorType>[ErrorType.plusMinusConfusion];
      }
      return const <ErrorType>[ErrorType.quantityError];
    }
    if (_task.unit.toLowerCase().contains('silben')) {
      return const <ErrorType>[ErrorType.syllableCountWrong];
    }
    if (_task.unit.toLowerCase().contains('laut') ||
        _task.unit.toLowerCase().contains('st oder sp')) {
      return const <ErrorType>[ErrorType.soundMisread];
    }
    if (_task.unit.toLowerCase().contains('schreiben') ||
        _task.unit.toLowerCase().contains('mehrzahl')) {
      return const <ErrorType>[ErrorType.wordImageMismatch];
    }
    return const <ErrorType>[ErrorType.conceptConfusion];
  }

  void _nextQuestion() {
    if (!mounted || _activeSessionScope != _sessionScope) return;
    _autoAdvanceTimer?.cancel();
    if (_questionNum >= _totalQuestions) {
      final st = widget.appState.state;
      if (st.sessionKind == LumoSessionKind.test) {
        unawaited(const TestResultRepository().record(
          st.childName,
          TestResult(
            subject: st.subject,
            correct: _testFirstTryCorrect,
            total: _totalQuestions,
            finishedAt: DateTime.now(),
          ),
        ));
      }
      setState(() => _sessionFinished = true);
      _publishTaskContext();
      LumoCompanionRequests.instance.recordLearningEvent(
          LumoLearningEventKind.lessonCompleted,
          context: _publishedTaskContext);
      return;
    }
    setState(() {
      final nextQuestion =
          _questionNum < _totalQuestions ? _questionNum + 1 : 1;
      if (nextQuestion == 1) {
        _attemptCount = 0;
      }
      _questionNum = nextQuestion;
      _loadNextTask(resetCounter: false);
    });
  }

  @override
  void dispose() {
    LumoCompanionRequests.instance.helpRequested
        .removeListener(_requestTaskHelp);
    final published = _publishedTaskContext;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final requests = LumoCompanionRequests.instance;
      if (identical(requests.taskContext.value, published)) {
        requests.clearTask(published);
      }
    });
    _autoAdvanceTimer?.cancel();
    _lumo.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final st = widget.appState.state;
    if (_sessionFinished) {
      // Diese Anzeige verwendet ausschließlich echte Konto-/Lernwerte.
      // Keine erfundenen "+25 XP" oder vorgetäuschten Freischaltungen.
      Widget stat(IconData icon, String label, String value, Color accent) {
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 12),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
                colors: [Color(0xEE154886), Color(0xEE081D43)]),
            borderRadius: BorderRadius.circular(19),
            border: Border.all(color: accent.withValues(alpha: .65)),
            boxShadow: [
              BoxShadow(color: accent.withValues(alpha: .16), blurRadius: 15)
            ],
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, color: accent, size: 27),
            const SizedBox(height: 6),
            Text(value,
                style: const TextStyle(
                    fontFamily: 'Nunito',
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 21)),
            Text(label,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontFamily: 'Nunito',
                    color: LumoVisualTokens.muted,
                    fontWeight: FontWeight.w800,
                    fontSize: 11)),
          ]),
        );
      }

      final header = LumoGlassCard(
        padding: const EdgeInsets.fromLTRB(14, 16, 14, 17),
        radius: 25,
        child: Column(children: [
          Row(children: [
            LumoCharacter(
              pose: LumoDesignFoxPose.cheer,
              size: 112,
              controller: _lumo,
              reduceMotion:
                  st.settings.reduceAnimations || st.settings.calmMode,
              onTap: _lumo.cheer,
            ),
            const SizedBox(width: 6),
            const Expanded(
                child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Einheit beendet',
                    style: TextStyle(
                        fontFamily: 'Nunito',
                        color: LumoVisualTokens.cyanBright,
                        fontWeight: FontWeight.w900,
                        fontSize: 13)),
                SizedBox(height: 4),
                Text('Lektion abgeschlossen!',
                    style: TextStyle(
                        fontFamily: 'Nunito',
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 24)),
                SizedBox(height: 4),
                Text('Super gemacht – weiter so!',
                    style: TextStyle(
                        fontFamily: 'Nunito',
                        color: LumoVisualTokens.muted,
                        fontWeight: FontWeight.w700,
                        fontSize: 12)),
              ],
            )),
          ]),
          const SizedBox(height: 10),
          Text('Du hast $_totalQuestions Aufgaben bearbeitet.',
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontFamily: 'Nunito',
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                  fontSize: 14)),
          const SizedBox(height: 15),
          Row(children: [
            Expanded(
                child: stat(Icons.star_rounded, 'Sterne gesamt',
                    st.stars.toString(), LumoVisualTokens.gold)),
            const SizedBox(width: 8),
            Expanded(
                child: stat(Icons.bolt_rounded, 'XP gesamt', st.xp.toString(),
                    LumoVisualTokens.cyanBright)),
            const SizedBox(width: 8),
            Expanded(
                child: stat(
                    Icons.local_fire_department_rounded,
                    'Lerntage in Folge',
                    widget.appState.learningStreakDays().toString(),
                    const Color(0xFFFFB36D))),
          ]),
          const SizedBox(height: 18),
          SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: LumoVisualTokens.cyanBright,
                  foregroundColor: LumoVisualTokens.night,
                  minimumSize: const Size(48, 56),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(17)),
                ),
                onPressed: () => setState(() {
                  _sessionTaskKeys.clear();
                  _loadNextTask(resetCounter: true);
                }),
                icon: const Icon(Icons.play_arrow_rounded),
                label: const Text('Neue Einheit starten',
                    style: TextStyle(
                        fontFamily: 'Nunito', fontWeight: FontWeight.w900)),
              )),
          const SizedBox(height: 7),
          const Text('Du kannst im Menü auch ein anderes Thema auswählen.',
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontFamily: 'Nunito',
                  color: LumoVisualTokens.muted,
                  fontWeight: FontWeight.w700,
                  fontSize: 11)),
        ]),
      );
      final tree = LumoLearningTreeCard(
        skills: widget.appState.learningSkills(),
        compact: true,
        onOpenWorld: () => Navigator.of(context).push(
          MaterialPageRoute<void>(
            builder: (_) => LumoWeltScreen(appState: widget.appState),
          ),
        ),
      );
      return LayoutBuilder(builder: (context, constraints) {
        final wide = constraints.maxWidth >= 760;
        return Center(
            child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 950),
            child: wide
                ? Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Expanded(child: header),
                    const SizedBox(width: 15),
                    Expanded(child: tree),
                  ])
                : Column(children: [
                    header,
                    const SizedBox(height: 13),
                    tree,
                  ]),
          ),
        ));
      });
    }
    final title = _experienceTitle;
    final experienceSubtitle = _experienceSubtitle;
    // prettifyUnit setzt Umlaute in Code-stabilen Unit-Namen wieder ein
    // (z.B. 'Rechenhaeuser' -> 'Rechenhäuser') ohne die internen Keys
    // zu aendern, die als Lookup in template-Maps weiter funktionieren.
    final unitDisplay =
        st.unit == 'Alle' ? 'alle Themen' : Curriculum.prettifyUnit(st.unit);
    final chip = st.subject == 'Alle'
        ? 'Klasse ${st.grade} • adaptiv'
        : '${st.subject} • $unitDisplay';
    final progressTitle =
        st.subject == 'Mathematik' ? 'Mathe-Abenteuer • $unitDisplay' : chip;

    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 560;
        // Stack mit Confetti-Overlay: bei richtigen Antworten regnet es
        // physikalisch korrektes Konfetti (Newton-Schwerkraft + Luftwiderstand)
        // ueber den gesamten Inhalt.
        return Stack(
          children: [
            SingleChildScrollView(
              // Unten Platz für Lumos Fuchs-Knopf, damit er keine Antwort verdeckt.
              padding: EdgeInsets.fromLTRB(
                  compact ? 14 : 26, compact ? 10 : 26, compact ? 14 : 26, 80),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 840),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  title,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontFamily: 'Nunito',
                                    fontSize: 28,
                                    fontWeight: FontWeight.w900,
                                    color: LumoVisualTokens.white,
                                    height: 1.05,
                                    shadows: [
                                      Shadow(
                                          color: Color(0x88000000),
                                          blurRadius: 8)
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  experienceSubtitle,
                                  style: const TextStyle(
                                    fontFamily: 'Nunito',
                                    fontSize: 13,
                                    fontWeight: FontWeight.w900,
                                    color: LumoVisualTokens.cyanBright,
                                    height: 1.3,
                                    shadows: [
                                      Shadow(
                                          color: Color(0xCC000000),
                                          blurRadius: 8)
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 3),
                                Text(
                                  _welcomeForKind,
                                  style: const TextStyle(
                                    fontFamily: 'Nunito',
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    color: LumoVisualTokens.muted,
                                    height: 1.25,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          // Vorlesen: runder Glasknopf wie in den Zielbildern.
                          Material(
                            color: const Color(0xFF1E6FD9),
                            shape: const CircleBorder(
                                side: BorderSide(
                                    color: LumoVisualTokens.cyanBright)),
                            child: IconButton(
                              tooltip: 'Aufgabe vorlesen',
                              icon: const Icon(Icons.volume_up_rounded,
                                  color: Colors.white, size: 24),
                              onPressed: () {
                                _lumo.talk();
                                unawaited(_speakTutorHint(
                                  _task.prompt,
                                  explainAvailability: true,
                                ));
                              },
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      _LessonProgressRow(
                        currentStep: _questionNum,
                        totalSteps: _totalQuestions,
                        subject: progressTitle,
                        lumo: _lumo,
                        reduceMotion: st.settings.reduceAnimations ||
                            st.settings.calmMode ||
                            MediaQuery.disableAnimationsOf(context),
                      ),
                      if (_rechentricks != null) ...[
                        const SizedBox(height: 14),
                        RechentricksMentorCard(explanation: _rechentricks!),
                      ],
                      if (_allowHelp &&
                          !_answered &&
                          _tutorCoordinator.shouldOffer) ...[
                        const SizedBox(height: 14),
                        LumoTutorOfferCard(
                          reduceMotion: st.settings.reduceAnimations ||
                              st.settings.calmMode,
                          onAccept: _requestTaskHelp,
                          onDecline: () {
                            setState(() => LumoCompanionRequests.instance
                                .recordLearningEvent(
                                    LumoLearningEventKind.hintDeclined,
                                    context: _publishedTaskContext));
                          },
                        ),
                      ],
                      if (widget.appState.tutorSaveError != null) ...[
                        Text(widget.appState.tutorSaveError!,
                            style: const TextStyle(color: Colors.white)),
                        TextButton(
                            onPressed: () =>
                                unawaited(widget.appState.flushTutorEvidence()),
                            style: TextButton.styleFrom(
                                minimumSize: const Size(48, 48)),
                            child: const Text('Lernschritt erneut speichern')),
                      ],
                      if (_tutorHint != null) ...[
                        const SizedBox(height: 14),
                        LumoTutorHintCard(
                          text: _tutorHint!,
                          reduceMotion: st.settings.reduceAnimations ||
                              st.settings.calmMode,
                          onSpeak: () => unawaited(_speakTutorHint(_tutorHint!,
                              explainAvailability: true)),
                        ),
                      ],
                      if (_allowHelp &&
                          !_answered &&
                          NativeLearningActivity.fromTask(_taskInstance) !=
                              null) ...[
                        const SizedBox(height: 12),
                        FilledButton.icon(
                          key: const ValueKey('adaptive-open-3d'),
                          onPressed: _nativeLearningOpen
                              ? null
                              : () => unawaited(_openNativeLearning()),
                          style: FilledButton.styleFrom(
                              minimumSize: const Size(48, 56)),
                          icon: const Icon(Icons.view_in_ar_rounded),
                          label: const Text('Mit Lumo in 3D ausprobieren'),
                        ),
                      ],
                      // After choosing three explicit help steps, let the
                      // child count actual tens instead of merely rereading
                      // the explanation. No rewards or automatic answers.
                      if (_allowHelp &&
                          !_answered &&
                          _requestedHelpLevel > 0 &&
                          _placeValueLesson != null) ...[
                        const SizedBox(height: 14),
                        LumoLearningSceneCard(
                            key: ValueKey(
                                'scene-${_taskInstance.taskInstanceId}'),
                            appState: widget.appState,
                            scope: _publishedTaskContext!.tutorScope,
                            number: _placeValueLesson!.sourceNumber,
                            requestedHelpLevel: _requestedHelpLevel,
                            requestSerial: _sceneRequestSerial,
                            reduceMotion: st.settings.reduceAnimations ||
                                st.settings.calmMode,
                            onDifferentTask: () =>
                                setState(() => _loadNextTask()),
                            onMethodChosen: (method) {
                              if (!_allowHelp || _answered) return;
                              _placeValueLesson?.markTransferHelp();
                              setState(() {
                                _sceneMethod = method;
                                _requestedHelpLevel = math.max(
                                    _requestedHelpLevel,
                                    (method.index + 1).clamp(1, 3));
                              });
                              _publishTaskContext();
                              LumoCompanionRequests.instance
                                  .recordLearningEvent(
                                      LumoLearningEventKind.hintRequested,
                                      context: _publishedTaskContext);
                            }),
                      ],
                      if (_sceneCompletionError != null) ...[
                        Text(_sceneCompletionError!,
                            style: const TextStyle(color: Colors.white)),
                        TextButton(
                            onPressed: () => unawaited(_saveSceneCompletion()),
                            style: TextButton.styleFrom(
                                minimumSize: const Size(48, 48)),
                            child: const Text('Lernschritt erneut speichern')),
                      ],
                      if (_allowHelp &&
                          !_answered &&
                          _requestedHelpLevel >= 3 &&
                          _task.subject == 'Mathematik' &&
                          LumoPlaceValueWorkshop.numberForPrompt(
                                  _task.prompt) !=
                              null) ...[
                        const SizedBox(height: 14),
                        LumoPlaceValueWorkshop(
                          key: ValueKey(
                              'lumo-place-value-${_taskInstance.taskInstanceId}'),
                          number: LumoPlaceValueWorkshop.numberForPrompt(
                              _task.prompt)!,
                          lesson: _placeValueLesson,
                          onTransferChecked: (result) {
                            if (!_allowHelp || result.proof == null) return;
                            if (_tutorCoordinator
                                    .checkSceneTransfer(result.proof!) ==
                                null) {
                              return;
                            }
                            _pendingSceneCompletion = result.proof;
                            _pendingSceneMethod = _sceneMethod;
                            unawaited(_saveSceneCompletion());
                          },
                          reduceMotion: st.settings.reduceAnimations ||
                              st.settings.calmMode,
                          sounds: st.settings.soundEnabled,
                        ),
                      ],
                      if (_visualAid != null) ...[
                        const SizedBox(height: 14),
                        _VisualAidCard(aid: _visualAid!),
                      ],
                      // KI-Hilfe-Button: nur sichtbar wenn aiProxyEnabled.
                      // Heinz wollte KI in alle Bereiche integrieren - wenn aktiviert.
                      if (_allowHelp && !_answered) ...[
                        const SizedBox(height: 12),
                        _AiHelpButton(
                          loading: _aiHelpLoading,
                          onTap: _requestTaskHelp,
                          subject: _task.subject,
                        ),
                      ],
                      if (_aiHelpReply != null) ...[
                        const SizedBox(height: 12),
                        _AiHelpBubble(
                          text: _aiHelpReply!,
                          onSpeak: () {
                            _lumo.talk();
                            unawaited(
                              LumoVoice.instance.speak(
                                _aiHelpReply!,
                                style: VoiceStyle.explain,
                              ),
                            );
                          },
                        ),
                      ],
                      const SizedBox(height: 12),
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 280),
                        switchInCurve: Curves.easeOutCubic,
                        switchOutCurve: Curves.easeInCubic,
                        transitionBuilder: (child, animation) {
                          final slide = Tween<Offset>(
                            begin: const Offset(0.05, 0.04),
                            end: Offset.zero,
                          ).animate(animation);
                          return FadeTransition(
                            opacity: animation,
                            child: SlideTransition(
                              position: slide,
                              child: child,
                            ),
                          );
                        },
                        child: AdaptiveTaskRenderer(
                          key: ValueKey(_taskInstance.taskInstanceId),
                          task: _taskInstance,
                          allowRetry: _allowHelp,
                          onAnswered: _answerAdaptive,
                          onWritingSubmitted: _answerWriting,
                          onWritingPraise: _speakWritingPraise,
                          onShapeTraced: _answerShapeTrace,
                        ),
                      ),
                      if (_answered && _lastCorrect != null) ...[
                        const SizedBox(height: 22),
                        _ExplanationCard(
                          correct: _lastCorrect!,
                          explanation: _task.explanation,
                          correctAnswer: '${_taskInstance.correctAnswer}',
                          rewardDelta: _lastRewardDelta,
                          skillState: _lastSkillState,
                          feedback: _lastFeedback,
                          onNext: _nextQuestion,
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
            // Konfetti-Layer: feuert bei jeder richtigen Antwort.
            Positioned.fill(
              child: LumoConfettiBurst(trigger: _confettiTrigger),
            ),
          ],
        );
      },
    );
  }
}

/// Bildhilfe-Karte als 4. Hilfsstufe nach 5+ Fehlversuchen.
/// Zeigt Lumo's Erklaerung mit visuellen Schritten (Emoji-basiert),
/// damit Heinz' Toechter die Aufgabe wirklich verstehen koennen.
/// Kein Cloud-Image, alles lokal generiert.
class _VisualAidCard extends StatefulWidget {
  const _VisualAidCard({required this.aid});

  final LumoVisualAid aid;

  @override
  State<_VisualAidCard> createState() => _VisualAidCardState();
}

class _VisualAidCardState extends State<_VisualAidCard>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 720),
  )..forward();

  late final Animation<double> _headerFade = CurvedAnimation(
    parent: _controller,
    curve: const Interval(0.0, .4, curve: Curves.easeOutQuart),
  );

  late final Animation<double> _bodyFade = CurvedAnimation(
    parent: _controller,
    curve: const Interval(.2, .7, curve: Curves.easeOutQuart),
  );

  Animation<double> _stepFade(int index) {
    final start = (.35 + index * .12).clamp(0.0, .92);
    final end = (start + .25).clamp(start + .05, 1.0);
    return CurvedAnimation(
      parent: _controller,
      curve: Interval(start, end, curve: Curves.easeOutBack),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final steps = widget.aid.steps;
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: LumoGradients.visualCool,
        borderRadius: BorderRadius.circular(LumoRadius.lg),
        border: Border.all(
          color: const Color(0xFF6366F1).withOpacity(.32),
          width: 1.4,
        ),
        boxShadow: LumoShadow.help(const Color(0xFF6366F1)),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(LumoRadius.lg),
        child: Stack(
          children: [
            // Dekorativer Hintergrund-Glow oben rechts
            Positioned(
              top: -40,
              right: -40,
              child: IgnorePointer(
                ignoring: true,
                child: Container(
                  width: 160,
                  height: 160,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        const Color(0xFFA5B4FC).withOpacity(.45),
                        const Color(0xFFA5B4FC).withOpacity(0),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            // Akzent-Linie links
            Positioned(
              left: 0,
              top: 0,
              bottom: 0,
              child: Container(
                width: 5,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Color(0xFF6366F1), Color(0xFF8B5CF6)],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 18, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // HEADER mit großem Avatar
                  FadeTransition(
                    opacity: _headerFade,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          width: 48,
                          height: 48,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            gradient: const RadialGradient(
                              colors: [Color(0xFF163E72), Color(0xFF081F49)],
                              radius: .9,
                            ),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: const Color(0xFF6366F1).withOpacity(.40),
                              width: 1.6,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFF6366F1).withOpacity(.32),
                                blurRadius: 14,
                                offset: const Offset(0, 5),
                              ),
                            ],
                          ),
                          child: const Text(
                            '🎨',
                            style: TextStyle(fontSize: 26),
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const Text(
                                    'Lumo zeigt es dir',
                                    style: TextStyle(
                                      fontFamily: 'Nunito',
                                      fontSize: 11,
                                      fontWeight: FontWeight.w900,
                                      color: LumoVisualTokens.cyanBright,
                                      letterSpacing: .8,
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 7,
                                      vertical: 2,
                                    ),
                                    decoration: BoxDecoration(
                                      color: const Color(
                                        0xFF6366F1,
                                      ).withOpacity(.20),
                                      borderRadius: BorderRadius.circular(
                                        LumoRadius.pill,
                                      ),
                                    ),
                                    child: const Text(
                                      'BILD-HILFE',
                                      style: TextStyle(
                                        fontFamily: 'Nunito',
                                        fontSize: 8,
                                        fontWeight: FontWeight.w900,
                                        color: LumoVisualTokens.white,
                                        letterSpacing: .8,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 3),
                              Text(
                                widget.aid.title,
                                style: const TextStyle(
                                  fontFamily: 'Nunito',
                                  fontSize: 18,
                                  fontWeight: FontWeight.w900,
                                  color: LumoVisualTokens.white,
                                  height: 1.15,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  // ERKLAERUNG
                  FadeTransition(
                    opacity: _bodyFade,
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xCC0A2A55),
                        borderRadius: BorderRadius.circular(LumoRadius.md),
                        border: Border.all(
                          color: LumoVisualTokens.cyan.withOpacity(.38),
                          width: 1.0,
                        ),
                      ),
                      child: Text(
                        widget.aid.explanation,
                        style: const TextStyle(
                          fontFamily: 'Nunito',
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                          color: LumoVisualTokens.white,
                          height: 1.4,
                        ),
                      ),
                    ),
                  ),
                  if (steps.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    ...steps.asMap().entries.map((entry) {
                      final index = entry.key;
                      final step = entry.value;
                      final isLast = index == steps.length - 1;
                      return ScaleTransition(
                        scale: _stepFade(index),
                        alignment: Alignment.centerLeft,
                        child: FadeTransition(
                          opacity: _stepFade(index),
                          child: Padding(
                            padding: EdgeInsets.only(bottom: isLast ? 0 : 12),
                            child: IntrinsicHeight(
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  // Step-Nummer + Verbindungslinie
                                  Column(
                                    children: [
                                      Container(
                                        width: 32,
                                        height: 32,
                                        alignment: Alignment.center,
                                        decoration: BoxDecoration(
                                          gradient: const LinearGradient(
                                            begin: Alignment.topLeft,
                                            end: Alignment.bottomRight,
                                            colors: [
                                              Color(0xFF6366F1),
                                              Color(0xFF8B5CF6),
                                            ],
                                          ),
                                          shape: BoxShape.circle,
                                          boxShadow: [
                                            BoxShadow(
                                              color: const Color(
                                                0xFF6366F1,
                                              ).withOpacity(.36),
                                              blurRadius: 8,
                                              offset: const Offset(0, 3),
                                            ),
                                          ],
                                        ),
                                        child: Text(
                                          '${index + 1}',
                                          style: const TextStyle(
                                            fontFamily: 'Nunito',
                                            fontSize: 14,
                                            fontWeight: FontWeight.w900,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                      if (!isLast)
                                        Expanded(
                                          child: Container(
                                            width: 2,
                                            margin: const EdgeInsets.symmetric(
                                              vertical: 2,
                                            ),
                                            color: const Color(
                                              0xFF6366F1,
                                            ).withOpacity(.30),
                                          ),
                                        ),
                                    ],
                                  ),
                                  const SizedBox(width: 12),
                                  // Step-Inhalt als kleine Karte
                                  Expanded(
                                    child: Container(
                                      padding: const EdgeInsets.fromLTRB(
                                        14,
                                        10,
                                        14,
                                        12,
                                      ),
                                      decoration: BoxDecoration(
                                        color: const Color(0xD10B2D5B),
                                        borderRadius: BorderRadius.circular(
                                          LumoRadius.md,
                                        ),
                                        border: Border.all(
                                          color: LumoVisualTokens.cyan
                                              .withOpacity(.28),
                                          width: 1.0,
                                        ),
                                        boxShadow: [
                                          BoxShadow(
                                            color: const Color(
                                              0xFF6366F1,
                                            ).withOpacity(.08),
                                            blurRadius: 8,
                                            offset: const Offset(0, 3),
                                          ),
                                        ],
                                      ),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          // Visual gross und mittig, das ist der Kernpunkt
                                          Center(
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                vertical: 4,
                                              ),
                                              child: Text(
                                                step.visual,
                                                style: const TextStyle(
                                                  fontSize: 28,
                                                  height: 1.2,
                                                  letterSpacing: 2,
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(height: 4),
                                          Text(
                                            step.caption,
                                            style: const TextStyle(
                                              fontFamily: 'Nunito',
                                              fontSize: 13,
                                              fontWeight: FontWeight.w800,
                                              color: LumoVisualTokens.white,
                                              height: 1.3,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    }),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// 3D-Lernkarte mit Lumo-Fuchs der von Station zu Station huepft.
/// Inspiriert von Golf-Apps und Duolingo - Heinz' Toechter sehen
/// ihren Fortschritt visuell als Reise auf einem Pfad.
///
/// Pfad-Layout: 8-12 Stationen entlang einer geschwungenen Kurve mit
/// Perspektive (kleinere Stationen hinten, groesser vorne).
class _LumoJourneyMap extends StatefulWidget {
  const _LumoJourneyMap({
    required this.currentStep,
    required this.totalSteps,
    required this.subject,
    required this.lastWasCorrect,
  });

  final int currentStep;
  final int totalSteps;
  final String subject;

  /// null = noch nicht beantwortet
  /// true  = Lumo huepft mit Freude-Animation
  /// false = Lumo schwankt sanft (kein Drama)
  final bool? lastWasCorrect;

  @override
  State<_LumoJourneyMap> createState() => _LumoJourneyMapState();
}

class _LumoJourneyMapState extends State<_LumoJourneyMap>
    with TickerProviderStateMixin {
  late final AnimationController _hopController = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 700),
  );
  late final AnimationController _idleController = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 2400),
  )..repeat(reverse: true);

  @override
  void didUpdateWidget(covariant _LumoJourneyMap old) {
    super.didUpdateWidget(old);
    // Wenn Lumo zur naechsten Station kommt: Hop-Animation triggern
    if (old.currentStep != widget.currentStep) {
      _hopController.forward(from: 0);
    }
  }

  @override
  void dispose() {
    _hopController.dispose();
    _idleController.dispose();
    super.dispose();
  }

  /// Liefert die x/y-Koordinaten einer Station auf dem geschwungenen Pfad.
  /// 0..1 normalisiert. Geschwungene S-Kurve fuer Tiefe-Effekt.
  Offset _stationOffset(int step, int total, double width, double height) {
    final t = (step / (total - 1).clamp(1, double.infinity)).clamp(0.0, 1.0);
    // X laeuft von links unten nach rechts oben mit S-Schwung
    final x = 0.10 + 0.80 * t + 0.12 * (math.sin(t * math.pi * 2));
    // Y: oben (hinten) bei spaeten Stationen, unten (vorne) bei fruehen
    final y = 0.85 - 0.65 * t;
    return Offset(x * width, y * height);
  }

  /// Skalierung fuer 3D-Tiefe: vorne groesser, hinten kleiner.
  double _stationScale(int step, int total) {
    final t = (step / (total - 1).clamp(1, double.infinity)).clamp(0.0, 1.0);
    return 1.0 - 0.40 * t;
  }

  /// Symbol fuer eine Station - rotiert je nach Position fuer Abwechslung.
  String _stationEmoji(int step, int total) {
    if (step == total - 1) return '🏆'; // Ziel
    const symbols = [
      '🌟',
      '🎯',
      '🎨',
      '📚',
      '✏️',
      '🎵',
      '🌈',
      '🦋',
      '🍀',
      '⭐',
      '🎁',
    ];
    return symbols[step % symbols.length];
  }

  @override
  Widget build(BuildContext context) {
    final total = widget.totalSteps.clamp(2, 20);
    final progress = (widget.currentStep / total).clamp(0.0, 1.0);
    final percent = (progress * 100).round();
    return Container(
      width: double.infinity,
      decoration: lumoCard(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xF00B315F), Color(0xF0061D43), Color(0xF0092A56)],
        ),
      ),
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // HEADER mit Fortschritt
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 11,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [LumoColors.orange, LumoColors.orangeLight],
                  ),
                  borderRadius: BorderRadius.circular(LumoRadius.pill),
                  boxShadow: [
                    BoxShadow(
                      color: LumoColors.orange.withOpacity(.32),
                      blurRadius: 8,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Text(
                  'Station ${widget.currentStep}',
                  style: const TextStyle(
                    fontFamily: 'Nunito',
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: .3,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                'von $total',
                style: const TextStyle(
                  fontFamily: 'Nunito',
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  color: LumoVisualTokens.muted,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xCC0B2D5B),
                  borderRadius: BorderRadius.circular(LumoRadius.pill),
                  border: Border.all(
                    color: LumoVisualTokens.cyan.withOpacity(.38),
                    width: 1.2,
                  ),
                ),
                child: Text(
                  '$percent%',
                  style: const TextStyle(
                    fontFamily: 'Nunito',
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    color: LumoColors.orange,
                    letterSpacing: .2,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          // SUBJECT-CHIP klein und subtil
          Text(
            widget.subject,
            style: const TextStyle(
              fontFamily: 'Nunito',
              fontSize: 11,
              fontWeight: FontWeight.w800,
              color: LumoVisualTokens.muted,
              letterSpacing: .3,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 8),
          // 3D-PFAD mit Lumo
          AspectRatio(
            aspectRatio: 2.4,
            child: LayoutBuilder(
              builder: (context, constraints) {
                final w = constraints.maxWidth;
                final h = constraints.maxHeight;
                return ClipRRect(
                  borderRadius: BorderRadius.circular(LumoRadius.lg),
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Color(0xFF0B3B67), // holografischer Himmel
                          Color(0xFF061A3E), // dunkler Lernpfad
                        ],
                      ),
                    ),
                    child: AnimatedBuilder(
                      animation: Listenable.merge([
                        _hopController,
                        _idleController,
                      ]),
                      builder: (context, _) => CustomPaint(
                        painter: _JourneyPainter(
                          total: total,
                          currentStep: widget.currentStep,
                          hopProgress: _hopController.value,
                          idlePulse: _idleController.value,
                          stationOffset: _stationOffset,
                          stationScale: _stationScale,
                          stationEmoji: _stationEmoji,
                          lastWasCorrect: widget.lastWasCorrect,
                        ),
                        size: Size(w, h),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 8),
          // Progress-Balken als zusaetzliche Lese-Hilfe
          Stack(
            clipBehavior: Clip.none,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(LumoRadius.pill),
                child: TweenAnimationBuilder<double>(
                  duration: const Duration(milliseconds: 480),
                  curve: Curves.easeOutCubic,
                  tween: Tween<double>(begin: 0.0, end: progress),
                  builder: (context, animatedProgress, _) =>
                      LinearProgressIndicator(
                    value: animatedProgress,
                    minHeight: 6,
                    color: LumoColors.orange,
                    backgroundColor: LumoColors.orange.withOpacity(.14),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// CustomPainter fuer die 3D-Lernreise.
/// Zeichnet:
///   - Geschwungenen Pfad (gepunktet bis aktuelle Station, danach gestrichelt)
///   - Stationen als Kreise mit Schatten und Symbol
///   - Lumo-Fuchs an der aktuellen Position mit Hop-Bewegung
class _JourneyPainter extends CustomPainter {
  _JourneyPainter({
    required this.total,
    required this.currentStep,
    required this.hopProgress,
    required this.idlePulse,
    required this.stationOffset,
    required this.stationScale,
    required this.stationEmoji,
    required this.lastWasCorrect,
  });

  final int total;
  final int currentStep;
  final double hopProgress;
  final double idlePulse;
  final Offset Function(int, int, double, double) stationOffset;
  final double Function(int, int) stationScale;
  final String Function(int, int) stationEmoji;
  final bool? lastWasCorrect;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // PFAD ZEICHNEN - geschwungene Linie zwischen allen Stationen
    final pathDone = Path();
    final pathTodo = Path();
    Offset? prev;
    for (var i = 0; i < total; i++) {
      final pos = stationOffset(i, total, w, h);
      if (i == 0) {
        pathDone.moveTo(pos.dx, pos.dy);
        pathTodo.moveTo(pos.dx, pos.dy);
      } else {
        // Bezier-Kurve fuer weichen Schwung
        final ctrl = Offset(
          (prev!.dx + pos.dx) / 2,
          (prev.dy + pos.dy) / 2 + 8,
        );
        if (i < currentStep) {
          pathDone.quadraticBezierTo(ctrl.dx, ctrl.dy, pos.dx, pos.dy);
        }
        if (i >= currentStep - 1) {
          pathTodo.quadraticBezierTo(ctrl.dx, ctrl.dy, pos.dx, pos.dy);
        }
      }
      prev = pos;
    }

    // Done-Pfad: dick und orange
    final donePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4.5
      ..strokeCap = StrokeCap.round
      ..shader = const LinearGradient(
        colors: [Color(0xFFFF7A2F), Color(0xFFFFB800)],
      ).createShader(Rect.fromLTWH(0, 0, w, h));
    canvas.drawPath(pathDone, donePaint);

    // Todo-Pfad: gestrichelt und blass
    final todoPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5
      ..strokeCap = StrokeCap.round
      ..color = const Color(0xFFFF7A2F).withOpacity(.30);
    _drawDashedPath(canvas, pathTodo, todoPaint);

    // STATIONEN ZEICHNEN
    for (var i = 0; i < total; i++) {
      final pos = stationOffset(i, total, w, h);
      final scale = stationScale(i, total);
      final isPast = i < currentStep - 1;
      final isCurrent = i == currentStep - 1;
      final isFuture = i >= currentStep;
      final isFinal = i == total - 1;
      final r = (isFinal ? 22 : 16) * scale;

      // Schatten unter Station
      canvas.drawCircle(
        pos.translate(0, r * 0.8),
        r * 0.7,
        Paint()..color = Colors.black.withOpacity(.10),
      );

      // Station-Kreis
      Color fillColor;
      if (isPast) {
        fillColor = const Color(0xFF22C55E); // Mint - geschafft
      } else if (isCurrent) {
        fillColor = const Color(0xFFFF7A2F); // Orange - aktiv
      } else {
        fillColor = Colors.white;
      }
      canvas.drawCircle(pos, r, Paint()..color = fillColor);
      // Border
      canvas.drawCircle(
        pos,
        r,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.4
          ..color = isPast
              ? const Color(0xFF15803D)
              : isCurrent
                  ? const Color(0xFFC2410C)
                  : const Color(0xFFFCD34D),
      );

      // Pulse fuer current
      if (isCurrent) {
        final pulse = 1.0 + idlePulse * 0.30;
        canvas.drawCircle(
          pos,
          r * pulse,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 2.0
            ..color = const Color(
              0xFFFF7A2F,
            ).withOpacity(.40 * (1 - idlePulse)),
        );
      }

      // Symbol
      final symbol = isPast
          ? '✓'
          : isFinal && isFuture
              ? '🏆'
              : stationEmoji(i, total);
      final tp = TextPainter(
        text: TextSpan(
          text: symbol,
          style: TextStyle(
            fontFamily: 'Nunito',
            fontSize: r * 1.0,
            fontWeight: FontWeight.w900,
            color: isPast ? Colors.white : Colors.black,
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, pos.translate(-tp.width / 2, -tp.height / 2));
    }

    // LUMO-FUCHS an aktueller Position mit Hop-Animation
    final lumoStation = (currentStep - 1).clamp(0, total - 1);
    final lumoBase = stationOffset(lumoStation, total, w, h);
    // Hop: parabel-foermige Bewegung nach oben waehrend hopProgress 0 -> 1
    final hopHeight = lastWasCorrect == false
        ? 4.0 // bei falsch nur leichtes Schwanken
        : 18.0;
    final hopY = -4 * hopHeight * hopProgress * (1 - hopProgress);
    // Idle wackeln: leichte Bewegung wenn nicht gerade gehoppt wird
    final idleY = hopProgress > 0.95 || hopProgress < 0.05
        ? math.sin(idlePulse * math.pi * 2) * 1.5
        : 0.0;
    final lumoPos = lumoBase.translate(0, hopY + idleY - 22);
    // Lumo-Schatten
    canvas.drawCircle(
      lumoBase.translate(0, -2),
      11,
      Paint()..color = Colors.black.withOpacity(.18 - hopProgress * .12),
    );
    // Lumo selbst (Fuchs-Emoji)
    final lumoTp = TextPainter(
      text: const TextSpan(text: '🦊', style: TextStyle(fontSize: 28)),
      textDirection: TextDirection.ltr,
    )..layout();
    lumoTp.paint(
      canvas,
      lumoPos.translate(-lumoTp.width / 2, -lumoTp.height / 2),
    );
  }

  void _drawDashedPath(Canvas canvas, Path path, Paint paint) {
    const dashLen = 6.0;
    const gapLen = 4.0;
    for (final metric in path.computeMetrics()) {
      var distance = 0.0;
      while (distance < metric.length) {
        final next = (distance + dashLen).clamp(0, metric.length).toDouble();
        canvas.drawPath(metric.extractPath(distance, next), paint);
        distance = next + gapLen;
      }
    }
  }

  @override
  bool shouldRepaint(_JourneyPainter old) =>
      old.currentStep != currentStep ||
      old.hopProgress != hopProgress ||
      old.idlePulse != idlePulse ||
      old.lastWasCorrect != lastWasCorrect;
}

class _ExplanationCard extends StatefulWidget {
  const _ExplanationCard({
    required this.correct,
    required this.explanation,
    required this.correctAnswer,
    required this.onNext,
    this.rewardDelta,
    this.skillState,
    this.feedback,
  });

  final bool correct;
  final String explanation;
  final String correctAnswer;
  final VoidCallback onNext;
  final RewardDelta? rewardDelta;
  final SkillState? skillState;
  final LumoFeedbackTurn? feedback;

  @override
  State<_ExplanationCard> createState() => _ExplanationCardState();
}

class _ExplanationCardState extends State<_ExplanationCard>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 540),
  )..forward();

  late final Animation<double> _scale = Tween<double>(
    begin: .92,
    end: 1.0,
  ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutBack));

  late final Animation<double> _fade = CurvedAnimation(
    parent: _controller,
    curve: Curves.easeOutQuart,
  );

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final reward = widget.rewardDelta;
    final skill = widget.skillState;
    final fb = widget.feedback;
    final correct = widget.correct;
    return FadeTransition(
      opacity: _fade,
      child: ScaleTransition(
        scale: _scale,
        alignment: Alignment.topCenter,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(LumoRadius.xl),
            gradient: correct
                ? LumoGradients.successFresh
                : LumoGradients.peachComfort,
            border: Border.all(
              color:
                  (correct ? const Color(0xFF22C55E) : const Color(0xFFF59E0B))
                      .withOpacity(.32),
              width: 1.4,
            ),
            boxShadow: correct
                ? LumoShadow.success
                : LumoShadow.help(const Color(0xFFFB923C)),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(LumoRadius.xl),
            child: Stack(
              children: [
                // Dekorativer Glow oben rechts
                Positioned(
                  top: -50,
                  right: -40,
                  child: IgnorePointer(
                    ignoring: true,
                    child: Container(
                      width: 180,
                      height: 180,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            (correct
                                    ? const Color(0xFF34D399)
                                    : const Color(0xFFFB923C))
                                .withOpacity(.32),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                // Konfetti-Sterne dezent bei Erfolg
                if (correct) ...const [
                  Positioned(
                    top: 14,
                    right: 70,
                    child: Text('✨', style: TextStyle(fontSize: 14)),
                  ),
                  Positioned(
                    top: 38,
                    right: 24,
                    child: Text('⭐', style: TextStyle(fontSize: 16)),
                  ),
                  Positioned(
                    top: 62,
                    right: 56,
                    child: Text('✨', style: TextStyle(fontSize: 12)),
                  ),
                ],
                Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            width: 46,
                            height: 46,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              gradient: RadialGradient(
                                colors: [
                                  Colors.white,
                                  (correct
                                      ? const Color(0xFFD1FAE5)
                                      : const Color(0xFFFEF3C7)),
                                ],
                                radius: .9,
                              ),
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: (correct
                                          ? const Color(0xFF34D399)
                                          : const Color(0xFFF59E0B))
                                      .withOpacity(.32),
                                  blurRadius: 14,
                                  offset: const Offset(0, 5),
                                ),
                              ],
                            ),
                            child: Text(
                              correct ? '🎉' : '💪',
                              style: const TextStyle(fontSize: 24),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              fb?.title ??
                                  (correct
                                      ? 'Super gemacht!'
                                      : 'Nicht aufgeben!'),
                              style: TextStyle(
                                fontFamily: 'Nunito',
                                fontSize: 19,
                                fontWeight: FontWeight.w900,
                                color: correct
                                    ? const Color(0xFF14532D)
                                    : const Color(0xFF78350F),
                                height: 1.15,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        fb?.cardMessage ?? widget.explanation,
                        style: LumoTextStyles.body.copyWith(
                          color: correct
                              ? const Color(0xFF166534)
                              : const Color(0xFF92400E),
                          fontWeight: FontWeight.w800,
                          fontSize: 14,
                          height: 1.4,
                        ),
                      ),
                      const SizedBox(height: 10),
                      _LearningTipBox(
                        text: fb?.learningTip ?? widget.explanation,
                        correct: correct,
                      ),
                      if (!correct) ...[
                        const SizedBox(height: 10),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 8,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xCC0B2D5B),
                            borderRadius: BorderRadius.circular(LumoRadius.sm),
                            border: Border.all(
                              color: const Color(0xFFF59E0B).withOpacity(.42),
                              width: 1.0,
                            ),
                          ),
                          child: Row(
                            children: [
                              const Text(
                                '✓',
                                style: TextStyle(
                                  fontSize: 16,
                                  color: Color(0xFF15803D),
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  'Richtige Antwort: ${widget.correctAnswer}',
                                  style: const TextStyle(
                                    fontFamily: 'Nunito',
                                    fontSize: 14,
                                    fontWeight: FontWeight.w900,
                                    color: Color(0xFFFFD39A),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                      if (reward != null) ...[
                        const SizedBox(height: 14),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            _InfoPill(
                                text:
                                    '${reward.stars >= 0 ? '+' : ''}${reward.stars} Sterne'),
                            _InfoPill(text: '+${reward.xp} XP'),
                            if (fb != null) _InfoPill(text: fb.rewardLabel),
                            if (fb?.badgeLabel != null)
                              _InfoPill(text: fb!.badgeLabel!),
                            if (skill != null)
                              _InfoPill(
                                text:
                                    'Können ${(skill.masteryScore * 100).round()}%',
                              ),
                          ],
                        ),
                      ],
                      const SizedBox(height: 16),
                      Align(
                        alignment: Alignment.centerRight,
                        child: GestureDetector(
                          onTap: widget.onNext,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 24,
                              vertical: 13,
                            ),
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [
                                  LumoColors.orange,
                                  LumoColors.orangeLight,
                                ],
                              ),
                              borderRadius: BorderRadius.circular(
                                LumoRadius.pill,
                              ),
                              boxShadow: LumoShadow.pill,
                            ),
                            child: const Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  'Weiter',
                                  style: TextStyle(
                                    fontFamily: 'Nunito',
                                    fontSize: 15,
                                    fontWeight: FontWeight.w900,
                                    color: Colors.white,
                                  ),
                                ),
                                SizedBox(width: 6),
                                Text(
                                  '→',
                                  style: TextStyle(
                                    fontFamily: 'Nunito',
                                    fontSize: 17,
                                    fontWeight: FontWeight.w900,
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _LearningTipBox extends StatelessWidget {
  const _LearningTipBox({required this.text, required this.correct});

  final String text;
  final bool correct;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xCC0B2D5B),
        borderRadius: BorderRadius.circular(LumoRadius.md),
        border: Border.all(
          color: (correct ? const Color(0xFF22C55E) : const Color(0xFFF59E0B))
              .withOpacity(.22),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.psychology_rounded,
            color: correct ? const Color(0xFF22C55E) : const Color(0xFFF59E0B),
            size: 20,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(
                fontFamily: 'Nunito',
                fontSize: 13,
                fontWeight: FontWeight.w900,
                color: LumoVisualTokens.white,
                height: 1.28,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoPill extends StatelessWidget {
  const _InfoPill({required this.text});
  final String text;

  /// Erkennt typische Reward-Texte und zeigt passendes Emoji vorne dran.
  /// Macht die kleinen Pillen sofort lesbar.
  String get _emoji {
    final lower = text.toLowerCase();
    if (lower.contains('stern')) return '⭐';
    if (lower.contains('xp')) return '⚡';
    if (lower.contains('können') || lower.contains('koennen')) return '📈';
    if (lower.contains('badge') || lower.contains('abzeichen')) return '🏅';
    if (lower.contains('streak')) return '🔥';
    if (lower.contains('level')) return '🎖️';
    return '';
  }

  @override
  Widget build(BuildContext context) {
    final em = _emoji;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xE6173F6A),
            Color(0xD00A2854),
          ],
        ),
        borderRadius: BorderRadius.circular(LumoRadius.pill),
        border: Border.all(color: LumoColors.orange.withOpacity(.22)),
        boxShadow: [
          BoxShadow(
            color: LumoColors.orange.withOpacity(.12),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (em.isNotEmpty) ...[
            Text(em, style: const TextStyle(fontSize: 13)),
            const SizedBox(width: 5),
          ],
          Text(
            text,
            style: const TextStyle(
              fontFamily: 'Nunito',
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: LumoColors.ink700,
              letterSpacing: .1,
            ),
          ),
        ],
      ),
    );
  }
}

/// Premium KI-Hilfe-Button. Sichtbar nur wenn aiProxyEnabled.
/// Hat einen pulsierenden Glow + Sparkle-Icon.
class _AiHelpButton extends StatefulWidget {
  const _AiHelpButton({
    required this.loading,
    required this.onTap,
    required this.subject,
  });

  final bool loading;
  final VoidCallback onTap;
  final String subject;

  @override
  State<_AiHelpButton> createState() => _AiHelpButtonState();
}

class _AiHelpButtonState extends State<_AiHelpButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    // Hologlass is shared across all subjects, unlike the old orange/pink
    // per-subject buttons that clashed with the blue Lumo learning world.
    const color = LumoVisualTokens.cyanBright;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: widget.loading ? null : widget.onTap,
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: MediaQuery.disableAnimationsOf(context)
            ? Duration.zero
            : const Duration(milliseconds: 120),
        curve: Curves.easeOutCubic,
        child: Container(
          key: const ValueKey('lumo-help-hologlass-button'),
          constraints: const BoxConstraints(minHeight: 48),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xED0C4477), Color(0xF0082852)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(LumoRadius.lg),
            border: Border.all(color: color.withOpacity(.75), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.25),
                blurRadius: 14,
                offset: const Offset(0, 6),
                spreadRadius: -2,
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (widget.loading)
                const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.4,
                    color: Colors.white,
                  ),
                )
              else
                const Icon(
                  Icons.auto_awesome_rounded,
                  key: ValueKey('lumo-help-sparkle'),
                  size: 20,
                  color: Colors.white,
                ),
              const SizedBox(width: 8),
              Flexible(
                child:
                    Text(widget.loading ? 'Lumo denkt nach…' : 'Lumo, hilf mir',
                        style: const TextStyle(
                          fontFamily: 'Nunito',
                          fontSize: 15,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          letterSpacing: 0.2,
                        )),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Antwort-Bubble fuer die KI-Hilfe.
/// Lila Gradient + Sparkles + Vorlese-Button.
class _AiHelpBubble extends StatelessWidget {
  const _AiHelpBubble({required this.text, required this.onSpeak});
  final String text;
  final VoidCallback onSpeak;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xF00D3B70), Color(0xF0082149)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(LumoRadius.lg),
        border: Border.all(
            color: const Color(0xFF4EDCFF).withOpacity(.66), width: 1.4),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF37CFF9).withOpacity(0.18),
            blurRadius: 14,
            offset: const Offset(0, 5),
            spreadRadius: -3,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF1B5F93), Color(0xFF0A315B)],
                  ),
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF37CFF9).withOpacity(0.4),
                      blurRadius: 8,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: const LumoFoxPose(
                    pose: LumoDesignFoxPose.teacherStick, size: 33),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  'Lumo sagt:',
                  style: TextStyle(
                    fontFamily: 'Nunito',
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF81E9FF),
                    letterSpacing: 0.3,
                  ),
                ),
              ),
              IconButton(
                onPressed: onSpeak,
                icon: const Icon(
                  Icons.volume_up_rounded,
                  size: 22,
                  color: Color(0xFF81E9FF),
                ),
                tooltip: 'Lumo vorlesen lassen',
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            text,
            style: const TextStyle(
              fontFamily: 'Nunito',
              fontSize: 14.5,
              fontWeight: FontWeight.w700,
              color: Color(0xFFF3FAFF),
              height: 1.45,
            ),
          ),
        ],
      ),
    );
  }
}

/// Kompakter Fortschritt wie in Bild 02: „Aufgabe N / M“, Leuchtsegmente,
/// Thema und ein lebendiger Lumo, der nach jeder Antwort reagiert.
class _LessonProgressRow extends StatelessWidget {
  const _LessonProgressRow({
    required this.currentStep,
    required this.totalSteps,
    required this.subject,
    required this.lumo,
    required this.reduceMotion,
  });

  final int currentStep;
  final int totalSteps;
  final String subject;
  final LumoCharacterController lumo;
  final bool reduceMotion;

  @override
  Widget build(BuildContext context) {
    final segments = math.min(totalSteps, 10);
    final filled = (currentStep / totalSteps * segments).ceil();
    return LumoGlassCard(
      padding: const EdgeInsets.fromLTRB(14, 11, 4, 8),
      radius: 24,
      child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
        Expanded(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(
              subject,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontFamily: 'Nunito',
                fontSize: 13,
                fontWeight: FontWeight.w900,
                letterSpacing: .25,
                color: LumoVisualTokens.cyanBright,
                shadows: [Shadow(color: Color(0x8837D2FD), blurRadius: 10)],
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'Aufgabe $currentStep / $totalSteps',
              key: const ValueKey('lesson-progress-label'),
              style: const TextStyle(
                fontFamily: 'Nunito',
                fontSize: 21,
                fontWeight: FontWeight.w900,
                color: LumoVisualTokens.white,
              ),
            ),
            const SizedBox(height: 8),
            Row(children: [
              for (var i = 0; i < segments; i++)
                Expanded(
                  child: AnimatedContainer(
                    duration: reduceMotion
                        ? Duration.zero
                        : const Duration(milliseconds: 450),
                    curve: Curves.easeOutCubic,
                    height: 10,
                    margin: const EdgeInsets.symmetric(horizontal: 1.2),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      color: i < filled
                          ? LumoVisualTokens.cyanBright
                          : const Color(0xFF16365F),
                      boxShadow: i < filled
                          ? [
                              BoxShadow(
                                color: LumoVisualTokens.cyan
                                    .withValues(alpha: .68),
                                blurRadius: 8,
                              ),
                            ]
                          : null,
                    ),
                  ),
                ),
            ]),
            const SizedBox(height: 10),
            const Text(
              'Gemeinsam Schritt für Schritt.',
              style: TextStyle(
                fontFamily: 'Nunito',
                fontSize: 11,
                fontWeight: FontWeight.w800,
                color: LumoVisualTokens.muted,
              ),
            ),
          ]),
        ),
        const SizedBox(width: 6),
        SizedBox(
          width: 118,
          height: 118,
          child: Stack(clipBehavior: Clip.none, children: [
            Positioned(
              left: 0,
              right: 8,
              top: 0,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                decoration: BoxDecoration(
                  color: const Color(0xD90A3A75),
                  borderRadius: BorderRadius.circular(12),
                  border:
                      Border.all(color: LumoVisualTokens.cyan.withOpacity(.65)),
                  boxShadow: [
                    BoxShadow(
                      color: LumoVisualTokens.cyan.withOpacity(.20),
                      blurRadius: 10,
                    ),
                  ],
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.auto_awesome_rounded,
                      key: ValueKey('lesson-encouragement-sparkle'),
                      size: 10,
                      color: Colors.white,
                    ),
                    SizedBox(width: 3),
                    Flexible(
                      child: Text(
                        'Du schaffst das!',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontFamily: 'Nunito',
                          fontSize: 9.5,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              right: -4,
              bottom: -8,
              child: LumoCharacter(
                key: const ValueKey('lesson-lumo'),
                pose: LumoDesignFoxPose.teacherStick,
                ambientPoses: const <LumoDesignFoxPose>[
                  LumoDesignFoxPose.pointSide,
                  LumoDesignFoxPose.bookPoint,
                  LumoDesignFoxPose.thumbWink,
                ],
                size: 112,
                reduceMotion: reduceMotion,
                controller: lumo,
                onTap: lumo.wave,
              ),
            ),
          ]),
        ),
      ]),
    );
  }
}
