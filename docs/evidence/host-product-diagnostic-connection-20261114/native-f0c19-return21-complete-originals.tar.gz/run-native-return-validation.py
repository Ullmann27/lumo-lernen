from pathlib import Path
import subprocess,json,hashlib,datetime,time,os,re
repo=Path("/tmp/lumo-recovery-20261114/native")
pack=Path("/workspace/scratch/b3485b7bb989/native-c4-return-f0c19-validation-20261114");pack.mkdir()
scratch=Path("/tmp/lumo-recovery-20261114/native-return-runtime");scratch.mkdir()
env=os.environ.copy();env.update({"GIT_OPTIONAL_LOCKS":"0","XDG_DATA_HOME":str(scratch/"data"),"XDG_CONFIG_HOME":str(scratch/"config"),"XDG_CACHE_HOME":str(scratch/"cache")})
def git(*args):return subprocess.check_output(["git","-C",str(repo),*args],env=env)
def snapshot():
 records=[]
 for row in git("ls-files","-s","-z").split(b"\0"):
  if not row:continue
  meta,name=row.split(b"\t");mode,sha,stage=meta.decode().split();p=repo/os.fsdecode(name)
  if not p.is_file():continue
  data=p.read_bytes();actual=hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest();assert actual==sha,str(p)
  records.append({"path":os.fsdecode(name),"mode":mode,"blob":sha,"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()})
 return {"head":git("rev-parse","HEAD").decode().strip(),"tree":git("rev-parse","HEAD^{tree}").decode().strip(),"status":git("status","--porcelain").decode(),"index_sha256":hashlib.sha256((repo/".git/index").read_bytes()).hexdigest(),"files":records}
before=snapshot();assert before["head"]=="f0c19f9eb69ea330ac5d2b8f9948cb029ca218aa" and before["status"]==""
(pack/"before.json").write_text(json.dumps(before,indent=2)+"\n")
version=subprocess.check_output(["godot","--version"],env=env).decode();(pack/"godot-version.log").write_text(version)
assert version.strip()=="4.6.3.stable.official.7d41c59c4"
def run(name,command,timeout):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic();error=None
 with (pack/(name+".log")).open("wb") as stream:
  try:result=subprocess.run(command,cwd=repo,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=timeout);code=result.returncode
  except subprocess.TimeoutExpired as e:error=str(e);code=None
 data=(pack/(name+".log")).read_bytes()
 record={"command":command,"cwd":str(repo),"started_at":started,"finished_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"wall_seconds":time.monotonic()-t,"returncode":code,"timeout":timeout,"error":error,"log":{"path":name+".log","bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()},"error_lines":[line for line in data.decode("utf-8","replace").splitlines() if re.search(r"SCRIPT ERROR|Parse Error|ERROR:",line)]}
 (pack/(name+"-execution.json")).write_text(json.dumps(record,indent=2)+"\n")
 return record,data
imported,import_log=run("source-import",["godot","--headless","--audio-driver","Dummy","--path",str(repo),"--editor","--import","--quit"],180)
if imported["returncode"]!=0 or imported["error_lines"]:
 print(json.dumps({"status":"IMPORT_BLOCKED","record":imported}));raise SystemExit(1)
mid=snapshot();assert mid["files"]==before["files"] and mid["head"]==before["head"] and mid["tree"]==before["tree"]
(pack/"after-import.json").write_text(json.dumps(mid,indent=2)+"\n")
execution,log=run("return-regression",["godot","--headless","--audio-driver","Dummy","--path",str(repo),"--script","res://scripts/tests/connect_four_return_regression.gd"],60)
after=snapshot();(pack/"after.json").write_text(json.dumps(after,indent=2)+"\n")
passed=execution["returncode"]==0 and not execution["error_lines"] and "CONNECT_FOUR_RETURN_PASS checks=21" in log.decode().splitlines()
result={"schema":1,"source":before["head"],"tree":before["tree"],"status":"PASS" if passed else "FAIL","checks":21 if passed else None,"actual_engine_version":version.strip(),"test_execution":execution,"committed_sources_unchanged":before["files"]==after["files"],"materialized_sources":len(before["files"]),"git_identity_unchanged":all(before[k]==after[k] for k in ("head","tree","index_sha256")),"generated_untracked_files":git("ls-files","--others","--exclude-standard").decode().splitlines(),"scope":"Actual production Godot scene/send/poll with explicit Android host boundary fixture. No actual Android, complete52-mode run, renderer or device FPS acceptance."}
(pack/"result.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result))
raise SystemExit(0 if passed and result["committed_sources_unchanged"] and result["git_identity_unchanged"] else 1)
