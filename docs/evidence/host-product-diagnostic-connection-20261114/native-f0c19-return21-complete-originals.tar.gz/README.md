# Actual C4 return regression on f0c19

The published Native17 integration plus the exact PR171 return patch passed all21 checks in the actual production Godot scene using Godot4.6.3. Only the Android host boundary is an explicit fixture. Import and test logs are original. Tracked sources, commit, tree and index remain unchanged. The editor generated untracked UID files; their exact bytes were archived and only those files removed from this isolated checkout afterward.

This is not an Android, renderer, complete52-mode or device FPS approval.
