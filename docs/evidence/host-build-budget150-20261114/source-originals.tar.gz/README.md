# Narrow outer build budget follow-up

Base is the active published Host37ec6c6a / Nativebaf148b0 candidate. The patch changes only verify-and-build timeout from120 to150 minutes and the two existing Delivery assertions of that same job budget. The Android80-minute job, all individual gates/deadlines, all pin/product/branch bytes, and every 120.005s synthetic log fixture remain unchanged.

The source proposal does not cancel, retry or mutate the active Run43601673844. Root owns publication, later targeted71-Delivery/actionlint authorization, and verified replacement activation. No test or Actionlint has run from this pack.

Historical timing rationale is explicitly Root-supplied original evidence, separately documented in root-evidence-instruction.json; no result is transferred to the current candidate.
