# Separate C4 visibility test proposal

This frozen proposal contains only three exact published PR493 test files against Host79c. It has not been executed. The current product layout, pins, workflows, writing trainer, journal and original Lumo assets are outside the patch.

The existing minimum 48dp RenderBox requirement remains strict. Only floating-point subtraction in global coordinates uses a 1e-9 comparison; hit testing and existing bounds checks remain required.

The historical unchanged-APK fixture repair and its one-case Red/Green are a separate pack. No historical Producer or Root test success is assigned to this proposed three-file combination.
