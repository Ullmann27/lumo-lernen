# Historical unchanged-APK QA fixture: exact79c red/green

One existing unittest case was executed once on unchanged published79c, producing the original error `Source checkout native pin differs`. The same case then passed once using the exact published26a127 test module in an external test view. All production modules were linked to the unchanged79c source; the only proposed repository file is the existing test module.

The historical diagnostic intentionally requires17f5 in both candidate and QA source configurations. The old test isolated only the candidate checkout and let the QA fixture read the live2020/f052 configuration. The new fixture copies current original helper bytes into a disposable2019/17f5 QA Git directory. The actual committed-helper byte checks, APK/PCK validation and metadata conditions remain in force; no production verifier, pin, workflow or runtime gate is modified.

The original1-error/exit1 and proposed1-pass/exit0 outputs are preserved completely. Only one test method and its subprocess import change; all other direct function/method ASTs are identical. HEAD/tree/branch/index/status and the eight bound source/config files were checked before and after and remained identical.

No broader suite, package operation, device call or CI action occurred. The test view and temporary Git fixtures are not repository changes and are excluded from the compact archive; their exact construction and source links are recorded in test-view-binding.json. Fresh full CI on a future Root checkpoint remains separate.
