# Host0b7 / Nativebaf: original Native CI artifact

The complete original artifact14120912172 from run43604903064/attempt1 is verified.
All5872 ZIPmembers were fully read and checked for CRC/SHA/size, and all181 PNGs
were fully decoded. The published Host0b7 delivery verifier was then used only
for its scoped Native check against the exact Nativebaf checkout.

The original52-mode results and logs, existing24/4/6/7 rosters, current17-image
extension with original movie/sidecars, Dream5/7/2 and Discovery10/38/2 all pass
unchanged read-only replay. All3689 tracked source entries, full local index and
all466 selected originals remained unchanged. Generated/import entries remain
separately inventoried and were not removed.

The first local replay stopped because the extraction filter omitted the322-byte
discovery/source-commit.raw. Its original error is retained. That exact already
verified ZIP member was materialized and the unchanged production reader then
passed. No second artifact export, no engine/gameplay/test rerun and no changed
CI source were involved.

The compact archive includes complete original API snapshots and central build
job log, all selected non-image/non-video technical originals, original reports,
source inventories, bound reader sources, both local replay records and complete
ZIP/PNG identities. Every archive member is compared byte-for-byte to its source.
It deliberately excludes the full219538798-byte ZIP, all181 PNGs and the original
AVI/MP4. Those originals remain unchanged at the paths in report.json and the
complete inclusion/exclusion lists. Cache and user files remain solely in the
original ZIP, including its generated debug keystore. No signed download URL is
included. Actions expiry is recorded from the original API metadata.

This is a technical desktop CI evidence checkpoint for Host0b7 and Nativebaf.
It does not qualify Native2281, a new APK, Android, physical-device FPS, release,
or human visual acceptance. The active integration refs were not changed.
