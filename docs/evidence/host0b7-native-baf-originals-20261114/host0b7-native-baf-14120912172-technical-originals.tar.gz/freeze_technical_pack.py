#!/usr/bin/env python3
"""Package completed technical originals, preserving large payloads separately."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
ZIP_NAME = '14120912172-original.zip'
ARCHIVE_NAME = 'host0b7-native-baf-14120912172-technical-originals.tar.gz'
PAYLOAD_SUFFIXES = {'.png', '.avi', '.mp4'}


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()}


def write(name, value):
    raw = (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()
    with (ROOT / name).open('xb') as handle:
        handle.write(raw)
    assert (ROOT / name).read_bytes() == raw


def main():
    result = json.loads((ROOT / 'replay-v2/summary.json').read_bytes())
    assert result['status'] == 'PASS'
    archive_check = json.loads((ROOT / 'archive-verification.json').read_bytes())
    assert archive_check['member_count'] == 5872 and archive_check['png_count'] == 181
    assert archive_check['all_crc_sha_verified'] and archive_check['all_pngs_fully_decoded']
    assert not json.loads((ROOT / 'transport-publication-scan.json').read_bytes())['findings']
    selected = json.loads((ROOT / 'selected-original-index.json').read_bytes())['files']
    supplement = json.loads((ROOT / 'selected-original-supplement.json').read_bytes())['files']
    selected += supplement
    selected_map = {row['path']: row for row in selected}
    for row in selected:
        assert identity((ROOT / 'selected-originals' / row['path']).read_bytes()) == {
            key: row[key] for key in ('bytes', 'sha256', 'git_blob')}
    with (ROOT / ZIP_NAME).open('rb') as handle:
        assert hashlib.file_digest(handle, 'sha256').hexdigest() == archive_check['archive_sha256']
    write('verification-executions.json', {
        'archive_verification': {'script': 'verify_original_archive.py', 'exit_code': 0,
            'stdout': 'archive-verification.stdout.log', 'stderr': 'archive-verification.stderr.log'},
        'initial_pure_replay': {'script': 'replay_bound_native.py', 'exit_code': 1,
            'stdout': 'replay.stdout.log', 'stderr': 'replay.stderr.log',
            'original_failure': 'replay/original-replay-error.json',
            'cause': 'The selected local file-extension set omitted the manifest-referenced source-commit.raw. The complete original ZIP already contained and verified that 322-byte member. No CI or product failure is inferred.'},
        'completed_pure_replay': {'script': 'replay_bound_native_v2.py', 'exit_code': 0,
            'stdout': 'replay-v2.stdout.log', 'stderr': 'replay-v2.stderr.log',
            'input_supplement': 'selected-original-supplement.json'},
        'new_engine_gameplay_or_test_runs': 0, 'connector_exports': 1, 'payload_downloads': 1,
        'duplicate_build_log_downloads': 0,
    })
    report = {
        'schema': 1, 'status': 'PASS', 'repository': 'Ullmann27/lumo-lernen',
        'workflow': '.github/workflows/lumo-connect-four-2020.yml',
        'run_id': 43604903064, 'attempt': 1, 'build_job_id': 132478533146,
        'artifact_id': 14120912172, 'artifact_name': 'lumo-candidate-pinned-native-gameplay',
        'host': '0b7bacadd3cdc45d22a8e038c5df50ba8b739d62',
        'host_tree': 'f3a7df4c3112ac63577db00a9637facfea5c0175',
        'native': result['native'], 'native_tree': result['tree'],
        'artifact_bytes': archive_check['archive_bytes'], 'artifact_sha256': archive_check['archive_sha256'],
        'zip_members_verified': 5872, 'original_pngs_fully_decoded': 181,
        'local_png_decoder': 'Pillow 13.0.0',
        'core': {'modes': 52, 'exact_results_order': True, 'per_log_engine_banners': 1,
                 'per_log_matching_pass_markers': 1,
                 'unchanged_original_rosters': {'studio': 24, 'village': 4, 'puzzle_menu': 6,
                    'safe_area': 7, 'studio_2020_extension': 17},
                 'facial_movie': 'Original AVI/MP4 bytes, original ffprobe output, successful original encode/decode exit codes and empty original decode/error logs were checked by the published pure verifier. No local re-encoding or additional movie run.'},
        'dream': result['dream'], 'discovery': result['discovery'],
        'actual_ci_step_seconds': {'native_gameplay': 2913, 'dream': 59, 'discovery': 913},
        'source_invariance': {'ci_dream_and_discovery': 'Both contain all3689 tracked entries, matching before/after bytes and index; 961 generated/untracked entries separately inventoried.',
            'local_read_only_replay': 'All3689 tracked entries, full index, readers and466 selected originals unchanged; existing961 untracked/import entries unchanged.'},
        'source_local_selection_failure_preserved': 'replay/original-replay-error.json',
        'complete_build_job_log': {'path': 'originals/terminal-build/job.original.log', 'bytes': 1864894,
            'sha256': 'af226a4345187fb82f7d2880291db08c9d761feb6fdfe04b303029813ba042ff',
            'origin': 'Copied unchanged from the one central terminal download by pipeline_repair.'},
        'retention': {'complete_original_zip': str(ROOT / ZIP_NAME),
            'selected_originals': str(ROOT / 'selected-originals'), 'selected_files': len(selected),
            'selected_bytes': sum(row['bytes'] for row in selected),
            'actions_expiry_original_api': '2026-12-14T15:55:26Z'},
        'limits': ['This is new Host0b7/Nativebaf CI evidence only; Native2281 qualification remains separate.',
            'The full Host run, candidate APK, Android tours, additional runtime-artifact Return/Wisp gates, release and publication are outside this scoped verification.',
            'No human visual receipt, audible playback or physical-device FPS claim.',
            'The complete ZIP, PNGs, AVI and MP4 remain unchanged outside this compact technical archive.',
            'Full build log retains command echoes as well as actual output. The native-marker index identifies exact original line numbers; one Discovery command echo is not counted as a second executed PASS.'],
    }
    write('report.json', report)
    readme = '''# Host0b7 / Nativebaf: original Native CI artifact

The complete original artifact14120912172 from run43604903064/attempt1 is verified.
All5872 ZIPmembers were fully read and checked for CRC/SHA/size, and all181 PNGs
were fully decoded. The published Host0b7 delivery verifier was then used only
for its scoped Native check against the exact Nativebaf checkout.

The original52-mode results and logs, existing24/4/6/7 rosters, current17-image
extension with original movie/sidecars, Dream5/7/2 and Discovery10/38/2 all pass
unchanged read-only replay. All3689 tracked source entries, full local index and
all466 selected originals remained unchanged. Generated/import entries remain
separately inventoried and were not removed.

The first local replay stopped because the extraction filter omitted the322-byte
discovery/source-commit.raw. Its original error is retained. That exact already
verified ZIP member was materialized and the unchanged production reader then
passed. No second artifact export, no engine/gameplay/test rerun and no changed
CI source were involved.

The compact archive includes complete original API snapshots and central build
job log, all selected non-image/non-video technical originals, original reports,
source inventories, bound reader sources, both local replay records and complete
ZIP/PNG identities. Every archive member is compared byte-for-byte to its source.
It deliberately excludes the full219538798-byte ZIP, all181 PNGs and the original
AVI/MP4. Those originals remain unchanged at the paths in report.json and the
complete inclusion/exclusion lists. Cache and user files remain solely in the
original ZIP, including its generated debug keystore. No signed download URL is
included. Actions expiry is recorded from the original API metadata.

This is a technical desktop CI evidence checkpoint for Host0b7 and Nativebaf.
It does not qualify Native2281, a new APK, Android, physical-device FPS, release,
or human visual acceptance. The active integration refs were not changed.
'''
    with (ROOT / 'README.md').open('x', encoding='utf-8') as handle:
        handle.write(readme)
    member_index = json.loads((ROOT / 'zip-member-inventory.json').read_bytes())['members']
    exclusions = []
    for row in member_index:
        name = row['path']
        included = name in selected_map and Path(name).suffix.lower() not in PAYLOAD_SUFFIXES
        if not included:
            exclusions.append({'original_zip_entry': name,
                **{key: row[key] for key in ('bytes', 'sha256', 'git_blob', 'crc32')},
                'retained_zip': str(ROOT / ZIP_NAME),
                'local_selected_original': str(ROOT / 'selected-originals' / name) if name in selected_map else None,
                'reason': 'Image/movie payload separately retained' if name in selected_map else 'Unselected original cache/user member remains in complete ZIP'})
    write('exclusion-list.json', {'original_zip': {'path': str(ROOT / ZIP_NAME),
        'bytes': archive_check['archive_bytes'], 'sha256': archive_check['archive_sha256']},
        'excluded_original_zip_members': exclusions})
    reserved = {'inclusion-list.json', 'source-file-index.json', 'manifest.json', 'SHA256SUMS',
                'technical-roundtrip.json', 'handoff.json', ARCHIVE_NAME, ZIP_NAME}
    files = []
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or path.is_symlink():
            continue
        relative = path.relative_to(ROOT).as_posix()
        if relative in reserved or path.suffix.lower() in PAYLOAD_SUFFIXES or path.suffix == '.zip':
            continue
        files.append(relative)
    identities = [{'path': name, **identity((ROOT / name).read_bytes())} for name in files]
    write('inclusion-list.json', {'technical_files': identities,
        'included_original_zip_members': [name for name in selected_map
                                         if Path(name).suffix.lower() not in PAYLOAD_SUFFIXES]})
    files.append('inclusion-list.json')
    write('source-file-index.json', {'source_root': str(ROOT), 'files': [
        {'source_path': str(ROOT / name), 'archive_path': name, **identity((ROOT / name).read_bytes())}
        for name in sorted(files)]})
    files.append('source-file-index.json')
    manifest = {'schema': 1, 'status': 'FROZEN', 'scope': 'Technical originals; large unchanged payloads separately retained',
                'host': report['host'], 'native': report['native'], 'artifact_id': report['artifact_id'],
                'files': [{'path': name, **identity((ROOT / name).read_bytes())} for name in sorted(files)]}
    write('manifest.json', manifest)
    files.append('manifest.json')
    checksums = ''.join(identity((ROOT / name).read_bytes())['sha256'] + '  ' + name + '\n'
                        for name in sorted(files))
    with (ROOT / 'SHA256SUMS').open('x', encoding='utf-8') as handle:
        handle.write(checksums)
    files.append('SHA256SUMS')
    archive_path = ROOT / ARCHIVE_NAME
    expected = {name: identity((ROOT / name).read_bytes()) for name in sorted(files)}
    with tarfile.open(archive_path, 'x:gz', compresslevel=9) as archive:
        for name, item in expected.items():
            raw = (ROOT / name).read_bytes()
            assert identity(raw) == item
            entry = tarfile.TarInfo(name)
            entry.size = len(raw)
            entry.mode = 0o644
            entry.mtime = 0
            archive.addfile(entry, io.BytesIO(raw))
    checked = []
    with tarfile.open(archive_path, 'r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == len(expected) and len({m.name for m in members}) == len(expected)
        for member in members:
            assert member.isfile() and member.name in expected
            raw = archive.extractfile(member).read()
            assert raw == (ROOT / member.name).read_bytes() and identity(raw) == expected[member.name]
            checked.append({'path': member.name, **expected[member.name]})
    archive_identity = identity(archive_path.read_bytes())
    write('technical-roundtrip.json', {'status': 'PASS', 'archive': ARCHIVE_NAME,
        **archive_identity, 'members': len(checked), 'all_members_full_bytes_equal_sources': True,
        'files': checked})
    handoff = {'schema': 1, 'status': 'FROZEN', 'frozen_at': datetime.now(timezone.utc).isoformat(),
        'source_root': str(ROOT), 'host': report['host'], 'native': report['native'],
        'run_id': report['run_id'], 'attempt': 1, 'artifact_id': report['artifact_id'],
        'summary': {'core_modes': 52, 'extension_pngs': 17, 'dream': '5/7/2', 'discovery': '10/38/2',
                    'zip_members': 5872, 'all_pngs_decoded': 181},
        'technical_archive': {'path': str(archive_path), **archive_identity, 'members': len(checked)},
        'manifest': {'path': str(ROOT / 'manifest.json'), **identity((ROOT / 'manifest.json').read_bytes())},
        'report': {'path': str(ROOT / 'report.json'), **identity((ROOT / 'report.json').read_bytes())},
        'roundtrip': {'path': str(ROOT / 'technical-roundtrip.json'), **identity((ROOT / 'technical-roundtrip.json').read_bytes())},
        'original_zip_retained': {'path': str(ROOT / ZIP_NAME), 'bytes': archive_check['archive_bytes'],
                                  'sha256': archive_check['archive_sha256']},
        'limits': report['limits']}
    write('handoff.json', handoff)
    print(json.dumps({'handoff': identity((ROOT / 'handoff.json').read_bytes()),
                      'archive': archive_identity, 'members': len(checked),
                      'manifest': handoff['manifest'], 'report': handoff['report']}, indent=2))


if __name__ == '__main__':
    main()
