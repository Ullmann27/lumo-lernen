#!/usr/bin/env python3
"""Read the one original CI ZIP; retain selected originals without rewriting them."""
from __future__ import annotations

import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import time
import zipfile
import zlib

from PIL import Image, __version__ as pillow_version

ROOT = Path(__file__).resolve().parent
ARCHIVE = ROOT / '14120912172-original.zip'
EXPECTED_SIZE = 219538798
EXPECTED_SHA = '8449c8a68c13f6b85e829301ff25a62b158e1ba09715fc29df785271ff48a310'
SELECTED = ROOT / 'selected-originals'


def dump(name: str, value) -> None:
    with (ROOT / name).open('x', encoding='utf-8') as output:
        output.write(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def retained(name: str) -> bool:
    path = PurePosixPath(name)
    if len(path.parts) == 1:
        return path.suffix in {'.log', '.txt', '.py'}
    if path.parts[0] not in {'2014', 'action-stage', 'technical-art', 'nextgen', 'dream', 'discovery'}:
        return False
    if path.suffix in {'.png', '.avi', '.mp4', '.log', '.json', '.tsv', '.txt', '.py'}:
        return True
    return path.name in {'source-index-before.bin', 'source-index-after.bin',
                         'source-tree-before.bin', 'source-tree-after.bin'}


def main() -> None:
    started = time.time()
    assert not SELECTED.exists(), 'A fresh selected-originals directory is required'
    assert ARCHIVE.stat().st_size == EXPECTED_SIZE
    with ARCHIVE.open('rb') as stream:
        actual_digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    assert actual_digest == EXPECTED_SHA
    SELECTED.mkdir()
    rows, pngs, selected, seen = [], [], [], set()
    with zipfile.ZipFile(ARCHIVE) as archive:
        infos = archive.infolist()
        for index, info in enumerate(infos):
            name = info.filename
            posix = PurePosixPath(name)
            assert name and '\\' not in name and not posix.is_absolute()
            assert '..' not in posix.parts and '.' not in posix.parts
            assert str(posix) == name.rstrip('/')
            assert not any(ord(char) < 32 or ord(char) == 127 for char in name)
            assert name not in seen, 'Duplicate ZIP member: ' + name
            seen.add(name)
            mode = info.external_attr >> 16
            kind = stat.S_IFMT(mode)
            assert not stat.S_ISLNK(mode), 'Symlink ZIP member: ' + name
            assert kind in (0, stat.S_IFREG, stat.S_IFDIR), 'Nonregular ZIP member: ' + name
            assert not info.flag_bits & 1, 'Encrypted ZIP member: ' + name
            should_keep = not info.is_dir() and retained(name)
            target = SELECTED.joinpath(*posix.parts)
            if should_keep:
                target.parent.mkdir(parents=True, exist_ok=True)
            sha = hashlib.sha256()
            git = hashlib.sha1(b'blob ' + str(info.file_size).encode() + b'\0')
            crc, length = 0, 0
            png_buffer = io.BytesIO() if posix.suffix.lower() == '.png' else None
            output = target.open('xb') if should_keep else None
            try:
                with archive.open(info) as stream:
                    while chunk := stream.read(1024 * 1024):
                        length += len(chunk)
                        sha.update(chunk)
                        git.update(chunk)
                        crc = zlib.crc32(chunk, crc)
                        if output is not None:
                            output.write(chunk)
                        if png_buffer is not None:
                            png_buffer.write(chunk)
            finally:
                if output is not None:
                    output.close()
            assert length == info.file_size, 'Uncompressed size differs: ' + name
            assert crc & 0xffffffff == info.CRC, 'CRC differs: ' + name
            row = {'path': name, 'bytes': length, 'sha256': sha.hexdigest(),
                   'git_blob': git.hexdigest(), 'crc32': f'{info.CRC:08x}',
                   'compressed_bytes': info.compress_size, 'compression': info.compress_type,
                   'external_attr': info.external_attr, 'directory': info.is_dir(),
                   'selected_original': should_keep}
            rows.append(row)
            if png_buffer is not None:
                raw = png_buffer.getvalue()
                with Image.open(io.BytesIO(raw)) as image:
                    assert image.format == 'PNG'
                    image.verify()
                with Image.open(io.BytesIO(raw)) as image:
                    image.load()
                    assert image.format == 'PNG'
                    pngs.append({'path': name, 'bytes': length, 'sha256': row['sha256'],
                                 'width': image.width, 'height': image.height,
                                 'mode': image.mode, 'full_decode': True})
                png_buffer.close()
            if should_keep:
                with target.open('rb') as stream:
                    readback = hashlib.file_digest(stream, 'sha256').hexdigest()
                assert target.stat().st_size == length and readback == row['sha256']
                selected.append({key: row[key] for key in ('path', 'bytes', 'sha256', 'git_blob')})
            if (index + 1) % 1000 == 0:
                print(f'ZIP members verified: {index + 1}/{len(infos)}', flush=True)
    result = {'schema': 1, 'artifact_id': 14120912172, 'run_id': 43604903064,
              'attempt': 1, 'host': '0b7bacadd3cdc45d22a8e038c5df50ba8b739d62',
              'native': 'baf148b03a7a32c6ad9f737d731f900eb9113ea1',
              'archive_bytes': EXPECTED_SIZE, 'archive_sha256': actual_digest,
              'member_count': len(rows), 'expanded_bytes': sum(row['bytes'] for row in rows),
              'all_crc_sha_verified': True, 'all_paths_safe_unique_regular_or_directory': True,
              'png_count': len(pngs), 'all_pngs_fully_decoded': True,
              'pillow_version': pillow_version, 'selected_count': len(selected),
              'selected_bytes': sum(row['bytes'] for row in selected),
              'seconds': time.time() - started,
              'retention': 'The complete unchanged ZIP is retained locally. Nonselected caches and user files remain only in that ZIP; selected originals were copied byte-for-byte and reread.',
              'scope': 'Transport/member integrity and PNG decoding only. No engine, gameplay, Android, visual review or FPS test was run.'}
    dump('zip-member-inventory.json', {'archive_sha256': actual_digest, 'members': rows})
    dump('png-decode-inventory.json', {'pillow_version': pillow_version, 'pngs': pngs})
    dump('selected-original-index.json', {'files': selected})
    dump('archive-verification.json', result)
    print(json.dumps(result, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        failure = {'status': 'FAIL', 'error_type': type(error).__name__, 'message': str(error)}
        if not (ROOT / 'archive-verification-error.json').exists():
            dump('archive-verification-error.json', failure)
        raise
