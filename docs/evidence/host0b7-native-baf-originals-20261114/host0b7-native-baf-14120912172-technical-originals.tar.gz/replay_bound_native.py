#!/usr/bin/env python3
"""Call only the actual Host0b7 read-only Native delivery validator."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
import traceback

sys.dont_write_bytecode = True
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
os.environ['GIT_OPTIONAL_LOCKS'] = '0'
os.environ['GIT_NO_LAZY_FETCH'] = '1'
ROOT = Path(__file__).resolve().parent
SOURCE = Path('/workspace/scratch/b3485b7bb989/native2281-packaging-export-20261114/checkout-before-baf')
NATIVE = 'baf148b03a7a32c6ad9f737d731f900eb9113ea1'
TREE = '0c18a0ca5200ade267cfedb4c12d5c4b0a761a00'
HOST_HELPER = ROOT / 'bound-readers/host/scripts/verify_connect_four_delivery.py'
EVIDENCE = ROOT / 'selected-originals'
OUTPUT = ROOT / 'replay'


def write(name, value):
    with (OUTPUT / name).open('x', encoding='utf-8') as handle:
        handle.write(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()}


def imported(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main():
    OUTPUT.mkdir()
    started = time.monotonic()
    invocation = {
        'started_at': datetime.now(timezone.utc).isoformat(),
        'command': [sys.executable, '-B', str(Path(__file__).resolve())],
        'host_source': '0b7bacadd3cdc45d22a8e038c5df50ba8b739d62',
        'native_source': NATIVE, 'native_tree': TREE,
        'operation': 'verify_connect_four_delivery.checked_native(originals, exact_baf_checkout, baf)',
        'engine_or_gameplay_or_test_execution': False,
        'original_rewrites': False,
        'legacy_roster_mirror': 'Production verifier creates a temporary private mirror for four older manifest writers; original JSON and payloads remain unchanged.',
    }
    write('invocation.json', invocation)
    closure = json.loads((ROOT / 'native-replay-reader-closure.json').read_bytes())['files']
    for row in closure:
        actual = identity(SOURCE / row['path'])
        assert all(actual[key] == row[key] for key in ('bytes', 'sha256', 'git_blob'))
    expected_host = {
        'bytes': 67003,
        'sha256': '229b33a0f1b7de1c09cbfff871edaec5470e783df9068629a2337d3de4ccaa18',
        'git_blob': '1c788c7d1ea153bcbad90813537f022b6c1d8871',
    }
    assert identity(HOST_HELPER) == expected_host
    selected = json.loads((ROOT / 'selected-original-index.json').read_bytes())['files']
    for row in selected:
        assert identity(EVIDENCE / row['path']) == {key: row[key] for key in ('bytes', 'sha256', 'git_blob')}
    dream = imported(SOURCE / 'tools/verify_dream_rasters.py', '_original_dream_snapshot')
    before = dream.snapshot_source(SOURCE, OUTPUT, 'before')
    assert before['head'] == NATIVE and before['tree'] == TREE
    host = imported(HOST_HELPER, '_original_host0b7_delivery')
    result = None
    error = None
    try:
        result = host.checked_native(EVIDENCE, SOURCE, NATIVE)
        write('native-delivery-recomputed.json', result)
    except BaseException as exc:
        error = exc
        write('original-replay-error.json', {'error_type': type(exc).__name__, 'message': str(exc),
                                           'traceback': traceback.format_exc()})
    finally:
        after = dream.snapshot_source(SOURCE, OUTPUT, 'after')
        unchanged = before == after
        evidence_unchanged = all(identity(EVIDENCE / row['path']) ==
            {key: row[key] for key in ('bytes', 'sha256', 'git_blob')} for row in selected)
        readers_unchanged = identity(HOST_HELPER) == expected_host and all(
            all(identity(SOURCE / row['path'])[key] == row[key]
                for key in ('bytes', 'sha256', 'git_blob')) for row in closure)
        write('invariance.json', {'source_snapshot_unchanged': unchanged,
            'head': after['head'], 'tree': after['tree'],
            'index_sha256': after['index_sha256'], 'tracked_entries': len(after['tracked']),
            'materialized_tracked_entries': sum(row['materialized'] for row in after['tracked']),
            'untracked_import_entries': len(after['untracked_import_inventory']),
            'selected_original_count': len(selected), 'all_selected_originals_unchanged': evidence_unchanged,
            'all_bound_readers_unchanged': readers_unchanged})
        assert unchanged and evidence_unchanged and readers_unchanged
    if error is not None:
        raise error
    summary = {'status': 'PASS', 'host': invocation['host_source'], 'native': NATIVE, 'tree': TREE,
        'run_id': 43604903064, 'attempt': 1, 'artifact_id': 14120912172,
        'core_modes': result['core_modes'], 'original_rosters': result['original_rosters'],
        'dream': {key: result['dream'][key] for key in ('status', 'probe_modes', 'png_count', 'report_count')},
        'discovery': {key: result['discovery'][key] for key in ('status', 'probe_modes', 'png_count', 'report_count')},
        'finished_at': datetime.now(timezone.utc).isoformat(), 'seconds': time.monotonic() - started,
        'scope': 'Fresh original Host0b7/Nativebaf desktop CI evidence rechecked using the published Host validator and exact Native helpers. No new engine run, complete Host delivery, APK, Android, human visual or FPS acceptance.'}
    write('summary.json', summary)
    print(json.dumps(summary, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
