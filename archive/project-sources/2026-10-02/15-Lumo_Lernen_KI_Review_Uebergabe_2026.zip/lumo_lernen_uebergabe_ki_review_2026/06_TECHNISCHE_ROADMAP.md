# Technische Roadmap – Lumo Lernen

## Phase 0 – aktueller Prototyp

Technik:

- HTML
- CSS
- JavaScript
- PWA-Grundlage
- localStorage
- Browser-TTS
- CSS-3D-Fuchs

Ziel:

- Ideen testen
- Handy ausprobieren
- Struktur verstehen
- Feedback sammeln

## Phase 1 – geordnete PWA

Ziele:

- Code modularisieren
- Datenstruktur auslagern
- Aufgabenbank als JSON
- Gutscheinbank als JSON
- besseres Routing
- bessere Offline-Speicherung
- einfache Elternprofile

Technik:

- Vite / React
- TypeScript
- IndexedDB
- Service Worker
- Rive/Lottie Testintegration

## Phase 2 – echte Mobile-App

Optionen:

### Flutter

Vorteile:

- sehr gute Cross-Plattform
- gute Performance
- Rive-Integration stark
- adaptive Layouts möglich

### React Native / Expo

Vorteile:

- schnelle Entwicklung
- Web/Native nahe am Prototyp
- viele Libraries

### Native Android / Jetpack Compose

Vorteile:

- beste Foldable-Integration
- Window Size Classes
- adaptive Layouts
- starke Android-Performance

Empfehlung:

Für ein ernstes Produkt: **Flutter + Rive** oder **Jetpack Compose für Android-first**.

## Phase 3 – Backend

Bausteine:

- Authentifizierung
- Elternkonto
- Kinderprofile
- Aufgabenfortschritt
- Belohnungen
- Fotoanalyse
- Elternberichte
- Datenschutzverwaltung

Optionen:

- Firebase
- Supabase
- eigener Backend-Server

## Phase 4 – KI und OCR

### Fotoanalyse

- OCR
- Klassifikation: Fach, Thema, Punkte, Note, Fehler
- manuelle Elternkorrektur
- Lernplan-Anpassung

### KI-Tutor

- geschlossener Lernkontext
- keine offenen Themen
- kurze Antworten
- kindgerechte Sprache
- Elternfreigabe
- Logging

## Phase 5 – 3D-Premium

- Lumo als Rive/Spine/3D-Figur
- Mundbewegung
- Emotionen
- animierte Lernwelten
- einfliegende Buchstaben
- animierte Rechenobjekte
- Belohnungsraum

## Phase 6 – Store-Launch

- Google Play Families Policy prüfen
- Datenschutztext
- Elternfreigabe
- Kinderschutztest
- Barrierefreiheit
- Performance auf Foldables
- interne Tests mit Eltern/Kinder
