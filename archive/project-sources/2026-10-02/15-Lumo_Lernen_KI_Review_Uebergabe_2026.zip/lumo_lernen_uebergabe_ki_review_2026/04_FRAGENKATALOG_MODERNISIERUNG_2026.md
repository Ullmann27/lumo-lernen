# Fragenkatalog Modernisierung 2026 – Lumo Lernen

Dieser Fragenkatalog ist bewusst sehr umfangreich. Eine andere KI oder ein Entwicklerteam soll damit systematisch prüfen, wie die App moderner, hochwertiger, kindgerechter und technisch zukunftsfähiger werden kann.


## Produktvision & Markt

- Welche Kernemotion soll das Kind beim Öffnen der App spüren?
- Welche drei Wörter beschreiben Lumo als Marke?
- Wirkt die App eher wie Schule, Spiel oder persönlicher Lernfreund?
- Welche modernen Lern-Apps sind 2026 visuell der beste Vergleich?
- Welche Teile dürfen wie Duolingo wirken und welche nicht?
- Wie kann die App hochwertig wirken, ohne das Kind zu überreizen?
- Was unterscheidet Lumo Lernen von klassischen Rechen-Apps?
- Welche Zielgruppe ist zuerst wichtiger: Kind oder Eltern?
- Welche App-Funktion muss in den ersten 10 Sekunden überzeugen?
- Welche langfristige Produktvision entsteht aus dem aktuellen Prototyp?

## UX & Informationsarchitektur

- Ist die aktuelle Navigation für ein 6–8-jähriges Kind sofort verständlich?
- Soll der Startbildschirm nur eine Hauptaktion zeigen?
- Soll es eine tägliche Mission statt freier Fächerwahl geben?
- Wie viele Buttons sind pro Screen maximal sinnvoll?
- Welche Informationen gehören nur in den Elternbereich?
- Welche Informationen überfordern Kinder?
- Wie kann die Innenansicht des Fold besser als Lernzentrale genutzt werden?
- Wie kann die Außenansicht einhändig perfekt bedient werden?
- Welche Screen-Hierarchie wäre für Version 2.0 ideal?
- Braucht jedes Fach eine eigene Lernwelt?

## Visual Design 2026

- Welche Farbpalette wirkt modern, kindgerecht und nicht billig?
- Welche Schatten, Rundungen und Glassmorphism-Elemente sind sinnvoll?
- Wie kann die App hochwertig wie eine Premium-Kinder-App wirken?
- Welche Karten sollen größer werden?
- Welche Elemente wirken noch wie Prototyp statt Produkt?
- Wie sollten Icons ersetzt werden: Emoji, 3D-Icons, eigene Illustrationen?
- Wie viel 3D ist sinnvoll, ohne die App langsam zu machen?
- Wie wird die App auf AMOLED/Fold-Display besonders schön?
- Welche Typografie ist für 1.–2. Klasse geeignet?
- Welche Design-Tokens braucht das System?

## 3D-Figur Lumo

- Wie kann Lumo von CSS-3D zu einem echten 3D/2.5D-Charakter werden?
- Soll Lumo mit Rive, Lottie, Spine, Spline, Unity oder Three.js gebaut werden?
- Welche Idle-Animationen braucht Lumo?
- Wie bewegt Lumo den Kopf, wenn er zuhört?
- Wie zeigt Lumo Freude bei richtigen Antworten?
- Wie reagiert Lumo sanft bei Fehlern?
- Wie kann Lumo müde, stolz, neugierig oder überrascht wirken?
- Wie wird der Mund beim Sprechen animiert?
- Welche Viseme/Phoneme braucht die Lippensynchronisation?
- Wie viele Outfits und Accessoires sollen freischaltbar sein?
- Wie sieht Lumos Zimmer als 3D-Belohnungsraum aus?
- Wie kann Lumo auf dem Fold-Innenbildschirm frei herumlaufen?
- Wie verhindert man, dass Lumo vom Lernen ablenkt?
- Welche Animationsqualität ist Minimum für Premium-App-Feeling?
- Welche Performance-Grenzen gelten auf Android-Handys?

## Animation & Motion

- Welche Buchstaben sollen beim Deutschlernen einfliegen?
- Wie sollen Zahlen bei Matheaufgaben animiert werden?
- Wie sieht eine richtige Antwort visuell aus?
- Wie sieht eine falsche Antwort unterstützend aus, ohne zu beschämen?
- Welche Belohnungsanimation ist motivierend, aber nicht manipulativ?
- Wie animiert man Sterne, ohne Suchtmechaniken zu erzeugen?
- Wie soll der Übergang zwischen Außen- und Innenbildschirm aussehen?
- Welche Mikroanimationen braucht jeder Button?
- Welche Animationen müssen im ruhigen Modus deaktiviert werden?
- Wie können Aufgaben als kleine Szenen statt Textkarten erscheinen?

## Stimme & Sprachinteraktion

- Wie wird aus Android-TTS eine realistische Kinder-App-Stimme?
- Braucht Lumo eine professionelle Sprecherstimme?
- Soll die Stimme lokal oder über Cloud-TTS laufen?
- Wie wird Datenschutz bei Sprachaufnahmen gesichert?
- Wie klingt eine freundliche österreichische Kinderlern-Stimme?
- Wie viele verschiedene Antwortvarianten braucht Lumo?
- Wie erkennt Lumo Frust oder Überforderung?
- Wie soll Lumo antworten, wenn das Kind sagt: Ich kann das nicht?
- Wie wird verhindert, dass Lumo über offene Themen spricht?
- Welche maximale Satzlänge ist für 6–8 Jahre sinnvoll?
- Wie wird Mundbewegung mit Sprache synchronisiert?
- Wie klingt Lumo bei richtiger Antwort anders als bei Hilfe?
- Welche Sprechgeschwindigkeit ist ideal?
- Wie werden Pausen natürlicher gesetzt?
- Wie verhindert man Roboterklang?

## KI-Tutor & Lernlogik

- Welche Aufgaben versteht der aktuelle regelbasierte Lumo bereits?
- Wo braucht es echte KI statt Regeln?
- Wie wird der Lernkontext begrenzt?
- Welche Antworten darf die KI Kindern nicht geben?
- Wie erkennt das System wiederholte Fehler?
- Wie wird ein Kompetenzprofil aufgebaut?
- Wie wird der nächste Lernschritt berechnet?
- Wie oft soll ein Thema wiederholt werden?
- Wie wird Schwierigkeit automatisch erhöht?
- Wie wird Schwierigkeit automatisch reduziert?
- Wie werden Fotoanalysen in den Lernplan integriert?
- Wie wird ein 7-Tage-Lernplan fachlich korrekt generiert?
- Wie wird verhindert, dass KI halluziniert?
- Welche Guardrails braucht der Kinderchat?
- Wie wird die Elternfreigabe für KI-Funktionen gestaltet?

## Aufgabenbank & Pädagogik

- Sind die Matheaufgaben für 1.–2. Klasse korrekt abgestuft?
- Sind Deutschaufgaben altersgerecht?
- Welche österreichischen Lehrplan-Kompetenzen fehlen?
- Wie sollten Aufgaben Metadaten bekommen?
- Welche Fehlerarten müssen gespeichert werden?
- Wie viele Aufgaben pro Kompetenz sind nötig?
- Wie verhindert man Wiederholungs-Langeweile?
- Wie baut man Textaufgaben mit Bildern?
- Wie baut man Hörverständnisübungen?
- Wie baut man Diktatmodus?
- Wie baut man Leseflüssigkeitsanalyse?
- Wie prüft man Aufgabenqualität pädagogisch?
- Wie werden Elternberichte verständlich formuliert?
- Wie werden Tests fair bewertet?
- Wie unterscheidet man Übungsmodus und Prüfungsmodus?

## Belohnungssystem & Gutscheine

- Sind Sterne, XP, Level und Gutscheine sinnvoll verbunden?
- Welche Freischaltlogik ist fair?
- Wie vermeidet man Kaufdruck oder manipulative Streaks?
- Wie werden reale Gutscheine elternfreundlich verwaltet?
- Welche Gutschein-Kategorien fehlen?
- Sollten Eltern eigene Gutscheine erstellen können?
- Soll jeder Gutschein ein Kostenlimit haben?
- Soll es Tages-/Wochenlimits geben?
- Wie verhindert man, dass Kinder nur für Belohnungen lernen?
- Wie werden Bemühung und Mut belohnt?
- Wie werden schwierige Aufgabenversuche belohnt?
- Wie wird ein eingelöster Gutschein dokumentiert?
- Wie können Geschwisterprofile faire Belohnungen bekommen?
- Wie zeigt man Fortschritt ohne Vergleich mit anderen Kindern?
- Wie können digitale und reale Belohnungen kombiniert werden?

## Elternbereich

- Welche KPIs wollen Eltern wirklich sehen?
- Wie zeigt man Schwächen ohne Panik?
- Wie formuliert man Elternberichte positiv?
- Wie sieht ein guter Wochenbericht aus?
- Wie werden Tests, Noten und Zeugnisse gespeichert?
- Wie wird Fotoanalyse erklärt?
- Welche Exportfunktion braucht der Elternbereich?
- Wie werden Daten gelöscht?
- Wie verwaltet man mehrere Kinderprofile?
- Wie können Eltern Lernzeiten einstellen?
- Wie können Eltern Gutscheine bearbeiten?
- Wie können Eltern eigene Lernziele anlegen?
- Wie wird die PIN sicherer?
- Braucht es biometrische Entsperrung?
- Welche Warnhinweise sind sinnvoll?

## Datenschutz & Kinderschutz

- Welche Daten sind besonders sensibel?
- Welche Daten sollten nur lokal gespeichert werden?
- Welche Daten brauchen Cloud-Synchronisierung?
- Welche Daten dürfen niemals für Werbung verwendet werden?
- Wie wird Einwilligung der Eltern dokumentiert?
- Wie wird Datenminimierung umgesetzt?
- Wie wird ein Datenexport umgesetzt?
- Wie wird Datenlöschung umgesetzt?
- Wie wird ein Audit-Log erstellt?
- Wie verhindert man offene Kommunikation mit Fremden?
- Wie verhindert man Rankings und Bloßstellung?
- Wie wird die KI auf Lernkontext begrenzt?
- Welche Store-Policies müssen geprüft werden?
- Wie wird Sicherheit bei Foto-Uploads gewährleistet?
- Wie wird der Umgang mit Sprachdaten geregelt?

## Technik & Architektur

- Soll die App in Flutter, React Native oder Jetpack Compose gebaut werden?
- Welche Technologie ist für Foldables am besten?
- Wie wird responsives Layout für 6.5 Zoll und 8 Zoll umgesetzt?
- Welche lokale Datenbank ist geeignet?
- Welche Cloud ist geeignet: Firebase, Supabase, eigener Server?
- Wie wird Offline-first umgesetzt?
- Wie wird Sync konfliktfrei?
- Wie wird OCR angebunden?
- Wie wird KI sicher angebunden?
- Wie werden Audiodateien verwaltet?
- Wie werden 3D-Assets performant geladen?
- Wie wird App-Größe begrenzt?
- Wie werden Animationen getestet?
- Wie wird Barrierefreiheit getestet?
- Wie wird Store-Release vorbereitet?

## Roadmap & Priorisierung

- Was muss sofort verbessert werden?
- Was gehört in MVP 1.0?
- Was gehört in Version 1.1?
- Was gehört in Version 2.0?
- Was ist nur Premium-Zielbild?
- Welche Funktion bringt Kindern den größten Nutzen?
- Welche Funktion überzeugt Eltern am stärksten?
- Welche Funktion ist technisch am riskantesten?
- Welche Funktion ist rechtlich am sensibelsten?
- Welche Funktion sollte man streichen?
- Welche Funktion braucht echte pädagogische Prüfung?
- Welche Milestones braucht ein Entwicklerteam?
- Wie sieht ein 30-Tage-Plan aus?
- Wie sieht ein 90-Tage-Plan aus?
- Wie sieht ein 12-Monats-Plan aus?

## Zusatzauftrag an die prüfende KI

Beantworte nicht nur die Fragen einzeln. Erstelle daraus eine priorisierte Modernisierungsstrategie:

1. Was ist optisch sofort zu verbessern?
2. Was ist technisch zwingend neu zu bauen?
3. Was ist nur Nice-to-have?
4. Was ist für Kinderschutz/Datenschutz kritisch?
5. Was würde die App am stärksten wie eine 2026-Premium-App wirken lassen?
6. Welche 10 Verbesserungen sollen zuerst umgesetzt werden?
