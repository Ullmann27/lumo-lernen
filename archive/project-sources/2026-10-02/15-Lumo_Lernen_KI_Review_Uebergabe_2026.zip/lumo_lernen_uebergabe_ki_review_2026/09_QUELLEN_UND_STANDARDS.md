# Quellen und technische Bezugspunkte

Diese Quellen wurden als Orientierung für das Review-Briefing aufgenommen:

1. Material Design 3 – Adaptive Design
   https://m3.material.io/foundations/adaptive-design

2. Material Design 3 – Layout
   https://m3.material.io/foundations/layout/understanding-layout

3. Android Developers – Foldables / Adaptive layouts
   https://developer.android.com/develop/ui/compose/layouts/adaptive/foldables/learn-about-foldables

4. WCAG 2.2 – W3C
   https://www.w3.org/TR/WCAG22/

5. WCAG 2 Overview – WAI
   https://www.w3.org/WAI/standards-guidelines/wcag/

6. Google Play Families Policies
   https://support.google.com/googleplay/android-developer/answer/9893335

7. Google Play Console – Families
   https://play.google.com/console/about/programs/families/

8. Samsung Galaxy Z Fold7 official specs
   https://www.samsung.com/ae/smartphones/galaxy-z-fold7/specs/

Hinweis:
Dieses Projekt ersetzt keine juristische Datenschutzprüfung, keine pädagogische Prüfung und keine professionelle Store-Compliance-Prüfung. Für Veröffentlichung im Play Store müssen Richtlinien, Datenschutzrecht und Kinderschutzanforderungen gesondert geprüft werden.
