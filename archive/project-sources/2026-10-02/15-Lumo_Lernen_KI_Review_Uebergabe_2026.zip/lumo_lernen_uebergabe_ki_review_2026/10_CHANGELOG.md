# Changelog Projektstand

## Version Übergabe 2026

Enthalten:

- geordnete App-Struktur
- Außen-/Innenbildschirm-Modus
- Lumo als CSS-3D-Prototyp
- Lumo-Stimme über Browser-TTS
- Lumo-KI-Dialog als regelbasiertes System
- dynamische Aufgabenbank
- Sterne-/XP-/Levelsystem
- Rating/Trefferquote
- 100+ Gutscheine
- automatische Gutschein-Freischaltung
- Eltern-PIN
- Noten-/Fotoanalyse-Demo
- Review-Prompt für KI
- großer Modernisierungsfragenkatalog
- 3D-/Animations-/Stimmen-Briefing
- technische Roadmap
