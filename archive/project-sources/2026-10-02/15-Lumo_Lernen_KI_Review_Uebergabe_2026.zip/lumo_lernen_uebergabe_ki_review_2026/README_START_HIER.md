# Lumo Lernen – Übergabepaket für KI-/Entwickler-Review 2026

## Zweck dieses ZIP-Pakets

Dieses Paket enthält den aktuellen Stand des Projekts **Lumo Lernen**: eine kindgerechte Lern-App für Volksschüler der 1.–2. Klasse, optimiert für Android/Fold-Geräte, insbesondere Galaxy-Z-Fold-ähnliche Außen- und Innenbildschirme.

Die App ist derzeit ein **HTML/PWA-Prototyp**, der direkt am Handy in Chrome geöffnet werden kann.

## Start

1. `index.html` öffnen.
2. In Chrome testen.
3. Optional: Chrome-Menü → „Zum Startbildschirm hinzufügen“.
4. Elternbereich Demo-PIN: `1234`.

## Inhalt des Pakets

- `index.html` – aktuelle lauffähige App
- `01_APP_AKTUELL_index.html` – identische Sicherung der App
- `manifest.json` – PWA-Manifest
- `sw.js` – einfacher Service Worker
- `02_PROJEKTUEBERSICHT.md` – Projektstand und Funktionen
- `03_KI_REVIEW_MASTERPROMPT_2026.md` – Prompt für andere KI / App-Builder / Entwickler-KI
- `04_FRAGENKATALOG_MODERNISIERUNG_2026.md` – sehr großer Fragenkatalog zur Verbesserung
- `05_3D_ANIMATION_STIMME_BRIEFING.md` – Briefing für 3D-Figur, Mundbewegung, Stimme, Animation
- `06_TECHNISCHE_ROADMAP.md` – technische Roadmap Richtung echter App
- `07_CHECKLISTE_KINDERSCHUTZ_DATENSCHUTZ.md` – Kinderschutz-/Datenschutz-Checkliste
- `08_REVIEW_AUFGABE_AN_DIE_KI.txt` – kurze direkte Anweisung an eine andere KI

## Aktueller Funktionsstand

- Fächer: Mathe, Deutsch, Sachunterricht, Logik
- dynamische Aufgabenbank mit 400+ Aufgabenvarianten
- Punkte-/Sterne-System
- XP-/Level-System
- Rating/Trefferquote
- automatische Gutschein-Freischaltung
- 100+ Gutscheinvarianten nach Kategorien
- Eltern-PIN für Gutschein-Einlösung
- Lumo-KI-Dialog als regelbasiertes Offline-System
- optionale Spracheingabe über Browser, falls unterstützt
- Android-/Chrome-Sprachausgabe für Lumo
- CSS-3D-Fuchs mit Bewegung
- Fold-Modus: Außenbildschirm und Innenbildschirm

## Wichtiger Hinweis

Der aktuelle Prototyp ist bewusst als Einzeldatei gebaut, damit er direkt am Handy funktioniert. Für ein echtes Produkt sollte er später in Flutter, React Native/Expo oder native Android/Jetpack Compose übertragen werden.
