# 3D-, Animations- und Stimmen-Briefing – Lumo Lernen 2026

## Ziel

Lumo soll nicht mehr wie eine einfache 2D-Zeichnung wirken, sondern wie eine moderne, lebendige, hochwertige Figur aus einer Premium-Kinder-App.

## Gewünschte Wirkung

- freundlich
- weich
- glaubwürdig
- kindgerecht
- nicht gruselig
- nicht zu realistisch wie ein echtes Tier
- nicht billig-cartoonhaft
- eher hochwertiger 3D-Kinderfilm-/Game-Look

## Figur: Lumo, der Fuchs aus Gänserndorf

### Körper

- 3D- oder 2.5D-Fuchs
- großer Kopf
- weiche runde Formen
- große freundliche Augen
- kurzer Körper
- flauschiger Schweif
- Schal oder Halstuch als Wiedererkennungsmerkmal
- freischaltbare Kleidung / Accessoires

### Emotionen

Lumo braucht mindestens diese Zustände:

1. neutral / idle
2. freundlich begrüßend
3. nachdenklich
4. stolz
5. jubelnd
6. tröstend
7. erklärend
8. überrascht
9. konzentriert
10. müde / ruhiger Modus

### Animationen

#### Idle

- sanftes Atmen
- leichtes Schweben
- gelegentliches Blinzeln
- kleine Kopfbewegung
- Schweif bewegt sich langsam

#### Beim Sprechen

- Mundbewegung
- Kopf leicht mitbewegen
- Augen schauen zum Kind
- kleine Gesten mit Pfoten
- Emotion passt zum Satz

#### Bei richtiger Antwort

- Lumo springt leicht
- Sterne fliegen sanft
- Lumo klatscht
- kurzer fröhlicher Sound

#### Bei falscher Antwort

- kein negativer Ton
- Lumo schaut liebevoll
- hebt eine Pfote
- sagt ruhig: „Fast geschafft“
- keine rote aggressive Animation

#### Bei Gutschein-Freischaltung

- Ticket schwebt herein
- Lumo hält Gutschein hoch
- sanfte Glitzeranimation
- Eltern-PIN wird klar erklärt

## Technologien

Mögliche Ansätze:

### Rive

Gut für:

- interaktive 2.5D-Figur
- State Machines
- kleine Dateigröße
- Mobile Performance
- Flutter/React Native Integration

### Lottie

Gut für:

- fertige Motion-Sequenzen
- Onboarding
- Belohnungen
- Sternanimationen

Nicht ideal für komplexe interaktive Figuren.

### Spine

Gut für:

- 2D-Skelettanimation
- Charakterbewegungen
- Spielelogik

### Three.js / React Three Fiber

Gut für:

- echte Web-3D-Umgebung
- 3D-Figur im Browser
- experimentellen PWA-Prototyp

Risiko:

- Performance
- App-Größe
- Komplexität

### Unity

Gut für:

- sehr hochwertiges 3D
- echte Spielwelt

Risiko:

- schwerer
- größere App
- mehr Entwicklungsaufwand

### Flutter + Rive

Empfehlung für echte App:

- Flutter für Android/Fold/iOS
- Rive für Lumo
- Lottie für Belohnungen
- Firebase/Supabase für Backend
- lokale Datenbank für Offline-Modus

## Mundbewegung / Lip Sync

Mindestlösung:

- Mund öffnet/schließt während Sprachausgabe
- mehrere Mundformen:
  - geschlossen
  - leicht offen
  - breit
  - rund
  - lächeln
  - überrascht

Bessere Lösung:

- Viseme aus TTS generieren
- Audiodatei + Zeitmarken
- Mundbewegung passend zu Silben

Premium-Lösung:

- TTS mit Viseme-Events
- Lumo-State-Machine reagiert auf Satztyp
- Emotion + Mund + Gestik synchron

## Stimme

### Aktuelle Grenze

Der HTML-Prototyp nutzt Android/Chrome Text-to-Speech. Das ist nützlich, aber klingt je nach Gerät unterschiedlich und oft technisch.

### Ziel

- professionelle Kinder-App-Stimme
- warme österreichisch/deutsche Aussprache
- keine Roboterstimme
- klare kurze Sätze
- natürliche Pausen
- freundliche Satzmelodie

### Optionen

1. Professionelle Sprecherin/Sprecher aufnehmen
2. Cloud-TTS mit kindgerechter Stimme
3. On-device TTS, falls hochwertig genug
4. Hybrid: feste Hauptsätze als Audio + dynamische KI-Antworten per TTS

## Buchstaben- und Zahlenanimationen

### Deutsch

- Buchstaben fliegen weich ein
- Silben klatschen visuell
- Wörter bauen sich aus Buchstaben zusammen
- Reimwörter hüpfen nebeneinander
- gelesene Wörter leuchten leicht auf

### Mathe

- Zahlenblöcke / Würfel
- Zehnerstangen
- Einerpunkte
- Plus: Objekte kommen dazu
- Minus: Objekte verschwinden sanft
- Textaufgaben als kleine Szenen mit Äpfeln, Tieren, Figuren

## Fold-spezifische Visualisierung

### Außenbildschirm

- eine Aufgabe pro Screen
- große Buttons
- wenig Text
- Lumo klein unten oder oben
- einhändig bedienbar

### Innenbildschirm

- Lernwelt-Karte links/oben
- Aufgabe zentral
- Lumo als Begleiter
- Eltern-/Fortschrittsinfos in Panels
- Drag-and-drop möglich
- Split-Screen-Lernwelt

## Modernisierungsziel

Die App soll wirken wie:

- kindgerechte Premium-Lernwelt
- 3D-Spielzeugwelt
- sicherer KI-Nachhilfelehrer
- Eltern-Dashboard mit professionellen Analysen
- keine billige Schul-App
