# Projektübersicht – Lumo Lernen

## Produktidee

**Lumo Lernen** ist eine moderne, sichere und kindgerechte Lern-App für Volksschüler der 1.–2. Klasse. Die App soll wie eine lebendige Lernwelt wirken, nicht wie ein trockenes Aufgabenblatt.

Kernfigur ist **Lumo, der Fuchs aus Gänserndorf**. Lumo begrüßt das Kind, erklärt Aufgaben, motiviert bei Fehlern, vergibt Sterne und begleitet durch Lernpfade.

## Zielgruppe

- Kinder 6–8 Jahre
- Eltern / Erziehungsberechtigte
- später optional Lehrer / Nachhilfe

## App-Struktur

### Start

- Lumo-Begrüßung
- Tagesübersicht
- Lernpfad starten
- Belohnungen
- Elternbereich

### Lernen

- Rubriken: Mathe, Deutsch, Sachunterricht, Logik
- einzelne Aufgaben
- Lumo-Hilfe
- Überraschungstest
- KI-Dialog mit Lumo

### Belohnungen

- Sterne
- XP
- Level
- Trefferquote
- 100+ Gutscheine
- automatische Freischaltung
- Eltern-PIN-Einlösung

### Eltern

- PIN-Bereich
- Lernanalyse
- Noteneingabe
- Fotoanalyse-Demo

### Schutz

- Kinderschutz
- keine Werbung
- keine offenen Chats
- keine öffentlichen Rankings
- Datenschutz-/Barrierefreiheitsbereich

## Bestehende technische Umsetzung

- HTML
- CSS
- JavaScript
- PWA-Grundstruktur
- lokale Speicherung über `localStorage`
- Browser-Sprachausgabe über Web Speech API
- optional Speech Recognition API, falls Android/Chrome verfügbar

## Aktuelle Grenzen

- kein echtes Backend
- keine echte OCR/KI-Fotoanalyse
- kein echter Nutzer-Login
- keine echte sichere Datenbank
- keine professionelle synthetische Fuchsstimme
- keine echte 3D-Engine, sondern CSS-3D-Prototyp
- keine echte Mund-/Lippensynchronisation
- keine validierte Pädagogik-Engine
- keine Store-Compliance-Prüfung

## Ziel der nächsten Version

Die nächste Version soll wie eine hochwertige App nach Stand 2026 wirken:

- echtes modernes 3D-Maskottchen
- lebendige Bewegungen
- Mundbewegung passend zur Stimme
- einfliegende Buchstaben/Zahlen
- Lernwelt mit animierten Inseln
- stärkerer KI-Tutor
- professionelles Eltern-Dashboard
- sicherer Datenaufbau
- echte App-Technologie
