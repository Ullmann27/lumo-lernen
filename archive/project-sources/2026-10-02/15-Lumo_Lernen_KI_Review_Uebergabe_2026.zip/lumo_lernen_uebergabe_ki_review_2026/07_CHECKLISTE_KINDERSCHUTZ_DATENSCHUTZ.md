# Checkliste Kinderschutz, Datenschutz und Barrierefreiheit

## Kinderschutz

- [ ] keine Werbung
- [ ] keine fremden Kontakte
- [ ] kein öffentlicher Chat
- [ ] keine Rankings mit anderen Kindern
- [ ] keine Bloßstellung bei Fehlern
- [ ] keine aggressiven Kaufmechaniken
- [ ] keine Lootboxen
- [ ] keine manipulativen Streaks
- [ ] Eltern-PIN für sensible Bereiche
- [ ] Elternfreigabe für Fotoanalyse
- [ ] Elternkontrolle für Gutscheine
- [ ] kindgerechte Sprache
- [ ] Fehler immer positiv erklären

## Datenschutz

- [ ] Datenminimierung
- [ ] lokale Speicherung bevorzugen
- [ ] Cloud nur mit Elternfreigabe
- [ ] Datenexport
- [ ] Datenlöschung
- [ ] Einwilligungsverwaltung
- [ ] Audit-Log für Elternbereich
- [ ] sichere Speicherung von Fotos
- [ ] keine Weitergabe an Werbenetzwerke
- [ ] keine Profilbildung zu Werbezwecken
- [ ] klare Datenschutzerklärung
- [ ] Alters-/Elternlogik

## KI-Sicherheit

- [ ] KI nur im Lernkontext
- [ ] keine offenen Gespräche
- [ ] keine sensiblen Themen
- [ ] keine medizinischen/rechtlichen/privaten Beratungen für Kinder
- [ ] Antwortlänge begrenzen
- [ ] altersgerechte Sprache
- [ ] Eltern können Chat deaktivieren
- [ ] Eltern können Protokoll einsehen
- [ ] Problematische Eingaben werden sicher umgeleitet

## Barrierefreiheit

- [ ] große Touchflächen
- [ ] große Schrift
- [ ] hoher Kontrast
- [ ] Vorlesefunktion
- [ ] ruhiger Modus ohne Animation
- [ ] keine wichtigen Infos nur über Farbe
- [ ] Screenreader-Labels
- [ ] Tastatur-/Switch-Bedienbarkeit prüfen
- [ ] Legasthenie-freundliche Schriftoption
- [ ] reduzierte Bewegung respektieren
