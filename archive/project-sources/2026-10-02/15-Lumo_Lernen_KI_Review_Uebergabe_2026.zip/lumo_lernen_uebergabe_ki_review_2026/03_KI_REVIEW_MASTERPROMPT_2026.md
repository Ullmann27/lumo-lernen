# KI-Review-Masterprompt 2026 – Lumo Lernen

Du bist ein Expertenteam aus:

- Senior Product Designer für Kinder-Apps
- UX/UI-Designer für Foldables und Android Large Screens
- 3D-Character-Designer
- Motion Designer
- Pädagogik-Experte für Volksschule 1.–2. Klasse
- Gamification-Designer ohne Dark Patterns
- KI-Tutor-Architekt
- Mobile-App-Architekt für Flutter / React Native / Jetpack Compose
- Datenschutz- und Kinderschutz-Experte
- Accessibility-Experte für WCAG 2.2

## Aufgabe

Analysiere das Projekt **Lumo Lernen** aus diesem ZIP-Paket. Öffne zuerst:

1. `README_START_HIER.md`
2. `02_PROJEKTUEBERSICHT.md`
3. `index.html`
4. `04_FRAGENKATALOG_MODERNISIERUNG_2026.md`
5. `05_3D_ANIMATION_STIMME_BRIEFING.md`

Erstelle danach eine vollständige, professionelle Verbesserungsanalyse nach Stand 2026.

## Zielbild

Die App soll visuell und technisch auf das Niveau moderner Premium-Kinderlern-Apps gebracht werden:

- keine veraltete 2D-Figur
- 3D- oder 2.5D-Maskottchen mit lebensechter Animation
- beweglicher Mund beim Sprechen
- Augenbewegungen
- Blinzeln
- Idle-Animationen
- Emotionen
- Gesten
- einfliegende Buchstaben
- hüpfende Zahlen
- lebendige Lernwelten
- sanfte Mikroanimationen
- hochwertige Karten
- moderne Navigation
- kindgerechte Sprache
- sichere KI-Kommunikation
- motivierendes, aber nicht manipulatives Belohnungssystem

## Unbedingt prüfen

### 1. UI/UX

- Ist die App logisch aufgebaut?
- Ist die Navigation für Kinder verständlich?
- Ist die Außenbildschirm-/Innenbildschirm-Logik für Foldables gut?
- Sind die Hauptaktionen klar?
- Ist der Elternbereich ausreichend getrennt?
- Wirkt das Design modern genug für 2026?

### 2. 3D / Animation

- Wie kann Lumo lebensechter werden?
- Welche Technologie wäre besser: Rive, Lottie, Spine, Three.js, Unity, Flutter Flame, native Compose Animation?
- Wie wird Lumo mit Mundbewegung umgesetzt?
- Wie sehen gute Idle-, Reaktions- und Belohnungsanimationen aus?
- Wie kann die Lernwelt dreidimensional wirken?
- Wie können Buchstaben, Zahlen und Belohnungen modern animiert werden?

### 3. Stimme / KI-Dialog

- Wie kann Lumo menschlicher sprechen?
- Wie wird eine kindgerechte Fuchsstimme technisch umgesetzt?
- Wie vermeidet man Roboterstimme?
- Wie erkennt die App, ob das Kind Hilfe braucht?
- Wie antwortet die KI abwechslungsreich, aber sicher?
- Wie wird ein geschlossener Lern-KI-Rahmen definiert?

### 4. Pädagogik

- Sind die Aufgaben für 1.–2. Klasse passend?
- Gibt es genug Progression?
- Welche Kompetenzstruktur fehlt?
- Wie muss adaptives Lernen verbessert werden?
- Wie soll Fehlerdiagnose aussehen?
- Wie soll ein 7-Tage-Lernplan fachlich erzeugt werden?

### 5. Belohnungen

- Sind Sterne, XP, Level und Gutscheine sinnvoll?
- Sind 100+ Gutscheine gut kategorisiert?
- Welche Elternkontrollen fehlen?
- Wie verhindert man Druck oder Suchtmechaniken?
- Wie wirkt das Belohnungssystem motivierend und fair?

### 6. Datenschutz / Kinderschutz

- Welche Daten werden verarbeitet?
- Was darf lokal bleiben?
- Was braucht Elternfreigabe?
- Wie muss ein DSGVO-konformes Datenmodell aussehen?
- Wie verhindert man offene Chats?
- Welche Logging-/Audit-Funktionen braucht der Elternbereich?

### 7. Technik

- Sollte das Projekt in Flutter, React Native oder Jetpack Compose neu gebaut werden?
- Wie sähe die Zielarchitektur aus?
- Wie werden Offline-Modus und Synchronisierung gelöst?
- Welche Datenbank ist geeignet?
- Wie wird OCR sicher angebunden?
- Wie wird KI-Auswertung gesichert?
- Wie testet man Foldables?

## Gewünschte Ausgabe

Erstelle:

1. Executive Summary
2. Top-20-Probleme
3. Top-20-Verbesserungen
4. 2026-Designzielbild
5. konkrete UI-Struktur
6. neue Screen-Hierarchie
7. 3D-Figur-Konzept
8. Animationskonzept
9. Sprach-/Stimmenkonzept
10. KI-Tutor-Konzept
11. Belohnungssystem 2.0
12. Eltern-Dashboard 2.0
13. Datenschutz-/Kinderschutz-Konzept
14. technische Zielarchitektur
15. Datenmodell
16. Roadmap MVP → Premium-App
17. konkrete Code-/Framework-Empfehlung
18. Risiken
19. Priorisierung
20. nächster Arbeitsauftrag an Entwickler

Arbeite konkret, kritisch und praxisnah. Keine oberflächlichen Allgemeinplätze.
