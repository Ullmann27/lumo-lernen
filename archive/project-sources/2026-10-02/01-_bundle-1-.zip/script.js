const titles = {
  home: "Gemütliches 3D-Lernzimmer",
  learn: "3D-Lerninsel mit Lumo",
  agent: "Sicherer 3D-Lumo-Agent",
  recognize: "Aufgaben-Erkennung am Zaubertisch",
  check: "Kognitiver Lern-Check",
  bonus: "Lumos Bonus- und Gutscheinzimmer",
  parent: "Ruhiger Elternbereich",
  memory: "MemoryGraph als 3D-Lernbaum",
  privacy: "Datenschutz und Freigaben",
};

const app = document.getElementById("app");
const viewTitle = document.getElementById("viewTitle");
const speech = document.getElementById("speech");
let wrongAttempts = 0;
let stars = 128;
let level = 3;

function setView(id) {
  document.querySelectorAll(".view").forEach((view) => view.classList.toggle("active", view.id === id));
  document.querySelectorAll(".nav-item").forEach((item) => item.classList.toggle("active", item.dataset.view === id));
  viewTitle.textContent = titles[id] || "Lumo Lernen";
  const lines = {
    home: "Servus! Ich bin Lumo. Wir lernen ruhig zusammen.",
    learn: "Ich stehe neben der Aufgabe und verdecke keine Buttons.",
    agent: "Ich rede nur über sichere Lernthemen.",
    recognize: "Ich erkenne Aufgaben und markiere Unsicheres für Eltern.",
    check: "Das ist kein IQ-Test. Es ist nur ein freundliches Förderprofil.",
    bonus: "Echte Gutscheine brauchen immer die Eltern-PIN.",
    parent: "Hier erkläre ich professionell, warum ich etwas empfehle.",
    memory: "Der Lernbaum zeigt Fortschritt, Fehlerarten und hilfreiche Strategien.",
    privacy: "Offline-first. Keine Werbung. Keine fremden Kontakte.",
  };
  speech.textContent = lines[id] || lines.home;
}

document.querySelectorAll("[data-view]").forEach((button) => {
  button.addEventListener("click", () => setView(button.dataset.view));
});

document.getElementById("foldBtn").addEventListener("click", (event) => {
  app.classList.toggle("cover-mode");
  event.target.textContent = app.classList.contains("cover-mode") ? "Außen" : "Innen";
});

document.querySelectorAll(".answer").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".answer").forEach((item) => item.classList.remove("good", "bad"));
    if (button.dataset.answer === "13") {
      button.classList.add("good");
      wrongAttempts = 0;
      stars += 5;
      if (stars > 150) level = 4;
      document.getElementById("stars").textContent = stars;
      document.getElementById("level").textContent = level;
      speech.textContent = "Juhu, richtig! Lumo springt, feiert und Sterne erscheinen.";
      burstStars(button);
    } else {
      button.classList.add("bad");
      wrongAttempts += 1;
      speech.textContent =
        wrongAttempts >= 3
          ? "Fast. Das ist kein Problem. Ich zeige dir jetzt die Lösung langsam."
          : "Fast. Ich setze mich neben die Aufgabe und gebe dir einen ruhigen Tipp.";
      if (wrongAttempts >= 3) {
        document.getElementById("steps").classList.remove("hidden");
      }
    }
  });
});

document.getElementById("helpBtn").addEventListener("click", () => {
  speech.textContent = "Starte bei 18 und gehe 5 Schritte zurück. Ich zeige auf den Zahlenstrahl.";
  document.getElementById("steps").classList.remove("hidden");
});

document.getElementById("nextBtn").addEventListener("click", () => {
  wrongAttempts = 0;
  document.getElementById("steps").classList.add("hidden");
  document.querySelectorAll(".answer").forEach((item) => item.classList.remove("good", "bad"));
  speech.textContent = "Neue Folgeaufgabe: ähnlich, aber etwas ruhiger.";
});

document.getElementById("agentBtn").addEventListener("click", () => {
  const text = document.getElementById("agentInput").value.toLowerCase();
  const answer = document.getElementById("agentAnswer");
  if (/(adresse|telefon|schule|passwort|geheim|wohn)/.test(text)) {
    answer.textContent = "Das musst du mir nicht sagen. Frag bitte Mama, Papa oder einen vertrauten Erwachsenen. Ich helfe dir gern beim Lernen.";
  } else if (/(angst|traurig|weh|verletz|weinen)/.test(text)) {
    answer.textContent = "Das klingt schwer. Bitte sag es Mama, Papa oder einem vertrauten Erwachsenen. Ich bleibe hier und mache mit dir nur einen ruhigen Schritt.";
  } else if (/(treffen|tiktok|instagram|gewalt|sex|kaufen|politik)/.test(text)) {
    answer.textContent = "Darüber rede ich nicht. Aber beim Lernen, Mutmachen oder Ausruhen helfe ich dir gern.";
  } else {
    answer.textContent = "Wir machen es Schritt für Schritt. Ich zeige dir den Anfang.";
  }
});

document.getElementById("recognizeBtn").addEventListener("click", () => {
  const input = document.getElementById("recognitionInput").value.trim();
  const cards = document.getElementById("resultCards");
  let html;
  if (/^\d+\s*\+\s*\d+$/.test(input)) {
    html = [
      ["Fach", "Mathe"],
      ["Kompetenz", "Addition"],
      ["Confidence", "96 %"],
      ["Prüfung", "nicht nötig"],
    ];
  } else if (/^\d+\s*-\s*\d+$/.test(input)) {
    html = [
      ["Fach", "Mathe"],
      ["Kompetenz", "Subtraktion"],
      ["Confidence", "95 %"],
      ["Prüfung", "nicht nötig"],
    ];
  } else if (/note/i.test(input)) {
    html = [
      ["Typ", "Noteneintrag"],
      ["Bereich", "Eltern"],
      ["Confidence", "91 %"],
      ["Prüfung", "Elternprüfung nötig"],
    ];
  } else {
    html = [
      ["Status", "unsicher"],
      ["Fach", "unklar"],
      ["Confidence", "42 %"],
      ["Prüfung", "Elternprüfung nötig"],
    ];
  }
  cards.innerHTML = html.map(([a, b]) => `<div><b>${a}</b><span>${b}</span></div>`).join("");
});

document.getElementById("whyBtn").addEventListener("click", () => {
  const box = document.getElementById("whyBox");
  box.textContent =
    "Lumo empfiehlt Minusrechnen, weil in den letzten 8 Minusaufgaben 5 Fehler beim Rückwärtszählen passiert sind. Die Zahlenstrahl-Hilfe führte in 70 % der Folgeaufgaben zu einer richtigen Lösung. Empfohlen wird eine 5-Tage-Serie mit kurzen Einheiten von 7 Minuten.";
});

function burstStars(target) {
  const rect = target.getBoundingClientRect();
  for (let i = 0; i < 12; i++) {
    const star = document.createElement("span");
    star.textContent = "✦";
    star.style.position = "fixed";
    star.style.left = `${rect.left + rect.width / 2}px`;
    star.style.top = `${rect.top + rect.height / 2}px`;
    star.style.color = "#f6b934";
    star.style.fontSize = `${18 + Math.random() * 18}px`;
    star.style.pointerEvents = "none";
    star.style.zIndex = "1000";
    document.body.appendChild(star);
    const x = (Math.random() - 0.5) * 180;
    const y = -40 - Math.random() * 120;
    star.animate(
      [
        { transform: "translate(0,0) scale(1)", opacity: 1 },
        { transform: `translate(${x}px,${y}px) scale(.2)`, opacity: 0 },
      ],
      { duration: 900, easing: "cubic-bezier(.2,.8,.2,1)" },
    ).onfinish = () => star.remove();
  }
}

let idleTimer;
function resetIdle() {
  clearTimeout(idleTimer);
  idleTimer = setTimeout(() => {
    speech.textContent = "Brauchst du einen kleinen Tipp? Wir können ganz langsam weitermachen.";
  }, 20000);
}
["mousemove", "keydown", "click", "touchstart"].forEach((event) => window.addEventListener(event, resetIdle));
resetIdle();
