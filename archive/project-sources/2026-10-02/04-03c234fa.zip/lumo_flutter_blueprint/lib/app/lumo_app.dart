import 'package:flutter/material.dart';
import '../core/theme/lumo_theme.dart';
import '../features/shell/presentation/lumo_shell.dart';

class LumoApp extends StatelessWidget {
  const LumoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Lumo Lernen',
      theme: LumoTheme.light(),
      darkTheme: LumoTheme.dark(),
      home: const LumoShell(),
    );
  }
}
