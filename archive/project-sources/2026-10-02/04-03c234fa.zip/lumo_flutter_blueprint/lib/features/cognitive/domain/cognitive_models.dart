enum CognitiveArea { pattern, language, numbers, memory, attention }
class CognitiveProfile { final Map<CognitiveArea, double> supportNeed; const CognitiveProfile(this.supportNeed); }
