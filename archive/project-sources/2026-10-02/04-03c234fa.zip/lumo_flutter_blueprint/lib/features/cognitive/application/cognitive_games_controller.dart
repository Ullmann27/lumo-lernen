import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/cognitive_models.dart';

class CognitiveGamesController extends StateNotifier<CognitiveProfile> {
  CognitiveGamesController() : super(const CognitiveProfile({
    CognitiveArea.pattern: 0.3,
    CognitiveArea.language: 0.2,
    CognitiveArea.numbers: 0.5,
    CognitiveArea.memory: 0.4,
    CognitiveArea.attention: 0.35,
  }));
}
final cognitiveGamesControllerProvider = StateNotifierProvider<CognitiveGamesController, CognitiveProfile>((ref) => CognitiveGamesController());
