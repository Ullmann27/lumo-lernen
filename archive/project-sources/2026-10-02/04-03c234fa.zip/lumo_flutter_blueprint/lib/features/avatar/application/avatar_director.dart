import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/avatar_state.dart';

class AvatarDirector extends StateNotifier<LumoAvatarState> {
  AvatarDirector() : super(LumoAvatarState.idle);
  static const movementZones = [AvatarMovementZone(left: 16, top: 88, right: 16, bottom: 132)];

  void handle(AvatarEvent event) {
    switch (event) {
      case AvatarEvent.taskCorrect:
      case AvatarEvent.voucherUnlocked:
      case AvatarEvent.levelUp:
        state = LumoAvatarState.celebrate; break;
      case AvatarEvent.taskWrong1:
      case AvatarEvent.taskWrong2:
        state = LumoAvatarState.comfort; break;
      case AvatarEvent.taskWrong3:
        state = LumoAvatarState.explain; break;
      case AvatarEvent.agentOpened:
        state = LumoAvatarState.listen; break;
      case AvatarEvent.idle20s:
        state = LumoAvatarState.sleepy; break;
    }
  }
}

final avatarDirectorProvider = StateNotifierProvider<AvatarDirector, LumoAvatarState>((ref) => AvatarDirector());
