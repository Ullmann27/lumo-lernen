enum LumoAvatarState { idle, greet, listen, thinking, celebrate, comfort, explain, pointLeft, pointRight, walk, bend, jump, sit, sleepy }
enum AvatarEvent { taskCorrect, taskWrong1, taskWrong2, taskWrong3, idle20s, voucherUnlocked, levelUp, agentOpened }
class AvatarMovementZone {
  final double left; final double top; final double right; final double bottom;
  const AvatarMovementZone({required this.left, required this.top, required this.right, required this.bottom});
}
