import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../application/avatar_director.dart';

class LumoAvatarWidget extends ConsumerWidget {
  const LumoAvatarWidget({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(avatarDirectorProvider);
    return Column(children: [
      Container(height: 220, alignment: Alignment.center, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)), child: const Text('Rive: assets/rive/lumo_avatar.riv')),
      const SizedBox(height: 8),
      Text('AvatarState: ${state.name}'),
    ]);
  }
}
