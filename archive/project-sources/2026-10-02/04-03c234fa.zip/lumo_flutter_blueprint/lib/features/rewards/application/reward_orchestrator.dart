import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/reward_models.dart';

class RewardOrchestrator extends StateNotifier<RewardSnapshot> {
  RewardOrchestrator() : super(const RewardSnapshot(stars: 0, xp: 0, level: 1));
  final List<String> redemptionHistory = [];
  void rewardSuccess({required int stars, required int xp}) {
    final totalXp = state.xp + xp;
    state = RewardSnapshot(stars: state.stars + stars, xp: totalXp, level: 1 + (totalXp ~/ 120));
  }
  bool canUnlockVoucher(int cost) => state.stars >= cost;
  void redeemVoucher(String voucherId, String parentPin) { if (parentPin.length == 6) redemptionHistory.add(voucherId); }
}
final rewardOrchestratorProvider = StateNotifierProvider<RewardOrchestrator, RewardSnapshot>((ref) => RewardOrchestrator());
