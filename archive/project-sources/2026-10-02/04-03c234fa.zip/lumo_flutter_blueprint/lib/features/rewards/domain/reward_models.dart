class RewardSnapshot { final int stars; final int xp; final int level; const RewardSnapshot({required this.stars, required this.xp, required this.level}); }
class Voucher { final String id; final String title; final int cost; final bool unlocked; const Voucher({required this.id, required this.title, required this.cost, required this.unlocked}); }
