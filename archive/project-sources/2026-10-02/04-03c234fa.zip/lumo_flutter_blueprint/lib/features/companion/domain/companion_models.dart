enum CompanionTopic { learning, courage, breakTime, kindness, miniStory, reward }
class CompanionReply { final String text; final bool escalateToAdult; const CompanionReply({required this.text, required this.escalateToAdult}); }
