import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/companion_models.dart';

class CompanionAgent {
  static final _blocked = RegExp(r'adresse|telefon|schule|treffen|whatsapp|instagram|snapchat', caseSensitive: false);
  static final _serious = RegExp(r'angst|allein|hilfe|weh|schmerz|bedroh', caseSensitive: false);

  CompanionReply answer(String input, CompanionTopic topic) {
    if (_blocked.hasMatch(input) || _serious.hasMatch(input)) {
      return const CompanionReply(text: 'Bitte hol einen Erwachsenen dazu. Darüber rede ich hier nicht weiter.', escalateToAdult: true);
    }
    final text = switch (topic) {
      CompanionTopic.learning => 'Wir machen nur den nächsten kleinen Lernschritt.',
      CompanionTopic.courage => 'Du darfst langsam sein. Wichtig ist, dass du weiterprobierst.',
      CompanionTopic.breakTime => 'Mach kurz Pause und atme ruhig ein und aus.',
      CompanionTopic.kindness => 'Freundlich sein heißt warten, zuhören und fair bleiben.',
      CompanionTopic.miniStory => 'Lumo fand heute einen Stern, der nur leuchtet, wenn man mutig weiterübt.',
      CompanionTopic.reward => 'Belohnungen gibt es für Mühe, Fortschritt und Dranbleiben.',
    };
    return CompanionReply(text: text, escalateToAdult: false);
  }
}
final companionAgentProvider = Provider<CompanionAgent>((ref) => CompanionAgent());
