import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../memory/application/memory_graph.dart';
import '../domain/learning_models.dart';

class LearningBrain {
  LearningBrain(this.memoryGraph);
  final MemoryGraph memoryGraph;

  TaskRecommendation nextTask(List<LearningTask> pool) {
    pool.sort((a, b) => memoryGraph.skillRisk(b.skillId).compareTo(memoryGraph.skillRisk(a.skillId)));
    final chosen = pool.first;
    return TaskRecommendation(task: chosen, reason: 'Empfohlen wegen aktueller Förderlücke in ${chosen.skillId}.');
  }

  String explainAfterThreeErrors(LearningTask task) => 'Wir gehen ${task.skillId} jetzt langsam Schritt für Schritt durch.';
  LearningTask followUpTask(LearningTask task) => LearningTask(id: '${task.id}_followup', subject: task.subject, skillId: task.skillId, prompt: 'Ähnliche Aufgabe: ${task.prompt}', options: task.options, correctAnswer: task.correctAnswer, supportedStrategies: task.supportedStrategies);
}

final learningBrainProvider = Provider<LearningBrain>((ref) => LearningBrain(ref.watch(memoryGraphProvider)));
