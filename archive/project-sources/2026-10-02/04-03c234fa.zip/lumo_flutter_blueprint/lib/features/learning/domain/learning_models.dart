enum SubjectArea { math, german, knowledge, logic }
enum ErrorType { concept, attention, reading, impulsive, counting, unknown }
enum HelpStrategy { visualHint, stepByStep, exampleFirst, verbalCue, repeatPrompt }
class SkillScore { final String skillId; final double mastery; final double confidence; final int attempts; const SkillScore({required this.skillId, required this.mastery, required this.confidence, required this.attempts}); }
class LearningTask { final String id; final SubjectArea subject; final String skillId; final String prompt; final List<String> options; final String correctAnswer; final List<HelpStrategy> supportedStrategies; const LearningTask({required this.id, required this.subject, required this.skillId, required this.prompt, required this.options, required this.correctAnswer, required this.supportedStrategies}); }
class TaskRecommendation { final LearningTask task; final String reason; const TaskRecommendation({required this.task, required this.reason}); }
