import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/recognition_models.dart';

class RecognitionEngine {
  Future<RecognitionResult> parseText(String input) async => RecognitionResult(normalizedTask: input.trim(), confidence: 0.92, source: RecognitionSource.textInput, parentCorrectionRequired: false);
  Future<RecognitionResult> parseSpeech(String transcript) async => RecognitionResult(normalizedTask: transcript.trim(), confidence: 0.84, source: RecognitionSource.speechInput, parentCorrectionRequired: transcript.trim().length < 6);
  Future<RecognitionResult> parsePhoto(String imagePath) async => RecognitionResult(normalizedTask: 'OCR: $imagePath', confidence: 0.78, source: RecognitionSource.photoOcr, parentCorrectionRequired: true);
}
final recognitionEngineProvider = Provider<RecognitionEngine>((ref) => RecognitionEngine());
