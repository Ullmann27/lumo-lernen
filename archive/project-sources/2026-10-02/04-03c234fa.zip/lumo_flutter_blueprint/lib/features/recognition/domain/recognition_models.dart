enum RecognitionSource { textInput, speechInput, photoOcr }
class RecognitionResult { final String normalizedTask; final double confidence; final RecognitionSource source; final bool parentCorrectionRequired; const RecognitionResult({required this.normalizedTask, required this.confidence, required this.source, required this.parentCorrectionRequired}); }
