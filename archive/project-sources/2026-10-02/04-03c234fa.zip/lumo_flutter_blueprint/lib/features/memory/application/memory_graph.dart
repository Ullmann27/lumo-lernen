import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/memory_models.dart';
import '../../learning/domain/learning_models.dart';

class MemoryGraph {
  final Map<String, SkillMemoryNode> _nodes = {};
  void storeObservation({required String skillId, required ErrorType errorType, required HelpStrategy strategy, required double effect}) {
    final existing = _nodes[skillId];
    _nodes[skillId] = SkillMemoryNode(skillId: skillId, errors: [...?existing?.errors, errorType], learnedStrategies: [...?existing?.learnedStrategies, StrategyEffect(strategy: strategy, effectScore: effect)]);
  }
  double skillRisk(String skillId) {
    final node = _nodes[skillId];
    if (node == null) return 0.5;
    return (0.6 + node.errors.length * 0.08 - node.learnedStrategies.fold(0.0, (a, b) => a + b.effectScore) / (node.learnedStrategies.isEmpty ? 1 : node.learnedStrategies.length)).clamp(0.0, 1.0);
  }
  RecommendationDebug debugWhy(String skillId) => RecommendationDebug(skillId: skillId, explanation: 'Empfohlen wegen Fehlerhäufung und bisher geringer Stabilisierung.', risk: skillRisk(skillId));
}
final memoryGraphProvider = Provider<MemoryGraph>((ref) => MemoryGraph());
