import '../../learning/domain/learning_models.dart';
class StrategyEffect { final HelpStrategy strategy; final double effectScore; const StrategyEffect({required this.strategy, required this.effectScore}); }
class SkillMemoryNode { final String skillId; final List<ErrorType> errors; final List<StrategyEffect> learnedStrategies; const SkillMemoryNode({required this.skillId, required this.errors, required this.learnedStrategies}); }
class RecommendationDebug { final String skillId; final String explanation; final double risk; const RecommendationDebug({required this.skillId, required this.explanation, required this.risk}); }
