enum VoiceMode { greeting, praise, celebrate, comfort, hint, explainAfter3, story, parentReport }
class VoiceLine {
  final String id; final String text; final VoiceMode mode; final bool premiumRecorded;
  const VoiceLine({required this.id, required this.text, required this.mode, required this.premiumRecorded});
}
