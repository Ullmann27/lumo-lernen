import 'dart:collection';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/voice_models.dart';

class VoiceDirector {
  VoiceDirector(this._tts);
  final FlutterTts _tts;
  final Queue<String> _recent = Queue<String>();
  static const disclosure = 'Hinweis: Das ist eine KI-Stimme.';

  Future<void> speak(VoiceLine line) async {
    if (_recent.contains(line.id)) return;
    if (_recent.length >= 80) _recent.removeFirst();
    _recent.add(line.id);
    await _tts.setLanguage('de-AT');
    await _tts.speak(line.text);
  }
}

final voiceDirectorProvider = Provider<VoiceDirector>((ref) => VoiceDirector(FlutterTts()));
