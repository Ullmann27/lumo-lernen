import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../memory/application/memory_graph.dart';

class ParentDashboardController {
  ParentDashboardController(this.memoryGraph);
  final MemoryGraph memoryGraph;
  String debugWhy(String skillId) => memoryGraph.debugWhy(skillId).explanation;
  String exportSummary() => 'Export enthält Profile, Noten, Testfotos, Lernberichte, Skill-Trends und Datenschutzfreigaben.';
}
final parentDashboardControllerProvider = Provider<ParentDashboardController>((ref) => ParentDashboardController(ref.watch(memoryGraphProvider)));
