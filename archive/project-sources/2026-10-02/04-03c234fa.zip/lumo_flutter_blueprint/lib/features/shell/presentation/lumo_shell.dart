import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/layout/adaptive_layout.dart';
import '../../avatar/presentation/lumo_avatar_widget.dart';
import '../../rewards/application/reward_orchestrator.dart';

class LumoShell extends ConsumerWidget {
  const LumoShell({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final reward = ref.watch(rewardOrchestratorProvider);
    return LayoutBuilder(builder: (context, c) {
      final info = AdaptiveLayoutInfo.fromWidth(c.maxWidth);
      return Scaffold(
        appBar: AppBar(title: const Text('Lumo Lernen'), actions: [Padding(padding: const EdgeInsets.only(right: 16), child: Center(child: Text('⭐ ${reward.stars} | XP ${reward.xp} | Lvl ${reward.level}')))]),
        body: info.splitPanel ? Row(children: const [SizedBox(width: 340, child: _CompanionPanel()), VerticalDivider(width: 1), Expanded(child: _LearningPanel(compact: false))]) : const _LearningPanel(compact: true),
        bottomNavigationBar: info.compact ? const NavigationBar(destinations: [NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Start'), NavigationDestination(icon: Icon(Icons.psychology_outlined), label: 'Lernen'), NavigationDestination(icon: Icon(Icons.card_giftcard), label: 'Bonus'), NavigationDestination(icon: Icon(Icons.family_restroom), label: 'Eltern')], selectedIndex: 1) : null,
      );
    });
  }
}
class _CompanionPanel extends StatelessWidget { const _CompanionPanel(); @override Widget build(BuildContext context) { return Padding(padding: const EdgeInsets.all(16), child: Card(child: ListView(padding: const EdgeInsets.all(16), children: const [Text('Lumo', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), SizedBox(height: 12), LumoAvatarWidget(), SizedBox(height: 12), Text('Innenbildschirm: Split-Panel mit Avatar links und Lernfluss rechts.'), Text('Außenbildschirm: kompakt, einhändig, priorisierte Hauptaktion.')]))); } }
class _LearningPanel extends StatelessWidget { final bool compact; const _LearningPanel({required this.compact}); @override Widget build(BuildContext context) { return ListView(padding: const EdgeInsets.all(16), children: [Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(compact ? 'Außenmodus' : 'Innenmodus', style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 8), const Text('Adaptive AppShell, offline-first, lokale DB, vorbereitet für OCR, Sprache, Agent und Eltern-Debug.'), const SizedBox(height: 12), Wrap(spacing: 8, runSpacing: 8, children: [FilledButton(onPressed: null, child: const Text('Lernen starten')), OutlinedButton(onPressed: null, child: const Text('Aufgabe erkennen')), OutlinedButton(onPressed: null, child: const Text('Elternbereich'))])])))]); } }
