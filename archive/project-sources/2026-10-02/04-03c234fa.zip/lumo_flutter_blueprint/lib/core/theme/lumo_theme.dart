import 'package:flutter/material.dart';

class LumoTheme {
  static ThemeData light() => ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF4F7CFF)),
        scaffoldBackgroundColor: const Color(0xFFF4F9FF),
      );

  static ThemeData dark() => ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF4F7CFF), brightness: Brightness.dark),
      );
}
