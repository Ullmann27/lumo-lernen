class AdaptiveLayoutInfo {
  final bool compact;
  final bool splitPanel;
  const AdaptiveLayoutInfo({required this.compact, required this.splitPanel});

  factory AdaptiveLayoutInfo.fromWidth(double width) {
    return AdaptiveLayoutInfo(compact: width < 600, splitPanel: width >= 840);
  }
}
