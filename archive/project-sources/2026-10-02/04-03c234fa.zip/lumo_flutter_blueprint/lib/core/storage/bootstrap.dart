import 'package:hive_flutter/hive_flutter.dart';

Future<void> bootstrapStorage() async {
  await Hive.initFlutter();
  await Hive.openBox('lumo_app');
}
