import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'app/lumo_app.dart';
import 'core/storage/bootstrap.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await bootstrapStorage();
  runApp(const ProviderScope(child: LumoApp()));
}
