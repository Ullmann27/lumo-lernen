# Technischer Umsetzungsbericht – Lumo Lernen Flutter Umbau

Lumo Lernen wird als modulare Flutter-App mit Android-Fokus, Foldable-Support, Offline-first-Datenhaltung und getrennten Feature-Modulen aufgebaut.[web:69][web:71] Für OCR ist `google_mlkit_text_recognition` geeignet; die Erkennung läuft nativ auf dem Gerät, Flutter dient als Bridge.[web:73][web:79]

## Module

- AvatarDirector: steuert Rive-State-Machine und Event-Mapping.[web:74][web:80]
- VoiceDirector: Hybrid aus Premium-Audio und lokaler TTS mit Anti-Wiederholung.[file:6][file:52]
- LearningBrain: adaptive Aufgabenwahl mit Begründung und Folgeaufgabe nach drei Fehlern.[file:52]
- MemoryGraph: speichert Skill-, Fehler- und Hilfestrategie-Wirkung statt flüchtiger Animationen.[file:52]
- RecognitionEngine: Text, Sprache und OCR mit Confidence Score und Elternkorrektur.[web:73][file:52]
- CompanionAgent: sicherer Themenraum ohne private Datenerhebung.[file:1][file:6]
- RewardOrchestrator: Sterne, XP, Level, Zimmer, Gutscheine, Eltern-PIN.[file:52]
- ParentDashboard: Profile, Noten, Trends, Export und Debug-Erklärungen.[file:52]
- CognitiveGames: Kognitiver Lern-Check statt IQ-Test.[file:52]
- AppShell: adaptive Flutter-UI für außen kompakt, innen Split-Panel.[web:69][web:71]
