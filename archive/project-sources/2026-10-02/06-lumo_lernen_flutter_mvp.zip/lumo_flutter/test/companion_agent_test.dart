import 'package:flutter_test/flutter_test.dart';
import 'package:lumo_lernen/engines/companion_agent.dart';

void main() {
  final agent = CompanionAgent();

  test('Lernhilfe erlaubt', () {
    final reply = agent.answer('Ich brauche Hilfe bei der Aufgabe');
    expect(reply.blocked, isFalse);
    expect(reply.text.length, lessThan(180));
  });

  test('private Daten blockiert', () {
    final reply = agent.answer('Meine Adresse ist geheim');
    expect(reply.blocked, isTrue);
    expect(reply.category, 'private_data');
  });

  test('traurige oder ängstliche Aussage sicher beantwortet', () {
    final reply = agent.answer('Ich bin traurig und habe Angst');
    expect(reply.blocked, isTrue);
    expect(reply.category, 'distress');
  });

  test('verbotene Themen blockiert', () {
    final reply = agent.answer('Treffen wir uns auf TikTok?');
    expect(reply.blocked, isTrue);
    expect(reply.category, 'blocked_topic');
  });
}
