import 'package:flutter_test/flutter_test.dart';
import 'package:lumo_lernen/core/models/enums.dart';
import 'package:lumo_lernen/core/models/rewards.dart';
import 'package:lumo_lernen/engines/reward_orchestrator.dart';

void main() {
  test('Sterne/XP werden vergeben und Level steigt', () {
    final orchestrator = RewardOrchestrator(wallet: RewardWallet(stars: 0, xp: 98, level: 1, vouchers: const <Voucher>[]));
    final result = orchestrator.grant(RewardEvent.correctAnswer);
    expect(result.success, isTrue);
    expect(orchestrator.wallet.stars, greaterThan(0));
    expect(orchestrator.wallet.xp, greaterThan(98));
    expect(orchestrator.wallet.level, greaterThan(1));
  });

  test('Gutschein nur mit PIN und Historie wird gespeichert', () {
    final voucher = const Voucher(id: 'story', title: 'Extra-Geschichte', emoji: '📖', costStars: 40);
    final orchestrator = RewardOrchestrator(wallet: RewardWallet(stars: 50, xp: 0, level: 1, vouchers: <Voucher>[voucher]));
    expect(orchestrator.redeemVoucher('story', '0000').success, isFalse);
    final result = orchestrator.redeemVoucher('story', '1234');
    expect(result.success, isTrue);
    expect(orchestrator.wallet.history, isNotEmpty);
    expect(orchestrator.wallet.vouchers.first.redeemed, isTrue);
  });
}
