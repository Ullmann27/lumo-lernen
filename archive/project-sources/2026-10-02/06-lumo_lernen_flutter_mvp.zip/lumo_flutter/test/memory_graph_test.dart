import 'package:flutter_test/flutter_test.dart';
import 'package:lumo_lernen/core/models/enums.dart';
import 'package:lumo_lernen/engines/exercise_factory.dart';
import 'package:lumo_lernen/engines/memory_graph.dart';

void main() {
  test('SkillScore speichern und Fehlerart zählen', () {
    final graph = MemoryGraph();
    final exercise = ExerciseFactory().generate(Skill.subtractionTo20);
    graph.recordExercise(exercise, correct: false, errorType: 'Rückwärtszählen');
    expect(graph.memoryFor(Skill.subtractionTo20).mistakes, 1);
    expect(graph.errorTypeCounts.count('Rückwärtszählen'), 1);
  });

  test('HelpStrategyEffect und LearnedStrategy erst ab mindestens 5 Nutzungen und >65 Prozent Erfolg', () {
    final graph = MemoryGraph();
    for (var i = 0; i < 4; i++) {
      graph.recordHelpStrategy(Skill.subtractionTo20, ExplanationStyle.numberLine, success: true);
    }
    expect(graph.learnedStrategies, isEmpty);
    graph.recordHelpStrategy(Skill.subtractionTo20, ExplanationStyle.numberLine, success: true);
    expect(graph.learnedStrategies, isNotEmpty);
  });

  test('toJson/fromJson funktioniert', () {
    final graph = MemoryGraph();
    final exercise = ExerciseFactory().generate(Skill.additionTo10);
    graph.recordExercise(exercise, correct: true);
    final restored = MemoryGraph.fromJson(graph.toJson());
    expect(restored.memoryFor(Skill.additionTo10).successes, 1);
  });
}
