import 'package:flutter_test/flutter_test.dart';
import 'package:lumo_lernen/core/models/enums.dart';
import 'package:lumo_lernen/core/models/recognition_models.dart';
import 'package:lumo_lernen/engines/recognition_engine.dart';

void main() {
  final engine = RecognitionEngine();

  test('erkennt 12 + 7', () {
    final result = engine.parse('12 + 7');
    expect(result.recognized, isTrue);
    expect(result.skill, Skill.additionTo20);
  });

  test('erkennt 18 - 5', () {
    final result = engine.parse('18 - 5');
    expect(result.recognized, isTrue);
    expect(result.skill, Skill.subtractionTo20);
  });

  test('erkennt Zahlenreihe', () {
    final result = engine.parse('2, 4, 6, ?');
    expect(result.recognized, isTrue);
    expect(result.skill, Skill.numberSequence);
    expect(result.exercise?.answer, '8');
  });

  test('erkennt Anfangsbuchstabe Mama', () {
    final result = engine.parse('Anfangsbuchstabe Mama');
    expect(result.recognized, isTrue);
    expect(result.skill, Skill.initialSound);
  });

  test('erkennt Reim Haus', () {
    final result = engine.parse('Was reimt sich auf Haus?');
    expect(result.recognized, isTrue);
    expect(result.skill, Skill.rhymes);
  });

  test('erkennt Neue Note Mathe 2', () {
    final result = engine.parse('Neue Note Mathe 2');
    expect(result.recognized, isTrue);
    expect(result.kind, RecognitionKind.gradeEntry);
    expect(result.needsParentReview, isTrue);
  });

  test('unbekannte Eingabe ergibt recognized=false', () {
    final result = engine.parse('xyz ohne sinn');
    expect(result.recognized, isFalse);
  });
}
