import 'package:flutter_test/flutter_test.dart';
import 'package:lumo_lernen/core/models/enums.dart';
import 'package:lumo_lernen/engines/learning_brain.dart';
import 'package:lumo_lernen/engines/memory_graph.dart';

void main() {
  test('LearningBrain erzeugt Aufgabe mit Reason', () {
    final brain = LearningBrain(memory: MemoryGraph());
    final recommendation = brain.nextExercise(focus: Skill.subtractionTo20);
    expect(recommendation.exercise.prompt, isNotEmpty);
    expect(recommendation.reason, contains('Lumo empfiehlt'));
  });

  test('richtige Antwort wird als Erfolg gewertet', () {
    final memory = MemoryGraph();
    final brain = LearningBrain(memory: memory);
    final recommendation = brain.nextExercise(focus: Skill.subtractionTo20);
    final feedback = brain.submitAnswer(recommendation.exercise, recommendation.exercise.answer);
    expect(feedback.isCorrect, isTrue);
    expect(memory.memoryFor(recommendation.exercise.skill).successes, 1);
  });

  test('falsche Antworten erhöhen Fehlversuche und nach 3 Fehlern entsteht Erklärung mit Folgeaufgabe', () {
    final brain = LearningBrain(memory: MemoryGraph());
    final exercise = brain.nextExercise(focus: Skill.subtractionTo20).exercise;
    expect(brain.submitAnswer(exercise, '0').attempts, 1);
    expect(brain.submitAnswer(exercise, '1').attempts, 2);
    final third = brain.submitAnswer(exercise, '2');
    expect(third.attempts, 3);
    expect(third.showExplanation, isTrue);
    expect(third.explanationSteps, isNotEmpty);
    expect(third.followUp, isNotNull);
  });
}
