import 'package:flutter/material.dart';

import '../../engines/app_state.dart';
import '../../widgets/common/lumo_button.dart';
import '../../widgets/common/lumo_card.dart';

class RewardsScreen extends StatefulWidget {
  const RewardsScreen({super.key});

  @override
  State<RewardsScreen> createState() => _RewardsScreenState();
}

class _RewardsScreenState extends State<RewardsScreen> {
  final TextEditingController pin = TextEditingController(text: '1234');
  String message = 'Demo-PIN 1234 ist nur Prototyp. Später sichere PIN-Verwaltung nötig.';

  @override
  void dispose() {
    pin.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    return SingleChildScrollView(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
        LumoCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
          Text('Lumo-Zimmer', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 12),
          Wrap(spacing: 12, runSpacing: 12, children: <Widget>[
            _RoomItem(label: 'Schal', icon: '🧣'),
            _RoomItem(label: 'Lampe', icon: '💡'),
            _RoomItem(label: 'Mini-Haustier', icon: '🐾'),
            _RoomItem(label: 'Sterne', icon: '⭐ ${state.wallet.stars}'),
          ]),
        ])),
        const SizedBox(height: 16),
        TextField(controller: pin, decoration: const InputDecoration(labelText: 'Eltern-PIN Demo', border: OutlineInputBorder())),
        const SizedBox(height: 10),
        Text(message),
        const SizedBox(height: 16),
        GridView.count(
          crossAxisCount: MediaQuery.sizeOf(context).width < 700 ? 1 : 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 2.6,
          children: state.wallet.vouchers
              .map((voucher) => LumoCard(
                    child: Row(children: <Widget>[
                      Text(voucher.emoji, style: const TextStyle(fontSize: 32)),
                      const SizedBox(width: 12),
                      Expanded(child: Text('${voucher.title}\n${voucher.costStars} Sterne${voucher.redeemed ? ' · eingelöst' : ''}', style: const TextStyle(fontWeight: FontWeight.w800))),
                      LumoButton(
                        label: 'Einlösen',
                        onPressed: voucher.redeemed
                            ? null
                            : () {
                                final result = state.redeemVoucher(voucher.id, pin.text);
                                setState(() => message = result.message);
                              },
                      ),
                    ]),
                  ))
              .toList(),
        ),
      ]),
    );
  }
}

class _RoomItem extends StatelessWidget {
  const _RoomItem({required this.label, required this.icon});

  final String label;
  final String icon;

  @override
  Widget build(BuildContext context) => DecoratedBox(
        decoration: BoxDecoration(color: Colors.white.withAlpha(170), borderRadius: BorderRadius.circular(22)),
        child: Padding(padding: const EdgeInsets.all(16), child: Text('$icon\n$label', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800))),
      );
}
