import 'package:flutter/material.dart';

import '../../engines/app_state.dart';
import '../../widgets/common/lumo_button.dart';
import '../../widgets/common/lumo_card.dart';

class CognitiveScreen extends StatelessWidget {
  const CognitiveScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final profile = state.cognitiveProfile;
    return SingleChildScrollView(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
        GridView.count(
          crossAxisCount: MediaQuery.sizeOf(context).width < 700 ? 1 : 3,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          children: const <Widget>[
            _GameCard(title: 'Zahlenreihe fortsetzen', body: '2 · 4 · 6 · ?'),
            _GameCard(title: 'Symbolfolge merken', body: '⭐ 🟢 🔷 🦊'),
            _GameCard(title: 'Muster erkennen', body: '◆ ● ◆ ● ?'),
          ],
        ),
        const SizedBox(height: 16),
        LumoCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
          Text('Kognitiver Lern-Check', style: Theme.of(context).textTheme.headlineSmall),
          const Text('Kein IQ-Test. Keine Diagnose. Keine klinische Bewertung. Nur ein lokales Förderprofil.'),
          const SizedBox(height: 12),
          LumoButton(label: 'Förderprofil starten', onPressed: state.runCognitiveCheck),
          if (profile != null) ...<Widget>[const SizedBox(height: 12), Text(profile.summary, style: const TextStyle(fontWeight: FontWeight.w900))],
        ])),
      ]),
    );
  }
}

class _GameCard extends StatelessWidget {
  const _GameCard({required this.title, required this.body});

  final String title;
  final String body;

  @override
  Widget build(BuildContext context) => LumoCard(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
        Text(title, style: Theme.of(context).textTheme.titleLarge, textAlign: TextAlign.center),
        const SizedBox(height: 12),
        Text(body, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
      ]));
}
