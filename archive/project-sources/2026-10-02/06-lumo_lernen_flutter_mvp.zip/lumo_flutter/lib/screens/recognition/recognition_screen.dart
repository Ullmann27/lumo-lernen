import 'package:flutter/material.dart';

import '../../core/models/enums.dart';
import '../../engines/app_state.dart';
import '../../widgets/common/lumo_button.dart';
import '../../widgets/common/lumo_card.dart';

class LearningRecognitionScreen extends StatefulWidget {
  const LearningRecognitionScreen({super.key, required this.onNavigateToLearning});

  final VoidCallback onNavigateToLearning;

  @override
  State<LearningRecognitionScreen> createState() => _LearningRecognitionScreenState();
}

class _LearningRecognitionScreenState extends State<LearningRecognitionScreen> {
  final TextEditingController controller = TextEditingController(text: '12 + 7');

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final result = state.lastRecognition;
    return SingleChildScrollView(
      child: LumoCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
          Text('3D-Zaubertisch für Aufgaben-Erkennung', style: Theme.of(context).textTheme.headlineSmall),
          const Text('Text, Sprache oder später Foto/OCR werden in Fach, Kompetenz, Schwierigkeit und Confidence übersetzt.'),
          const SizedBox(height: 12),
          TextField(controller: controller, decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'Aufgabe oder Notiz')),
          const SizedBox(height: 12),
          Wrap(spacing: 10, runSpacing: 10, children: <Widget>[
            LumoButton(label: 'Erkennen', onPressed: () => state.recognize(controller.text)),
            LumoButton(
              label: state.consentService.isEnabled(ConsentType.photoAnalysis) ? 'Foto/OCR Stub' : 'Foto braucht Elternfreigabe',
              secondary: true,
              onPressed: state.consentService.isEnabled(ConsentType.photoAnalysis) ? () => state.recognize('18 - 5') : null,
            ),
          ]),
          const SizedBox(height: 16),
          if (result != null)
            GridView.count(
              crossAxisCount: MediaQuery.sizeOf(context).width < 700 ? 2 : 4,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              children: <Widget>[
                _ResultTile(label: 'Status', value: result.recognized ? 'erkannt' : 'unsicher'),
                _ResultTile(label: 'Fach', value: result.subject?.label ?? 'unklar'),
                _ResultTile(label: 'Kompetenz', value: result.skill?.label ?? 'unklar'),
                _ResultTile(label: 'Confidence', value: '${(result.confidence * 100).round()} %'),
              ],
            ),
          if (result != null) ...<Widget>[
            const SizedBox(height: 12),
            Text(result.explanation),
            const SizedBox(height: 12),
            Wrap(spacing: 10, children: <Widget>[
              LumoButton(
                label: 'ins Training übernehmen',
                onPressed: result.exercise == null
                    ? null
                    : () {
                        state.takeRecognizedIntoTraining();
                        widget.onNavigateToLearning();
                      },
              ),
              if (result.needsParentReview) LumoButton(label: 'Elternprüfung nötig', secondary: true, onPressed: () {}),
            ]),
          ],
        ]),
      ),
    );
  }
}

class _ResultTile extends StatelessWidget {
  const _ResultTile({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => LumoCard(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
          Text(label, style: Theme.of(context).textTheme.labelMedium),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w900)),
        ]),
      );
}
