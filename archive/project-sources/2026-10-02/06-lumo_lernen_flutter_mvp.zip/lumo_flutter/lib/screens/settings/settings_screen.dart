import 'package:flutter/material.dart';

import '../../core/models/enums.dart';
import '../../engines/app_state.dart';
import '../../widgets/common/consent_tile.dart';
import '../../widgets/common/lumo_button.dart';
import '../../widgets/common/lumo_card.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    return SingleChildScrollView(
      child: LumoCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
        Text('Datenschutz und Freigaben', style: Theme.of(context).textTheme.headlineSmall),
        const Text('Standard: keine Werbung, keine offenen Chats, keine fremden Kontakte, keine Standortdaten, keine echten Schulnamen und keine Werbeprofile.'),
        const SizedBox(height: 12),
        for (final type in ConsentType.values)
          ConsentTile(type: type, enabled: state.consentService.isEnabled(type), onChanged: (value) => state.setConsent(type, value)),
        const Divider(),
        Wrap(spacing: 10, runSpacing: 10, children: <Widget>[
          LumoButton(label: 'TTS testen', secondary: true, onPressed: state.consentService.isEnabled(ConsentType.aiVoice) ? () {} : null),
          LumoButton(label: 'Export Stub', secondary: true, onPressed: state.consentService.isEnabled(ConsentType.dataExport) ? () {} : null),
          LumoButton(label: 'Daten löschen', onPressed: state.consentService.isEnabled(ConsentType.dataDeletion) ? state.clearLocalLearningData : null),
        ]),
      ])),
    );
  }
}
