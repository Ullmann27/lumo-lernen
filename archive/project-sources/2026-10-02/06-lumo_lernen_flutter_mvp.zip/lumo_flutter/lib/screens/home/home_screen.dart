import 'package:flutter/material.dart';

import '../../app/theme.dart';
import '../../core/models/enums.dart';
import '../../engines/app_state.dart';
import '../../widgets/avatar/lumo_avatar.dart';
import '../../widgets/common/lumo_card.dart';
import '../../widgets/common/metric_tile.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.onNavigate});

  final ValueChanged<LumoMenu> onNavigate;

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          LayoutBuilder(
            builder: (context, constraints) {
              final compact = constraints.maxWidth < 720;
              return LumoCard(
                child: Stack(
                  children: <Widget>[
                    Positioned(right: 10, top: 10, child: _FloatingObject(text: 'A', color: LumoColors.blue)),
                    Positioned(right: 90, top: 60, child: _FloatingObject(text: '7', color: LumoColors.star)),
                    Positioned(left: 24, bottom: 24, child: _Blackboard(text: 'Heute: 7 Minuten ruhig lernen')),
                    if (compact)
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Center(child: LumoAvatar(size: 160, mood: AvatarMood.greet)),
                          const SizedBox(height: 22),
                          _HeroCopy(state: state),
                        ],
                      )
                    else
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          LumoAvatar(size: 220, mood: AvatarMood.greet),
                          const SizedBox(width: 22),
                          Expanded(child: _HeroCopy(state: state)),
                        ],
                      ),
                  ],
                ),
              );
            },
          ),
          const SizedBox(height: 18),
          GridView.count(
            crossAxisCount: MediaQuery.sizeOf(context).width < 700 ? 1 : 2,
            crossAxisSpacing: 14,
            mainAxisSpacing: 14,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: MediaQuery.sizeOf(context).width < 700 ? 3.0 : 2.2,
            children: <Widget>[
              _ModuleCard(title: 'Endlos lernen', body: 'Aufgabe, Hilfe, Folgeaufgabe', icon: '🧮', onTap: () => onNavigate(LumoMenu.learning)),
              _ModuleCard(title: 'Aufgabe erkennen', body: 'Text, Sprache, Foto später', icon: '🔎', onTap: () => onNavigate(LumoMenu.recognition)),
              _ModuleCard(title: 'Lumo fragen', body: 'Sicherer Lernfreund', icon: '💬', onTap: () => onNavigate(LumoMenu.agent)),
              _ModuleCard(title: 'Bonuszimmer', body: 'Sterne und Gutscheine', icon: '⭐', onTap: () => onNavigate(LumoMenu.rewards)),
            ],
          ),
        ],
      ),
    );
  }
}


class _HeroCopy extends StatelessWidget {
  const _HeroCopy({required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text('Servus! Ich bin Lumo.', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 8),
          Text(state.currentSpeech.text),
          const SizedBox(height: 16),
          Wrap(spacing: 12, runSpacing: 12, children: <Widget>[
            MetricTile(label: 'Sterne', value: '${state.wallet.stars}', icon: '⭐'),
            MetricTile(label: 'Level', value: '${state.wallet.level}', icon: '🏆'),
            const MetricTile(label: 'Mission', value: '7 min', icon: '⏱️'),
          ]),
        ],
      );
}

class _ModuleCard extends StatelessWidget {
  const _ModuleCard({required this.title, required this.body, required this.icon, required this.onTap});

  final String title;
  final String body;
  final String icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => LumoCard(
        onTap: onTap,
        child: Row(children: <Widget>[
          Text(icon, style: const TextStyle(fontSize: 34)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
            Text(title, style: Theme.of(context).textTheme.titleLarge),
            Text(body),
          ])),
        ]),
      );
}

class _Blackboard extends StatelessWidget {
  const _Blackboard({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) => DecoratedBox(
        decoration: BoxDecoration(color: const Color(0xFF355C4A), borderRadius: BorderRadius.circular(18)),
        child: Padding(padding: const EdgeInsets.all(14), child: Text(text, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800))),
      );
}

class _FloatingObject extends StatelessWidget {
  const _FloatingObject({required this.text, required this.color});

  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) => DecoratedBox(
        decoration: BoxDecoration(color: color.withAlpha(180), borderRadius: BorderRadius.circular(18)),
        child: Padding(padding: const EdgeInsets.all(14), child: Text(text, style: const TextStyle(fontWeight: FontWeight.w900))),
      );
}
