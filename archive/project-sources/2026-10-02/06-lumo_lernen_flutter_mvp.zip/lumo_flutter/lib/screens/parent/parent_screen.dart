import 'package:flutter/material.dart';

import '../../engines/app_state.dart';
import '../../widgets/common/lumo_button.dart';
import '../../widgets/common/lumo_card.dart';
import '../../widgets/common/metric_tile.dart';

class ParentScreen extends StatefulWidget {
  const ParentScreen({super.key});

  @override
  State<ParentScreen> createState() => _ParentScreenState();
}

class _ParentScreenState extends State<ParentScreen> {
  final TextEditingController pin = TextEditingController(text: '1234');
  bool unlocked = false;
  String why = 'Tippen Sie auf „Warum empfiehlt Lumo das?“';

  @override
  void dispose() {
    pin.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    if (!unlocked) {
      return LumoCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
        Text('Elternbereich', style: Theme.of(context).textTheme.headlineSmall),
        const Text('PIN-Schutz. Demo-PIN 1234 ist nur Prototyp; produktiv muss sie sicher verwaltet werden.'),
        const SizedBox(height: 12),
        TextField(controller: pin, decoration: const InputDecoration(labelText: 'Eltern-PIN', border: OutlineInputBorder()), obscureText: true),
        const SizedBox(height: 12),
        LumoButton(label: 'Entsperren', onPressed: () => setState(() => unlocked = pin.text == '1234')),
      ]));
    }
    final memory = state.memoryGraph.memoryFor(state.currentExercise.skill);
    return SingleChildScrollView(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
        Wrap(spacing: 12, runSpacing: 12, children: <Widget>[
          MetricTile(label: 'Was kann mein Kind?', value: '${(memory.successRate * 100).round()} %', icon: '✅'),
          MetricTile(label: 'Was fällt schwer?', value: state.memoryGraph.weakestSkill().label, icon: '🧩'),
          MetricTile(label: 'Was hilft?', value: 'Zahlenstrahl', icon: '📏'),
        ]),
        const SizedBox(height: 16),
        LumoCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
          Text('Dashboard', style: Theme.of(context).textTheme.headlineSmall),
          const Text('Im Bereich Subtraktion bis 20 zeigt sich erhöhter Wiederholungsbedarf.'),
          const Text('Die häufigste Fehlerart ist Rückwärtszählen.'),
          const Text('Visuelle Zahlenstrahl-Hilfe führte in gespeicherten Folgeaufgaben zu besseren Lösungen, sobald genug Daten vorliegen.'),
          const Text('Empfohlen wird eine 5-Tage-Serie mit kurzen Einheiten von 7 Minuten.'),
          const SizedBox(height: 12),
          LumoButton(label: 'Warum empfiehlt Lumo das?', onPressed: () => setState(() => why = state.whyRecommendation())),
          const SizedBox(height: 12),
          Text(why, style: const TextStyle(fontWeight: FontWeight.w800)),
        ])),
        const SizedBox(height: 16),
        LumoCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const <Widget>[
          Text('Weitere Elternfunktionen', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
          Text('Noten · Testfoto-Stubs · Datenschutzfreigaben · Export · Löschfunktion · Gutscheinverwaltung · eigene Aufgaben · Wochenbericht · Fotoanalyseprüfung'),
        ])),
      ]),
    );
  }
}
