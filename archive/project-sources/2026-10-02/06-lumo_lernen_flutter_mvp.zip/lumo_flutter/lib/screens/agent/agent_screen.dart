import 'package:flutter/material.dart';

import '../../engines/app_state.dart';
import '../../widgets/avatar/lumo_avatar.dart';
import '../../widgets/common/lumo_button.dart';
import '../../widgets/common/lumo_card.dart';

class AgentScreen extends StatefulWidget {
  const AgentScreen({super.key});

  @override
  State<AgentScreen> createState() => _AgentScreenState();
}

class _AgentScreenState extends State<AgentScreen> {
  final TextEditingController controller = TextEditingController(text: 'Ich verstehe die Aufgabe nicht');

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    return SingleChildScrollView(
      child: LumoCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
          Center(child: LumoAvatar(size: 150, mood: state.mood)),
          Text('Sicherer Lumo-Agent', style: Theme.of(context).textTheme.headlineSmall),
          const Text('Nur Lernen, Mut, Pause, Mini-Geschichten, Belohnung und kurze Erklärung. Kein offener Kinder-Chat.'),
          const SizedBox(height: 12),
          Wrap(spacing: 8, children: <Widget>[
            for (final chip in <String>['Lernen', 'Mut', 'Pause', 'Geschichte', 'Belohnung'])
              ActionChip(label: Text(chip), onPressed: () => controller.text = chip),
          ]),
          const SizedBox(height: 12),
          TextField(controller: controller, decoration: const InputDecoration(labelText: 'Sicheres Thema eingeben', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          LumoButton(label: 'Lumo antwortet sicher', onPressed: () => state.askAgent(controller.text)),
          const SizedBox(height: 12),
          LumoCard(
            padding: const EdgeInsets.all(16),
            child: Text(state.lastAgentReply?.text ?? 'Wir machen es Schritt für Schritt. Ich zeige dir den Anfang.'),
          ),
        ]),
      ),
    );
  }
}
