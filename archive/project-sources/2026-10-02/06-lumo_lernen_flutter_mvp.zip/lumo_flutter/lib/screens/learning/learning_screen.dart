import 'package:flutter/material.dart';

import '../../app/theme.dart';
import '../../engines/app_state.dart';
import '../../widgets/common/lumo_button.dart';
import '../../widgets/common/lumo_card.dart';
import '../../widgets/common/section_header.dart';

class LearningScreen extends StatelessWidget {
  const LearningScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final exercise = state.currentExercise;
    final feedback = state.lastFeedback;
    return SingleChildScrollView(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
        LumoCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
            SectionHeader(eyebrow: '${exercise.subject.label} · ${exercise.skill.label}', title: exercise.prompt, body: state.currentRecommendation.reason),
            const SizedBox(height: 18),
            _NumberLine(answer: exercise.answer),
            const SizedBox(height: 18),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: exercise.choices.isEmpty
                  ? <Widget>[const Text('Antwort über Erkennung übernommen. Elternprüfung möglich.')]
                  : exercise.choices
                      .map((choice) => SizedBox(width: 110, child: LumoButton(label: choice, onPressed: () => state.submitAnswer(choice))))
                      .toList(),
            ),
            const SizedBox(height: 12),
            Row(children: <Widget>[
              LumoButton(label: 'Hilfe holen', secondary: true, onPressed: () => state.submitAnswer('__hilfe__')),
              const SizedBox(width: 10),
              LumoButton(label: 'Nächste Aufgabe', secondary: true, onPressed: () => state.nextExercise()),
            ]),
            if (feedback != null) ...<Widget>[
              const SizedBox(height: 16),
              _FeedbackBox(),
            ],
          ]),
        ),
      ]),
    );
  }
}

class _NumberLine extends StatelessWidget {
  const _NumberLine({required this.answer});

  final String answer;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: LumoColors.blue.withAlpha(120), borderRadius: BorderRadius.circular(22)),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: <Widget>[
          for (final value in <String>['0', '5', '10', answer, '18'])
            DecoratedBox(
              decoration: BoxDecoration(color: value == answer ? LumoColors.star : Colors.white, borderRadius: BorderRadius.circular(99)),
              child: Padding(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), child: Text(value, style: const TextStyle(fontWeight: FontWeight.w900))),
            ),
        ]),
      );
}

class _FeedbackBox extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final feedback = state.lastFeedback!;
    return LumoCard(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
        Text(feedback.message, style: const TextStyle(fontWeight: FontWeight.w900)),
        if (feedback.showExplanation) ...<Widget>[
          const SizedBox(height: 10),
          for (final step in feedback.explanationSteps) Text('• $step'),
          const SizedBox(height: 10),
          LumoButton(label: 'Folgeaufgabe übernehmen', onPressed: state.acceptFollowUp),
        ],
      ]),
    );
  }
}
