import 'package:flutter/material.dart';

import '../../core/models/enums.dart';
import '../../engines/app_state.dart';
import '../../widgets/common/lumo_card.dart';

class MemoryScreen extends StatelessWidget {
  const MemoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    return SingleChildScrollView(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
        LumoCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
          Text('MemoryGraph-Lernbaum', style: Theme.of(context).textTheme.headlineSmall),
          const Text('Memory speichert Lernen, nicht Theater: keine Avatar-Position, keine Mikrogesten, keine flüchtigen UI-Effekte.'),
        ])),
        const SizedBox(height: 16),
        GridView.count(
          crossAxisCount: MediaQuery.sizeOf(context).width < 700 ? 1 : 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 2.1,
          children: Skill.values.take(10).map((skill) {
            final memory = state.memoryGraph.memoryFor(skill);
            return LumoCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
              Text('🌿 ${skill.label}', style: Theme.of(context).textTheme.titleLarge),
              Text('${memory.attempts} Aufgaben · ${memory.successes} richtig · ${memory.mistakes} Fehler'),
              LinearProgressIndicator(value: memory.score.clamp(0, 1).toDouble()),
            ]));
          }).toList(),
        ),
        const SizedBox(height: 16),
        LumoCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
          const Text('Gelernte Strategien', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
          if (state.memoryGraph.learnedStrategies.isEmpty) const Text('Noch keine Strategie hat 5 Nutzungen und mehr als 65 % Erfolg erreicht.'),
          for (final item in state.memoryGraph.learnedStrategies) Text('${item.skill.label}: ${item.style.label} · ${(item.successRate * 100).round()} %'),
        ])),
      ]),
    );
  }
}
