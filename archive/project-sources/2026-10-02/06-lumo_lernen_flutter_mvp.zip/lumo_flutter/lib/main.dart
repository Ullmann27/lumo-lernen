import 'package:flutter/material.dart';

import 'app/lumo_app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const LumoApp());
}
