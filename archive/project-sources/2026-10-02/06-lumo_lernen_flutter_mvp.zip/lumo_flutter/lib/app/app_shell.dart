import 'dart:async';

import 'package:flutter/material.dart';

import '../core/models/enums.dart';
import '../engines/app_state.dart';
import '../screens/agent/agent_screen.dart';
import '../screens/cognitive/cognitive_screen.dart';
import '../screens/home/home_screen.dart';
import '../screens/learning/learning_screen.dart';
import '../screens/memory/memory_screen.dart';
import '../screens/parent/parent_screen.dart';
import '../screens/recognition/recognition_screen.dart';
import '../screens/rewards/rewards_screen.dart';
import '../screens/settings/settings_screen.dart';
import '../widgets/avatar/floating_lumo.dart';
import '../widgets/avatar/lumo_side_panel.dart';
import 'theme.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  LumoMenu selected = LumoMenu.home;
  Timer? _idleTimer;

  @override
  void initState() {
    super.initState();
    _resetIdleTimer();
  }

  @override
  void dispose() {
    _idleTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final width = MediaQuery.sizeOf(context).width;
    final compact = width < 700;
    final wide = width >= 1050;
    final screen = _screenFor(selected);

    return Listener(
      onPointerDown: (_) => _resetIdleTimer(),
      child: Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: <Color>[LumoColors.cream, Color(0xFFFFE5BA), Color(0xFFE5FBF8)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: SafeArea(
            child: compact
                ? Stack(
                    children: <Widget>[
                      Padding(padding: const EdgeInsets.fromLTRB(16, 16, 16, 96), child: screen),
                      FloatingLumo(mood: state.mood),
                    ],
                  )
                : Row(
                    children: <Widget>[
                      _NavigationRailCard(selected: selected, extended: wide, onSelect: _select),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.all(18),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              _TopBar(menu: selected),
                              const SizedBox(height: 12),
                              Expanded(child: screen),
                            ],
                          ),
                        ),
                      ),
                      if (width >= 700) LumoSidePanel(onNavigate: _select),
                    ],
                  ),
          ),
        ),
        bottomNavigationBar: compact
            ? NavigationBar(
                selectedIndex: selected.index,
                onDestinationSelected: (index) => _select(LumoMenu.values[index]),
                destinations: LumoMenu.values
                    .map((menu) => NavigationDestination(icon: Text(menu.icon), label: menu.label))
                    .toList(),
              )
            : null,
      ),
    );
  }

  Widget _screenFor(LumoMenu menu) => switch (menu) {
        LumoMenu.home => HomeScreen(onNavigate: _select),
        LumoMenu.learning => const LearningScreen(),
        LumoMenu.agent => const AgentScreen(),
        LumoMenu.recognition => LearningRecognitionScreen(onNavigateToLearning: () => _select(LumoMenu.learning)),
        LumoMenu.cognitive => const CognitiveScreen(),
        LumoMenu.rewards => const RewardsScreen(),
        LumoMenu.parent => const ParentScreen(),
        LumoMenu.memory => const MemoryScreen(),
        LumoMenu.settings => const SettingsScreen(),
      };

  void _select(LumoMenu menu) {
    setState(() => selected = menu);
    final state = AppStateScope.of(context);
    if (menu == LumoMenu.agent) state.eventBus.emit(LumoEventType.agentOpened);
    if (menu == LumoMenu.parent) state.eventBus.emit(LumoEventType.parentAreaOpened);
  }

  void _resetIdleTimer() {
    _idleTimer?.cancel();
    _idleTimer = Timer(const Duration(seconds: 20), () {
      if (!mounted) return;
      AppStateScope.of(context).eventBus.emit(LumoEventType.idle20s);
    });
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({required this.menu});

  final LumoMenu menu;

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    return Row(
      children: <Widget>[
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text('Samsung Fold/Fold 7 · offline-first · kindersicher', style: Theme.of(context).textTheme.labelSmall),
              Text(menu.title, style: Theme.of(context).textTheme.headlineMedium),
            ],
          ),
        ),
        _Pill('⭐ ${state.wallet.stars}'),
        const SizedBox(width: 8),
        _Pill('🏆 Level ${state.wallet.level}'),
        const SizedBox(width: 8),
        const _Pill('🔒 Eltern-PIN'),
      ],
    );
  }
}

class _Pill extends StatelessWidget {
  const _Pill(this.text);

  final String text;

  @override
  Widget build(BuildContext context) => DecoratedBox(
        decoration: BoxDecoration(color: Colors.white.withAlpha(220), borderRadius: BorderRadius.circular(99)),
        child: Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10), child: Text(text, style: const TextStyle(fontWeight: FontWeight.w800))),
      );
}

class _NavigationRailCard extends StatelessWidget {
  const _NavigationRailCard({required this.selected, required this.extended, required this.onSelect});

  final LumoMenu selected;
  final bool extended;
  final ValueChanged<LumoMenu> onSelect;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: extended ? 230 : 92,
      margin: const EdgeInsets.all(18),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withAlpha(190),
        borderRadius: BorderRadius.circular(32),
        border: Border.all(color: Colors.white.withAlpha(230)),
        boxShadow: <BoxShadow>[BoxShadow(color: Colors.black.withAlpha(18), blurRadius: 26, offset: const Offset(0, 18))],
      ),
      child: Column(
        children: <Widget>[
          Row(
            mainAxisAlignment: extended ? MainAxisAlignment.start : MainAxisAlignment.center,
            children: <Widget>[
              const Text('🦊', style: TextStyle(fontSize: 28)),
              if (extended) const SizedBox(width: 10),
              if (extended) const Expanded(child: Text('Lumo Lernen', style: TextStyle(fontWeight: FontWeight.w900))),
            ],
          ),
          const SizedBox(height: 16),
          for (final menu in LumoMenu.values)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: FilledButton.tonal(
                style: FilledButton.styleFrom(
                  backgroundColor: selected == menu ? Colors.white : Colors.white.withAlpha(120),
                  foregroundColor: LumoColors.ink,
                  alignment: extended ? Alignment.centerLeft : Alignment.center,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                ),
                onPressed: () => onSelect(menu),
                child: extended ? Text('${menu.icon}  ${menu.label}') : Text(menu.icon),
              ),
            ),
          const Spacer(),
          if (extended) const Text('Fold-Ansicht: Innen', style: TextStyle(fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}
