import 'package:flutter/material.dart';

import '../engines/app_state.dart';
import 'app_shell.dart';
import 'theme.dart';

class LumoApp extends StatelessWidget {
  const LumoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return AppStateProvider(
      child: MaterialApp(
        title: 'Lumo Lernen',
        debugShowCheckedModeBanner: false,
        theme: buildLumoTheme(),
        home: const AppShell(),
      ),
    );
  }
}
