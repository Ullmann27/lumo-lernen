import 'package:flutter/material.dart';

class LumoColors {
  static const Color cream = Color(0xFFFFF7E8);
  static const Color orange = Color(0xFFFF8A3D);
  static const Color orangeDark = Color(0xFFC95D1E);
  static const Color turquoise = Color(0xFF51C9C3);
  static const Color mint = Color(0xFFBDECC8);
  static const Color blue = Color(0xFFAED8FF);
  static const Color star = Color(0xFFF6B934);
  static const Color ink = Color(0xFF2F2A24);
  static const Color muted = Color(0xFF766B60);
  static const Color parent = Color(0xFFEAF1FF);
}

ThemeData buildLumoTheme() {
  final scheme = ColorScheme.fromSeed(seedColor: LumoColors.orange, brightness: Brightness.light);
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme.copyWith(
      primary: LumoColors.orange,
      secondary: LumoColors.turquoise,
      surface: Colors.white,
    ),
    scaffoldBackgroundColor: LumoColors.cream,
    fontFamily: 'sans',
    textTheme: const TextTheme(
      headlineLarge: TextStyle(fontWeight: FontWeight.w900, color: LumoColors.ink),
      headlineMedium: TextStyle(fontWeight: FontWeight.w800, color: LumoColors.ink),
      titleLarge: TextStyle(fontWeight: FontWeight.w800, color: LumoColors.ink),
      bodyMedium: TextStyle(color: LumoColors.ink, height: 1.35),
    ),
    cardTheme: CardThemeData(
      elevation: 0,
      color: Colors.white.withAlpha(218),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
    ),
  );
}
