import '../core/models/enums.dart';
import '../core/models/exercise.dart';
import 'memory_graph.dart';

class ExplanationStyleEngine {
  ExplanationStyle chooseStyle(Skill skill, MemoryGraph memory) {
    if ((skill == Skill.subtractionTo10 || skill == Skill.subtractionTo20) && memory.errorTypeCounts.count('Rückwärtszählen') >= 1) {
      return ExplanationStyle.numberLine;
    }
    final learned = memory.learnedStrategies.where((item) => item.skill == skill).toList();
    if (learned.isNotEmpty) return learned.first.style;
    return switch (skill) {
      Skill.syllables => ExplanationStyle.syllableClap,
      Skill.initialSound || Skill.rhymes => ExplanationStyle.readAloud,
      Skill.simpleWordProblem => ExplanationStyle.objects,
      Skill.subtractionTo10 || Skill.subtractionTo20 => ExplanationStyle.numberLine,
      _ => ExplanationStyle.steps,
    };
  }

  void recordStyleResult(MemoryGraph memory, Skill skill, ExplanationStyle style, {required bool success}) {
    memory.recordHelpStrategy(skill, style, success: success);
  }

  List<String> buildExplanationSteps(Exercise exercise, ExplanationStyle style) {
    if (style == ExplanationStyle.numberLine && exercise.skill.name.startsWith('subtraction')) {
      return <String>[
        'Aufgabe ruhig lesen: ${exercise.prompt}',
        'Auf der größeren Zahl starten.',
        'So viele Schritte zurückgehen, wie nach dem Minus steht.',
        'Beim Landefeld steht das Ergebnis: ${exercise.answer}.',
      ];
    }
    if (style == ExplanationStyle.syllableClap) {
      return <String>['Wort langsam sagen.', 'Bei jedem Klatscher eine Silbe zählen.', 'Antwort prüfen: ${exercise.answer}.'];
    }
    return <String>['Aufgabe verstehen.', 'Ersten Schritt markieren.', exercise.explanation, 'Ähnliche Aufgabe langsam üben.'];
  }
}
