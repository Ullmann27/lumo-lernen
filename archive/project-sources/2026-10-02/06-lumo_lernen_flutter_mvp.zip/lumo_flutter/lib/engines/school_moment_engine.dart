import '../core/models/enums.dart';
import '../core/models/school_moment_models.dart';

class SchoolMomentEngine {
  SchoolMoment evaluate(String signal) {
    return switch (signal) {
      'app_opened' => const SchoolMoment(name: 'app_opened', avatarMood: AvatarMood.greet, voiceMode: VoiceMode.greeting, recommendation: 'Tagesvorschlag starten.'),
      'idle_20s' => const SchoolMoment(name: 'idle_20s', avatarMood: AvatarMood.sleepy, voiceMode: VoiceMode.calm, recommendation: 'Freundlich fragen, ob ein Tipp hilft.'),
      'wrong_streak' => const SchoolMoment(name: 'wrong_streak', avatarMood: AvatarMood.comfort, voiceMode: VoiceMode.comfort, recommendation: 'Leichtere Folgeaufgabe und visuelle Hilfe.'),
      'success_streak' => const SchoolMoment(name: 'success_streak', avatarMood: AvatarMood.celebrate, voiceMode: VoiceMode.celebrate, recommendation: 'Etwas schwierigere Aufgabe.', rewardEvent: RewardEvent.improvement),
      'test_mode' => const SchoolMoment(name: 'test_mode', avatarMood: AvatarMood.thinking, voiceMode: VoiceMode.testMode, recommendation: 'Keine Hilfe während der Aufgabe, Auswertung danach.'),
      'short_session' => const SchoolMoment(name: 'short_session', avatarMood: AvatarMood.sit, voiceMode: VoiceMode.calm, recommendation: 'Mini-Mission mit einer Aufgabe.'),
      'parent_review' => const SchoolMoment(name: 'parent_review', avatarMood: AvatarMood.sit, voiceMode: VoiceMode.parentReport, recommendation: 'Elternprüfung anzeigen.', parentHint: 'Fotoanalyse und unsichere Erkennung prüfen.'),
      'after_school' => const SchoolMoment(name: 'after_school', avatarMood: AvatarMood.comfort, voiceMode: VoiceMode.calm, recommendation: 'Ruhiger Einstieg ohne Druck.'),
      _ => const SchoolMoment(name: 'default', avatarMood: AvatarMood.idle, voiceMode: VoiceMode.focus, recommendation: 'Eine kleine Aufgabe anbieten.'),
    };
  }
}
