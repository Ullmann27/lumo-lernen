import '../core/models/enums.dart';
import '../core/models/exercise.dart';
import '../core/models/memory_models.dart';
import '../services/local_store.dart';

class MemoryGraph {
  MemoryGraph({
    Map<Skill, SkillMemory>? skills,
    ErrorTypeCounts? errorTypeCounts,
    Map<String, HelpStrategyEffect>? helpEffects,
    List<LearnedStrategy>? learnedStrategies,
    List<ExerciseHistory>? exerciseHistory,
    List<RewardHistory>? rewardHistory,
    List<ParentConsent>? parentConsents,
    List<ReportHistory>? reportHistory,
    List<RecognizedTaskHistory>? recognizedTaskHistory,
  })  : skills = skills ?? <Skill, SkillMemory>{},
        errorTypeCounts = errorTypeCounts ?? ErrorTypeCounts(),
        helpEffects = helpEffects ?? <String, HelpStrategyEffect>{},
        learnedStrategies = learnedStrategies ?? <LearnedStrategy>[],
        exerciseHistory = exerciseHistory ?? <ExerciseHistory>[],
        rewardHistory = rewardHistory ?? <RewardHistory>[],
        parentConsents = parentConsents ?? <ParentConsent>[],
        reportHistory = reportHistory ?? <ReportHistory>[],
        recognizedTaskHistory = recognizedTaskHistory ?? <RecognizedTaskHistory>[];

  final Map<Skill, SkillMemory> skills;
  final ErrorTypeCounts errorTypeCounts;
  final Map<String, HelpStrategyEffect> helpEffects;
  final List<LearnedStrategy> learnedStrategies;
  final List<ExerciseHistory> exerciseHistory;
  final List<RewardHistory> rewardHistory;
  final List<ParentConsent> parentConsents;
  final List<ReportHistory> reportHistory;
  final List<RecognizedTaskHistory> recognizedTaskHistory;

  SkillMemory memoryFor(Skill skill) {
    return skills.putIfAbsent(skill, () => SkillMemory(skill: skill, subject: skill.subject));
  }

  void recordExercise(Exercise exercise, {required bool correct, int attempts = 1, String? errorType}) {
    memoryFor(exercise.skill).record(correct: correct);
    exerciseHistory.add(ExerciseHistory(
      exerciseId: exercise.id,
      skill: exercise.skill,
      correct: correct,
      attempts: attempts,
      createdAt: DateTime.now(),
    ));
    if (!correct) {
      errorTypeCounts.increment(errorType ?? _defaultErrorType(exercise.skill));
    }
  }

  void recordHelpStrategy(Skill skill, ExplanationStyle style, {required bool success}) {
    final key = '${skill.key}:${style.name}';
    final effect = helpEffects.putIfAbsent(key, () => HelpStrategyEffect(skill: skill, style: style));
    effect.record(success: success);
    final alreadyLearned = learnedStrategies.any((item) => item.skill == skill && item.style == style);
    if (!alreadyLearned && effect.uses >= 5 && effect.successRate > 0.65) {
      learnedStrategies.add(LearnedStrategy(
        skill: skill,
        style: style,
        reason: '${style.label} half bei ${(effect.successRate * 100).round()} % der Folgeaufgaben.',
        successRate: effect.successRate,
        createdAt: DateTime.now(),
      ));
    }
  }

  void recordRecognizedTask({required String rawInput, required Skill skill, required double confidence, required bool parentReviewed}) {
    recognizedTaskHistory.add(RecognizedTaskHistory(
      rawInput: rawInput,
      skill: skill,
      confidence: confidence,
      parentReviewed: parentReviewed,
      createdAt: DateTime.now(),
    ));
  }

  void recordReward(String type, int amount, String note) {
    rewardHistory.add(RewardHistory(type: type, amount: amount, note: note, createdAt: DateTime.now()));
  }

  Skill weakestSkill() {
    if (skills.isEmpty) return Skill.subtractionTo20;
    final entries = skills.entries.toList()
      ..sort((a, b) {
        final scoreCompare = a.value.score.compareTo(b.value.score);
        if (scoreCompare != 0) return scoreCompare;
        return b.value.mistakes.compareTo(a.value.mistakes);
      });
    return entries.first.key;
  }

  String whyRecommendation(Skill skill) {
    final memory = memoryFor(skill);
    final commonError = errorTypeCounts.mostCommon;
    final usefulStrategy = learnedStrategies.where((item) => item.skill == skill).toList();
    final strategyText = usefulStrategy.isEmpty
        ? 'Zahlenstrahl-Hilfe wird als nächster ruhiger Schritt getestet.'
        : '${usefulStrategy.first.style.label} war bisher wirksam.';
    return 'Lumo empfiehlt ${skill.label}, weil in den letzten Aufgaben ${memory.mistakes} Fehler bei ${memory.attempts} Versuchen gespeichert sind. '
        'Die häufigste Fehlerart ist $commonError. $strategyText Empfohlen wird eine kurze Einheit von 7 Minuten.';
  }

  Map<String, Object?> toJson() => <String, Object?>{
        'skills': skills.map((key, value) => MapEntry(key.key, value.toJson())),
        'errorTypeCounts': errorTypeCounts.toJson(),
        'helpEffects': helpEffects.map((key, value) => MapEntry(key, value.toJson())),
        'learnedStrategies': learnedStrategies.map((item) => item.toJson()).toList(),
        'exerciseHistory': exerciseHistory.map((item) => item.toJson()).toList(),
        'rewardHistory': rewardHistory.map((item) => item.toJson()).toList(),
        'parentConsents': parentConsents.map((item) => item.toJson()).toList(),
        'reportHistory': reportHistory.map((item) => item.toJson()).toList(),
        'recognizedTaskHistory': recognizedTaskHistory.map((item) => item.toJson()).toList(),
      };

  factory MemoryGraph.fromJson(Map<String, Object?> json) {
    final skillJson = Map<String, Object?>.from(json['skills'] as Map? ?? const <String, Object?>{});
    final effectsJson = Map<String, Object?>.from(json['helpEffects'] as Map? ?? const <String, Object?>{});
    return MemoryGraph(
      skills: skillJson.map((key, value) => MapEntry(skillFromKey(key), SkillMemory.fromJson(Map<String, Object?>.from(value as Map)))),
      errorTypeCounts: ErrorTypeCounts.fromJson(Map<String, Object?>.from(json['errorTypeCounts'] as Map? ?? const <String, Object?>{})),
      helpEffects: effectsJson.map((key, value) => MapEntry(key, HelpStrategyEffect.fromJson(Map<String, Object?>.from(value as Map)))),
      learnedStrategies: _list(json['learnedStrategies']).map((item) => LearnedStrategy.fromJson(item)).toList(),
      exerciseHistory: _list(json['exerciseHistory']).map((item) => ExerciseHistory.fromJson(item)).toList(),
      rewardHistory: _list(json['rewardHistory']).map((item) => RewardHistory.fromJson(item)).toList(),
      parentConsents: _list(json['parentConsents']).map((item) => ParentConsent.fromJson(item)).toList(),
      reportHistory: _list(json['reportHistory']).map((item) => ReportHistory.fromJson(item)).toList(),
      recognizedTaskHistory: _list(json['recognizedTaskHistory']).map((item) => RecognizedTaskHistory.fromJson(item)).toList(),
    );
  }

  Future<void> save(LocalStore store) => store.writeJson('memory_graph', toJson());

  static Future<MemoryGraph> load(LocalStore store) async {
    final json = await store.readJson('memory_graph');
    return json == null ? MemoryGraph() : MemoryGraph.fromJson(json);
  }

  static List<Map<String, Object?>> _list(Object? value) {
    return (value as List<dynamic>? ?? const <dynamic>[]).map((item) => Map<String, Object?>.from(item as Map)).toList();
  }

  String _defaultErrorType(Skill skill) {
    if (skill == Skill.subtractionTo10 || skill == Skill.subtractionTo20) return 'Rückwärtszählen';
    if (skill == Skill.numberSequence) return 'Musterregel';
    if (skill == Skill.initialSound) return 'Anfangslaut';
    return 'Antwortunsicherheit';
  }
}
