import '../core/models/enums.dart';
import '../core/models/exercise.dart';
import '../core/models/recognition_models.dart';

class RecognitionEngine {
  RecognitionResult parse(String input) {
    final raw = input.trim();
    final normalized = raw.toLowerCase().replaceAll(RegExp(r'\s+'), ' ');
    if (raw.isEmpty) return _unknown(raw, normalized);

    final addition = RegExp(r'^(\d{1,2})\s*\+\s*(\d{1,2})$').firstMatch(normalized);
    if (addition != null) {
      final a = int.parse(addition.group(1)!);
      final b = int.parse(addition.group(2)!);
      final skill = a + b <= 10 ? Skill.additionTo10 : Skill.additionTo20;
      return _exercise(raw, normalized, skill, '$a + $b = ?', '${a + b}', 0.96, 'Addition erkannt.');
    }

    final subtraction = RegExp(r'^(\d{1,2})\s*-\s*(\d{1,2})$').firstMatch(normalized);
    if (subtraction != null) {
      final a = int.parse(subtraction.group(1)!);
      final b = int.parse(subtraction.group(2)!);
      final skill = a <= 10 ? Skill.subtractionTo10 : Skill.subtractionTo20;
      return _exercise(raw, normalized, skill, '$a - $b = ?', '${a - b}', 0.95, 'Subtraktion erkannt.');
    }

    if (RegExp(r'^(\d+)[,; ]+(\d+)[,; ]+(\d+)[,; ]*\?$').hasMatch(normalized)) {
      final numbers = RegExp(r'\d+').allMatches(normalized).map((match) => int.parse(match.group(0)!)).toList();
      final diff = numbers[1] - numbers[0];
      final answer = numbers[2] + diff;
      return _exercise(raw, normalized, Skill.numberSequence, '${numbers[0]}, ${numbers[1]}, ${numbers[2]}, ?', '$answer', 0.9, 'Zahlenreihe erkannt.');
    }

    final initial = RegExp(r'anfang(sbuchstabe|slaut)?\s+([a-zäöüß]+)').firstMatch(normalized);
    if (initial != null) {
      final word = initial.group(2)!;
      return _exercise(raw, normalized, Skill.initialSound, 'Welcher Anfangsbuchstabe steckt in $word?', word[0].toUpperCase(), 0.88, 'Anfangslaut-Aufgabe erkannt.');
    }

    final rhyme = RegExp(r'reimt sich auf\s+([a-zäöüß]+)').firstMatch(normalized);
    if (rhyme != null) {
      final word = rhyme.group(1)!;
      final answer = word == 'haus' ? 'Maus' : 'ein Wort mit gleichem Endklang';
      return _exercise(raw, normalized, Skill.rhymes, 'Was reimt sich auf $word?', answer, 0.87, 'Reim-Aufgabe erkannt.');
    }

    final grade = RegExp(r'(neue\s+)?note\s+([a-zäöüß]+)\s+(\d)').firstMatch(normalized);
    if (grade != null) {
      return RecognitionResult(
        recognized: true,
        confidence: 0.91,
        subject: Subject.mathematik,
        skill: Skill.simpleWordProblem,
        difficulty: Difficulty.easy,
        needsParentReview: true,
        rawInput: raw,
        normalizedInput: normalized,
        explanation: 'Noteneintrag erkannt. Das gehört in den Elternbereich und braucht Prüfung.',
        kind: RecognitionKind.gradeEntry,
      );
    }

    if (RegExp(r'(mia|paul|hat).*(dazu|weg|bleiben|insgesamt)').hasMatch(normalized)) {
      return _exercise(raw, normalized, Skill.simpleWordProblem, raw, '?', 0.72, 'Einfache Textaufgabe erkannt, Elternprüfung empfohlen.');
    }

    if (RegExp(r'(pflanze|tier|wasser|jahreszeit|wetter)').hasMatch(normalized)) {
      return _exercise(raw, normalized, Skill.basicScience, raw, '?', 0.68, 'Sachunterrichtsfrage erkannt, Elternprüfung empfohlen.');
    }

    if (RegExp(r'(übe|trainiere|wiederhole)').hasMatch(normalized)) {
      return RecognitionResult(
        recognized: true,
        confidence: 0.64,
        subject: null,
        skill: null,
        difficulty: Difficulty.easy,
        needsParentReview: true,
        rawInput: raw,
        normalizedInput: normalized,
        explanation: 'Übungsanweisung erkannt, aber noch ohne sichere Kompetenzzuordnung.',
        kind: RecognitionKind.instruction,
      );
    }

    return _unknown(raw, normalized);
  }

  RecognitionResult parseOcrText(String text) => parse(text);

  RecognitionResult _exercise(
    String raw,
    String normalized,
    Skill skill,
    String prompt,
    String answer,
    double confidence,
    String explanation,
  ) {
    final exercise = Exercise(
      id: 'recognized_${DateTime.now().microsecondsSinceEpoch}',
      subject: skill.subject,
      skill: skill,
      difficulty: confidence > 0.9 ? Difficulty.medium : Difficulty.easy,
      prompt: prompt,
      answer: answer,
      choices: const <String>[],
      explanation: explanation,
      helpStrategy: skill.name.startsWith('subtraction') ? 'Zahlenstrahl' : 'Schrittfolge',
      explanationStyle: skill.name.startsWith('subtraction') ? ExplanationStyle.numberLine : ExplanationStyle.steps,
      createdAt: DateTime.now(),
      source: 'recognition',
      parentReviewed: confidence >= 0.85,
    );
    return RecognitionResult(
      recognized: true,
      confidence: confidence,
      subject: skill.subject,
      skill: skill,
      difficulty: exercise.difficulty,
      exercise: exercise,
      needsParentReview: confidence < 0.85,
      rawInput: raw,
      normalizedInput: normalized,
      explanation: explanation,
    );
  }

  RecognitionResult _unknown(String raw, String normalized) => RecognitionResult(
        recognized: false,
        confidence: 0.42,
        subject: null,
        skill: null,
        difficulty: null,
        needsParentReview: true,
        rawInput: raw,
        normalizedInput: normalized,
        explanation: 'Unsicher. Bitte von den Eltern prüfen lassen.',
        kind: RecognitionKind.unknown,
      );
}
