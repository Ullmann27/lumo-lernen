import 'package:uuid/uuid.dart';

import '../core/models/enums.dart';
import '../core/models/exercise.dart';
import '../data/task_bank.dart';

class ExerciseFactory {
  ExerciseFactory({Uuid? uuid}) : _uuid = uuid ?? const Uuid();

  final Uuid _uuid;
  int _counter = 0;

  Exercise next({Skill? skill}) {
    final bank = seedTaskBank();
    final candidates = skill == null ? bank : bank.where((exercise) => exercise.skill == skill).toList();
    if (candidates.isNotEmpty) {
      final source = candidates[_counter % candidates.length];
      _counter += 1;
      return source.copyWith(id: 'generated_${_uuid.v4()}', createdAt: DateTime.now());
    }
    return generate(skill ?? Skill.subtractionTo20);
  }

  Exercise generate(Skill skill) {
    final now = DateTime.now();
    final id = 'generated_${_uuid.v4()}';
    switch (skill) {
      case Skill.additionTo10:
        return _math(id, skill, '4 + 3 = ?', '7', const <String>['6', '7', '8'], 'Zähle von 4 drei Schritte weiter.', Difficulty.easy, now);
      case Skill.additionTo20:
        return _math(id, skill, '9 + 6 = ?', '15', const <String>['14', '15', '16'], 'Zähle von 9 sechs Schritte weiter.', Difficulty.medium, now);
      case Skill.subtractionTo10:
        return _math(id, skill, '9 - 4 = ?', '5', const <String>['4', '5', '6'], 'Starte bei 9 und gehe 4 Schritte zurück.', Difficulty.easy, now);
      case Skill.subtractionTo20:
        return _math(id, skill, '18 - 5 = ?', '13', const <String>['12', '13', '14'], 'Starte bei 18 und gehe 5 Schritte zurück.', Difficulty.medium, now);
      case Skill.numberSequence:
        return Exercise(
          id: id,
          subject: skill.subject,
          skill: skill,
          difficulty: Difficulty.easy,
          prompt: '3, 6, 9, ?',
          answer: '12',
          choices: const <String>['10', '12', '15'],
          explanation: 'Die Reihe springt immer um 3 weiter.',
          helpStrategy: 'Sprungregel markieren',
          explanationStyle: ExplanationStyle.steps,
          createdAt: now,
        );
      case Skill.initialSound:
        return Exercise(
          id: id,
          subject: skill.subject,
          skill: skill,
          difficulty: Difficulty.easy,
          prompt: 'Welcher Anfangsbuchstabe steckt in Sonne?',
          answer: 'S',
          choices: const <String>['S', 'O', 'N'],
          explanation: 'Sonne beginnt mit S.',
          helpStrategy: 'Langsam sprechen',
          explanationStyle: ExplanationStyle.readAloud,
          createdAt: now,
        );
      case Skill.syllables:
        return Exercise(
          id: id,
          subject: skill.subject,
          skill: skill,
          difficulty: Difficulty.easy,
          prompt: 'Wie viele Silben hat Banane?',
          answer: '3',
          choices: const <String>['2', '3', '4'],
          explanation: 'Ba-na-ne hat drei Klatscher.',
          helpStrategy: 'Silbenklatschen',
          explanationStyle: ExplanationStyle.syllableClap,
          createdAt: now,
        );
      case Skill.rhymes:
        return Exercise(
          id: id,
          subject: skill.subject,
          skill: skill,
          difficulty: Difficulty.easy,
          prompt: 'Was reimt sich auf Haus?',
          answer: 'Maus',
          choices: const <String>['Maus', 'Baum', 'Ball'],
          explanation: 'Haus und Maus haben den gleichen Endklang.',
          helpStrategy: 'Endklang hören',
          explanationStyle: ExplanationStyle.readAloud,
          createdAt: now,
        );
      case Skill.simpleWordProblem:
        return Exercise(
          id: id,
          subject: skill.subject,
          skill: skill,
          difficulty: Difficulty.medium,
          prompt: 'Mia hat 6 Äpfel und bekommt 3 dazu. Wie viele hat sie?',
          answer: '9',
          choices: const <String>['8', '9', '10'],
          explanation: '6 Äpfel plus 3 Äpfel sind 9 Äpfel.',
          helpStrategy: 'Objekte zählen',
          explanationStyle: ExplanationStyle.objects,
          createdAt: now,
        );
      case Skill.basicScience:
        return Exercise(
          id: id,
          subject: skill.subject,
          skill: skill,
          difficulty: Difficulty.easy,
          prompt: 'Welches Tier sagt Miau?',
          answer: 'Katze',
          choices: const <String>['Hund', 'Katze', 'Ente'],
          explanation: 'Eine Katze sagt Miau.',
          helpStrategy: 'Alltagswissen',
          explanationStyle: ExplanationStyle.miniStory,
          createdAt: now,
        );
      case Skill.memorySequence:
      case Skill.attentionPattern:
      case Skill.patternRecognition:
        return Exercise(
          id: id,
          subject: skill.subject,
          skill: skill,
          difficulty: Difficulty.easy,
          prompt: '◆ ● ◆ ● ?',
          answer: '◆',
          choices: const <String>['◆', '●', '■'],
          explanation: 'Das Muster wechselt immer: Raute, Kreis, Raute, Kreis.',
          helpStrategy: 'Muster laut benennen',
          explanationStyle: ExplanationStyle.steps,
          createdAt: now,
        );
    }
  }

  Exercise generateSimilar(Exercise exercise) {
    return switch (exercise.skill) {
      Skill.subtractionTo20 => generate(Skill.subtractionTo10),
      Skill.additionTo20 => generate(Skill.additionTo10),
      _ => generate(exercise.skill),
    };
  }

  Exercise _math(
    String id,
    Skill skill,
    String prompt,
    String answer,
    List<String> choices,
    String explanation,
    Difficulty difficulty,
    DateTime now,
  ) {
    return Exercise(
      id: id,
      subject: Subject.mathematik,
      skill: skill,
      difficulty: difficulty,
      prompt: prompt,
      answer: answer,
      choices: choices,
      explanation: explanation,
      helpStrategy: skill.name.startsWith('subtraction') ? 'Zahlenstrahl' : 'Schrittfolge',
      explanationStyle: skill.name.startsWith('subtraction') ? ExplanationStyle.numberLine : ExplanationStyle.steps,
      createdAt: now,
    );
  }
}
