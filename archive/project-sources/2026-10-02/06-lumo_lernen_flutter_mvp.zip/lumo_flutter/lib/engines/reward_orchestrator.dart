import '../core/models/enums.dart';
import '../core/models/rewards.dart';
import '../data/seed_vouchers.dart';

class RewardOrchestrator {
  RewardOrchestrator({RewardWallet? wallet}) : wallet = wallet ?? RewardWallet(vouchers: seedVouchers());

  RewardWallet wallet;

  RewardResult grant(RewardEvent event) {
    final oldLevel = wallet.level;
    final stars = switch (event) {
      RewardEvent.correctAnswer => 5,
      RewardEvent.persistedAfterMistake => 4,
      RewardEvent.repetition => 3,
      RewardEvent.difficultAttempt => 6,
      RewardEvent.dailyPlanDone => 10,
      RewardEvent.improvement => 8,
      RewardEvent.focus => 4,
    };
    final xp = stars * 2;
    wallet.stars += stars;
    wallet.xp += xp;
    wallet.level = 1 + wallet.xp ~/ 100;
    wallet.history.add('+$stars Sterne: ${event.name}');
    final levelUp = wallet.level > oldLevel;
    if (levelUp && !wallet.achievements.contains('Level ${wallet.level}')) {
      wallet.achievements.add('Level ${wallet.level}');
    }
    return RewardResult(success: true, message: 'Fuchsstark: +$stars Sterne.', levelUp: levelUp);
  }

  RewardResult redeemVoucher(String voucherId, String pin) {
    if (pin != '1234') {
      return const RewardResult(success: false, message: 'Eltern-PIN stimmt nicht. Demo-PIN im Prototyp: 1234.');
    }
    final index = wallet.vouchers.indexWhere((voucher) => voucher.id == voucherId);
    if (index < 0) return const RewardResult(success: false, message: 'Gutschein nicht gefunden.');
    final voucher = wallet.vouchers[index];
    if (voucher.redeemed) return const RewardResult(success: false, message: 'Gutschein wurde bereits eingelöst.');
    if (wallet.stars < voucher.costStars) return const RewardResult(success: false, message: 'Noch nicht genug Sterne.');
    wallet.stars -= voucher.costStars;
    wallet.vouchers[index] = voucher.redeem();
    wallet.history.add('Gutschein eingelöst: ${voucher.title}');
    return RewardResult(success: true, message: '${voucher.emoji} ${voucher.title} wurde mit Eltern-PIN eingelöst.');
  }

  Map<String, Object?> toJson() => wallet.toJson();

  void restore(Map<String, Object?> json) {
    wallet = RewardWallet.fromJson(json);
    if (wallet.vouchers.isEmpty) wallet.vouchers = seedVouchers();
  }
}
