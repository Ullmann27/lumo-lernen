import '../data/safe_phrases.dart';

class AgentReply {
  const AgentReply({required this.text, required this.blocked, required this.category});

  final String text;
  final bool blocked;
  final String category;
}

class CompanionAgent {
  static final RegExp _privateData = RegExp(r'(adresse|telefon|schule|passwort|geheim|wohn|heiße|nachname|straße|ort)', caseSensitive: false);
  static final RegExp _distress = RegExp(r'(angst|traurig|weh|verletz|weinen|allein|hilfe)', caseSensitive: false);
  static final RegExp _blocked = RegExp(r'(treffen|tiktok|instagram|gewalt|sex|kaufen|politik|waffe|fremder|chatten)', caseSensitive: false);
  static final RegExp _learning = RegExp(r'(lernen|aufgabe|rech|minus|plus|deutsch|hilfe|erklär|verstehe)', caseSensitive: false);
  static final RegExp _pause = RegExp(r'(pause|müde|ausruhen|ruhig)', caseSensitive: false);
  static final RegExp _story = RegExp(r'(geschichte|erzähle|fuchs)', caseSensitive: false);

  AgentReply answer(String input) {
    final text = input.trim();
    if (_privateData.hasMatch(text)) return const AgentReply(text: privateDataReply, blocked: true, category: 'private_data');
    if (_distress.hasMatch(text)) return const AgentReply(text: distressReply, blocked: true, category: 'distress');
    if (_blocked.hasMatch(text)) return const AgentReply(text: blockedTopicReply, blocked: true, category: 'blocked_topic');
    if (_pause.hasMatch(text)) {
      return const AgentReply(text: 'Wir machen eine kleine Pause. Atme ruhig ein und aus. Danach reicht ein kleiner Schritt.', blocked: false, category: 'pause');
    }
    if (_story.hasMatch(text)) {
      return const AgentReply(text: 'Lumo legt einen Stern auf den Tisch. Der Stern sagt: Heute zählt ein ruhiger Versuch.', blocked: false, category: 'story');
    }
    if (_learning.hasMatch(text) || text.isEmpty) return const AgentReply(text: learningHelpReply, blocked: false, category: 'learning');
    return const AgentReply(text: 'Ich helfe dir gern beim Lernen, Mutmachen oder Ausruhen. Wähle eine kleine Sache aus.', blocked: false, category: 'safe_default');
  }
}
