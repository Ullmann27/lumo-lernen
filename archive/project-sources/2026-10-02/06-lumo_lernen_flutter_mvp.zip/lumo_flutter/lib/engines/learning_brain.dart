import '../core/models/enums.dart';
import '../core/models/exercise.dart';
import 'exercise_factory.dart';
import 'explanation_style_engine.dart';
import 'memory_graph.dart';

class LearningBrain {
  LearningBrain({
    required this.memory,
    ExerciseFactory? factory,
    ExplanationStyleEngine? explanationStyleEngine,
  })  : factory = factory ?? ExerciseFactory(),
        explanationStyleEngine = explanationStyleEngine ?? ExplanationStyleEngine();

  final MemoryGraph memory;
  final ExerciseFactory factory;
  final ExplanationStyleEngine explanationStyleEngine;
  final Map<String, int> _attempts = <String, int>{};

  LearningRecommendation nextExercise({Skill? focus}) {
    final skill = focus ?? memory.weakestSkill();
    final style = explanationStyleEngine.chooseStyle(skill, memory);
    final exercise = factory.next(skill: skill).copyWith(explanationStyle: style, helpStrategy: style.label);
    return LearningRecommendation(
      exercise: exercise,
      reason: memory.whyRecommendation(skill),
      helpStrategy: style.label,
      avatarMood: AvatarMood.explain,
      voiceMode: VoiceMode.focus,
      rewardPotential: exercise.difficulty == Difficulty.hard ? 12 : 8,
      followUpNeeded: memory.memoryFor(skill).mistakes > memory.memoryFor(skill).successes,
      explanationStyle: style,
      nextAction: 'Eine kleine Mission starten und danach kurz speichern.',
    );
  }

  AnswerFeedback submitAnswer(Exercise exercise, String answer) {
    final correct = exercise.checkAnswer(answer);
    final attempts = (_attempts[exercise.id] ?? 0) + (correct ? 0 : 1);
    if (correct) {
      _attempts.remove(exercise.id);
      memory.recordExercise(exercise, correct: true, attempts: attempts == 0 ? 1 : attempts);
      explanationStyleEngine.recordStyleResult(memory, exercise.skill, exercise.explanationStyle, success: true);
      return const AnswerFeedback(
        isCorrect: true,
        attempts: 0,
        message: 'Super, du hast gut nachgedacht.',
        showExplanation: false,
      );
    }

    _attempts[exercise.id] = attempts;
    memory.recordExercise(exercise, correct: false, attempts: attempts);
    if (attempts >= 3) {
      final steps = explanationStyleEngine.buildExplanationSteps(exercise, exercise.explanationStyle);
      final followUp = factory.generateSimilar(exercise);
      return AnswerFeedback(
        isCorrect: false,
        attempts: attempts,
        message: 'Fast. Das ist kein Problem. Ich zeige dir jetzt die Lösung langsam.',
        showExplanation: true,
        explanationSteps: steps,
        followUp: followUp,
      );
    }

    return AnswerFeedback(
      isCorrect: false,
      attempts: attempts,
      message: attempts == 1 ? 'Fast. Das ist kein Problem.' : 'Wir schauen es gemeinsam an. Ich gebe dir einen ruhigeren Tipp.',
      showExplanation: false,
    );
  }
}
