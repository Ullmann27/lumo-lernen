import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';

import '../core/models/enums.dart';
import '../core/models/exercise.dart';
import '../core/models/recognition_models.dart';
import '../core/models/rewards.dart';
import '../core/models/speech_models.dart';
import '../services/consent_service.dart';
import '../services/local_store.dart';
import 'avatar_director.dart';
import 'cognitive_games_engine.dart';
import 'companion_agent.dart';
import 'event_bus.dart';
import 'learning_brain.dart';
import 'memory_graph.dart';
import 'recognition_engine.dart';
import 'reward_orchestrator.dart';
import 'school_moment_engine.dart';
import 'voice_director.dart';

class AppState extends ChangeNotifier {
  AppState({
    LocalStore? localStore,
    MemoryGraph? memoryGraph,
    RewardOrchestrator? rewardOrchestrator,
  })  : localStore = localStore ?? LocalStore(),
        memoryGraph = memoryGraph ?? MemoryGraph(),
        rewardOrchestrator = rewardOrchestrator ?? RewardOrchestrator() {
    learningBrain = LearningBrain(memory: this.memoryGraph);
    currentRecommendation = learningBrain.nextExercise(focus: Skill.subtractionTo20);
    currentSpeech = voiceDirector.plan(VoiceMode.greeting);
    eventBus.stream.listen((event) {
      avatarDirector.handle(event.type);
      notifyListeners();
    });
  }

  final LocalStore localStore;
  MemoryGraph memoryGraph;
  late LearningBrain learningBrain;
  final RecognitionEngine recognitionEngine = RecognitionEngine();
  final CompanionAgent companionAgent = CompanionAgent();
  final AvatarDirector avatarDirector = AvatarDirector();
  final VoiceDirector voiceDirector = VoiceDirector();
  final SchoolMomentEngine schoolMomentEngine = SchoolMomentEngine();
  final CognitiveGamesEngine cognitiveGamesEngine = CognitiveGamesEngine();
  final EventBus eventBus = EventBus();
  RewardOrchestrator rewardOrchestrator;
  ConsentService consentService = ConsentService();

  late LearningRecommendation currentRecommendation;
  AnswerFeedback? lastFeedback;
  RecognitionResult? lastRecognition;
  AgentReply? lastAgentReply;
  CognitiveProfile? cognitiveProfile;
  SpeechPlan currentSpeech = const SpeechPlan(mode: VoiceMode.greeting, segments: <String>['Servus!']);
  String parentPinInput = '';

  RewardWallet get wallet => rewardOrchestrator.wallet;
  Exercise get currentExercise => currentRecommendation.exercise;
  AvatarMood get mood => avatarDirector.mood;

  Future<void> bootstrap() async {
    try {
      memoryGraph = await MemoryGraph.load(localStore);
      final rewardsJson = await localStore.readJson('rewards');
      if (rewardsJson != null) rewardOrchestrator.restore(rewardsJson);
      consentService = await ConsentService.load(localStore);
      learningBrain = LearningBrain(memory: memoryGraph);
      currentRecommendation = learningBrain.nextExercise(focus: memoryGraph.weakestSkill());
      notifyListeners();
    } catch (_) {
      // SharedPreferences may not be available in unit tests; keep in-memory defaults.
    }
  }

  void nextExercise({Skill? skill}) {
    currentRecommendation = learningBrain.nextExercise(focus: skill);
    lastFeedback = null;
    currentSpeech = voiceDirector.plan(VoiceMode.focus);
    eventBus.emit(LumoEventType.taskStarted);
    notifyListeners();
  }

  void submitAnswer(String answer) {
    final feedback = learningBrain.submitAnswer(currentExercise, answer);
    lastFeedback = feedback;
    if (feedback.isCorrect) {
      final reward = rewardOrchestrator.grant(RewardEvent.correctAnswer);
      memoryGraph.recordReward('stars', 5, reward.message);
      currentSpeech = voiceDirector.plan(reward.levelUp ? VoiceMode.celebrate : VoiceMode.praise);
      eventBus.emit(reward.levelUp ? LumoEventType.levelUp : LumoEventType.taskCorrect);
    } else {
      currentSpeech = voiceDirector.plan(feedback.showExplanation ? VoiceMode.explainAfter3 : VoiceMode.comfort, context: feedback.message);
      eventBus.emit(feedback.attempts >= 3
          ? LumoEventType.taskWrong3
          : feedback.attempts == 2
              ? LumoEventType.taskWrong2
              : LumoEventType.taskWrong1);
    }
    _persistSoft();
    notifyListeners();
  }

  void acceptFollowUp() {
    final followUp = lastFeedback?.followUp;
    if (followUp == null) return;
    currentRecommendation = LearningRecommendation(
      exercise: followUp,
      reason: 'Folgeaufgabe nach drei ruhigen Versuchen.',
      helpStrategy: followUp.helpStrategy,
      avatarMood: AvatarMood.explain,
      voiceMode: VoiceMode.focus,
      rewardPotential: 5,
      followUpNeeded: false,
      explanationStyle: followUp.explanationStyle,
      nextAction: 'Folgeaufgabe lösen.',
    );
    lastFeedback = null;
    notifyListeners();
  }

  void recognize(String input) {
    final result = recognitionEngine.parse(input);
    lastRecognition = result;
    if (result.recognized && result.skill != null) {
      memoryGraph.recordRecognizedTask(
        rawInput: input,
        skill: result.skill!,
        confidence: result.confidence,
        parentReviewed: !result.needsParentReview,
      );
    }
    currentSpeech = voiceDirector.plan(VoiceMode.hint, context: result.explanation);
    eventBus.emit(LumoEventType.taskRecognized);
    _persistSoft();
    notifyListeners();
  }

  void takeRecognizedIntoTraining() {
    final exercise = lastRecognition?.exercise;
    if (exercise == null) return;
    currentRecommendation = LearningRecommendation(
      exercise: exercise,
      reason: 'Diese Aufgabe wurde aus der Erkennung ins Training übernommen.',
      helpStrategy: exercise.helpStrategy,
      avatarMood: AvatarMood.explain,
      voiceMode: VoiceMode.focus,
      rewardPotential: 6,
      followUpNeeded: false,
      explanationStyle: exercise.explanationStyle,
      nextAction: 'Erkannte Aufgabe lösen.',
    );
    notifyListeners();
  }

  void askAgent(String input) {
    lastAgentReply = companionAgent.answer(input);
    currentSpeech = voiceDirector.plan(lastAgentReply!.blocked ? VoiceMode.comfort : VoiceMode.hint, context: lastAgentReply!.text);
    eventBus.emit(lastAgentReply!.category == 'distress' ? LumoEventType.taskWrong2 : LumoEventType.agentOpened);
    notifyListeners();
  }

  void runCognitiveCheck() {
    cognitiveProfile = cognitiveGamesEngine.runDemoCheck();
    currentSpeech = voiceDirector.plan(VoiceMode.testMode);
    eventBus.emit(LumoEventType.cognitiveCheckFinished);
    notifyListeners();
  }

  RewardResult redeemVoucher(String voucherId, String pin) {
    final result = rewardOrchestrator.redeemVoucher(voucherId, pin);
    if (result.success) eventBus.emit(LumoEventType.voucherUnlocked);
    _persistSoft();
    notifyListeners();
    return result;
  }

  void setConsent(ConsentType type, bool enabled) {
    consentService.setConsent(type, enabled);
    consentService.save(localStore);
    notifyListeners();
  }

  String whyRecommendation() => memoryGraph.whyRecommendation(currentExercise.skill);

  void clearLocalLearningData() {
    memoryGraph = MemoryGraph();
    learningBrain = LearningBrain(memory: memoryGraph);
    currentRecommendation = learningBrain.nextExercise(focus: Skill.subtractionTo20);
    lastFeedback = null;
    localStore.remove('memory_graph');
    notifyListeners();
  }

  Future<void> _persistSoft() async {
    try {
      await memoryGraph.save(localStore);
      await localStore.writeJson('rewards', rewardOrchestrator.toJson());
    } catch (_) {
      // Keep the app usable offline/in tests even when platform storage is absent.
    }
  }

  @override
  void dispose() {
    eventBus.dispose();
    super.dispose();
  }
}

class AppStateProvider extends StatefulWidget {
  const AppStateProvider({super.key, required this.child});

  final Widget child;

  @override
  State<AppStateProvider> createState() => _AppStateProviderState();
}

class _AppStateProviderState extends State<AppStateProvider> {
  late final AppState state;

  @override
  void initState() {
    super.initState();
    state = AppState();
    state.bootstrap();
  }

  @override
  void dispose() {
    state.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AppStateScope(state: state, child: widget.child);
}

class AppStateScope extends InheritedNotifier<AppState> {
  const AppStateScope({super.key, required AppState state, required super.child}) : super(notifier: state);

  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppStateScope>();
    assert(scope != null, 'AppStateScope missing');
    return scope!.notifier!;
  }
}
