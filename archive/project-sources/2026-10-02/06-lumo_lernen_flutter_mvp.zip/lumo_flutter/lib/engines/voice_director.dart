import '../core/models/enums.dart';
import '../core/models/speech_models.dart';

class VoiceDirector {
  final List<String> _recent = <String>[];

  SpeechPlan plan(VoiceMode mode, {String? context}) {
    final segments = switch (mode) {
      VoiceMode.greeting => <String>['Servus!', 'Ich bin Lumo.', 'Wir lernen ruhig zusammen.'],
      VoiceMode.praise => <String>['Super, du hast gut nachgedacht.'],
      VoiceMode.celebrate => <String>['Fuchsstark!', 'Du bleibst dran.'],
      VoiceMode.comfort => <String>['Fast.', 'Das ist kein Problem.', 'Wir schauen es gemeinsam an.'],
      VoiceMode.hint => <String>['Ich zeige dir den ersten Schritt.'],
      VoiceMode.explainAfter3 => <String>['Nach drei Versuchen helfe ich dir ganz ruhig.', context ?? 'Wir gehen Schritt für Schritt.'],
      VoiceMode.story => <String>['Eine Mini-Geschichte:', context ?? 'Der kleine Stern hilft beim Denken.'],
      VoiceMode.parentReport => <String>['Diese Empfehlung basiert auf den letzten Aufgaben und Hilfenutzungen.'],
      VoiceMode.calm => <String>['Heute reicht eine kleine Mission.'],
      VoiceMode.focus => <String>['Du musst nicht schnell sein.', 'Ein ruhiger Versuch reicht.'],
      VoiceMode.testMode => <String>['Jetzt kommt ein ruhiger Lern-Check.', 'Keine Diagnose, nur ein Förderprofil.'],
      VoiceMode.voucherUnlock => <String>['Ein Gutschein ist bereit.', 'Bitte mit Eltern-PIN einlösen.'],
    };
    final text = segments.join(' ');
    if (_recent.contains(text)) {
      return SpeechPlan(mode: mode, segments: <String>['Wir machen ruhig weiter.'], pausesMs: const <int>[180], emphasis: 'calm');
    }
    _recent.add(text);
    if (_recent.length > 80) _recent.removeAt(0);
    return SpeechPlan(mode: mode, segments: segments, pausesMs: const <int>[180, 240], emphasis: _emphasis(mode), visemeHints: const <int>[0, 2, 4]);
  }

  String _emphasis(VoiceMode mode) => switch (mode) {
        VoiceMode.celebrate || VoiceMode.praise || VoiceMode.voucherUnlock => 'bright',
        VoiceMode.comfort || VoiceMode.calm || VoiceMode.explainAfter3 => 'slow-calm',
        _ => 'warm',
      };
}
