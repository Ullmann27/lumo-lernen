class CognitiveProfile {
  const CognitiveProfile({required this.summary, required this.scores});

  final String summary;
  final Map<String, int> scores;
}

class CognitiveGamesEngine {
  CognitiveProfile runDemoCheck({String numberAnswer = '8', String symbolAnswer = '🦊', String patternAnswer = '◆'}) {
    final scores = <String, int>{
      'Zahlenreihen': numberAnswer.trim() == '8' ? 3 : 1,
      'Merkfolge': symbolAnswer.trim().isNotEmpty ? 2 : 1,
      'Muster': patternAnswer.trim() == '◆' ? 3 : 1,
    };
    return CognitiveProfile(
      summary: 'Zahlenreihen stark. Muster gut. Merkaufgaben mit 4 Symbolen noch üben.',
      scores: scores,
    );
  }
}
