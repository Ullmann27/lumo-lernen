import 'dart:async';

import '../core/models/enums.dart';

class LumoEvent {
  const LumoEvent(this.type, {this.payload = const <String, Object?>{}});

  final LumoEventType type;
  final Map<String, Object?> payload;
}

class EventBus {
  final StreamController<LumoEvent> _controller = StreamController<LumoEvent>.broadcast();

  Stream<LumoEvent> get stream => _controller.stream;

  void emit(LumoEventType type, {Map<String, Object?> payload = const <String, Object?>{}}) {
    if (!_controller.isClosed) _controller.add(LumoEvent(type, payload: payload));
  }

  void dispose() => _controller.close();
}
