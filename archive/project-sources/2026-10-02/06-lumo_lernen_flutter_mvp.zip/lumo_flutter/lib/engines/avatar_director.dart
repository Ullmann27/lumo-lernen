import '../core/models/enums.dart';

class AvatarDirector {
  AvatarMood mood = AvatarMood.idle;

  AvatarMood handle(LumoEventType event) {
    mood = switch (event) {
      LumoEventType.appOpened => AvatarMood.greet,
      LumoEventType.taskStarted => AvatarMood.explain,
      LumoEventType.taskCorrect => AvatarMood.celebrate,
      LumoEventType.taskWrong1 => AvatarMood.thinking,
      LumoEventType.taskWrong2 => AvatarMood.comfort,
      LumoEventType.taskWrong3 => AvatarMood.explain,
      LumoEventType.idle20s => AvatarMood.sleepy,
      LumoEventType.voucherUnlocked => AvatarMood.jump,
      LumoEventType.levelUp => AvatarMood.celebrate,
      LumoEventType.agentOpened => AvatarMood.listen,
      LumoEventType.photoUploaded => AvatarMood.thinking,
      LumoEventType.testFinished => AvatarMood.celebrate,
      LumoEventType.parentAreaOpened => AvatarMood.sit,
      LumoEventType.childSpeaking => AvatarMood.listen,
      LumoEventType.speechRecognized => AvatarMood.thinking,
      LumoEventType.taskRecognized => AvatarMood.pointLeft,
      LumoEventType.cognitiveCheckStarted => AvatarMood.thinking,
      LumoEventType.cognitiveCheckFinished => AvatarMood.celebrate,
    };
    return mood;
  }
}
