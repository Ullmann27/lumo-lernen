import 'enums.dart';

class SchoolMoment {
  const SchoolMoment({
    required this.name,
    required this.avatarMood,
    required this.voiceMode,
    required this.recommendation,
    this.parentHint,
    this.rewardEvent,
  });

  final String name;
  final AvatarMood avatarMood;
  final VoiceMode voiceMode;
  final String recommendation;
  final String? parentHint;
  final RewardEvent? rewardEvent;
}
