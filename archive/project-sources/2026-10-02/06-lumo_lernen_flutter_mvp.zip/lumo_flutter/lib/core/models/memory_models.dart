import 'enums.dart';

class SkillMemory {
  SkillMemory({
    required this.skill,
    required this.subject,
    this.attempts = 0,
    this.successes = 0,
    this.mistakes = 0,
    this.score = 0,
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? DateTime.now();

  final Skill skill;
  final Subject subject;
  int attempts;
  int successes;
  int mistakes;
  double score;
  DateTime updatedAt;

  double get successRate => attempts == 0 ? 0 : successes / attempts;

  void record({required bool correct}) {
    attempts += 1;
    if (correct) {
      successes += 1;
      score = (score + 0.08).clamp(0, 1).toDouble();
    } else {
      mistakes += 1;
      score = (score - 0.04).clamp(0, 1).toDouble();
    }
    updatedAt = DateTime.now();
  }

  Map<String, Object?> toJson() => <String, Object?>{
        'skill': skill.key,
        'subject': subject.name,
        'attempts': attempts,
        'successes': successes,
        'mistakes': mistakes,
        'score': score,
        'updatedAt': updatedAt.toIso8601String(),
      };

  factory SkillMemory.fromJson(Map<String, Object?> json) => SkillMemory(
        skill: skillFromKey(json['skill'] as String),
        subject: Subject.values.byName(json['subject'] as String),
        attempts: json['attempts'] as int? ?? 0,
        successes: json['successes'] as int? ?? 0,
        mistakes: json['mistakes'] as int? ?? 0,
        score: (json['score'] as num?)?.toDouble() ?? 0,
        updatedAt: DateTime.tryParse(json['updatedAt'] as String? ?? '') ?? DateTime.now(),
      );
}

class ErrorTypeCounts {
  ErrorTypeCounts({Map<String, int>? counts}) : counts = counts ?? <String, int>{};

  final Map<String, int> counts;

  void increment(String errorType) {
    counts[errorType] = (counts[errorType] ?? 0) + 1;
  }

  int count(String errorType) => counts[errorType] ?? 0;

  String get mostCommon {
    if (counts.isEmpty) return 'noch keine Fehlerart';
    final entries = counts.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return entries.first.key;
  }

  Map<String, Object?> toJson() => <String, Object?>{'counts': counts};

  factory ErrorTypeCounts.fromJson(Map<String, Object?> json) {
    return ErrorTypeCounts(counts: Map<String, int>.from(json['counts'] as Map? ?? const <String, int>{}));
  }
}

class HelpStrategyEffect {
  HelpStrategyEffect({
    required this.skill,
    required this.style,
    this.uses = 0,
    this.successes = 0,
  });

  final Skill skill;
  final ExplanationStyle style;
  int uses;
  int successes;

  double get successRate => uses == 0 ? 0 : successes / uses;

  void record({required bool success}) {
    uses += 1;
    if (success) successes += 1;
  }

  Map<String, Object?> toJson() => <String, Object?>{
        'skill': skill.key,
        'style': style.name,
        'uses': uses,
        'successes': successes,
      };

  factory HelpStrategyEffect.fromJson(Map<String, Object?> json) => HelpStrategyEffect(
        skill: skillFromKey(json['skill'] as String),
        style: ExplanationStyle.values.byName(json['style'] as String),
        uses: json['uses'] as int? ?? 0,
        successes: json['successes'] as int? ?? 0,
      );
}

class LearnedStrategy {
  const LearnedStrategy({
    required this.skill,
    required this.style,
    required this.reason,
    required this.successRate,
    required this.createdAt,
  });

  final Skill skill;
  final ExplanationStyle style;
  final String reason;
  final double successRate;
  final DateTime createdAt;

  Map<String, Object?> toJson() => <String, Object?>{
        'skill': skill.key,
        'style': style.name,
        'reason': reason,
        'successRate': successRate,
        'createdAt': createdAt.toIso8601String(),
      };

  factory LearnedStrategy.fromJson(Map<String, Object?> json) => LearnedStrategy(
        skill: skillFromKey(json['skill'] as String),
        style: ExplanationStyle.values.byName(json['style'] as String),
        reason: json['reason'] as String,
        successRate: (json['successRate'] as num).toDouble(),
        createdAt: DateTime.parse(json['createdAt'] as String),
      );
}

class ExerciseHistory {
  const ExerciseHistory({
    required this.exerciseId,
    required this.skill,
    required this.correct,
    required this.attempts,
    required this.createdAt,
  });

  final String exerciseId;
  final Skill skill;
  final bool correct;
  final int attempts;
  final DateTime createdAt;

  Map<String, Object?> toJson() => <String, Object?>{
        'exerciseId': exerciseId,
        'skill': skill.key,
        'correct': correct,
        'attempts': attempts,
        'createdAt': createdAt.toIso8601String(),
      };

  factory ExerciseHistory.fromJson(Map<String, Object?> json) => ExerciseHistory(
        exerciseId: json['exerciseId'] as String,
        skill: skillFromKey(json['skill'] as String),
        correct: json['correct'] as bool,
        attempts: json['attempts'] as int,
        createdAt: DateTime.parse(json['createdAt'] as String),
      );
}

class RewardHistory {
  const RewardHistory({
    required this.type,
    required this.amount,
    required this.note,
    required this.createdAt,
  });

  final String type;
  final int amount;
  final String note;
  final DateTime createdAt;

  Map<String, Object?> toJson() => <String, Object?>{
        'type': type,
        'amount': amount,
        'note': note,
        'createdAt': createdAt.toIso8601String(),
      };

  factory RewardHistory.fromJson(Map<String, Object?> json) => RewardHistory(
        type: json['type'] as String,
        amount: json['amount'] as int,
        note: json['note'] as String,
        createdAt: DateTime.parse(json['createdAt'] as String),
      );
}

class ParentConsent {
  const ParentConsent({
    required this.type,
    required this.enabled,
    required this.updatedAt,
  });

  final ConsentType type;
  final bool enabled;
  final DateTime updatedAt;

  Map<String, Object?> toJson() => <String, Object?>{
        'type': type.name,
        'enabled': enabled,
        'updatedAt': updatedAt.toIso8601String(),
      };

  factory ParentConsent.fromJson(Map<String, Object?> json) => ParentConsent(
        type: ConsentType.values.byName(json['type'] as String),
        enabled: json['enabled'] as bool,
        updatedAt: DateTime.parse(json['updatedAt'] as String),
      );
}

class ReportHistory {
  const ReportHistory({required this.title, required this.body, required this.createdAt});

  final String title;
  final String body;
  final DateTime createdAt;

  Map<String, Object?> toJson() => <String, Object?>{
        'title': title,
        'body': body,
        'createdAt': createdAt.toIso8601String(),
      };

  factory ReportHistory.fromJson(Map<String, Object?> json) => ReportHistory(
        title: json['title'] as String,
        body: json['body'] as String,
        createdAt: DateTime.parse(json['createdAt'] as String),
      );
}

class RecognizedTaskHistory {
  const RecognizedTaskHistory({
    required this.rawInput,
    required this.skill,
    required this.confidence,
    required this.parentReviewed,
    required this.createdAt,
  });

  final String rawInput;
  final Skill skill;
  final double confidence;
  final bool parentReviewed;
  final DateTime createdAt;

  Map<String, Object?> toJson() => <String, Object?>{
        'rawInput': rawInput,
        'skill': skill.key,
        'confidence': confidence,
        'parentReviewed': parentReviewed,
        'createdAt': createdAt.toIso8601String(),
      };

  factory RecognizedTaskHistory.fromJson(Map<String, Object?> json) => RecognizedTaskHistory(
        rawInput: json['rawInput'] as String,
        skill: skillFromKey(json['skill'] as String),
        confidence: (json['confidence'] as num).toDouble(),
        parentReviewed: json['parentReviewed'] as bool,
        createdAt: DateTime.parse(json['createdAt'] as String),
      );
}
