enum LumoMenu {
  home,
  learning,
  agent,
  recognition,
  cognitive,
  rewards,
  parent,
  memory,
  settings,
}

extension LumoMenuText on LumoMenu {
  String get label => switch (this) {
        LumoMenu.home => 'Home',
        LumoMenu.learning => 'Lernen',
        LumoMenu.agent => 'Lumo-Agent',
        LumoMenu.recognition => 'Erkennen',
        LumoMenu.cognitive => 'Lern-Check',
        LumoMenu.rewards => 'Bonus',
        LumoMenu.parent => 'Eltern',
        LumoMenu.memory => 'Memory',
        LumoMenu.settings => 'Datenschutz',
      };

  String get icon => switch (this) {
        LumoMenu.home => '🏠',
        LumoMenu.learning => '🧮',
        LumoMenu.agent => '💬',
        LumoMenu.recognition => '🔎',
        LumoMenu.cognitive => '🧠',
        LumoMenu.rewards => '⭐',
        LumoMenu.parent => '🛡️',
        LumoMenu.memory => '🌳',
        LumoMenu.settings => '⚙️',
      };

  String get title => switch (this) {
        LumoMenu.home => 'Gemütliches 3D-Lernzimmer',
        LumoMenu.learning => '3D-Lerninsel mit Lumo',
        LumoMenu.agent => 'Sicherer 3D-Lumo-Agent',
        LumoMenu.recognition => 'Aufgaben-Erkennung am Zaubertisch',
        LumoMenu.cognitive => 'Kognitiver Lern-Check',
        LumoMenu.rewards => 'Lumos Bonus- und Gutscheinzimmer',
        LumoMenu.parent => 'Ruhiger Elternbereich',
        LumoMenu.memory => 'MemoryGraph als Lernbaum',
        LumoMenu.settings => 'Datenschutz und Freigaben',
      };
}

enum Subject { mathematik, deutsch, sachunterricht, cognitive }

extension SubjectText on Subject {
  String get label => switch (this) {
        Subject.mathematik => 'Mathematik',
        Subject.deutsch => 'Deutsch',
        Subject.sachunterricht => 'Sachunterricht',
        Subject.cognitive => 'Kognitiver Lern-Check',
      };
}

enum Skill {
  additionTo10,
  additionTo20,
  subtractionTo10,
  subtractionTo20,
  numberSequence,
  initialSound,
  syllables,
  rhymes,
  simpleWordProblem,
  basicScience,
  memorySequence,
  attentionPattern,
  patternRecognition,
}

extension SkillText on Skill {
  String get key => switch (this) {
        Skill.additionTo10 => 'addition_to_10',
        Skill.additionTo20 => 'addition_to_20',
        Skill.subtractionTo10 => 'subtraction_to_10',
        Skill.subtractionTo20 => 'subtraction_to_20',
        Skill.numberSequence => 'number_sequence',
        Skill.initialSound => 'initial_sound',
        Skill.syllables => 'syllables',
        Skill.rhymes => 'rhymes',
        Skill.simpleWordProblem => 'simple_word_problem',
        Skill.basicScience => 'basic_science',
        Skill.memorySequence => 'memory_sequence',
        Skill.attentionPattern => 'attention_pattern',
        Skill.patternRecognition => 'pattern_recognition',
      };

  String get label => switch (this) {
        Skill.additionTo10 => 'Addition bis 10',
        Skill.additionTo20 => 'Addition bis 20',
        Skill.subtractionTo10 => 'Subtraktion bis 10',
        Skill.subtractionTo20 => 'Subtraktion bis 20',
        Skill.numberSequence => 'Zahlenreihen',
        Skill.initialSound => 'Anfangslaut',
        Skill.syllables => 'Silbenklatschen',
        Skill.rhymes => 'Reime',
        Skill.simpleWordProblem => 'Textaufgaben',
        Skill.basicScience => 'Sachunterricht',
        Skill.memorySequence => 'Merkfolge',
        Skill.attentionPattern => 'Aufmerksamkeitsmuster',
        Skill.patternRecognition => 'Muster erkennen',
      };

  Subject get subject => switch (this) {
        Skill.additionTo10 ||
        Skill.additionTo20 ||
        Skill.subtractionTo10 ||
        Skill.subtractionTo20 ||
        Skill.numberSequence ||
        Skill.simpleWordProblem => Subject.mathematik,
        Skill.initialSound || Skill.syllables || Skill.rhymes => Subject.deutsch,
        Skill.basicScience => Subject.sachunterricht,
        Skill.memorySequence ||
        Skill.attentionPattern ||
        Skill.patternRecognition => Subject.cognitive,
      };
}

Skill skillFromKey(String key) {
  return Skill.values.firstWhere(
    (skill) => skill.key == key || skill.name == key,
    orElse: () => Skill.subtractionTo20,
  );
}

enum Difficulty { easy, medium, hard }

enum AvatarMood {
  idle,
  greet,
  listen,
  thinking,
  celebrate,
  comfort,
  explain,
  pointLeft,
  pointRight,
  walk,
  bend,
  jump,
  sit,
  sleepy,
}

enum LumoEventType {
  appOpened,
  taskStarted,
  taskCorrect,
  taskWrong1,
  taskWrong2,
  taskWrong3,
  idle20s,
  voucherUnlocked,
  levelUp,
  agentOpened,
  photoUploaded,
  testFinished,
  parentAreaOpened,
  childSpeaking,
  speechRecognized,
  taskRecognized,
  cognitiveCheckStarted,
  cognitiveCheckFinished,
}

enum VoiceMode {
  greeting,
  praise,
  celebrate,
  comfort,
  hint,
  explainAfter3,
  story,
  parentReport,
  calm,
  focus,
  testMode,
  voucherUnlock,
}

enum ExplanationStyle {
  text,
  imagePlaceholder,
  numberLine,
  objects,
  syllableClap,
  steps,
  counterExample,
  miniStory,
  readAloud,
  slowSpeech,
  similarFollowUp,
}

extension ExplanationStyleText on ExplanationStyle {
  String get label => switch (this) {
        ExplanationStyle.text => 'Text',
        ExplanationStyle.imagePlaceholder => 'Bildplatzhalter',
        ExplanationStyle.numberLine => 'Zahlenstrahl',
        ExplanationStyle.objects => 'Objekte',
        ExplanationStyle.syllableClap => 'Silbenklatschen',
        ExplanationStyle.steps => 'Schrittfolge',
        ExplanationStyle.counterExample => 'Gegenbeispiel',
        ExplanationStyle.miniStory => 'Mini-Geschichte',
        ExplanationStyle.readAloud => 'Vorlesen',
        ExplanationStyle.slowSpeech => 'Langsam sprechen',
        ExplanationStyle.similarFollowUp => 'Ähnliche Folgeaufgabe',
      };
}

enum ConsentType {
  photoAnalysis,
  microphone,
  aiVoice,
  cloudSync,
  dataExport,
  dataDeletion,
}

extension ConsentTypeText on ConsentType {
  String get label => switch (this) {
        ConsentType.photoAnalysis => 'Fotoanalyse',
        ConsentType.microphone => 'Mikrofon',
        ConsentType.aiVoice => 'KI-Stimme',
        ConsentType.cloudSync => 'Cloud-Sync',
        ConsentType.dataExport => 'Datenexport',
        ConsentType.dataDeletion => 'Datenlöschung',
      };
}

enum RewardEvent {
  correctAnswer,
  persistedAfterMistake,
  repetition,
  difficultAttempt,
  dailyPlanDone,
  improvement,
  focus,
}
