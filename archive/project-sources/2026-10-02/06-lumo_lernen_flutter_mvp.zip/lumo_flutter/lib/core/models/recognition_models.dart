import 'enums.dart';
import 'exercise.dart';

enum RecognitionKind { exercise, gradeEntry, instruction, unknown }

class RecognitionResult {
  const RecognitionResult({
    required this.recognized,
    required this.confidence,
    required this.subject,
    required this.skill,
    required this.difficulty,
    this.exercise,
    required this.needsParentReview,
    required this.rawInput,
    required this.normalizedInput,
    required this.explanation,
    this.kind = RecognitionKind.exercise,
  });

  final bool recognized;
  final double confidence;
  final Subject? subject;
  final Skill? skill;
  final Difficulty? difficulty;
  final Exercise? exercise;
  final bool needsParentReview;
  final String rawInput;
  final String normalizedInput;
  final String explanation;
  final RecognitionKind kind;

  Map<String, Object?> toJson() => <String, Object?>{
        'recognized': recognized,
        'confidence': confidence,
        'subject': subject?.name,
        'skill': skill?.key,
        'difficulty': difficulty?.name,
        'exercise': exercise?.toJson(),
        'needsParentReview': needsParentReview,
        'rawInput': rawInput,
        'normalizedInput': normalizedInput,
        'explanation': explanation,
        'kind': kind.name,
      };
}
