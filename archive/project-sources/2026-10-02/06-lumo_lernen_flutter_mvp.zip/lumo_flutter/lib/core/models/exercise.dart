import 'enums.dart';

class Exercise {
  const Exercise({
    required this.id,
    required this.subject,
    required this.skill,
    required this.difficulty,
    required this.prompt,
    required this.answer,
    this.choices = const <String>[],
    required this.explanation,
    required this.helpStrategy,
    required this.explanationStyle,
    required this.createdAt,
    this.source = 'generated',
    this.parentReviewed = false,
    this.metadata = const <String, Object?>{},
  });

  final String id;
  final Subject subject;
  final Skill skill;
  final Difficulty difficulty;
  final String prompt;
  final String answer;
  final List<String> choices;
  final String explanation;
  final String helpStrategy;
  final ExplanationStyle explanationStyle;
  final DateTime createdAt;
  final String source;
  final bool parentReviewed;
  final Map<String, Object?> metadata;

  bool checkAnswer(String value) => _clean(value) == _clean(answer);

  static String _clean(String value) => value.trim().toLowerCase().replaceAll(',', '.');

  Exercise copyWith({
    String? id,
    Subject? subject,
    Skill? skill,
    Difficulty? difficulty,
    String? prompt,
    String? answer,
    List<String>? choices,
    String? explanation,
    String? helpStrategy,
    ExplanationStyle? explanationStyle,
    DateTime? createdAt,
    String? source,
    bool? parentReviewed,
    Map<String, Object?>? metadata,
  }) {
    return Exercise(
      id: id ?? this.id,
      subject: subject ?? this.subject,
      skill: skill ?? this.skill,
      difficulty: difficulty ?? this.difficulty,
      prompt: prompt ?? this.prompt,
      answer: answer ?? this.answer,
      choices: choices ?? this.choices,
      explanation: explanation ?? this.explanation,
      helpStrategy: helpStrategy ?? this.helpStrategy,
      explanationStyle: explanationStyle ?? this.explanationStyle,
      createdAt: createdAt ?? this.createdAt,
      source: source ?? this.source,
      parentReviewed: parentReviewed ?? this.parentReviewed,
      metadata: metadata ?? this.metadata,
    );
  }

  Map<String, Object?> toJson() => <String, Object?>{
        'id': id,
        'subject': subject.name,
        'skill': skill.key,
        'difficulty': difficulty.name,
        'prompt': prompt,
        'answer': answer,
        'choices': choices,
        'explanation': explanation,
        'helpStrategy': helpStrategy,
        'explanationStyle': explanationStyle.name,
        'createdAt': createdAt.toIso8601String(),
        'source': source,
        'parentReviewed': parentReviewed,
        'metadata': metadata,
      };

  factory Exercise.fromJson(Map<String, Object?> json) {
    return Exercise(
      id: json['id'] as String,
      subject: Subject.values.byName(json['subject'] as String),
      skill: skillFromKey(json['skill'] as String),
      difficulty: Difficulty.values.byName(json['difficulty'] as String),
      prompt: json['prompt'] as String,
      answer: json['answer'] as String,
      choices: (json['choices'] as List<dynamic>? ?? const <dynamic>[]).map((item) => item.toString()).toList(),
      explanation: json['explanation'] as String,
      helpStrategy: json['helpStrategy'] as String,
      explanationStyle: ExplanationStyle.values.byName(json['explanationStyle'] as String),
      createdAt: DateTime.parse(json['createdAt'] as String),
      source: json['source'] as String? ?? 'generated',
      parentReviewed: json['parentReviewed'] as bool? ?? false,
      metadata: Map<String, Object?>.from(json['metadata'] as Map? ?? const <String, Object?>{}),
    );
  }
}

class LearningRecommendation {
  const LearningRecommendation({
    required this.exercise,
    required this.reason,
    required this.helpStrategy,
    required this.avatarMood,
    required this.voiceMode,
    required this.rewardPotential,
    required this.followUpNeeded,
    required this.explanationStyle,
    required this.nextAction,
  });

  final Exercise exercise;
  final String reason;
  final String helpStrategy;
  final AvatarMood avatarMood;
  final VoiceMode voiceMode;
  final int rewardPotential;
  final bool followUpNeeded;
  final ExplanationStyle explanationStyle;
  final String nextAction;
}

class AnswerFeedback {
  const AnswerFeedback({
    required this.isCorrect,
    required this.attempts,
    required this.message,
    required this.showExplanation,
    this.explanationSteps = const <String>[],
    this.followUp,
  });

  final bool isCorrect;
  final int attempts;
  final String message;
  final bool showExplanation;
  final List<String> explanationSteps;
  final Exercise? followUp;
}
