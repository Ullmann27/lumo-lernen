import 'enums.dart';

class MenuContract {
  const MenuContract({
    required this.menu,
    required this.status,
    required this.actionLabel,
    required this.historyLabel,
    required this.completionLabel,
    required this.reportLabel,
    required this.recommendation,
  });

  final LumoMenu menu;
  final String status;
  final String actionLabel;
  final String historyLabel;
  final String completionLabel;
  final String reportLabel;
  final String recommendation;
}
