import 'enums.dart';

class SpeechPlan {
  const SpeechPlan({
    required this.mode,
    required this.segments,
    this.pausesMs = const <int>[],
    this.emphasis = 'warm',
    this.visemeHints = const <int>[],
  });

  final VoiceMode mode;
  final List<String> segments;
  final List<int> pausesMs;
  final String emphasis;
  final List<int> visemeHints;

  String get text => segments.join(' ');

  Map<String, Object?> toJson() => <String, Object?>{
        'mode': mode.name,
        'segments': segments,
        'pausesMs': pausesMs,
        'emphasis': emphasis,
        'visemeHints': visemeHints,
      };
}
