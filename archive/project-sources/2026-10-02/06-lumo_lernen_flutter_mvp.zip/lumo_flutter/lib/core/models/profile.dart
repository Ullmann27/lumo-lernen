class ChildProfile {
  const ChildProfile({
    this.displayName = 'Lernkind',
    this.grade = '1.–2. Klasse',
    this.region = 'Österreich',
  });

  final String displayName;
  final String grade;
  final String region;

  Map<String, Object?> toJson() => <String, Object?>{
        'displayName': displayName,
        'grade': grade,
        'region': region,
      };

  factory ChildProfile.fromJson(Map<String, Object?> json) => ChildProfile(
        displayName: json['displayName'] as String? ?? 'Lernkind',
        grade: json['grade'] as String? ?? '1.–2. Klasse',
        region: json['region'] as String? ?? 'Österreich',
      );
}
