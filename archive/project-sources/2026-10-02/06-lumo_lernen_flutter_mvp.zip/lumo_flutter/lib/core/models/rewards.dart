class Voucher {
  const Voucher({
    required this.id,
    required this.title,
    required this.emoji,
    required this.costStars,
    this.redeemed = false,
    this.redeemedAt,
  });

  final String id;
  final String title;
  final String emoji;
  final int costStars;
  final bool redeemed;
  final DateTime? redeemedAt;

  Voucher redeem() => Voucher(
        id: id,
        title: title,
        emoji: emoji,
        costStars: costStars,
        redeemed: true,
        redeemedAt: DateTime.now(),
      );

  Map<String, Object?> toJson() => <String, Object?>{
        'id': id,
        'title': title,
        'emoji': emoji,
        'costStars': costStars,
        'redeemed': redeemed,
        'redeemedAt': redeemedAt?.toIso8601String(),
      };

  factory Voucher.fromJson(Map<String, Object?> json) => Voucher(
        id: json['id'] as String,
        title: json['title'] as String,
        emoji: json['emoji'] as String,
        costStars: json['costStars'] as int,
        redeemed: json['redeemed'] as bool? ?? false,
        redeemedAt: DateTime.tryParse(json['redeemedAt'] as String? ?? ''),
      );
}

class RewardWallet {
  RewardWallet({
    this.stars = 128,
    this.xp = 240,
    this.level = 3,
    List<String>? achievements,
    List<String>? roomItems,
    List<Voucher>? vouchers,
    List<String>? history,
  })  : achievements = achievements ?? <String>['Dranbleiben'],
        roomItems = roomItems ?? <String>['Schal', 'Lampe'],
        vouchers = vouchers ?? <Voucher>[],
        history = history ?? <String>[];

  int stars;
  int xp;
  int level;
  final List<String> achievements;
  final List<String> roomItems;
  List<Voucher> vouchers;
  final List<String> history;

  Map<String, Object?> toJson() => <String, Object?>{
        'stars': stars,
        'xp': xp,
        'level': level,
        'achievements': achievements,
        'roomItems': roomItems,
        'vouchers': vouchers.map((voucher) => voucher.toJson()).toList(),
        'history': history,
      };

  factory RewardWallet.fromJson(Map<String, Object?> json) => RewardWallet(
        stars: json['stars'] as int? ?? 128,
        xp: json['xp'] as int? ?? 240,
        level: json['level'] as int? ?? 3,
        achievements: (json['achievements'] as List<dynamic>? ?? const <dynamic>[]).map((item) => item.toString()).toList(),
        roomItems: (json['roomItems'] as List<dynamic>? ?? const <dynamic>[]).map((item) => item.toString()).toList(),
        vouchers: (json['vouchers'] as List<dynamic>? ?? const <dynamic>[])
            .map((item) => Voucher.fromJson(Map<String, Object?>.from(item as Map)))
            .toList(),
        history: (json['history'] as List<dynamic>? ?? const <dynamic>[]).map((item) => item.toString()).toList(),
      );
}

class RewardResult {
  const RewardResult({required this.success, required this.message, this.levelUp = false});

  final bool success;
  final String message;
  final bool levelUp;
}
