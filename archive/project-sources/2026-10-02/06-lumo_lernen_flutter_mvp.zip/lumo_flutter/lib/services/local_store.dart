import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class LocalStore {
  Future<Map<String, Object?>?> readJson(String key) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(key);
    if (raw == null) return null;
    return Map<String, Object?>.from(jsonDecode(raw) as Map);
  }

  Future<void> writeJson(String key, Map<String, Object?> json) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(key, jsonEncode(json));
  }

  Future<void> remove(String key) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(key);
  }
}
