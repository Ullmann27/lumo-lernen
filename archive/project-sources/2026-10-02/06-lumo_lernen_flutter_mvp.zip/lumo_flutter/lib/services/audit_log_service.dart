class AuditLogService {
  final List<String> _entries = <String>[];

  List<String> get entries => List<String>.unmodifiable(_entries);

  void record(String message) {
    _entries.add('${DateTime.now().toIso8601String()} $message');
  }

  void clear() => _entries.clear();
}
