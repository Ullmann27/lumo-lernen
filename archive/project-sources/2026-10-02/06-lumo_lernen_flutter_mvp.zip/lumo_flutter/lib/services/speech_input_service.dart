import 'package:speech_to_text/speech_to_text.dart';

import '../core/models/enums.dart';
import 'consent_service.dart';

class SpeechInputService {
  SpeechInputService({SpeechToText? speech}) : _speech = speech ?? SpeechToText();

  final SpeechToText _speech;

  Future<bool> initialize(ConsentService consent) async {
    if (!consent.isEnabled(ConsentType.microphone)) return false;
    return _speech.initialize();
  }

  Future<String> listen(ConsentService consent) async {
    if (!consent.isEnabled(ConsentType.microphone)) {
      return 'Mikrofon braucht eine Elternfreigabe.';
    }
    final available = await initialize(consent);
    if (!available) return 'Mikrofon ist nicht verfügbar.';
    String recognized = '';
    await _speech.listen(onResult: (result) => recognized = result.recognizedWords);
    return recognized;
  }

  Future<void> stop() => _speech.stop();
}
