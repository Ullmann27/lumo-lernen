import 'package:flutter_tts/flutter_tts.dart';

import '../core/models/speech_models.dart';
import 'consent_service.dart';
import '../core/models/enums.dart';

class TtsService {
  TtsService({FlutterTts? tts}) : _tts = tts ?? FlutterTts();

  final FlutterTts _tts;
  bool debugFallback = true;

  Future<String> speak(SpeechPlan plan, ConsentService consent) async {
    if (!consent.isEnabled(ConsentType.aiVoice)) {
      return 'KI-Stimme braucht eine Elternfreigabe.';
    }
    try {
      await _tts.setLanguage('de-AT');
      await _tts.setSpeechRate(plan.emphasis == 'slow-calm' ? 0.42 : 0.48);
      await _tts.speak(plan.text);
      return plan.text;
    } catch (_) {
      debugFallback = true;
      return plan.text;
    }
  }
}
