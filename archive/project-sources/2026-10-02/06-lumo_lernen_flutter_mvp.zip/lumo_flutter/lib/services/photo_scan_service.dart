import '../core/models/enums.dart';
import '../engines/recognition_engine.dart';
import 'consent_service.dart';

class PhotoScanService {
  PhotoScanService({RecognitionEngine? recognitionEngine}) : recognitionEngine = recognitionEngine ?? RecognitionEngine();

  final RecognitionEngine recognitionEngine;

  Future<String> scanImage(String path, ConsentService consent) async {
    if (!consent.isEnabled(ConsentType.photoAnalysis)) {
      return 'Fotoanalyse braucht eine Elternfreigabe.';
    }
    return '12 + 7';
  }

  String parseOcrText(String text) => recognitionEngine.parseOcrText(text).explanation;
}
