import '../core/models/enums.dart';
import 'local_store.dart';

class ConsentService {
  ConsentService({Map<ConsentType, bool>? initial}) : _consents = initial ?? <ConsentType, bool>{
          for (final type in ConsentType.values) type: false,
        };

  final Map<ConsentType, bool> _consents;

  bool isEnabled(ConsentType type) => _consents[type] ?? false;

  void setConsent(ConsentType type, bool enabled) {
    _consents[type] = enabled;
  }

  Map<String, Object?> toJson() => <String, Object?>{
        for (final entry in _consents.entries) entry.key.name: entry.value,
      };

  factory ConsentService.fromJson(Map<String, Object?> json) => ConsentService(
        initial: <ConsentType, bool>{
          for (final type in ConsentType.values) type: json[type.name] as bool? ?? false,
        },
      );

  Future<void> save(LocalStore store) => store.writeJson('consents', toJson());

  static Future<ConsentService> load(LocalStore store) async {
    final json = await store.readJson('consents');
    return json == null ? ConsentService() : ConsentService.fromJson(json);
  }
}
