import '../core/models/rewards.dart';

List<Voucher> seedVouchers() => const <Voucher>[
      Voucher(id: 'ice', title: '1 Eis', emoji: '🍦', costStars: 80),
      Voucher(id: 'movie', title: 'Familienfilm', emoji: '🎬', costStars: 120),
      Voucher(id: 'story', title: 'Extra-Geschichte', emoji: '📖', costStars: 40),
      Voucher(id: 'swim', title: 'Schwimmen', emoji: '🏊', costStars: 160),
    ];
