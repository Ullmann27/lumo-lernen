const List<String> childFriendlyPhrases = <String>[
  'Fast. Das ist kein Problem.',
  'Wir schauen es gemeinsam an.',
  'Du musst nicht schnell sein.',
  'Ein Fehler zeigt uns nur, was wir üben.',
  'Ich zeige dir den ersten Schritt.',
  'Nach drei Versuchen helfe ich dir ganz ruhig.',
  'Super, du hast gut nachgedacht.',
  'Fuchsstark, du bleibst dran.',
  'Heute reicht eine kleine Mission.',
];

const String privateDataReply =
    'Das musst du mir nicht sagen. Frag bitte Mama, Papa oder einen vertrauten Erwachsenen. Ich helfe dir gern beim Lernen.';

const String distressReply =
    'Das klingt schwer. Bitte sag es Mama, Papa oder einem vertrauten Erwachsenen. Ich bleibe hier und mache mit dir nur einen ruhigen Schritt.';

const String blockedTopicReply =
    'Darüber rede ich nicht. Aber beim Lernen, Mutmachen oder Ausruhen helfe ich dir gern.';

const String learningHelpReply = 'Wir machen es Schritt für Schritt. Ich zeige dir den Anfang.';
