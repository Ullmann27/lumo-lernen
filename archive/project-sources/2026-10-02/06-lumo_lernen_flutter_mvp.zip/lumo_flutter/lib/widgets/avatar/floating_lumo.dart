import 'package:flutter/material.dart';

import '../../core/models/enums.dart';
import 'lumo_avatar.dart';

class FloatingLumo extends StatelessWidget {
  const FloatingLumo({super.key, required this.mood});

  final AvatarMood mood;

  @override
  Widget build(BuildContext context) => Positioned(
        right: 18,
        bottom: 18,
        child: IgnorePointer(
          child: DecoratedBox(
            decoration: BoxDecoration(color: Colors.white.withAlpha(160), borderRadius: BorderRadius.circular(26)),
            child: Padding(padding: const EdgeInsets.all(4), child: LumoAvatar(size: 92, mood: mood)),
          ),
        ),
      );
}
