import 'package:flutter/material.dart';

import '../../app/theme.dart';
import '../../core/models/enums.dart';
import '../../engines/app_state.dart';
import '../common/lumo_button.dart';
import 'lumo_avatar.dart';

class LumoSidePanel extends StatelessWidget {
  const LumoSidePanel({super.key, required this.onNavigate});

  final ValueChanged<LumoMenu> onNavigate;

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    return Container(
      width: 280,
      margin: const EdgeInsets.fromLTRB(0, 18, 18, 18),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white.withAlpha(200),
        borderRadius: BorderRadius.circular(32),
        border: Border.all(color: Colors.white.withAlpha(230)),
        boxShadow: <BoxShadow>[BoxShadow(color: Colors.black.withAlpha(18), blurRadius: 28, offset: const Offset(0, 18))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Center(child: LumoAvatar(size: 150, mood: state.mood)),
          Text('Tagesvorschlag', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Text(state.currentRecommendation.nextAction),
          const SizedBox(height: 12),
          Wrap(spacing: 8, runSpacing: 8, children: <Widget>[
            _Chip('⭐ ${state.wallet.stars}'),
            _Chip('Level ${state.wallet.level}'),
            _Chip(state.currentExercise.skill.label),
          ]),
          const SizedBox(height: 12),
          Text('Aktuelle Schwäche', style: Theme.of(context).textTheme.titleSmall),
          Text(state.memoryGraph.weakestSkill().label),
          const SizedBox(height: 12),
          Text('„${state.currentSpeech.text}”'),
          const Spacer(),
          LumoButton(label: 'Beste nächste Aufgabe', onPressed: () => onNavigate(LumoMenu.learning)),
          const SizedBox(height: 8),
          LumoButton(label: 'Warum?', secondary: true, onPressed: () => onNavigate(LumoMenu.parent)),
        ],
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  const _Chip(this.text);

  final String text;

  @override
  Widget build(BuildContext context) => DecoratedBox(
        decoration: BoxDecoration(color: LumoColors.mint.withAlpha(180), borderRadius: BorderRadius.circular(99)),
        child: Padding(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), child: Text(text, style: const TextStyle(fontWeight: FontWeight.w800))),
      );
}
