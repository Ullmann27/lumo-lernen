import 'package:flutter/material.dart';

import '../../core/models/enums.dart';
import 'lumo_avatar.dart';

class RiveLumoInputs {
  const RiveLumoInputs({
    required this.emotion,
    this.isSpeaking = false,
    this.visemeIndex = 0,
    this.triggerWin = false,
    this.triggerFail = false,
    this.triggerVoucher = false,
    this.triggerExplain = false,
    this.triggerListen = false,
    this.triggerIdle = false,
    this.triggerPointLeft = false,
    this.triggerPointRight = false,
  });

  final AvatarMood emotion;
  final bool isSpeaking;
  final int visemeIndex;
  final bool triggerWin;
  final bool triggerFail;
  final bool triggerVoucher;
  final bool triggerExplain;
  final bool triggerListen;
  final bool triggerIdle;
  final bool triggerPointLeft;
  final bool triggerPointRight;
}

class RiveLumoAvatar extends StatelessWidget {
  const RiveLumoAvatar({super.key, required this.inputs, this.size = 180});

  final RiveLumoInputs inputs;
  final double size;

  @override
  Widget build(BuildContext context) {
    // Adapter-Stub: später Rive-Datei anbinden. Aktuell bewusst Flutter-Avatar als testbarer Fallback.
    return LumoAvatar(size: size, mood: inputs.emotion);
  }
}
