import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/models/enums.dart';

class LumoAvatar extends StatefulWidget {
  const LumoAvatar({super.key, this.size = 180, this.mood = AvatarMood.idle});

  final double size;
  final AvatarMood mood;

  @override
  State<LumoAvatar> createState() => _LumoAvatarState();
}

class _LumoAvatarState extends State<LumoAvatar> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1600))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        final t = _controller.value;
        final bob = switch (widget.mood) {
          AvatarMood.celebrate || AvatarMood.jump => math.sin(t * math.pi) * -18,
          AvatarMood.sleepy => math.sin(t * math.pi * 2) * 2,
          _ => math.sin(t * math.pi * 2) * 6,
        };
        final tilt = switch (widget.mood) {
          AvatarMood.thinking => math.sin(t * math.pi * 2) * 0.08,
          AvatarMood.pointLeft => -0.12,
          AvatarMood.pointRight => 0.12,
          _ => 0.0,
        };
        return Transform.translate(
          offset: Offset(0, bob),
          child: Transform.rotate(
            angle: tilt,
            child: SizedBox(
              width: widget.size,
              height: widget.size,
              child: CustomPaint(painter: _LumoPainter(t: t, mood: widget.mood)),
            ),
          ),
        );
      },
    );
  }
}

class _LumoPainter extends CustomPainter {
  _LumoPainter({required this.t, required this.mood});

  final double t;
  final AvatarMood mood;

  @override
  void paint(Canvas canvas, Size size) {
    final s = size.width;
    final center = Offset(s / 2, s / 2 + s * .05);
    final shadow = Paint()..color = Colors.black.withAlpha(28);
    canvas.drawOval(Rect.fromCenter(center: Offset(s / 2, s * .88), width: s * .58, height: s * .13), shadow);

    final tailPaint = Paint()..shader = const LinearGradient(colors: <Color>[Color(0xFFFFA24F), Color(0xFFC95D1E)]).createShader(Rect.fromLTWH(0, 0, s, s));
    final tail = Path()
      ..moveTo(s * .28, s * .58)
      ..cubicTo(s * .02, s * .44, s * .1, s * .18, s * .4, s * .35)
      ..cubicTo(s * .27, s * .4, s * .34, s * .55, s * .47, s * .61)
      ..close();
    canvas.drawPath(tail, tailPaint);

    final bodyPaint = Paint()..color = const Color(0xFFFF8A3D);
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: center.translate(0, s * .15), width: s * .42, height: s * .48), Radius.circular(s * .22)), bodyPaint);
    canvas.drawOval(Rect.fromCenter(center: center.translate(0, s * .22), width: s * .22, height: s * .24), Paint()..color = const Color(0xFFFFE0BC));

    final headCenter = center.translate(0, -s * .17);
    final earPaint = Paint()..color = const Color(0xFFFF8A3D);
    final innerEar = Paint()..color = const Color(0xFFFFC7A5);
    final leftEar = Path()
      ..moveTo(s * .33, s * .25)
      ..lineTo(s * .42, s * .02)
      ..lineTo(s * .5, s * .28)
      ..close();
    final rightEar = Path()
      ..moveTo(s * .5, s * .28)
      ..lineTo(s * .58, s * .02)
      ..lineTo(s * .67, s * .25)
      ..close();
    canvas.drawPath(leftEar, earPaint);
    canvas.drawPath(rightEar, earPaint);
    canvas.drawCircle(Offset(s * .42, s * .15), s * .035, innerEar);
    canvas.drawCircle(Offset(s * .58, s * .15), s * .035, innerEar);
    canvas.drawCircle(headCenter, s * .23, bodyPaint);

    final face = Paint()..color = const Color(0xFFFFE9D3);
    canvas.drawOval(Rect.fromCenter(center: headCenter.translate(0, s * .08), width: s * .27, height: s * .16), face);
    final eyePaint = Paint()..color = const Color(0xFF2F2A24);
    final eyeY = headCenter.dy - s * .03;
    final blink = mood == AvatarMood.sleepy ? 0.35 : 1.0;
    canvas.drawOval(Rect.fromCenter(center: Offset(s * .43, eyeY), width: s * .035, height: s * .045 * blink), eyePaint);
    canvas.drawOval(Rect.fromCenter(center: Offset(s * .57, eyeY), width: s * .035, height: s * .045 * blink), eyePaint);
    canvas.drawCircle(Offset(s * .5, headCenter.dy + s * .07), s * .022, eyePaint);

    final pawPaint = Paint()..color = const Color(0xFFC95D1E);
    final wave = mood == AvatarMood.greet || mood == AvatarMood.celebrate ? math.sin(t * math.pi * 2) * s * .08 : 0.0;
    final listenLift = mood == AvatarMood.listen ? -s * .11 : 0.0;
    canvas.drawOval(Rect.fromCenter(center: Offset(s * .36, s * .68), width: s * .09, height: s * .16), pawPaint);
    canvas.drawOval(Rect.fromCenter(center: Offset(s * .64, s * .68 + listenLift + wave), width: s * .09, height: s * .16), pawPaint);

    if (mood == AvatarMood.thinking) {
      final bubble = Paint()..color = Colors.white.withAlpha(210);
      canvas.drawCircle(Offset(s * .74, s * .18), s * .035 + t * s * .012, bubble);
      canvas.drawCircle(Offset(s * .82, s * .1), s * .025 + t * s * .008, bubble);
    }
    if (mood == AvatarMood.celebrate || mood == AvatarMood.jump) {
      final starPaint = Paint()..color = const Color(0xFFF6B934);
      for (var i = 0; i < 5; i++) {
        final angle = i * math.pi * .4 + t;
        canvas.drawCircle(Offset(s * .5 + math.cos(angle) * s * .36, s * .35 + math.sin(angle) * s * .26), s * .018, starPaint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _LumoPainter oldDelegate) => oldDelegate.t != t || oldDelegate.mood != mood;
}
