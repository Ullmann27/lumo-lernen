import 'package:flutter/material.dart';

import '../../core/models/enums.dart';

class ConsentTile extends StatelessWidget {
  const ConsentTile({super.key, required this.type, required this.enabled, required this.onChanged});

  final ConsentType type;
  final bool enabled;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) => SwitchListTile(
        value: enabled,
        onChanged: onChanged,
        title: Text(type.label, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: const Text('Nur nach Elternfreigabe. Zweckgebunden, offline-first und ohne Werbung.'),
      );
}
