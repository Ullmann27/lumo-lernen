import 'package:flutter/material.dart';

import '../../app/theme.dart';

class LumoButton extends StatelessWidget {
  const LumoButton({super.key, required this.label, required this.onPressed, this.secondary = false});

  final String label;
  final VoidCallback? onPressed;
  final bool secondary;

  @override
  Widget build(BuildContext context) {
    final child = Padding(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12), child: Text(label, textAlign: TextAlign.center));
    return secondary
        ? OutlinedButton(onPressed: onPressed, style: OutlinedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))), child: child)
        : FilledButton(
            onPressed: onPressed,
            style: FilledButton.styleFrom(
              backgroundColor: LumoColors.orange,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
            ),
            child: child,
          );
  }
}
