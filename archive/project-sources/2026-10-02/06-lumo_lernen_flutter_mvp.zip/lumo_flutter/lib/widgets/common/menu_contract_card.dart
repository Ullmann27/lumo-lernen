import 'package:flutter/material.dart';

import '../../core/models/menu_contract.dart';
import 'lumo_card.dart';

class MenuContractCard extends StatelessWidget {
  const MenuContractCard({super.key, required this.contract});

  final MenuContract contract;

  @override
  Widget build(BuildContext context) => LumoCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
          Text('${contract.menu.icon} ${contract.menu.label}', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Text('Status: ${contract.status}'),
          Text('Aktion: ${contract.actionLabel}'),
          Text('Verlauf: ${contract.historyLabel}'),
          Text('Abschluss: ${contract.completionLabel}'),
          Text('Bericht: ${contract.reportLabel}'),
          const SizedBox(height: 8),
          Text(contract.recommendation, style: const TextStyle(fontWeight: FontWeight.w700)),
        ]),
      );
}
