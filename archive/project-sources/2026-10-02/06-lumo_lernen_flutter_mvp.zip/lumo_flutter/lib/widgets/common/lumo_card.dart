import 'package:flutter/material.dart';

class LumoCard extends StatelessWidget {
  const LumoCard({super.key, required this.child, this.padding = const EdgeInsets.all(20), this.onTap});

  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final card = Container(
      padding: padding,
      decoration: BoxDecoration(
        color: Colors.white.withAlpha(205),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: Colors.white.withAlpha(230)),
        boxShadow: <BoxShadow>[BoxShadow(color: Colors.black.withAlpha(18), blurRadius: 28, offset: const Offset(0, 16))],
      ),
      child: child,
    );
    return onTap == null ? card : InkWell(borderRadius: BorderRadius.circular(28), onTap: onTap, child: card);
  }
}
