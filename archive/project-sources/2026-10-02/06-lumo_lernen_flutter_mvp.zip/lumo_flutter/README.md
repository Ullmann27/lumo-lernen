# Lumo Lernen

Flutter/Android-MVP aus dem vorhandenen HTML/CSS/JavaScript-Prototyp (`index.html`, `styles.css`, `script.js`).

## Lokal testen

```bash
flutter create --platforms=android . # nur falls android/ fehlt
flutter pub get
flutter analyze
flutter test
flutter build apk --debug
```

APK-Pfad: `build/app/outputs/flutter-apk/app-debug.apk`

## GitHub Actions Artifact

Workflow: `.github/workflows/android-debug-apk.yml`
Artifact: `lumo-lernen-debug-apk`

## Aktuelle Stubs

- echte Rive-Datei
- Premium-TTS
- echte OCR-Kamera / Google ML Kit
- Cloud-Sync
- produktive PIN-Sicherheit

Die Demo-PIN ist `1234` und ist im Code/UI ausdrücklich als Prototyp markiert.
