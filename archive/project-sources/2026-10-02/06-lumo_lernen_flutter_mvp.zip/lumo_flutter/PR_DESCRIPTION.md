# Build Flutter Android MVP from Lumo Lernen HTML prototype

## 1. Was war der Ausgangspunkt?

Ausgangspunkt war ein HTML/CSS/JavaScript-Prototyp mit:

- `index.html`
- `styles.css`
- `script.js`

Der Prototyp enthielt eine 3D-App-Vision mit NavigationRail, Home, Lernen, Lumo-Agent, Aufgaben-Erkennung, kognitivem Lern-Check, Bonus/Gutscheinen, Elternbereich, MemoryGraph/Lernbaum, Datenschutzbereich, Fold-Ansicht, animiertem CSS/HTML-Lumo-Fuchs, einfacher Lernlogik, Safe-Agent-Regeln, Recognition-Regeln, Eltern-Why-Button, Idle-Reaktion und Starburst.

## 2. Was wurde gebaut?

- echte Flutter-App-Struktur unter `lib/`
- adaptive `AppShell` für kompakte Ansicht, Fold-Split-Panel und erweiterte NavigationRail
- Screens: Home, Lernen, Lumo-Agent, Erkennen, Kognitiver Lern-Check, Bonus/Gutscheine, Eltern, Memory, Datenschutz/Einstellungen
- Engines: LearningBrain, MemoryGraph, RecognitionEngine, CompanionAgent, RewardOrchestrator, AvatarDirector, VoiceDirector, CognitiveGamesEngine, SchoolMomentEngine, ExplanationStyleEngine, EventBus
- Services: LocalStore, ConsentService, TtsService, SpeechInputService, PhotoScanService Stub, AuditLogService
- Flutter-Widget-Avatar als animierter Lumo-Fuchs plus Rive-Adapter-Stub
- Tests für LearningBrain, RecognitionEngine, RewardOrchestrator, MemoryGraph, CompanionAgent
- GitHub Actions APK-Workflow

## 3. Welche HTML-Prototyp-Funktionen wurden übernommen?

- Navigation / Module
- Fold-Layout-Idee
- Lumo-Avatar als bewegter Flutter-Placeholder
- Learning-Screen mit Antwortlogik
- 3-Fehlversuche-Erklärung
- sichere Agent-Safety-Regeln
- Recognition für Addition, Subtraktion, Zahlenreihe, Anfangsbuchstabe, Reim, Noteneintrag
- Rewards/Gutscheine mit Eltern-PIN
- Parent-Button „Warum empfiehlt Lumo das?“
- MemoryGraph/Lernbaum
- Privacy Cards und Consent-Schalter
- Idle Reaction nach 20 Sekunden

## 4. Wie wird getestet?

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --debug
```

## 5. Wo ist die APK?

GitHub Actions erzeugt das Artifact:

- Artifact: `lumo-lernen-debug-apk`
- Pfad: `build/app/outputs/flutter-apk/app-debug.apk`

## 6. Was ist noch Stub?

- echte Rive-Datei
- Premium-TTS
- echte OCR-Kamera / Google ML Kit
- Cloud-Sync
- produktive PIN-Sicherheit

## 7. Was ist schon funktionsfähig?

- Lernen mit echten Exercise-Modellen
- Antwortprüfung
- 3-Fehlversuche-Erklärung und Folgeaufgabe
- MemoryGraph mit JSON-Serialisierung und lokalem Speicheradapter
- Agent-Safety
- Recognition
- Rewards und Demo-PIN-Einlösung
- Parent Dashboard mit Warum-Erklärung
- Datenschutzfreigaben
- Foldable Layout
- sichtbarer animierter Lumo-Avatar
